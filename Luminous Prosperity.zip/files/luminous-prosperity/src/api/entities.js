import { base44 } from './base44Client';


export const Assessment = base44.entities.Assessment;

export const Team = base44.entities.Team;

export const Organization = base44.entities.Organization;

export const CEOAssessment = base44.entities.CEOAssessment;

export const OrganizationalAssessment = base44.entities.OrganizationalAssessment;

export const DepartmentAI = base44.entities.DepartmentAI;

export const OrganizationAI = base44.entities.OrganizationAI;

export const Subscription = base44.entities.Subscription;

export const OrganizationInvite = base44.entities.OrganizationInvite;

export const UsageMetrics = base44.entities.UsageMetrics;

export const TeamAssessmentCampaign = base44.entities.TeamAssessmentCampaign;

export const PredictiveInsight = base44.entities.PredictiveInsight;

export const Skill = base44.entities.Skill;

export const RoleSkillRequirement = base44.entities.RoleSkillRequirement;

export const UserSkill = base44.entities.UserSkill;

export const SkillDevelopmentPath = base44.entities.SkillDevelopmentPath;

export const ResourceAllocationStrategy = base44.entities.ResourceAllocationStrategy;

export const DataAccessLog = base44.entities.DataAccessLog;

export const LearningJourney = base44.entities.LearningJourney;

export const StrategicClarity = base44.entities.StrategicClarity;

export const LeadershipEvolution = base44.entities.LeadershipEvolution;

export const WellnessLog = base44.entities.WellnessLog;

export const WellnessIntervention = base44.entities.WellnessIntervention;

export const UserWellnessPlan = base44.entities.UserWellnessPlan;

export const ImpactUnitDefinition = base44.entities.ImpactUnitDefinition;

export const ContributionRecord = base44.entities.ContributionRecord;

export const ImpactAggregate = base44.entities.ImpactAggregate;

export const EcosystemConnection = base44.entities.EcosystemConnection;

export const SharedChallenge = base44.entities.SharedChallenge;

export const CollaborativeProject = base44.entities.CollaborativeProject;

export const CollaborativeWorkflow = base44.entities.CollaborativeWorkflow;

export const CustomReport = base44.entities.CustomReport;

export const AIInsightAggregate = base44.entities.AIInsightAggregate;

export const EcosystemOpportunityReport = base44.entities.EcosystemOpportunityReport;

export const KnowledgeBaseArticle = base44.entities.KnowledgeBaseArticle;

export const SynthesizedKnowledge = base44.entities.SynthesizedKnowledge;

export const PartnerOutreach = base44.entities.PartnerOutreach;

export const ChallengeSolution = base44.entities.ChallengeSolution;

export const CollaborativeProjectAI = base44.entities.CollaborativeProjectAI;

export const PartnerFeedback = base44.entities.PartnerFeedback;

export const SkillGapAudit = base44.entities.SkillGapAudit;

export const PlatformUsageAnalytics = base44.entities.PlatformUsageAnalytics;

export const CoachingSession = base44.entities.CoachingSession;

export const PerformanceReview = base44.entities.PerformanceReview;



// auth sdk:
export const User = base44.auth;