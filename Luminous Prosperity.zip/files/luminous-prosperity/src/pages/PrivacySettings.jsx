import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Shield, Eye, EyeOff, Users, Lock, CheckCircle2, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function PrivacySettings() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const [settings, setSettings] = useState({
    allow_manager_view_assessment: user?.privacy_settings?.allow_manager_view_assessment || false,
    allow_executive_view_anonymized: user?.privacy_settings?.allow_executive_view_anonymized ?? true,
    share_with_team_insights: user?.privacy_settings?.share_with_team_insights ?? true,
    visible_to_hr: user?.privacy_settings?.visible_to_hr ?? true,
  });

  React.useEffect(() => {
    if (user?.privacy_settings) {
      setSettings({
        allow_manager_view_assessment: user.privacy_settings.allow_manager_view_assessment || false,
        allow_executive_view_anonymized: user.privacy_settings.allow_executive_view_anonymized ?? true,
        share_with_team_insights: user.privacy_settings.share_with_team_insights ?? true,
        visible_to_hr: user.privacy_settings.visible_to_hr ?? true,
      });
    }
  }, [user]);

  const updateSettingsMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const handleSave = async () => {
    try {
      await updateSettingsMutation.mutateAsync({
        privacy_settings: settings,
      });
      alert("Privacy settings updated successfully!");
    } catch (error) {
      console.error("Error updating privacy settings:", error);
      alert("Error updating settings. Please try again.");
    }
  };

  const handleToggle = (key) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Privacy & Data Settings</h1>
              <p className="text-gray-600">Control who can see your assessment data</p>
            </div>
          </div>
        </div>

        <Alert className="mb-6 border-blue-200 bg-blue-50">
          <Info className="w-4 h-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Your data is protected:</strong> By default, your personal assessment data is private. 
            Only aggregated, anonymized insights are shared with leadership. You control who sees your detailed information.
          </AlertDescription>
        </Alert>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Data Sharing Preferences</CardTitle>
            <CardDescription>Choose what information to share and with whom</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Manager Access */}
            <div className="flex items-start justify-between pb-4 border-b">
              <div className="flex-1 mr-4">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-semibold text-gray-900">Direct Manager Access</h3>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Allow your direct manager to view your complete assessment results and personal insights
                </p>
                <Badge variant="outline" className="text-xs">
                  {user?.manager_email ? `Manager: ${user.manager_email}` : 'No manager assigned'}
                </Badge>
              </div>
              <Switch
                checked={settings.allow_manager_view_assessment}
                onCheckedChange={() => handleToggle('allow_manager_view_assessment')}
              />
            </div>

            {/* Executive Access */}
            <div className="flex items-start justify-between pb-4 border-b">
              <div className="flex-1 mr-4">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold text-gray-900">Executive Anonymized Access</h3>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Allow executives to view your data in anonymized form (no name, only Employee ID) 
                  for strategic planning
                </p>
                <Badge className="bg-green-600 text-xs">Recommended</Badge>
              </div>
              <Switch
                checked={settings.allow_executive_view_anonymized}
                onCheckedChange={() => handleToggle('allow_executive_view_anonymized')}
              />
            </div>

            {/* Team Insights */}
            <div className="flex items-start justify-between pb-4 border-b">
              <div className="flex-1 mr-4">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <h3 className="font-semibold text-gray-900">Team Aggregation</h3>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Include your assessment data in team-level aggregations and insights 
                  (your individual data is not identifiable)
                </p>
                <Badge className="bg-green-600 text-xs">Recommended</Badge>
              </div>
              <Switch
                checked={settings.share_with_team_insights}
                onCheckedChange={() => handleToggle('share_with_team_insights')}
              />
            </div>

            {/* HR Access */}
            <div className="flex items-start justify-between pb-4">
              <div className="flex-1 mr-4">
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-5 h-5 text-amber-600" />
                  <h3 className="font-semibold text-gray-900">HR & Admin Access</h3>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Allow HR and organization administrators to view your assessment data for 
                  development planning and organizational insights
                </p>
                <Badge className="bg-green-600 text-xs">Recommended</Badge>
              </div>
              <Switch
                checked={settings.visible_to_hr}
                onCheckedChange={() => handleToggle('visible_to_hr')}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>How Your Data is Protected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Automatic Anonymization</h4>
                  <p className="text-sm text-gray-600">
                    When executives view organizational analytics, your data is automatically anonymized 
                    unless you've granted specific permission
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Aggregated Reporting</h4>
                  <p className="text-sm text-gray-600">
                    Team and department insights show patterns and trends without individual attribution
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Access Logging</h4>
                  <p className="text-sm text-gray-600">
                    All data access is logged and auditable. You can request an access report at any time
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Role-Based Access</h4>
                  <p className="text-sm text-gray-600">
                    Different roles see different levels of detail. Executives see trends, managers see team patterns, 
                    and only authorized personnel see individual data
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Who Can See What</CardTitle>
            <CardDescription>Breakdown of access levels by role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">You (Employee)</span>
                  <Badge className="bg-green-600">Full Access</Badge>
                </div>
                <p className="text-xs text-gray-600">Complete access to all your assessment data, results, and reports</p>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">Your Direct Manager</span>
                  <Badge className={settings.allow_manager_view_assessment ? 'bg-blue-600' : 'bg-gray-600'}>
                    {settings.allow_manager_view_assessment ? 'Full Access' : 'No Access'}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">
                  {settings.allow_manager_view_assessment 
                    ? 'Can view your complete assessment and development plans' 
                    : 'Cannot see your individual assessment data'}
                </p>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">Executives & C-Suite</span>
                  <Badge className={settings.allow_executive_view_anonymized ? 'bg-purple-600' : 'bg-gray-600'}>
                    {settings.allow_executive_view_anonymized ? 'Anonymized' : 'No Access'}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">
                  {settings.allow_executive_view_anonymized 
                    ? 'Can see your data with Employee ID instead of your name' 
                    : 'Cannot see any of your data, even anonymized'}
                </p>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">Team Analytics</span>
                  <Badge className={settings.share_with_team_insights ? 'bg-indigo-600' : 'bg-gray-600'}>
                    {settings.share_with_team_insights ? 'Aggregated Only' : 'Excluded'}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">
                  {settings.share_with_team_insights 
                    ? 'Your data is included in team averages and patterns (not individually identifiable)' 
                    : 'Your data is excluded from all team analytics'}
                </p>
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm">HR & Org Admins</span>
                  <Badge className={settings.visible_to_hr ? 'bg-amber-600' : 'bg-gray-600'}>
                    {settings.visible_to_hr ? 'Full Access' : 'No Access'}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">
                  {settings.visible_to_hr 
                    ? 'Can view your data for development planning and support' 
                    : 'Cannot see your individual data'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3 mt-6">
          <Button variant="outline" onClick={() => window.location.reload()}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-gradient-to-r from-indigo-600 to-purple-600"
          >
            <Shield className="w-4 h-4 mr-2" />
            Save Privacy Settings
          </Button>
        </div>
      </div>
    </div>
  );
}