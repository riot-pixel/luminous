import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Sparkles, Brain, Users, Target, BarChart3, Heart, ArrowRight, CheckCircle2, Building2, TrendingUp, Award, Zap, LogIn, Shield } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (isAuth) {
          const user = await base44.auth.me();
          setIsAuthenticated(true);
          setUserEmail(user.email);
        }
      } catch (error) {
        setIsAuthenticated(false);
      }
    };
    checkAuth();
  }, []);

  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.origin);
  };

  const handleLogout = async () => {
    await base44.auth.logout();
    setIsAuthenticated(false);
    setUserEmail('');
  };

  const frameworks = [
    {
      icon: Brain,
      title: "Integral Theory",
      description: "Map consciousness across four quadrants to understand your developmental journey",
    },
    {
      icon: Users,
      title: "Extended Myers-Briggs",
      description: "Deep personality profiling with cognitive functions analysis",
    },
    {
      icon: Target,
      title: "Character Strengths",
      description: "Identify signature strengths across six virtue categories",
    },
    {
      icon: BarChart3,
      title: "Life Balance Wheel",
      description: "Evaluate satisfaction across eight key life dimensions",
    },
    {
      icon: Heart,
      title: "Appreciative Inquiry",
      description: "Design your ideal future through the 5D methodology",
    },
  ];

  const enterpriseFeatures = [
    {
      icon: Building2,
      title: "Organization-Wide Intelligence",
      description: "Aggregate insights across departments and teams for strategic decision-making"
    },
    {
      icon: TrendingUp,
      title: "Strategic Alignment",
      description: "Connect individual growth with organizational goals and market opportunities"
    },
    {
      icon: Award,
      title: "Performance Optimization",
      description: "Data-driven team composition and talent deployment strategies"
    },
  ];

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] selection:bg-white selection:text-black">
      {/* Navbar */}
      <nav className="fixed w-full z-50 glass-panel border-x-0 border-t-0 top-0">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
              alt="Luminous Prosperity" 
              className="w-10 h-10 object-contain"
            />
            <span className="text-lg tracking-[0.2em] font-light text-white uppercase">Luminous</span>
          </div>
          <div className="hidden md:flex space-x-12 text-xs text-gray-400 font-medium tracking-widest uppercase">
            <a href="#concept" className="hover:text-white transition-colors duration-300">Concept</a>
            <a href="#mechanism" className="hover:text-white transition-colors duration-300">Mechanism</a>
            <a href="#results" className="hover:text-white transition-colors duration-300">Impact</a>
          </div>
          {isAuthenticated ? (
            <div className="flex items-center gap-4">
              <span className="text-xs text-gray-400">{userEmail}</span>
              <Button 
                onClick={() => navigate('/employee-portal')}
                className="bg-white text-black px-6 py-2 text-[10px] font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm"
              >
                Dashboard
              </Button>
            </div>
          ) : (
            <Button 
              onClick={handleLogin}
              className="bg-white text-black px-8 py-3 text-[10px] font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm"
            >
              Initialize
            </Button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="concept" className="min-h-screen flex flex-col justify-center items-center text-center px-4 relative overflow-hidden pt-20">
        {/* Ambient Background Light */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-white/5 to-transparent rounded-full blur-[100px] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-5xl mx-auto">
          <div className="flex justify-center mb-12">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
              alt="Luminous Prosperity" 
              className="w-32 h-32 md:w-40 md:h-40 object-contain drop-shadow-lg fade-in-up"
            />
          </div>

          <h1 className="serif text-5xl md:text-8xl mb-8 leading-[1.1] gradient-text fade-in-up">
            Illuminate Your<br />
            <span className="italic font-light gold-gradient-text">Path to Prosperity</span>
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg md:text-xl font-light leading-relaxed mb-16 fade-in-up delay-100">
            Transform organizations through the radiant alignment of individual potential with collective vision.
            <span className="text-white"> Where every person shines and the whole thrives.</span>
          </p>
          
          <div className="flex flex-col md:flex-row justify-center gap-6 fade-in-up delay-200">
            <div className="glass-panel px-10 py-5 rounded-full flex items-center space-x-4 hover:bg-white/5 transition-colors cursor-default">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_10px_rgba(52,211,153,0.8)]"></span>
              <span className="text-[10px] tracking-[0.2em] text-gray-300 uppercase">Enterprise Intelligence</span>
            </div>
            <div className="glass-panel px-10 py-5 rounded-full flex items-center space-x-4 hover:bg-white/5 transition-colors cursor-default">
              <span className="w-1.5 h-1.5 bg-amber-400 rounded-full shadow-[0_0_10px_rgba(251,191,36,0.8)]"></span>
              <span className="text-[10px] tracking-[0.2em] text-gray-300 uppercase">AI-Powered Insights</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-16 fade-in-up delay-300">
            <Link to={createPageUrl("QuickAssessment")}>
              <Button className="bg-white text-black px-10 py-6 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm group">
                <Zap className="w-4 h-4 mr-2" />
                Quick Start (15 min)
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link to={createPageUrl("Assessment")}>
              <Button variant="outline" className="border border-white/10 text-gray-300 px-10 py-6 text-xs font-bold tracking-[0.2em] uppercase hover:bg-white/5 hover:text-white rounded-sm">
                Full Assessment
              </Button>
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 opacity-30 animate-bounce">
          <div className="w-6 h-10 border border-white/30 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-white/50 rounded-full"></div>
          </div>
        </div>
      </section>

      {/* The Mechanism Section */}
      <section id="mechanism" className="py-32 bg-black relative border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-24 text-center md:text-left">
            <span className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-4 block">The Architecture</span>
            <h2 className="text-4xl md:text-5xl font-light text-white mb-6 serif">Choose Your Assessment Path</h2>
            <div className="h-px w-24 bg-gradient-to-r from-white/50 to-transparent mx-auto md:mx-0"></div>
            <p className="mt-8 text-gray-400 max-w-lg leading-relaxed font-light">
              Both deliver comprehensive insights powered by AI. Pick what works for your schedule.
            </p>
          </div>

          {/* The Flow Visualization */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-center text-center relative">
            
            {/* Connector Line (Desktop) */}
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent -z-10"></div>

            {/* Quick Assessment */}
            <div className="group">
              <div className="p-10 border border-white/5 bg-black rounded-3xl hover:bg-white/5 transition duration-700 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-600 to-emerald-400 opacity-0 group-hover:opacity-100 transition duration-700"></div>
                <Zap className="w-12 h-12 text-emerald-400 mx-auto mb-6" />
                <div className="text-gray-500 text-[10px] tracking-[0.2em] uppercase mb-4">15-20 Minutes</div>
                <div className="text-2xl serif text-white mb-4 group-hover:scale-105 transition-transform duration-500">Quick Assessment</div>
                <p className="text-sm text-gray-500 font-light mb-6">
                  Simple, behavioral questions.<br />Same powerful AI insights.
                </p>
                <ul className="text-left space-y-2 mb-6">
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Scenario-based questions</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>No deep reflection required</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Perfect for quick rollout</span>
                  </li>
                </ul>
                <Link to={createPageUrl("QuickAssessment")}>
                  <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-bold text-xs tracking-widest uppercase py-4">
                    Start Quick
                  </Button>
                </Link>
              </div>
            </div>

            {/* Process (The Core) */}
            <div className="relative">
              <div className="relative p-12 glow-box rounded-full border border-white/10 bg-black flex flex-col items-center justify-center aspect-square z-10">
                <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent rounded-full pointer-events-none"></div>
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
                  alt="Luminous Core" 
                  className="w-16 h-16 object-contain mb-4"
                />
                <div className="text-[10px] text-emerald-400 tracking-[0.2em] uppercase mb-3">Luminous Core</div>
                <div className="text-4xl font-thin text-white mb-3">AI</div>
                <div className="text-[10px] text-gray-400 tracking-wider uppercase">Intelligence Engine</div>
              </div>
              {/* Orbiting ring */}
              <div className="absolute inset-0 rounded-full border border-white/5 animate-[spin_20s_linear_infinite]"></div>
            </div>

            {/* Comprehensive Assessment */}
            <div className="group">
              <div className="p-10 border border-white/5 bg-black rounded-3xl hover:bg-white/5 transition duration-700 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-200 to-amber-600 opacity-0 group-hover:opacity-100 transition duration-700"></div>
                <Brain className="w-12 h-12 text-amber-400 mx-auto mb-6" />
                <div className="text-gray-500 text-[10px] tracking-[0.2em] uppercase mb-4">45-60 Minutes</div>
                <div className="text-2xl serif text-white mb-4 group-hover:scale-105 transition-transform duration-500">Comprehensive</div>
                <p className="text-sm text-gray-500 font-light mb-6">
                  Deep psychological frameworks.<br />Maximum developmental insights.
                </p>
                <ul className="text-left space-y-2 mb-6">
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Integral Theory framework</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Reflective questions</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-gray-400">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Leadership development</span>
                  </li>
                </ul>
                <Link to={createPageUrl("Assessment")}>
                  <Button className="w-full bg-transparent border border-amber-400/50 text-amber-400 hover:bg-amber-400/10 font-bold text-xs tracking-widest uppercase py-4">
                    Start Full
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enterprise Features Section */}
      <section id="results" className="py-32 bg-[#050505] relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <span className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-4 block">Enterprise Platform</span>
            <h2 className="text-4xl md:text-5xl font-light text-white mb-6 serif">Luminous Intelligence Architecture</h2>
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-white/50 to-transparent mx-auto"></div>
            <p className="mt-8 text-gray-400 max-w-2xl mx-auto leading-relaxed font-light">
              Move beyond assessment to organizational enlightenment—where data becomes wisdom and potential becomes prosperity
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {enterpriseFeatures.map((feature, index) => (
              <div key={index} className="group p-10 border border-white/5 bg-black rounded-3xl hover:bg-white/5 transition duration-700 relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-full h-1 opacity-0 group-hover:opacity-100 transition duration-700 ${
                  index === 0 ? 'bg-gradient-to-r from-white to-gray-400' :
                  index === 1 ? 'bg-gradient-to-r from-amber-400 to-amber-600' :
                  'bg-gradient-to-r from-emerald-400 to-emerald-600'
                }`}></div>
                <feature.icon className={`w-12 h-12 mx-auto mb-6 ${
                  index === 0 ? 'text-white' :
                  index === 1 ? 'text-amber-400' :
                  'text-emerald-400'
                }`} />
                <h3 className="text-xl serif text-white mb-4 text-center">{feature.title}</h3>
                <p className="text-sm text-gray-500 font-light text-center leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>

          {/* Frameworks Grid */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-5 gap-4">
            {frameworks.map((framework, index) => (
              <div key={index} className="glass-panel p-6 rounded-2xl text-center hover:bg-white/5 transition-all duration-300">
                <framework.icon className="w-8 h-8 text-gray-400 mx-auto mb-3" />
                <p className="text-xs text-gray-500 font-medium">{framework.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer / CTA */}
      <section className="py-40 flex flex-col items-center text-center px-6 relative overflow-hidden bg-black border-t border-white/5">
        {/* Background Glow */}
        <div className="absolute bottom-0 w-full h-[500px] bg-gradient-to-t from-white/5 to-transparent pointer-events-none"></div>

        <div className="relative z-10">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
            alt="Luminous Prosperity" 
            className="w-24 h-24 object-contain mx-auto mb-10"
          />
          <h2 className="serif text-5xl md:text-7xl text-white mb-10 tracking-tight">
            Ready to Ignite<br />
            <span className="gold-gradient-text italic">Organizational Brilliance?</span>
          </h2>
          <p className="text-gray-500 mb-8 font-light text-lg max-w-2xl mx-auto">
            Join visionary enterprises creating cultures where prosperity flows from purpose, and every individual illuminates the path forward
          </p>
          <div className="mb-16 glass-panel inline-block px-8 py-4 rounded-2xl">
            <span className="text-3xl font-light text-white">$100</span>
            <span className="text-gray-400 text-sm">/user/month</span>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link to={createPageUrl("QuickAssessment")}>
              <Button className="group relative px-12 py-6 bg-white text-black text-xs font-bold tracking-[0.25em] uppercase overflow-hidden transition-all hover:pr-16 rounded-sm">
                <span className="relative z-10">Initialize System</span>
                <ArrowRight className="absolute right-6 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 w-4 h-4" />
              </Button>
            </Link>
            {!isAuthenticated && (
              <Button 
                onClick={handleLogin}
                variant="outline"
                className="px-12 py-6 border border-white/10 text-gray-400 text-xs font-bold tracking-[0.25em] uppercase hover:bg-white/5 hover:text-white rounded-sm"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            )}
          </div>

          <div className="mt-32 flex flex-col md:flex-row items-center gap-8 text-[10px] text-gray-600 font-mono tracking-widest uppercase">
            <span>Luminous Prosperity © 2025</span>
            <span className="hidden md:inline">•</span>
            <span>Status: Operational</span>
            <span className="hidden md:inline">•</span>
            <span>Enterprise Intelligence Platform</span>
          </div>
        </div>
      </section>
    </div>
  );
}