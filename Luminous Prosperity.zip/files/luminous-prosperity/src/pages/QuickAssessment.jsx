import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import QuickIntegralSection from "../components/quick-assessment/QuickIntegralSection";
import QuickPersonalitySection from "../components/quick-assessment/QuickPersonalitySection";
import QuickStrengthsSection from "../components/quick-assessment/QuickStrengthsSection";
import QuickLifeBalanceSection from "../components/quick-assessment/QuickLifeBalanceSection";
import QuickAspirationSection from "../components/quick-assessment/QuickAspirationSection";
import QuickDepartmentSection from "../components/quick-assessment/QuickDepartmentSection";
import ProgressTracker from "../components/assessment/ProgressTracker";

export default function QuickAssessment() {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  
  const [assessmentData, setAssessmentData] = useState({
    integral: null,
    personality: null,
    strengths: null,
    lifeBalance: null,
    aspirations: null,
    department: null,
  });

  useEffect(() => {
    const loadUserInfo = async () => {
      try {
        const user = await base44.auth.me();
        setUserInfo(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUserInfo();
  }, []);

  const sections = [
    { name: "How You Work", key: "integral", component: QuickIntegralSection },
    { name: "Your Style", key: "personality", component: QuickPersonalitySection },
    { name: "Your Strengths", key: "strengths", component: QuickStrengthsSection },
    { name: "Life Balance", key: "lifeBalance", component: QuickLifeBalanceSection },
    { name: "Your Vision", key: "aspirations", component: QuickAspirationSection },
    { name: "Team Contribution", key: "department", component: QuickDepartmentSection },
  ];

  const CurrentSectionComponent = sections[currentSection].component;

  const handleSectionComplete = (data) => {
    const key = sections[currentSection].key;
    setAssessmentData(prev => ({
      ...prev,
      [key]: data,
    }));

    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      completeAssessment({
        ...assessmentData,
        [key]: data,
      });
    }
  };

  const completeAssessment = async (finalData) => {
    setIsProcessing(true);
    try {
      const user = await base44.auth.me();
      
      // Use AI to analyze all responses and generate structured assessment data
      const analysisPrompt = `You are an expert organizational psychologist. Analyze these open-ended responses and generate a comprehensive psychological profile.

RESPONSES:

HOW THEY WORK:
${JSON.stringify(finalData.integral.responses, null, 2)}

THEIR STYLE:
${JSON.stringify(finalData.personality.responses, null, 2)}

THEIR STRENGTHS:
${JSON.stringify(finalData.strengths.responses, null, 2)}

LIFE BALANCE:
${JSON.stringify(finalData.lifeBalance.responses, null, 2)}

ASPIRATIONS:
${JSON.stringify(finalData.aspirations.responses, null, 2)}

DEPARTMENT INSIGHTS:
${JSON.stringify(finalData.department.responses, null, 2)}

Generate a complete psychological profile with:
1. MBTI personality type and cognitive functions
2. Top 5 character strengths with scores
3. Integral theory quadrant analysis
4. Life balance scores across 8 areas
5. Appreciative inquiry 5D framework
6. Departmental contribution insights`;

      const structuredProfile = await base44.integrations.Core.InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            myers_briggs: {
              type: "object",
              properties: {
                type: { type: "string" },
                cognitive_functions: { type: "array", items: { type: "string" } }
              }
            },
            integral_theory: {
              type: "object",
              properties: {
                quadrants: {
                  type: "object",
                  properties: {
                    individual_interior: { type: "number" },
                    individual_exterior: { type: "number" },
                    collective_interior: { type: "number" },
                    collective_exterior: { type: "number" }
                  }
                },
                levels: { type: "array", items: { type: "string" } },
                primary_line: { type: "string" }
              }
            },
            strengths: {
              type: "object",
              properties: {
                top_strengths: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      category: { type: "string" },
                      score: { type: "number" }
                    }
                  }
                },
                strength_categories: {
                  type: "object",
                  properties: {
                    wisdom: { type: "number" },
                    courage: { type: "number" },
                    humanity: { type: "number" },
                    justice: { type: "number" },
                    temperance: { type: "number" },
                    transcendence: { type: "number" }
                  }
                }
              }
            },
            life_wheel: {
              type: "object",
              properties: {
                career: { type: "number" },
                finances: { type: "number" },
                health: { type: "number" },
                relationships: { type: "number" },
                personal: { type: "number" },
                fun: { type: "number" },
                contribution: { type: "number" },
                environment: { type: "number" },
                overall_satisfaction: { type: "number" }
              }
            },
            appreciative_inquiry: {
              type: "object",
              properties: {
                define: {
                  type: "object",
                  properties: {
                    core_topic: { type: "string" },
                    focus_area: { type: "string" }
                  }
                },
                discover: {
                  type: "object",
                  properties: {
                    peak_experiences: { type: "array", items: { type: "string" } },
                    core_values: { type: "array", items: { type: "string" } }
                  }
                },
                dream: {
                  type: "object",
                  properties: {
                    aspirations: { type: "array", items: { type: "string" } },
                    ideal_future: { type: "string" }
                  }
                },
                design: {
                  type: "object",
                  properties: {
                    action_commitments: { type: "array", items: { type: "string" } }
                  }
                },
                destiny: {
                  type: "object",
                  properties: {
                    next_steps: { type: "array", items: { type: "string" } }
                  }
                }
              }
            },
            departmental_ai: {
              type: "object",
              properties: {
                department_strengths: { type: "array", items: { type: "string" } },
                department_aspirations: { type: "array", items: { type: "string" } },
                cross_team_collaboration: { type: "string" },
                contribution_vision: { type: "string" }
              }
            }
          }
        }
      });

      // Generate personalized insights
      const insights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert career coach providing warm, actionable insights.

Based on this person's responses, provide encouraging, personalized insights (350-400 words):

THEIR RESPONSES:
${JSON.stringify({
  work: finalData.integral.responses,
  style: finalData.personality.responses,
  strengths: finalData.strengths.responses,
  balance: finalData.lifeBalance.responses,
  vision: finalData.aspirations.responses,
  contribution: finalData.department.responses
}, null, 2)}

THEIR PROFILE:
${JSON.stringify(structuredProfile, null, 2)}

CONTEXT:
Department: ${user.department || 'Not specified'}
Role: ${user.job_title || 'Not specified'}

Provide insights on:
1. Their natural work style and how to leverage it
2. Key strengths and how to use them daily
3. Opportunities for growth aligned with their vision
4. How they can contribute most effectively
5. Practical next steps for success
6. Alignment between personal goals and organizational needs

Write in a warm, encouraging, conversational tone. Be specific and actionable.`,
      });

      await base44.entities.Assessment.create({
        user_email: user.email,
        department: user.department,
        role: user.job_title,
        completed_date: new Date().toISOString(),
        integral_theory: structuredProfile.integral_theory,
        myers_briggs: structuredProfile.myers_briggs,
        strengths: structuredProfile.strengths,
        life_wheel: structuredProfile.life_wheel,
        appreciative_inquiry: structuredProfile.appreciative_inquiry,
        departmental_ai: structuredProfile.departmental_ai,
        overall_insights: insights,
      });

      navigate(createPageUrl("Results"));
    } catch (error) {
      console.error("Error saving assessment:", error);
      alert("There was an error processing your assessment. Please try again.");
    }
    setIsProcessing(false);
  };

  const handleBack = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <ProgressTracker 
          sections={sections.map(s => s.name)} 
          currentSection={currentSection}
          completedSections={Object.keys(assessmentData).filter(k => assessmentData[k] !== null).length}
        />

        <div className="mt-12">
          <CurrentSectionComponent
            onComplete={handleSectionComplete}
            onBack={currentSection > 0 ? handleBack : null}
            initialData={assessmentData[sections[currentSection].key]}
            isProcessing={isProcessing}
            userDepartment={userInfo?.department || 'Your Department'}
            userRole={userInfo?.job_title || 'Your Role'}
          />
        </div>
      </div>
    </div>
  );
}