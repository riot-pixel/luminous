import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Sparkles, Brain, Anchor, Zap, Compass, Users, MessageSquare,
  Target, Rocket, Star, RefreshCw, Heart, Shield, Scale,
  CheckCircle2, AlertTriangle, TrendingUp, Clock
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import LeadershipProfileCard from "../components/leadership/LeadershipProfileCard";
import EvolutionRoadmap from "../components/leadership/EvolutionRoadmap";
import FutureSelfVision from "../components/leadership/FutureSelfVision";
import WeeklyPractices from "../components/leadership/WeeklyPractices";

export default function LeadershipEvolution() {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingPhase, setGeneratingPhase] = useState("");
  const [isInputDialogOpen, setIsInputDialogOpen] = useState(false);
  const [leaderContext, setLeaderContext] = useState({
    currentChallenges: "",
    energyDrains: "",
    aspirations: "",
    teamDynamics: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments } = useQuery({
    queryKey: ['myAssessments'],
    queryFn: async () => {
      const u = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: u.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: ceoAssessments } = useQuery({
    queryKey: ['myCEOAssessments'],
    queryFn: async () => {
      const u = await base44.auth.me();
      return base44.entities.CEOAssessment.filter({ user_email: u.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: existingEvolution } = useQuery({
    queryKey: ['myLeadershipEvolution'],
    queryFn: async () => {
      const u = await base44.auth.me();
      return base44.entities.LeadershipEvolution.filter({ user_email: u.email }, '-created_date');
    },
    initialData: [],
  });

  const createEvolutionMutation = useMutation({
    mutationFn: (data) => base44.entities.LeadershipEvolution.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['myLeadershipEvolution'] }),
  });

  const updateEvolutionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LeadershipEvolution.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['myLeadershipEvolution'] }),
  });

  const latestAssessment = assessments[0];
  const latestCEOAssessment = ceoAssessments[0];
  const currentEvolution = existingEvolution[0];

  const stageConfig = {
    reactive: { label: "Reactive", color: "bg-red-500", description: "Operating from urgency and adrenaline" },
    proactive: { label: "Proactive", color: "bg-orange-500", description: "Anticipating and planning ahead" },
    creative: { label: "Creative", color: "bg-yellow-500", description: "Generating novel solutions" },
    integral: { label: "Integral", color: "bg-blue-500", description: "Seeing the whole system" },
    generative: { label: "Generative", color: "bg-purple-500", description: "Creating conditions for emergence" }
  };

  const generateEvolution = async () => {
    setIsGenerating(true);
    setIsInputDialogOpen(false);

    try {
      // Phase 1: Leadership Profile Analysis
      setGeneratingPhase("Analyzing leadership patterns and thinking clarity...");
      const profileAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a world-class executive coach specializing in meta-leadership transformation.

LEADER CONTEXT:
- Name: ${user?.full_name}
- Role: ${user?.job_title || 'Executive'}
- Personality Type: ${latestAssessment?.myers_briggs?.type || 'Unknown'}
- Top Strengths: ${latestAssessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ') || 'Unknown'}
- Life Satisfaction: ${latestAssessment?.life_wheel?.overall_satisfaction || 'Unknown'}%
- Career Satisfaction: ${(latestAssessment?.life_wheel?.career || 0) * 10}%
- Leadership Style: ${latestCEOAssessment?.leadership_style?.primary_style || 'Unknown'}
- Current Challenges: ${leaderContext.currentChallenges || 'Growth and scaling'}
- Energy Drains: ${leaderContext.energyDrains || 'Decision fatigue, meetings'}
- Aspirations: ${leaderContext.aspirations || 'Visionary leadership'}
- Team Dynamics: ${leaderContext.teamDynamics || 'Growing team'}

Analyze their leadership profile across four dimensions:
1. THINKING CLARITY: How clear, focused, and strategic is their thinking?
2. GROUNDEDNESS: Do they operate from calm presence or reactive stress?
3. LEVERAGE MASTERY: Are they doing high-leverage work or getting drained?
4. VISION ALIGNMENT: Are daily actions aligned to their north star?

For each dimension, provide:
- Current score (0-100)
- Observable patterns
- Blockers preventing growth
- Unlocks that would transform this dimension`,
        response_json_schema: {
          type: "object",
          properties: {
            current_stage: { type: "string" },
            thinking_clarity: {
              type: "object",
              properties: {
                score: { type: "number" },
                patterns: { type: "array", items: { type: "string" } },
                blockers: { type: "array", items: { type: "string" } },
                unlocks: { type: "array", items: { type: "string" } }
              }
            },
            groundedness: {
              type: "object",
              properties: {
                score: { type: "number" },
                stressors: { type: "array", items: { type: "string" } },
                anchors: { type: "array", items: { type: "string" } },
                practices: { type: "array", items: { type: "string" } }
              }
            },
            leverage_mastery: {
              type: "object",
              properties: {
                score: { type: "number" },
                high_leverage_activities: { type: "array", items: { type: "string" } },
                energy_drains: { type: "array", items: { type: "string" } },
                delegation_opportunities: { type: "array", items: { type: "string" } }
              }
            },
            vision_alignment: {
              type: "object",
              properties: {
                score: { type: "number" },
                north_star_clarity: { type: "string" },
                alignment_gaps: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      // Phase 2: Communication & Decision Patterns
      setGeneratingPhase("Mapping communication and decision patterns...");
      const patternsAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this leader's profile, analyze their communication and decision-making patterns:

LEADER PROFILE:
- Personality: ${latestAssessment?.myers_briggs?.type}
- Strengths: ${latestAssessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ')}
- Current Stage: ${profileAnalysis.current_stage}
- Team Dynamics: ${leaderContext.teamDynamics}

Analyze:
1. COMMUNICATION PATTERNS
- Natural style
- Strengths
- Blind spots
- How team dynamics are affected
- Upgrade path for better communication

2. DECISION PATTERNS
- Natural style
- Energy cost of decisions
- Bottlenecks
- How to streamline`,
        response_json_schema: {
          type: "object",
          properties: {
            communication_patterns: {
              type: "object",
              properties: {
                style: { type: "string" },
                strengths: { type: "array", items: { type: "string" } },
                blind_spots: { type: "array", items: { type: "string" } },
                team_dynamics: { type: "array", items: { type: "string" } },
                upgrade_path: { type: "array", items: { type: "string" } }
              }
            },
            decision_patterns: {
              type: "object",
              properties: {
                style: { type: "string" },
                energy_cost: { type: "string" },
                bottlenecks: { type: "array", items: { type: "string" } },
                streamline_opportunities: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      // Phase 3: Future Self & Evolution Roadmap
      setGeneratingPhase("Creating your future self vision and evolution roadmap...");
      const evolutionPlan = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a leadership evolution plan to transform this leader from reactive to generative:

CURRENT STATE:
- Stage: ${profileAnalysis.current_stage}
- Thinking Clarity: ${profileAnalysis.thinking_clarity?.score}%
- Groundedness: ${profileAnalysis.groundedness?.score}%
- Leverage Mastery: ${profileAnalysis.leverage_mastery?.score}%
- Vision Alignment: ${profileAnalysis.vision_alignment?.score}%
- Aspirations: ${leaderContext.aspirations}

Create:
1. FUTURE SELF PROFILE
- Vision of who they become
- Key shifts required
- Capabilities to develop
- Mindset upgrades needed

2. EVOLUTION ROADMAP (3-4 phases over 12 months)
- Phase name and duration
- Focus area
- Key practices
- Milestones

3. WEEKLY PRACTICES (5-7 rituals)
- Practice name
- Frequency
- Duration
- Purpose

Make this transformation feel inevitable, not aspirational.`,
        response_json_schema: {
          type: "object",
          properties: {
            future_self_profile: {
              type: "object",
              properties: {
                vision: { type: "string" },
                key_shifts: { type: "array", items: { type: "string" } },
                capabilities_to_develop: { type: "array", items: { type: "string" } },
                mindset_upgrades: { type: "array", items: { type: "string" } }
              }
            },
            evolution_roadmap: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  phase: { type: "string" },
                  duration: { type: "string" },
                  focus: { type: "string" },
                  practices: { type: "array", items: { type: "string" } },
                  milestones: { type: "array", items: { type: "string" } }
                }
              }
            },
            weekly_practices: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  practice: { type: "string" },
                  frequency: { type: "string" },
                  duration: { type: "string" },
                  purpose: { type: "string" }
                }
              }
            },
            ai_insights: { type: "string" }
          }
        }
      });

      // Combine all data
      const fullEvolutionData = {
        user_email: user.email,
        evolution_stage: profileAnalysis.current_stage,
        leadership_profile: {
          thinking_clarity: profileAnalysis.thinking_clarity,
          groundedness: profileAnalysis.groundedness,
          leverage_mastery: profileAnalysis.leverage_mastery,
          vision_alignment: profileAnalysis.vision_alignment
        },
        communication_patterns: patternsAnalysis.communication_patterns,
        decision_patterns: patternsAnalysis.decision_patterns,
        future_self_profile: evolutionPlan.future_self_profile,
        evolution_roadmap: evolutionPlan.evolution_roadmap,
        weekly_practices: evolutionPlan.weekly_practices,
        ai_insights: evolutionPlan.ai_insights,
        last_updated: new Date().toISOString()
      };

      if (currentEvolution) {
        await updateEvolutionMutation.mutateAsync({ id: currentEvolution.id, data: fullEvolutionData });
      } else {
        await createEvolutionMutation.mutateAsync(fullEvolutionData);
      }

      setGeneratingPhase("");
    } catch (error) {
      console.error("Error generating evolution:", error);
      setGeneratingPhase("");
    }

    setIsGenerating(false);
  };

  const currentStage = currentEvolution?.evolution_stage || "reactive";
  const currentConfig = stageConfig[currentStage];

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Leadership Evolution</h1>
            <p className="text-gray-500">Transform from reactive to generative leadership</p>
          </div>
          <Dialog open={isInputDialogOpen} onOpenChange={setIsInputDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                <Sparkles className="w-4 h-4 mr-2" />
                {currentEvolution ? "Refresh Analysis" : "Begin Evolution"}
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-white/10 text-white max-w-lg">
              <DialogHeader>
                <DialogTitle className="text-white">Leadership Evolution Analysis</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label className="text-gray-400">Current Challenges</Label>
                  <Textarea
                    value={leaderContext.currentChallenges}
                    onChange={(e) => setLeaderContext({...leaderContext, currentChallenges: e.target.value})}
                    placeholder="What leadership challenges are you facing?"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Energy Drains</Label>
                  <Textarea
                    value={leaderContext.energyDrains}
                    onChange={(e) => setLeaderContext({...leaderContext, energyDrains: e.target.value})}
                    placeholder="What drains your energy as a leader?"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Leadership Aspirations</Label>
                  <Textarea
                    value={leaderContext.aspirations}
                    onChange={(e) => setLeaderContext({...leaderContext, aspirations: e.target.value})}
                    placeholder="What kind of leader do you want to become?"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Team Dynamics</Label>
                  <Textarea
                    value={leaderContext.teamDynamics}
                    onChange={(e) => setLeaderContext({...leaderContext, teamDynamics: e.target.value})}
                    placeholder="Describe your team and communication patterns"
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <Button 
                  onClick={generateEvolution}
                  className="w-full bg-gradient-to-r from-purple-500 to-blue-500"
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                  ) : (
                    <><Brain className="w-4 h-4 mr-2" /> Generate Evolution Plan</>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Generation Progress */}
        <AnimatePresence>
          {isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <Card className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 border-purple-500/30">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                      <Brain className="w-6 h-6 text-purple-400 animate-pulse" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Analyzing Leadership Evolution</p>
                      <p className="text-purple-400 text-sm">{generatingPhase}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {currentEvolution ? (
          <>
            {/* Current Stage Banner */}
            <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-purple-500/20 via-blue-500/10 to-emerald-500/20 border border-purple-500/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-xl ${currentConfig.color} flex items-center justify-center`}>
                    <Rocket className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Current Evolution Stage</p>
                    <h2 className="text-2xl font-light text-white">{currentConfig.label}</h2>
                    <p className="text-sm text-gray-400">{currentConfig.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">Last Updated</p>
                  <p className="text-white">{new Date(currentEvolution.last_updated).toLocaleDateString()}</p>
                </div>
              </div>
            </div>

            {/* Main Tabs */}
            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList className="glass-panel p-1 rounded-xl">
                <TabsTrigger value="profile" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                  <Brain className="w-4 h-4 mr-2" /> Leadership Profile
                </TabsTrigger>
                <TabsTrigger value="communication" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                  <MessageSquare className="w-4 h-4 mr-2" /> Communication
                </TabsTrigger>
                <TabsTrigger value="future" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                  <Star className="w-4 h-4 mr-2" /> Future Self
                </TabsTrigger>
                <TabsTrigger value="roadmap" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                  <Rocket className="w-4 h-4 mr-2" /> Roadmap
                </TabsTrigger>
                <TabsTrigger value="practices" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                  <Target className="w-4 h-4 mr-2" /> Practices
                </TabsTrigger>
              </TabsList>

              <TabsContent value="profile">
                <LeadershipProfileCard profile={currentEvolution.leadership_profile} />
              </TabsContent>

              <TabsContent value="communication">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Communication Patterns */}
                  <Card className="bg-white/5 border-white/10">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <MessageSquare className="w-5 h-5 text-blue-400" />
                        Communication Style
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                        <p className="text-xs text-blue-400 uppercase mb-1">Style</p>
                        <p className="text-white">{currentEvolution.communication_patterns?.style}</p>
                      </div>
                      {currentEvolution.communication_patterns?.strengths?.length > 0 && (
                        <div>
                          <p className="text-xs text-emerald-400 uppercase mb-2">Strengths</p>
                          <div className="space-y-1">
                            {currentEvolution.communication_patterns.strengths.map((s, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm text-emerald-300">
                                <CheckCircle2 className="w-3 h-3" /> {s}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {currentEvolution.communication_patterns?.blind_spots?.length > 0 && (
                        <div>
                          <p className="text-xs text-orange-400 uppercase mb-2">Blind Spots</p>
                          <div className="space-y-1">
                            {currentEvolution.communication_patterns.blind_spots.map((b, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm text-orange-300">
                                <AlertTriangle className="w-3 h-3" /> {b}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {currentEvolution.communication_patterns?.upgrade_path?.length > 0 && (
                        <div>
                          <p className="text-xs text-purple-400 uppercase mb-2">Upgrade Path</p>
                          <div className="space-y-1">
                            {currentEvolution.communication_patterns.upgrade_path.map((u, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm text-purple-300">
                                <TrendingUp className="w-3 h-3" /> {u}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Decision Patterns */}
                  <Card className="bg-white/5 border-white/10">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-white">
                        <Scale className="w-5 h-5 text-amber-400" />
                        Decision Making
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
                        <p className="text-xs text-amber-400 uppercase mb-1">Style</p>
                        <p className="text-white">{currentEvolution.decision_patterns?.style}</p>
                      </div>
                      <div className="p-3 bg-white/5 rounded-lg">
                        <p className="text-xs text-gray-500 uppercase mb-1">Energy Cost</p>
                        <p className="text-gray-300">{currentEvolution.decision_patterns?.energy_cost}</p>
                      </div>
                      {currentEvolution.decision_patterns?.bottlenecks?.length > 0 && (
                        <div>
                          <p className="text-xs text-red-400 uppercase mb-2">Bottlenecks</p>
                          <div className="space-y-1">
                            {currentEvolution.decision_patterns.bottlenecks.map((b, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm text-red-300">
                                <AlertTriangle className="w-3 h-3" /> {b}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {currentEvolution.decision_patterns?.streamline_opportunities?.length > 0 && (
                        <div>
                          <p className="text-xs text-emerald-400 uppercase mb-2">Streamline</p>
                          <div className="space-y-1">
                            {currentEvolution.decision_patterns.streamline_opportunities.map((s, i) => (
                              <div key={i} className="flex items-center gap-2 text-sm text-emerald-300">
                                <Zap className="w-3 h-3" /> {s}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="future">
                <FutureSelfVision 
                  futureProfile={currentEvolution.future_self_profile}
                  currentStage={currentEvolution.evolution_stage}
                />
              </TabsContent>

              <TabsContent value="roadmap">
                <EvolutionRoadmap 
                  roadmap={currentEvolution.evolution_roadmap}
                  currentStage={currentEvolution.evolution_stage}
                />
              </TabsContent>

              <TabsContent value="practices">
                <WeeklyPractices practices={currentEvolution.weekly_practices} />
              </TabsContent>
            </Tabs>

            {/* AI Insights */}
            {currentEvolution.ai_insights && (
              <Card className="mt-6 bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-xs text-purple-400 uppercase tracking-widest mb-2">AI Coach Insight</p>
                      <p className="text-gray-300 leading-relaxed">{currentEvolution.ai_insights}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        ) : (
          /* Empty State */
          <div className="glass-panel rounded-3xl p-16 text-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex items-center justify-center mx-auto mb-8">
              <Rocket className="w-12 h-12 text-purple-400" />
            </div>
            <h2 className="text-3xl font-light text-white mb-4 serif">Begin Your Leadership Evolution</h2>
            <p className="text-gray-500 max-w-xl mx-auto mb-8">
              Transform from reactive adrenaline-driven leadership to generative, 
              vision-aligned leadership. Think clearer, communicate better, and make decisions that energize.
            </p>
            <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto mb-10">
              <div className="p-4 bg-white/5 rounded-xl">
                <Brain className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Think Clearer</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <MessageSquare className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Communicate Better</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Zap className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Energizing Decisions</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Star className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Generative Leadership</p>
              </div>
            </div>
            <Button 
              onClick={() => setIsInputDialogOpen(true)}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 px-8 py-6 text-lg"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Begin Evolution
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}