import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Heart, Brain, Sparkles, Send, Wind, Moon, Sun, Activity,
  Smile, Frown, Meh, Battery, Zap, Watch, Plus, CheckCircle2,
  TrendingUp, Calendar, MessageCircle, Leaf, Coffee, Dumbbell,
  Music, BookOpen, Users, Target, Award, Flame
} from "lucide-react";
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format, subDays } from "date-fns";

export default function WellnessCompanion() {
  const queryClient = useQueryClient();
  const chatEndRef = useRef(null);
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", content: "Hello! I'm your Wellness Companion. How are you feeling today? I'm here to support your well-being journey with personalized guidance and interventions." }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showLogDialog, setShowLogDialog] = useState(false);
  const [dailyLog, setDailyLog] = useState({
    mood_score: 5,
    energy_level: 5,
    stress_level: 5,
    sleep_hours: 7,
    sleep_quality: 5,
    journal_entry: "",
    gratitude_notes: ["", "", ""]
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: wellnessLogs } = useQuery({
    queryKey: ['wellnessLogs', user?.email],
    queryFn: () => base44.entities.WellnessLog.filter({ user_email: user?.email }, '-log_date', 30),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: interventions } = useQuery({
    queryKey: ['interventions'],
    queryFn: () => base44.entities.WellnessIntervention.filter({ is_active: true }),
    initialData: [],
  });

  const { data: wellnessPlan } = useQuery({
    queryKey: ['wellnessPlan', user?.email],
    queryFn: async () => {
      const plans = await base44.entities.UserWellnessPlan.filter({ user_email: user?.email, status: 'active' });
      return plans[0] || null;
    },
    enabled: !!user?.email,
  });

  const createLogMutation = useMutation({
    mutationFn: (data) => base44.entities.WellnessLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wellnessLogs'] });
      setShowLogDialog(false);
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: (data) => wellnessPlan?.id 
      ? base44.entities.UserWellnessPlan.update(wellnessPlan.id, data)
      : base44.entities.UserWellnessPlan.create({ ...data, user_email: user.email }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['wellnessPlan'] });
    },
  });

  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);

  const generatePersonalizedPlan = async () => {
    if (!user || wellnessLogs.length === 0) return;
    setIsGeneratingPlan(true);
    
    try {
      const avgMood = wellnessLogs.reduce((s, l) => s + (l.mood_score || 5), 0) / wellnessLogs.length;
      const avgEnergy = wellnessLogs.reduce((s, l) => s + (l.energy_level || 5), 0) / wellnessLogs.length;
      const avgStress = wellnessLogs.reduce((s, l) => s + (l.stress_level || 5), 0) / wellnessLogs.length;
      const avgSleep = wellnessLogs.reduce((s, l) => s + (l.sleep_hours || 7), 0) / wellnessLogs.length;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert wellness coach. Based on the user's wellness data, create a personalized 4-week wellness intervention plan.

USER WELLNESS DATA (last ${wellnessLogs.length} days):
- Average Mood: ${avgMood.toFixed(1)}/10
- Average Energy: ${avgEnergy.toFixed(1)}/10  
- Average Stress: ${avgStress.toFixed(1)}/10
- Average Sleep: ${avgSleep.toFixed(1)} hours

AVAILABLE INTERVENTIONS:
${interventions?.map(i => `- ${i.name} (${i.category}, ${i.duration_minutes} min): ${i.description}`).join('\n')}

RECENT JOURNAL ENTRIES:
${wellnessLogs.slice(0, 5).filter(l => l.journal_entry).map(l => `"${l.journal_entry}"`).join('\n') || 'None'}

Create a comprehensive plan with:
1. 3-4 specific wellness goals with measurable targets
2. Daily practices using available interventions
3. Focus areas based on their data
4. AI recommendations for improvement
5. Suggested schedule`,
        response_json_schema: {
          type: "object",
          properties: {
            plan_name: { type: "string" },
            goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  goal: { type: "string" },
                  target_metric: { type: "string" },
                  target_value: { type: "number" },
                  current_value: { type: "number" },
                  deadline: { type: "string" }
                }
              }
            },
            daily_practices: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  intervention_name: { type: "string" },
                  scheduled_time: { type: "string" },
                  frequency: { type: "string" }
                }
              }
            },
            focus_areas: { type: "array", items: { type: "string" } },
            ai_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  recommendation: { type: "string" },
                  reason: { type: "string" },
                  priority: { type: "string" }
                }
              }
            }
          }
        }
      });

      await updatePlanMutation.mutateAsync({
        plan_name: result.plan_name || "Personalized Wellness Plan",
        goals: result.goals,
        daily_practices: result.daily_practices,
        focus_areas: result.focus_areas,
        ai_recommendations: result.ai_recommendations,
        status: "active"
      });

      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: `🎯 I've created your personalized wellness plan: "${result.plan_name}"!\n\n**Focus Areas:** ${result.focus_areas?.join(', ')}\n\n**Goals:**\n${result.goals?.map(g => `• ${g.goal}`).join('\n')}\n\nCheck the "My Plan" section to see your daily practices and recommendations.`
      }]);
    } catch (error) {
      console.error("Error generating plan:", error);
    }
    setIsGeneratingPlan(false);
  };

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const sendMessage = async () => {
    if (!userInput.trim() || isProcessing) return;
    
    const userMessage = userInput;
    setChatMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setUserInput("");
    setIsProcessing(true);

    try {
      const recentLogs = wellnessLogs?.slice(0, 7) || [];
      const avgMood = recentLogs.length > 0 
        ? (recentLogs.reduce((s, l) => s + (l.mood_score || 5), 0) / recentLogs.length).toFixed(1)
        : "unknown";

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a compassionate, wise Wellness Companion AI. Your role is to support the user's mental, emotional, and physical well-being.

USER CONTEXT:
- Name: ${user?.full_name || 'Friend'}
- Recent average mood: ${avgMood}/10
- Recent wellness logs: ${JSON.stringify(recentLogs.slice(0, 3))}
- Available interventions: ${interventions?.map(i => i.name).join(', ')}

USER MESSAGE: "${userMessage}"

Respond with empathy and wisdom. If appropriate, suggest a specific intervention from the available list. Keep responses warm but concise (2-4 sentences). If the user seems stressed or struggling, offer immediate coping strategies.`,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            suggested_intervention: { type: "string" },
            mood_detected: { type: "string" },
            urgency_level: { type: "string" }
          }
        }
      });

      let assistantMessage = response.response;
      if (response.suggested_intervention) {
        assistantMessage += `\n\n💡 *Suggested: ${response.suggested_intervention}*`;
      }

      setChatMessages(prev => [...prev, { role: "assistant", content: assistantMessage }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { role: "assistant", content: "I'm here for you. Let me know how I can help with your wellness journey." }]);
    }
    setIsProcessing(false);
  };

  const submitDailyLog = async () => {
    const logData = {
      user_email: user.email,
      log_date: new Date().toISOString(),
      mood_score: dailyLog.mood_score,
      energy_level: dailyLog.energy_level,
      stress_level: dailyLog.stress_level,
      sleep_hours: dailyLog.sleep_hours,
      sleep_quality: dailyLog.sleep_quality,
      journal_entry: dailyLog.journal_entry,
      gratitude_notes: dailyLog.gratitude_notes.filter(n => n.trim()),
      wearable_source: "manual"
    };
    await createLogMutation.mutateAsync(logData);
  };

  const getMoodIcon = (score) => {
    if (score >= 7) return <Smile className="w-5 h-5 text-green-500" />;
    if (score >= 4) return <Meh className="w-5 h-5 text-yellow-500" />;
    return <Frown className="w-5 h-5 text-red-500" />;
  };

  const chartData = wellnessLogs?.slice(0, 14).reverse().map(log => ({
    date: format(new Date(log.log_date), 'MMM d'),
    mood: log.mood_score || 0,
    energy: log.energy_level || 0,
    stress: log.stress_level || 0
  })) || [];

  const todayLog = wellnessLogs?.find(l => 
    format(new Date(l.log_date), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
  );

  const streak = wellnessPlan?.streak_days || 0;

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Wellness Companion</h1>
            <p className="text-gray-400">Your personalized AI wellness guide</p>
          </div>
          <div className="flex gap-3">
            {streak > 0 && (
              <Badge className="bg-orange-600 text-white px-4 py-2">
                <Flame className="w-4 h-4 mr-2" />
                {streak} Day Streak
              </Badge>
            )}
            <Button 
              onClick={generatePersonalizedPlan}
              disabled={isGeneratingPlan || wellnessLogs.length === 0}
              className="bg-purple-600 hover:bg-purple-700 mr-2"
            >
              {isGeneratingPlan ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" /> Generate Plan</>
              )}
            </Button>
            <Dialog open={showLogDialog} onOpenChange={setShowLogDialog}>
              <DialogTrigger asChild>
                <Button className="bg-white text-black hover:bg-gray-200">
                  <Plus className="w-4 h-4 mr-2" />
                  Log Today
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
                <DialogHeader>
                  <DialogTitle>Daily Wellness Check-In</DialogTitle>
                </DialogHeader>
                <div className="space-y-6 py-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Mood (1-10)</label>
                    <div className="flex items-center gap-4">
                      <Slider
                        value={[dailyLog.mood_score]}
                        onValueChange={([v]) => setDailyLog({...dailyLog, mood_score: v})}
                        max={10}
                        min={1}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-2xl font-bold text-white w-8">{dailyLog.mood_score}</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Energy Level (1-10)</label>
                    <div className="flex items-center gap-4">
                      <Slider
                        value={[dailyLog.energy_level]}
                        onValueChange={([v]) => setDailyLog({...dailyLog, energy_level: v})}
                        max={10}
                        min={1}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-2xl font-bold text-white w-8">{dailyLog.energy_level}</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Stress Level (1-10)</label>
                    <div className="flex items-center gap-4">
                      <Slider
                        value={[dailyLog.stress_level]}
                        onValueChange={([v]) => setDailyLog({...dailyLog, stress_level: v})}
                        max={10}
                        min={1}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-2xl font-bold text-white w-8">{dailyLog.stress_level}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400 mb-2 block">Sleep Hours</label>
                      <Input
                        type="number"
                        value={dailyLog.sleep_hours}
                        onChange={(e) => setDailyLog({...dailyLog, sleep_hours: parseFloat(e.target.value)})}
                        className="bg-gray-800 border-gray-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-gray-400 mb-2 block">Sleep Quality (1-10)</label>
                      <Input
                        type="number"
                        value={dailyLog.sleep_quality}
                        onChange={(e) => setDailyLog({...dailyLog, sleep_quality: parseInt(e.target.value)})}
                        className="bg-gray-800 border-gray-700 text-white"
                        min={1}
                        max={10}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Gratitude (3 things)</label>
                    {[0, 1, 2].map(i => (
                      <Input
                        key={i}
                        value={dailyLog.gratitude_notes[i]}
                        onChange={(e) => {
                          const notes = [...dailyLog.gratitude_notes];
                          notes[i] = e.target.value;
                          setDailyLog({...dailyLog, gratitude_notes: notes});
                        }}
                        placeholder={`I'm grateful for...`}
                        className="bg-gray-800 border-gray-700 text-white mb-2"
                      />
                    ))}
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Journal Entry (optional)</label>
                    <Textarea
                      value={dailyLog.journal_entry}
                      onChange={(e) => setDailyLog({...dailyLog, journal_entry: e.target.value})}
                      placeholder="How was your day? Any reflections?"
                      className="bg-gray-800 border-gray-700 text-white h-24"
                    />
                  </div>
                  <Button onClick={submitDailyLog} className="w-full bg-white text-black hover:bg-gray-200">
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Save Check-In
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-900 border-gray-800 h-[600px] flex flex-col">
              <CardHeader className="border-b border-gray-800">
                <CardTitle className="text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-purple-400" />
                  Chat with Your Companion
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col p-0">
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {chatMessages.map((msg, idx) => (
                      <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-3 rounded-2xl ${
                          msg.role === 'user' 
                            ? 'bg-purple-600 text-white' 
                            : 'bg-gray-800 text-gray-200'
                        }`}>
                          <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        </div>
                      </div>
                    ))}
                    {isProcessing && (
                      <div className="flex justify-start">
                        <div className="bg-gray-800 text-gray-200 p-3 rounded-2xl">
                          <Sparkles className="w-4 h-4 animate-spin" />
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                </ScrollArea>
                <div className="p-4 border-t border-gray-800">
                  <div className="flex gap-2">
                    <Input
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      placeholder="Share how you're feeling..."
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                    <Button onClick={sendMessage} disabled={isProcessing} className="bg-purple-600 hover:bg-purple-700">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel */}
          <div className="space-y-6">
            {/* Today's Status */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">Today's Wellness</CardTitle>
              </CardHeader>
              <CardContent>
                {todayLog ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Mood</span>
                      <div className="flex items-center gap-2">
                        {getMoodIcon(todayLog.mood_score)}
                        <span className="text-white font-bold">{todayLog.mood_score}/10</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Energy</span>
                      <div className="flex items-center gap-2">
                        <Battery className="w-5 h-5 text-yellow-500" />
                        <span className="text-white font-bold">{todayLog.energy_level}/10</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Stress</span>
                      <div className="flex items-center gap-2">
                        <Activity className="w-5 h-5 text-red-500" />
                        <span className="text-white font-bold">{todayLog.stress_level}/10</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6">
                    <Moon className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400 mb-4">No check-in yet today</p>
                    <Button onClick={() => setShowLogDialog(true)} variant="outline" className="border-gray-700 text-gray-300">
                      Log Now
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Interventions */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">Quick Interventions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="border-gray-700 text-gray-300 h-auto py-3 flex-col">
                    <Wind className="w-5 h-5 mb-1 text-blue-400" />
                    <span className="text-xs">Breathe</span>
                  </Button>
                  <Button variant="outline" className="border-gray-700 text-gray-300 h-auto py-3 flex-col">
                    <Brain className="w-5 h-5 mb-1 text-purple-400" />
                    <span className="text-xs">Meditate</span>
                  </Button>
                  <Button variant="outline" className="border-gray-700 text-gray-300 h-auto py-3 flex-col">
                    <Leaf className="w-5 h-5 mb-1 text-green-400" />
                    <span className="text-xs">Gratitude</span>
                  </Button>
                  <Button variant="outline" className="border-gray-700 text-gray-300 h-auto py-3 flex-col">
                    <Dumbbell className="w-5 h-5 mb-1 text-orange-400" />
                    <span className="text-xs">Move</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* My Wellness Plan */}
            {wellnessPlan && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg flex items-center gap-2">
                    <Target className="w-5 h-5 text-green-400" />
                    My Plan
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {wellnessPlan.focus_areas?.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Focus Areas</p>
                      <div className="flex flex-wrap gap-1">
                        {wellnessPlan.focus_areas.slice(0, 3).map((area, i) => (
                          <Badge key={i} variant="outline" className="text-xs border-green-800 text-green-400">{area}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  {wellnessPlan.daily_practices?.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Today's Practices</p>
                      {wellnessPlan.daily_practices.slice(0, 3).map((p, i) => (
                        <div key={i} className="flex items-center justify-between py-1 text-sm">
                          <span className="text-gray-300">{p.intervention_name}</span>
                          <span className="text-gray-500 text-xs">{p.scheduled_time}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {wellnessPlan.ai_recommendations?.length > 0 && (
                    <div className="p-2 bg-purple-900/30 rounded-lg border border-purple-800">
                      <p className="text-xs text-purple-300 font-medium">💡 AI Tip</p>
                      <p className="text-xs text-gray-300 mt-1">{wellnessPlan.ai_recommendations[0]?.recommendation}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Wearable Status */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center gap-2">
                  <Watch className="w-5 h-5 text-cyan-400" />
                  Wearable Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                {wellnessPlan?.wearable_connected ? (
                  <div className="text-center">
                    <Badge className="bg-green-600 mb-2">Connected</Badge>
                    <p className="text-xs text-gray-400">{wellnessPlan.wearable_type}</p>
                  </div>
                ) : (
                  <div className="text-center py-2">
                    <p className="text-gray-400 text-sm mb-3">Connect your wearable for automatic tracking</p>
                    <Button variant="outline" className="border-gray-700 text-gray-300 text-xs">
                      Connect Device
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Trends Chart */}
        {chartData.length > 0 && (
          <Card className="bg-gray-900 border-gray-800 mt-6">
            <CardHeader>
              <CardTitle className="text-white">Wellness Trends (14 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="date" stroke="#666" />
                  <YAxis domain={[0, 10]} stroke="#666" />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                  <Area type="monotone" dataKey="mood" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} name="Mood" />
                  <Area type="monotone" dataKey="energy" stroke="#eab308" fill="#eab308" fillOpacity={0.3} name="Energy" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}