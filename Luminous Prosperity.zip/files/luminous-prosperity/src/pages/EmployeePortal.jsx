import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sparkles, FileText, Users, Target, Award, Zap, ArrowRight, CheckCircle2, Brain, BarChart3, Wind, Heart, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { AnimatePresence } from "framer-motion";
import OnboardingChecklist from "../components/onboarding/OnboardingChecklist";
import BreathingExercise from "../components/wellness/BreathingExercise";
import DailyWellnessCard from "../components/wellness/DailyWellnessCard";

export default function EmployeePortal() {
  const queryClient = useQueryClient();
  const [showBreathing, setShowBreathing] = useState(false);

  const { data: user, isLoading: loadingUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments, isLoading: loadingAssessments } = useQuery({
    queryKey: ['myAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: teams, isLoading: loadingTeams } = useQuery({
    queryKey: ['myTeams'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      const allTeams = await base44.entities.Team.list();
      return allTeams.filter(team => 
        team.member_emails?.includes(currentUser.email) || 
        team.leader_email === currentUser.email
      );
    },
    initialData: [],
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  if (loadingUser || loadingAssessments || loadingTeams) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-white/30 animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm tracking-widest uppercase">Loading Portal...</p>
        </div>
      </div>
    );
  }

  const latestAssessment = assessments[0];
  const showOnboarding = !user?.onboarding_tasks?.dismissed_checklist && 
    (!user?.onboarding_tasks?.completed_assessment || !user?.onboarding_tasks?.viewed_results);

  const quickActions = [
    {
      title: "Quick Assessment",
      description: "15 min • Behavioral questions",
      icon: Zap,
      url: createPageUrl("QuickAssessment"),
      color: "emerald",
      badge: "Recommended"
    },
    {
      title: "Full Assessment",
      description: "45-60 min • Deep psychological insights",
      icon: Brain,
      url: createPageUrl("Assessment"),
      color: "amber",
    },
    {
      title: "View Results",
      description: "Your integrated insights",
      icon: BarChart3,
      url: createPageUrl("Results"),
      color: "white",
      disabled: assessments.length === 0
    },
    {
      title: "Generate Report",
      description: "Create shareable PDF reports",
      icon: FileText,
      url: createPageUrl("ReportGenerator"),
      color: "white",
      disabled: assessments.length === 0
    },
    {
      title: "Career Paths",
      description: "AI-powered career planning",
      icon: TrendingUp,
      url: createPageUrl("CareerPaths"),
      color: "white",
      disabled: assessments.length === 0
    },
    {
      title: "Coaching Journey",
      description: "Your development path",
      icon: Heart,
      url: createPageUrl("CoachingJourney"),
      color: "white",
      disabled: assessments.length === 0
    },
  ];

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      {/* Breathing Exercise Modal */}
      <AnimatePresence>
        {showBreathing && (
          <BreathingExercise onClose={() => setShowBreathing(false)} variant="dark" />
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full border border-white/10 bg-white/5 flex items-center justify-center">
                <span className="text-2xl font-light text-white">
                  {user?.full_name?.charAt(0) || user?.email?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <div>
                <h1 className="text-3xl font-light text-white tracking-tight">
                  Welcome back, <span className="gold-gradient-text">{user?.full_name?.split(' ')[0] || 'Explorer'}</span>
                </h1>
                <p className="text-gray-500 text-sm mt-1">{user?.job_title || user?.department || 'Your personal development portal'}</p>
              </div>
            </div>
            <Button
              onClick={() => setShowBreathing(true)}
              variant="outline"
              className="border-white/10 text-gray-400 hover:bg-white/5 hover:text-white"
            >
              <Wind className="w-4 h-4 mr-2" />
              Breathe
            </Button>
          </div>
        </div>

        {/* Daily Wellness Card */}
        <div className="mb-8">
          <DailyWellnessCard user={user} assessment={latestAssessment} variant="dark" />
        </div>

        {/* Onboarding Checklist */}
        {showOnboarding && (
          <div className="mb-10">
            <OnboardingChecklist user={user} onDismiss={() => {
              updateUserMutation.mutate({
                onboarding_tasks: {
                  ...(user?.onboarding_tasks || {}),
                  dismissed_checklist: true
                }
              });
            }} />
          </div>
        )}

        {/* Assessment Progress */}
        {assessments.length === 0 ? (
          <div className="glass-panel rounded-3xl p-12 text-center mb-10 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-amber-500"></div>
            <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-6" />
            <h2 className="text-2xl font-light text-white mb-4 serif">Begin Your Journey</h2>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              Take your first assessment to unlock personalized insights and development pathways
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("QuickAssessment")}>
                <Button className="bg-white text-black px-8 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm">
                  <Zap className="w-4 h-4 mr-2" />
                  Quick Start (15 min)
                </Button>
              </Link>
              <Link to={createPageUrl("Assessment")}>
                <Button variant="outline" className="border border-white/10 text-gray-400 px-8 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-white/5 hover:text-white rounded-sm">
                  Full Assessment
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="glass-panel rounded-3xl p-8 mb-10 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-emerald-400"></div>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 uppercase tracking-widest">Latest Assessment</p>
                  <p className="text-white font-medium">{format(new Date(latestAssessment.completed_date), 'MMMM d, yyyy')}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Link to={createPageUrl("Results")}>
                  <Button className="bg-white text-black px-6 py-3 text-xs font-bold tracking-[0.15em] uppercase hover:bg-gray-200 rounded-sm">
                    View Results
                  </Button>
                </Link>
                <Link to={createPageUrl("QuickAssessment")}>
                  <Button variant="outline" className="border border-white/10 text-gray-400 px-6 py-3 text-xs tracking-[0.15em] uppercase hover:bg-white/5 hover:text-white rounded-sm">
                    Retake
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions Grid */}
        <div className="mb-12">
          <h2 className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-6">Quick Actions</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <Link 
                key={index} 
                to={action.disabled ? '#' : action.url}
                className={action.disabled ? 'pointer-events-none' : ''}
              >
                <div className={`group p-6 border border-white/5 bg-black rounded-2xl hover:bg-white/5 transition duration-500 relative overflow-hidden h-full ${action.disabled ? 'opacity-40' : ''}`}>
                  <div className={`absolute top-0 left-0 w-full h-0.5 opacity-0 group-hover:opacity-100 transition duration-500 ${
                    action.color === 'emerald' ? 'bg-emerald-500' :
                    action.color === 'amber' ? 'bg-amber-500' :
                    'bg-white/50'
                  }`}></div>
                  <div className="flex items-start justify-between mb-4">
                    <action.icon className={`w-8 h-8 ${
                      action.color === 'emerald' ? 'text-emerald-400' :
                      action.color === 'amber' ? 'text-amber-400' :
                      'text-gray-400'
                    }`} />
                    {action.badge && (
                      <span className="text-[9px] tracking-widest uppercase bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded">
                        {action.badge}
                      </span>
                    )}
                  </div>
                  <h3 className="text-white font-medium mb-1">{action.title}</h3>
                  <p className="text-xs text-gray-500">{action.description}</p>
                  <ArrowRight className="w-4 h-4 text-gray-600 absolute bottom-6 right-6 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Latest Insights */}
        {latestAssessment && (
          <div className="mb-12">
            <h2 className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-6">Your Insights</h2>
            <div className="grid md:grid-cols-3 gap-4">
              {latestAssessment.myers_briggs?.type && (
                <div className="glass-panel rounded-2xl p-6">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Personality Type</p>
                  <p className="text-3xl font-light text-white">{latestAssessment.myers_briggs.type}</p>
                </div>
              )}
              {latestAssessment.strengths?.top_strengths?.[0] && (
                <div className="glass-panel rounded-2xl p-6">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Top Strength</p>
                  <p className="text-xl font-light text-white">{latestAssessment.strengths.top_strengths[0].name}</p>
                </div>
              )}
              {latestAssessment.life_wheel?.overall_satisfaction && (
                <div className="glass-panel rounded-2xl p-6">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Life Satisfaction</p>
                  <p className="text-3xl font-light text-white">{latestAssessment.life_wheel.overall_satisfaction}%</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Teams */}
        {teams.length > 0 && (
          <div>
            <h2 className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-6">Your Teams</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {teams.map((team) => (
                <div key={team.id} className="glass-panel rounded-2xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                      <Users className="w-5 h-5 text-gray-400" />
                    </div>
                    <div>
                      <h3 className="text-white font-medium">{team.name}</h3>
                      <p className="text-xs text-gray-500">{team.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>{team.member_emails?.length || 0} members</span>
                    <span>•</span>
                    <span className={team.status === 'active' ? 'text-emerald-400' : 'text-gray-500'}>
                      {team.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}