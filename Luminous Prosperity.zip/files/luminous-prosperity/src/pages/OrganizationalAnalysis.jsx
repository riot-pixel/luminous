import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Building2, TrendingUp, Search } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function OrganizationalAnalysis() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [orgData, setOrgData] = useState({
    identifier: "",
    identifier_type: "name",
    location: "",
    industry: "",
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: ceoAssessments } = useQuery({
    queryKey: ['ceoAssessments'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.CEOAssessment.filter({ user_email: user.email }, '-completed_date');
    },
    initialData: [],
  });

  const createOrgMutation = useMutation({
    mutationFn: (data) => base44.entities.Organization.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
    },
  });

  const createOrgAssessmentMutation = useMutation({
    mutationFn: (data) => base44.entities.OrganizationalAssessment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orgAssessments'] });
      navigate(createPageUrl("CEODashboard"));
    },
  });

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      // Create or get organization
      let organization = organizations.find(o => 
        o.name?.toLowerCase() === orgData.identifier.toLowerCase() ||
        o.stock_symbol?.toLowerCase() === orgData.identifier.toLowerCase()
      );

      if (!organization) {
        organization = await createOrgMutation.mutateAsync({
          name: orgData.identifier_type === 'name' ? orgData.identifier : `Company (${orgData.identifier})`,
          stock_symbol: orgData.identifier_type === 'stock' ? orgData.identifier : null,
          location: orgData.location,
          industry: orgData.industry,
          size: employees.length > 500 ? 'enterprise' : employees.length > 100 ? 'large' : employees.length > 20 ? 'medium' : 'small',
        });
      }

      // Gather employee assessment data
      const latestAssessments = assessments.reduce((acc, assessment) => {
        if (!acc[assessment.user_email] || new Date(assessment.completed_date) > new Date(acc[assessment.user_email].completed_date)) {
          acc[assessment.user_email] = assessment;
        }
        return acc;
      }, {});

      const hrCapabilityData = {
        total_employees: employees.length,
        assessed_employees: Object.keys(latestAssessments).length,
        personality_distribution: {},
        strength_distribution: {},
        average_life_satisfaction: 0,
      };

      // Calculate distributions
      let totalSatisfaction = 0;
      let satisfactionCount = 0;

      Object.values(latestAssessments).forEach(assessment => {
        if (assessment.myers_briggs?.type) {
          const type = assessment.myers_briggs.type;
          hrCapabilityData.personality_distribution[type] = (hrCapabilityData.personality_distribution[type] || 0) + 1;
        }
        
        if (assessment.strengths?.top_strengths) {
          assessment.strengths.top_strengths.forEach(strength => {
            hrCapabilityData.strength_distribution[strength.name] = 
              (hrCapabilityData.strength_distribution[strength.name] || 0) + 1;
          });
        }

        if (assessment.life_wheel?.overall_satisfaction) {
          totalSatisfaction += assessment.life_wheel.overall_satisfaction;
          satisfactionCount++;
        }
      });

      hrCapabilityData.average_life_satisfaction = satisfactionCount > 0 
        ? Math.round(totalSatisfaction / satisfactionCount) 
        : 0;

      // Get CEO assessment if available
      const latestCEOAssessment = ceoAssessments[0];

      // Use AI to perform comprehensive organizational analysis
      const marketPrompt = orgData.identifier_type === 'stock' 
        ? `Get current market data, competitive position, and industry trends for company with stock symbol ${orgData.identifier}`
        : `Research and analyze ${orgData.identifier} company in ${orgData.location}, industry: ${orgData.industry}`;

      const marketAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `${marketPrompt}

Provide a comprehensive market analysis including:
1. Current market position and competitive landscape
2. Key competitors and market share
3. Industry trends and dynamics
4. Financial health indicators (if publicly available)
5. Recent news and developments
6. Stakeholder perception`,
        add_context_from_internet: true,
      });

      const pestleAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Perform a detailed PESTLE analysis for ${orgData.identifier} in ${orgData.location}, industry: ${orgData.industry}.

Analyze:
- Political: Government policies, regulations, political stability
- Economic: Economic trends, market conditions, growth indicators
- Social: Demographics, cultural trends, consumer behavior
- Technological: Innovation, digital transformation, tech adoption
- Legal: Compliance requirements, legal frameworks
- Environmental: Sustainability, climate impact, ecological considerations

Be specific and data-driven where possible.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            political: { type: "string" },
            economic: { type: "string" },
            social: { type: "string" },
            technological: { type: "string" },
            legal: { type: "string" },
            environmental: { type: "string" }
          }
        }
      });

      const swotAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Perform a comprehensive SWOT analysis for ${orgData.identifier}.

Based on market research and industry analysis, identify:
- Strengths: Internal capabilities and competitive advantages
- Weaknesses: Internal limitations and vulnerabilities
- Opportunities: External favorable conditions
- Threats: External risks and challenges

Provide 4-6 specific items for each category.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            strengths: { type: "array", items: { type: "string" } },
            weaknesses: { type: "array", items: { type: "string" } },
            opportunities: { type: "array", items: { type: "string" } },
            threats: { type: "array", items: { type: "string" } }
          }
        }
      });

      const sustainabilityAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze the sustainability profile of ${orgData.identifier} across three dimensions:

1. ECOLOGICAL: Environmental impact, carbon footprint, resource usage, conservation efforts
2. SOCIAL: Labor practices, community impact, diversity & inclusion, ethical sourcing
3. ECONOMIC: Long-term financial sustainability, value creation, economic resilience

Rate each dimension 0-100 based on available data and industry standards.
Provide detailed justification for each score.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            ecological_impact: { type: "number" },
            ecological_analysis: { type: "string" },
            social_responsibility: { type: "number" },
            social_analysis: { type: "string" },
            economic_sustainability: { type: "number" },
            economic_analysis: { type: "string" }
          }
        }
      });

      const integralOrgHealth = await base44.integrations.Core.InvokeLLM({
        prompt: `Using Integral Theory's four quadrants, assess organizational health:

INDIVIDUAL INTERIOR (I): Employee mindsets, values, motivation, psychological well-being
- Data: Average life satisfaction: ${hrCapabilityData.average_life_satisfaction}%
- Assessed employees: ${hrCapabilityData.assessed_employees}/${hrCapabilityData.total_employees}

INDIVIDUAL EXTERIOR (IT): Skills, behaviors, performance, competencies
- Personality distribution: ${JSON.stringify(hrCapabilityData.personality_distribution)}
- Top strengths: ${JSON.stringify(hrCapabilityData.strength_distribution)}

COLLECTIVE INTERIOR (WE): Culture, shared values, relationships
- CEO Leadership Data: ${latestCEOAssessment ? JSON.stringify(latestCEOAssessment.leadership_style) : 'Not available'}

COLLECTIVE EXTERIOR (ITS): Systems, structures, processes, infrastructure
- Company: ${orgData.identifier}
- Industry: ${orgData.industry}
- Size: ${hrCapabilityData.total_employees} employees

Rate each quadrant 0-100 and provide analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            individual_interior: { type: "number" },
            individual_interior_analysis: { type: "string" },
            individual_exterior: { type: "number" },
            individual_exterior_analysis: { type: "string" },
            collective_interior: { type: "number" },
            collective_interior_analysis: { type: "string" },
            collective_exterior: { type: "number" },
            collective_exterior_analysis: { type: "string" }
          }
        }
      });

      const comprehensiveInsights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a world-class organizational consultant specializing in holistic business transformation.

Synthesize the following data into comprehensive strategic insights (600-800 words):

MARKET ANALYSIS:
${marketAnalysis}

PESTLE ANALYSIS:
${JSON.stringify(pestleAnalysis, null, 2)}

SWOT ANALYSIS:
${JSON.stringify(swotAnalysis, null, 2)}

SUSTAINABILITY METRICS:
${JSON.stringify(sustainabilityAnalysis, null, 2)}

HUMAN CAPITAL:
${JSON.stringify(hrCapabilityData, null, 2)}

INTEGRAL ORGANIZATIONAL HEALTH:
${JSON.stringify(integralOrgHealth, null, 2)}

CEO LEADERSHIP:
${latestCEOAssessment ? JSON.stringify({
  leadership_style: latestCEOAssessment.leadership_style,
  strategic_vision: latestCEOAssessment.strategic_vision,
  stakeholder_orientation: latestCEOAssessment.stakeholder_orientation
}) : 'No CEO assessment available'}

Provide:
1. Overall organizational health assessment
2. Critical alignment gaps between leadership, strategy, people, and market
3. Key opportunities for value creation
4. Risks requiring immediate attention
5. Strategic recommendations for optimizing profit, human wellness, and stakeholder relationships
6. How to leverage human capital more effectively
7. Sustainability integration opportunities

Be specific, actionable, and integrate insights across all dimensions.`,
      });

      const recommendations = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on all the analysis, provide 8-10 prioritized strategic recommendations.

Each recommendation should include:
- Category (e.g., "Human Capital", "Market Strategy", "Sustainability", "Operations")
- Priority (high/medium/low)
- Specific action
- Expected impact

Focus on actions that simultaneously optimize:
1. Financial performance
2. Employee well-being and development
3. Customer value
4. Stakeholder relationships
5. Environmental sustainability`,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  priority: { type: "string" },
                  action: { type: "string" },
                  impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      const alignmentScore = Math.round(
        (integralOrgHealth.individual_interior +
         integralOrgHealth.individual_exterior +
         integralOrgHealth.collective_interior +
         integralOrgHealth.collective_exterior +
         hrCapabilityData.average_life_satisfaction) / 5
      );

      await createOrgAssessmentMutation.mutateAsync({
        organization_id: organization.id,
        ceo_assessment_id: latestCEOAssessment?.id,
        completed_date: new Date().toISOString(),
        market_analysis: { summary: marketAnalysis },
        pestle_analysis: pestleAnalysis,
        swot_analysis: swotAnalysis,
        sustainability_metrics: {
          ecological_impact: sustainabilityAnalysis.ecological_impact,
          social_responsibility: sustainabilityAnalysis.social_responsibility,
          economic_sustainability: sustainabilityAnalysis.economic_sustainability,
        },
        hr_capability_analysis: hrCapabilityData,
        integral_organizational_health: integralOrgHealth,
        alignment_score: alignmentScore,
        recommendations: recommendations.recommendations,
        comprehensive_insights: comprehensiveInsights,
      });

    } catch (error) {
      console.error("Error analyzing organization:", error);
      alert("Error performing analysis. Please try again.");
    }
    setIsAnalyzing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-indigo-100 rounded-full px-5 py-2 text-indigo-700 text-sm font-medium mb-4">
            <Building2 className="w-4 h-4" />
            <span>Comprehensive Organizational Analysis</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Organizational Assessment</h1>
          <p className="text-xl text-gray-600">
            AI-powered analysis integrating market data, sustainability metrics, and human capital
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Company Information
            </CardTitle>
            <CardDescription>
              Enter your company details to begin comprehensive analysis
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>How would you like to identify your organization?</Label>
              <Select value={orgData.identifier_type} onValueChange={(value) => setOrgData({ ...orgData, identifier_type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Company Name</SelectItem>
                  <SelectItem value="stock">Stock Symbol</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>
                {orgData.identifier_type === 'stock' ? 'Stock Symbol' : 'Company Name'}
              </Label>
              <Input
                value={orgData.identifier}
                onChange={(e) => setOrgData({ ...orgData, identifier: e.target.value })}
                placeholder={orgData.identifier_type === 'stock' ? 'e.g., AAPL, MSFT, TSLA' : 'e.g., Acme Corporation'}
              />
            </div>

            <div className="space-y-2">
              <Label>Primary Location (City, Country)</Label>
              <Input
                value={orgData.location}
                onChange={(e) => setOrgData({ ...orgData, location: e.target.value })}
                placeholder="e.g., San Francisco, USA"
              />
            </div>

            <div className="space-y-2">
              <Label>Industry</Label>
              <Input
                value={orgData.industry}
                onChange={(e) => setOrgData({ ...orgData, industry: e.target.value })}
                placeholder="e.g., Technology, Healthcare, Manufacturing"
              />
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">What You'll Get:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Comprehensive market and competitive analysis</li>
                <li>• PESTLE analysis (Political, Economic, Social, Technological, Legal, Environmental)</li>
                <li>• SWOT analysis (Strengths, Weaknesses, Opportunities, Threats)</li>
                <li>• Triple bottom line sustainability assessment (Ecological, Social, Economic)</li>
                <li>• Integral organizational health across all quadrants</li>
                <li>• HR capability analysis based on employee assessments</li>
                <li>• Leadership-strategy-people alignment score</li>
                <li>• Prioritized strategic recommendations</li>
              </ul>
            </div>

            <Button
              onClick={handleAnalyze}
              disabled={!orgData.identifier || !orgData.location || !orgData.industry || isAnalyzing}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              size="lg"
            >
              {isAnalyzing ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing Organization... This may take 2-3 minutes
                </>
              ) : (
                <>
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Generate Comprehensive Analysis
                </>
              )}
            </Button>

            {isAnalyzing && (
              <div className="text-center space-y-2 text-sm text-gray-600">
                <p>🔍 Gathering market intelligence...</p>
                <p>📊 Performing PESTLE analysis...</p>
                <p>💪 Analyzing strengths and opportunities...</p>
                <p>🌱 Assessing sustainability metrics...</p>
                <p>👥 Evaluating human capital alignment...</p>
                <p>✨ Generating strategic insights...</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}