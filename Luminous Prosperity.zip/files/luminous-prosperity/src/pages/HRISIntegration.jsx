import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Link2, CheckCircle2, AlertCircle, RefreshCw, Users, Building2,
  Shield, Zap, Settings, ChevronRight, Database, Clock
} from "lucide-react";

export default function HRISIntegration() {
  const queryClient = useQueryClient();
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState({});

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: organization } = useQuery({
    queryKey: ['organization'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      return orgs[0];
    },
  });

  const updateOrgMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Organization.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organization'] });
    },
  });

  const hrisProviders = [
    {
      id: 'workday',
      name: 'Workday',
      logo: '🔷',
      description: 'Enterprise cloud applications for finance and HR',
      features: ['Employee Sync', 'Org Structure', 'Role Data', 'Real-time Updates'],
      status: organization?.hris_integration?.workday ? 'connected' : 'disconnected',
    },
    {
      id: 'bamboohr',
      name: 'BambooHR',
      logo: '🎋',
      description: 'HR software for small and medium businesses',
      features: ['Employee Profiles', 'Department Sync', 'Custom Fields', 'Webhooks'],
      status: organization?.hris_integration?.bamboohr ? 'connected' : 'disconnected',
    },
    {
      id: 'sap',
      name: 'SAP SuccessFactors',
      logo: '🔶',
      description: 'Integrated human experience management suite',
      features: ['Core HR', 'Talent Management', 'Analytics', 'Learning Integration'],
      status: organization?.hris_integration?.sap ? 'connected' : 'disconnected',
    },
  ];

  const syncCapabilities = [
    {
      id: 'employee_profiles',
      name: 'Employee Profiles',
      description: 'Sync names, emails, job titles, and departments',
      icon: Users,
      available: true,
    },
    {
      id: 'org_structure',
      name: 'Organization Structure',
      description: 'Sync reporting relationships and team hierarchies',
      icon: Building2,
      available: true,
    },
    {
      id: 'roles',
      name: 'Role & Position Data',
      description: 'Sync job roles, levels, and career paths',
      icon: Shield,
      available: true,
    },
    {
      id: 'assessments',
      name: 'Assessment Status',
      description: 'Push assessment completion status back to HRIS',
      icon: CheckCircle2,
      available: true,
    },
  ];

  const handleConnect = async (providerId) => {
    setSelectedProvider(providerId);
    // In production, this would redirect to OAuth flow
    // For now, we'll simulate a connection
    setConnectionStatus(prev => ({ ...prev, [providerId]: 'connecting' }));
    
    setTimeout(async () => {
      if (organization) {
        await updateOrgMutation.mutateAsync({
          id: organization.id,
          data: {
            hris_integration: {
              ...(organization.hris_integration || {}),
              [providerId]: {
                connected: true,
                connected_at: new Date().toISOString(),
                last_sync: null,
              }
            }
          }
        });
      }
      setConnectionStatus(prev => ({ ...prev, [providerId]: 'connected' }));
    }, 2000);
  };

  const handleSync = async (providerId) => {
    setIsSyncing(true);
    
    // Simulate sync process
    try {
      // In production, this would call the actual HRIS API
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      if (organization) {
        await updateOrgMutation.mutateAsync({
          id: organization.id,
          data: {
            hris_integration: {
              ...(organization.hris_integration || {}),
              [providerId]: {
                ...(organization.hris_integration?.[providerId] || {}),
                last_sync: new Date().toISOString(),
                sync_status: 'success',
                records_synced: Math.floor(Math.random() * 50) + 10,
              }
            }
          }
        });
      }
    } catch (error) {
      console.error("Sync error:", error);
    }
    
    setIsSyncing(false);
  };

  const handleDisconnect = async (providerId) => {
    if (organization) {
      const updatedIntegration = { ...(organization.hris_integration || {}) };
      delete updatedIntegration[providerId];
      
      await updateOrgMutation.mutateAsync({
        id: organization.id,
        data: {
          hris_integration: updatedIntegration
        }
      });
    }
    setConnectionStatus(prev => ({ ...prev, [providerId]: 'disconnected' }));
  };

  const isAdmin = user?.role === 'admin' || user?.user_role === 'org_admin';

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-black text-[#f5f5f5] p-6 flex items-center justify-center">
        <div className="glass-panel rounded-3xl max-w-md text-center p-12">
          <Shield className="w-16 h-16 text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-light text-white mb-4 serif">Admin Access Required</h2>
          <p className="text-gray-500">Only organization administrators can manage HRIS integrations</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-light text-white mb-2 serif">HRIS Integration</h1>
          <p className="text-gray-500">Connect and sync employee data from your HR systems</p>
        </div>

        {/* Status Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-10">
          <div className="glass-panel rounded-2xl p-6">
            <Database className="w-6 h-6 text-emerald-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Connected Systems</p>
            <p className="text-3xl font-light text-white mt-1">
              {hrisProviders.filter(p => p.status === 'connected').length}
            </p>
          </div>
          <div className="glass-panel rounded-2xl p-6">
            <Users className="w-6 h-6 text-amber-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Synced Employees</p>
            <p className="text-3xl font-light text-white mt-1">
              {Object.values(organization?.hris_integration || {}).reduce((sum, i) => sum + (i.records_synced || 0), 0)}
            </p>
          </div>
          <div className="glass-panel rounded-2xl p-6">
            <Clock className="w-6 h-6 text-blue-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Last Sync</p>
            <p className="text-lg font-light text-white mt-1">
              {(() => {
                const lastSyncs = Object.values(organization?.hris_integration || {})
                  .map(i => i.last_sync)
                  .filter(Boolean)
                  .sort()
                  .reverse();
                if (lastSyncs[0]) {
                  const date = new Date(lastSyncs[0]);
                  return date.toLocaleDateString();
                }
                return 'Never';
              })()}
            </p>
          </div>
          <div className="glass-panel rounded-2xl p-6">
            <Zap className="w-6 h-6 text-white mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Sync Status</p>
            <p className="text-lg font-light text-emerald-400 mt-1">
              {isSyncing ? 'Syncing...' : 'Ready'}
            </p>
          </div>
        </div>

        <Tabs defaultValue="providers" className="space-y-6">
          <TabsList className="glass-panel p-1 rounded-xl">
            <TabsTrigger value="providers" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <Link2 className="w-4 h-4 mr-2" />
              Providers
            </TabsTrigger>
            <TabsTrigger value="capabilities" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <Settings className="w-4 h-4 mr-2" />
              Sync Settings
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <Database className="w-4 h-4 mr-2" />
              Sync Logs
            </TabsTrigger>
          </TabsList>

          {/* Providers Tab */}
          <TabsContent value="providers" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              {hrisProviders.map(provider => {
                const integration = organization?.hris_integration?.[provider.id];
                const isConnected = integration?.connected;
                const isConnecting = connectionStatus[provider.id] === 'connecting';

                return (
                  <div key={provider.id} className={`glass-panel rounded-2xl p-6 border ${
                    isConnected ? 'border-emerald-500/30' : 'border-white/5'
                  }`}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="text-3xl">{provider.logo}</span>
                        <div>
                          <h3 className="text-white font-medium">{provider.name}</h3>
                          <p className="text-xs text-gray-500">{provider.description}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-xs text-gray-500 mb-2">Capabilities:</p>
                      <div className="flex flex-wrap gap-1">
                        {provider.features.map((f, i) => (
                          <span key={i} className="text-[10px] px-2 py-0.5 bg-white/5 rounded text-gray-400">
                            {f}
                          </span>
                        ))}
                      </div>
                    </div>

                    {isConnected ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-sm text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Connected</span>
                        </div>
                        {integration.last_sync && (
                          <p className="text-xs text-gray-500">
                            Last sync: {new Date(integration.last_sync).toLocaleString()}
                            {integration.records_synced && ` (${integration.records_synced} records)`}
                          </p>
                        )}
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleSync(provider.id)}
                            disabled={isSyncing}
                            size="sm"
                            className="flex-1 bg-white text-black hover:bg-gray-200 text-xs"
                          >
                            {isSyncing ? <RefreshCw className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3 mr-1" />}
                            Sync Now
                          </Button>
                          <Button
                            onClick={() => handleDisconnect(provider.id)}
                            size="sm"
                            variant="outline"
                            className="border-red-500/30 text-red-400 hover:bg-red-500/10 text-xs"
                          >
                            Disconnect
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button
                        onClick={() => handleConnect(provider.id)}
                        disabled={isConnecting}
                        className="w-full bg-white text-black hover:bg-gray-200 text-xs"
                      >
                        {isConnecting ? (
                          <><RefreshCw className="w-3 h-3 mr-2 animate-spin" /> Connecting...</>
                        ) : (
                          <><Link2 className="w-3 h-3 mr-2" /> Connect</>
                        )}
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Manual Import Option */}
            <div className="glass-panel rounded-2xl p-6 border border-dashed border-white/20">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                  <Database className="w-6 h-6 text-gray-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-medium">Manual CSV Import</h3>
                  <p className="text-sm text-gray-500">Import employee data from a CSV file</p>
                </div>
                <Button variant="outline" className="border-white/10 text-gray-400 hover:bg-white/5 text-xs">
                  Upload CSV
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Capabilities Tab */}
          <TabsContent value="capabilities" className="space-y-6">
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-lg font-light text-white mb-6">Sync Capabilities</h3>
              <div className="space-y-4">
                {syncCapabilities.map(cap => (
                  <div key={cap.id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                        <cap.icon className="w-5 h-5 text-gray-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{cap.name}</p>
                        <p className="text-sm text-gray-500">{cap.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-xs px-2 py-1 rounded ${
                        cap.available ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'
                      }`}>
                        {cap.available ? 'Enabled' : 'Disabled'}
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-lg font-light text-white mb-6">Sync Schedule</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                  <div>
                    <p className="text-white font-medium">Automatic Sync</p>
                    <p className="text-sm text-gray-500">Sync employee data automatically</p>
                  </div>
                  <select className="bg-black border border-white/10 text-white rounded-lg px-3 py-2 text-sm">
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="manual">Manual Only</option>
                  </select>
                </div>
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                  <div>
                    <p className="text-white font-medium">Sync Direction</p>
                    <p className="text-sm text-gray-500">Control data flow between systems</p>
                  </div>
                  <select className="bg-black border border-white/10 text-white rounded-lg px-3 py-2 text-sm">
                    <option value="import">Import from HRIS</option>
                    <option value="bidirectional">Bidirectional</option>
                  </select>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-lg font-light text-white mb-6">Recent Sync Activity</h3>
              <div className="space-y-3">
                {Object.entries(organization?.hris_integration || {}).map(([providerId, data]) => {
                  if (!data.last_sync) return null;
                  const provider = hrisProviders.find(p => p.id === providerId);
                  
                  return (
                    <div key={providerId} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-4">
                        <span className="text-2xl">{provider?.logo}</span>
                        <div>
                          <p className="text-white font-medium">{provider?.name} Sync</p>
                          <p className="text-xs text-gray-500">
                            {new Date(data.last_sync).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`text-xs px-2 py-1 rounded ${
                          data.sync_status === 'success' 
                            ? 'bg-emerald-500/20 text-emerald-400' 
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {data.sync_status === 'success' ? 'Success' : 'Failed'}
                        </span>
                        {data.records_synced && (
                          <p className="text-xs text-gray-500 mt-1">{data.records_synced} records</p>
                        )}
                      </div>
                    </div>
                  );
                })}
                {!Object.values(organization?.hris_integration || {}).some(d => d.last_sync) && (
                  <div className="text-center py-8 text-gray-500">
                    No sync activity yet. Connect an HRIS provider to get started.
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}