import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Edit, Star, Users, Brain, CheckCircle2 } from "lucide-react";

export default function SkillManagement() {
  const queryClient = useQueryClient();
  const [showSkillDialog, setShowSkillDialog] = useState(false);
  const [showRoleReqDialog, setShowRoleReqDialog] = useState(false);
  const [newSkill, setNewSkill] = useState({
    name: '',
    category: 'technical',
    description: '',
    is_core_competency: false,
  });
  const [newRoleReq, setNewRoleReq] = useState({
    role_title: '',
    department: '',
    skill_id: '',
    required_proficiency: 'Intermediate',
    priority: 'should_have',
    weight: 5,
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: skills } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const createSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.Skill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      setShowSkillDialog(false);
      setNewSkill({ name: '', category: 'technical', description: '', is_core_competency: false });
    },
  });

  const createRoleReqMutation = useMutation({
    mutationFn: (data) => base44.entities.RoleSkillRequirement.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roleRequirements'] });
      setShowRoleReqDialog(false);
      setNewRoleReq({ role_title: '', department: '', skill_id: '', required_proficiency: 'Intermediate', priority: 'should_have', weight: 5 });
    },
  });

  const handleCreateSkill = () => {
    if (!newSkill.name) {
      alert("Please provide a skill name");
      return;
    }
    createSkillMutation.mutate(newSkill);
  };

  const handleCreateRoleReq = () => {
    if (!newRoleReq.role_title || !newRoleReq.skill_id) {
      alert("Please fill in all required fields");
      return;
    }
    
    const selectedSkill = skills.find(s => s.id === newRoleReq.skill_id);
    createRoleReqMutation.mutate({
      ...newRoleReq,
      skill_name: selectedSkill.name,
    });
  };

  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
  const roles = [...new Set(employees.map(e => e.job_title).filter(Boolean))];

  const roleStats = roles.map(role => {
    const requirements = roleRequirements.filter(rr => rr.role_title === role);
    return {
      role,
      totalSkills: requirements.length,
      mustHave: requirements.filter(r => r.priority === 'must_have').length,
      shouldHave: requirements.filter(r => r.priority === 'should_have').length,
    };
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Skill Management</h1>
          <p className="text-gray-600">Define organizational skills and role requirements</p>
        </div>

        <Tabs defaultValue="skills" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="skills">Skills Library</TabsTrigger>
            <TabsTrigger value="roles">Role Requirements</TabsTrigger>
          </TabsList>

          <TabsContent value="skills">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Organization Skills</CardTitle>
                    <CardDescription>{skills.length} skills defined</CardDescription>
                  </div>
                  <Button onClick={() => setShowSkillDialog(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Skill
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {skills.map((skill) => (
                    <Card key={skill.id} className="border-2">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-base flex items-center gap-2">
                              {skill.name}
                              {skill.is_core_competency && (
                                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                              )}
                            </CardTitle>
                            <Badge className="mt-2 text-xs">{skill.category}</Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-xs text-gray-600">{skill.description || 'No description'}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {skills.length === 0 && (
                  <div className="text-center py-12">
                    <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">No skills defined yet</p>
                    <Button onClick={() => setShowSkillDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create First Skill
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="roles">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Role Requirements</CardTitle>
                    <CardDescription>Define skill requirements for each role</CardDescription>
                  </div>
                  <Button onClick={() => setShowRoleReqDialog(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Requirement
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {roleStats.map((roleStat) => {
                    const reqs = roleRequirements.filter(rr => rr.role_title === roleStat.role);
                    return (
                      <div key={roleStat.role} className="border-2 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-bold text-lg">{roleStat.role}</h3>
                          <div className="flex items-center gap-2">
                            <Badge>{roleStat.totalSkills} skills</Badge>
                            <Badge className="bg-red-600">{roleStat.mustHave} must-have</Badge>
                          </div>
                        </div>
                        <div className="space-y-2">
                          {reqs.map((req) => (
                            <div key={req.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium">{req.skill_name}</span>
                                <Badge variant="outline" className="text-xs">{req.required_proficiency}</Badge>
                              </div>
                              <Badge className={
                                req.priority === 'must_have' ? 'bg-red-600' :
                                req.priority === 'should_have' ? 'bg-orange-600' :
                                'bg-blue-600'
                              }>
                                {req.priority.replace('_', ' ')}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}

                  {roleStats.length === 0 && (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">No role requirements defined yet</p>
                      <Button onClick={() => setShowRoleReqDialog(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Define First Requirement
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Skill Dialog */}
        <Dialog open={showSkillDialog} onOpenChange={setShowSkillDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Skill</DialogTitle>
              <DialogDescription>Define a skill for your organization</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Skill Name *</label>
                <Input
                  value={newSkill.name}
                  onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })}
                  placeholder="e.g., Python Programming, Public Speaking"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <Select value={newSkill.category} onValueChange={(v) => setNewSkill({ ...newSkill, category: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="communication">Communication</SelectItem>
                    <SelectItem value="analytical">Analytical</SelectItem>
                    <SelectItem value="creative">Creative</SelectItem>
                    <SelectItem value="operational">Operational</SelectItem>
                    <SelectItem value="strategic">Strategic</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <Textarea
                  value={newSkill.description}
                  onChange={(e) => setNewSkill({ ...newSkill, description: e.target.value })}
                  placeholder="Describe this skill and how it's used..."
                  rows={3}
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newSkill.is_core_competency}
                  onChange={(e) => setNewSkill({ ...newSkill, is_core_competency: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-sm">Mark as core organizational competency</span>
              </label>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowSkillDialog(false)}>Cancel</Button>
                <Button onClick={handleCreateSkill}>Create Skill</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add Role Requirement Dialog */}
        <Dialog open={showRoleReqDialog} onOpenChange={setShowRoleReqDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Role Requirement</DialogTitle>
              <DialogDescription>Define skill requirements for a role</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Role Title *</label>
                <Select value={newRoleReq.role_title} onValueChange={(v) => setNewRoleReq({ ...newRoleReq, role_title: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(role => (
                      <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Department</label>
                <Select value={newRoleReq.department} onValueChange={(v) => setNewRoleReq({ ...newRoleReq, department: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select department (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map(dept => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Skill *</label>
                <Select value={newRoleReq.skill_id} onValueChange={(v) => setNewRoleReq({ ...newRoleReq, skill_id: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select skill" />
                  </SelectTrigger>
                  <SelectContent>
                    {skills.map(skill => (
                      <SelectItem key={skill.id} value={skill.id}>
                        {skill.name} ({skill.category})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Required Proficiency</label>
                <Select value={newRoleReq.required_proficiency} onValueChange={(v) => setNewRoleReq({ ...newRoleReq, required_proficiency: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                    <SelectItem value="Expert">Expert</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Priority</label>
                <Select value={newRoleReq.priority} onValueChange={(v) => setNewRoleReq({ ...newRoleReq, priority: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="must_have">Must Have</SelectItem>
                    <SelectItem value="should_have">Should Have</SelectItem>
                    <SelectItem value="nice_to_have">Nice to Have</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowRoleReqDialog(false)}>Cancel</Button>
                <Button onClick={handleCreateRoleReq}>Add Requirement</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}