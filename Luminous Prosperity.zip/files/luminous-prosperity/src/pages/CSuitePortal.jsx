import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Building2, TrendingUp, Users, Target, Award, Heart, Sparkles, BarChart3, Briefcase, ArrowRight } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import ReactMarkdown from "react-markdown";

export default function CSuitePortal() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: ceoAssessments } = useQuery({
    queryKey: ['ceoAssessments'],
    queryFn: () => base44.entities.CEOAssessment.list('-completed_date'),
    initialData: [],
  });

  const { data: orgAssessments } = useQuery({
    queryKey: ['orgAssessments'],
    queryFn: () => base44.entities.OrganizationalAssessment.list('-completed_date'),
    initialData: [],
  });

  const { data: orgAI } = useQuery({
    queryKey: ['orgAI'],
    queryFn: () => base44.entities.OrganizationAI.list('-compilation_date'),
    initialData: [],
  });

  const { data: deptAI } = useQuery({
    queryKey: ['deptAI'],
    queryFn: () => base44.entities.DepartmentAI.list('-compilation_date'),
    initialData: [],
  });

  const latestCEO = ceoAssessments[0];
  const latestOrg = orgAssessments[0];
  const latestOrgAI = orgAI[0];

  // Calculate key metrics
  const latestAssessments = assessments.reduce((acc, assessment) => {
    if (!acc[assessment.user_email] || new Date(assessment.completed_date) > new Date(acc[assessment.user_email].completed_date)) {
      acc[assessment.user_email] = assessment;
    }
    return acc;
  }, {});

  const completionRate = (Object.keys(latestAssessments).length / employees.length) * 100;
  
  // Personality distribution
  const personalityTypes = {};
  Object.values(latestAssessments).forEach(assessment => {
    if (assessment.myers_briggs?.type) {
      personalityTypes[assessment.myers_briggs.type] = (personalityTypes[assessment.myers_briggs.type] || 0) + 1;
    }
  });
  const personalityData = Object.entries(personalityTypes).slice(0, 8).map(([name, value]) => ({ name, value }));

  // Department distribution
  const deptCounts = employees.reduce((acc, emp) => {
    const dept = emp.department || 'Unassigned';
    acc[dept] = (acc[dept] || 0) + 1;
    return acc;
  }, {});
  const deptData = Object.entries(deptCounts).map(([name, value]) => ({ name, value }));

  // Organizational health radar
  const orgHealthData = latestOrg?.integral_organizational_health ? [
    { subject: 'Individual Interior', value: latestOrg.integral_organizational_health.individual_interior || 0 },
    { subject: 'Individual Exterior', value: latestOrg.integral_organizational_health.individual_exterior || 0 },
    { subject: 'Collective Interior', value: latestOrg.integral_organizational_health.collective_interior || 0 },
    { subject: 'Collective Exterior', value: latestOrg.integral_organizational_health.collective_exterior || 0 },
  ] : [];

  const COLORS = ['#B8967D', '#E8A87C', '#C38D9E', '#85A392', '#D4A574', '#B8967D', '#A68364', '#948054'];

  const strategicDashboards = [
    {
      title: "Leadership Insights",
      description: "Your leadership effectiveness and alignment",
      url: createPageUrl("CEODashboard"),
      icon: Briefcase,
      color: "from-[#B8967D] to-[#A68364]",
      metrics: latestCEO ? "1 Assessment" : "Pending",
    },
    {
      title: "Organizational Intelligence",
      description: "Company-wide strategic synthesis",
      url: createPageUrl("OrganizationalAnalysis"),
      icon: Building2,
      color: "from-orange-400 to-orange-500",
      metrics: latestOrg ? `${latestOrg.alignment_score}/100 Alignment` : "Not Analyzed",
    },
    {
      title: "Collective Vision",
      description: "Employee-driven strategic insights",
      url: createPageUrl("OrganizationalAI"),
      icon: Heart,
      color: "from-amber-400 to-amber-500",
      metrics: latestOrgAI ? `${latestOrgAI.total_participants} Contributors` : "Not Compiled",
    },
    {
      title: "Workforce Analytics",
      description: "Comprehensive organizational metrics",
      url: createPageUrl("OrganizationDashboard"),
      icon: BarChart3,
      color: "from-yellow-400 to-yellow-500",
      metrics: `${employees.length} Employees`,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20 p-6">
      <div className="max-w-7xl mx-auto">
        {/* C-Suite Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-xl flex items-center justify-center shadow-xl">
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-stone-800">C-Suite Intelligence Center</h1>
              <p className="text-stone-600">{user?.full_name} • {user?.job_title}</p>
            </div>
          </div>
          <p className="text-lg text-stone-600">
            Comprehensive organizational synthesis across leadership, people, and strategy
          </p>
        </div>

        {/* Executive Summary Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[#B8967D] to-[#A68364] text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Total Workforce</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{employees.length}</div>
              <p className="text-xs text-white/80 mt-1">employees</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-400 to-orange-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Assessment Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{Math.round(completionRate)}%</div>
              <p className="text-xs text-white/80 mt-1">{Object.keys(latestAssessments).length} completed</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-400 to-amber-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Strategic Alignment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{latestOrg?.alignment_score || '--'}</div>
              <p className="text-xs text-white/80 mt-1">out of 100</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-400 to-yellow-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Active Teams</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{teams.filter(t => t.status === 'active').length}</div>
              <p className="text-xs text-white/80 mt-1">in operation</p>
            </CardContent>
          </Card>
        </div>

        {/* Strategic Dashboards */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-stone-800 mb-4">Strategic Command Center</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {strategicDashboards.map((dashboard, index) => (
              <Link key={index} to={dashboard.url}>
                <Card className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-[#B8967D]/30 cursor-pointer h-full">
                  <CardHeader>
                    <div className={`w-14 h-14 bg-gradient-to-br ${dashboard.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                      <dashboard.icon className="w-7 h-7 text-white" />
                    </div>
                    <CardTitle className="text-lg group-hover:text-[#B8967D] transition-colors flex items-center justify-between">
                      {dashboard.title}
                      <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </CardTitle>
                    <CardDescription>{dashboard.description}</CardDescription>
                    <div className="mt-3 pt-3 border-t border-stone-100">
                      <span className="text-sm font-semibold text-[#B8967D]">{dashboard.metrics}</span>
                    </div>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Comprehensive Insights */}
        <Tabs defaultValue="synthesis" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="synthesis">Synthesis</TabsTrigger>
            <TabsTrigger value="people">People</TabsTrigger>
            <TabsTrigger value="strategy">Strategy</TabsTrigger>
            <TabsTrigger value="culture">Culture</TabsTrigger>
          </TabsList>

          <TabsContent value="synthesis">
            <div className="space-y-6">
              {latestOrg?.comprehensive_insights && (
                <Card className="border-2 border-[#B8967D]/20">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-2xl">
                      <Sparkles className="w-6 h-6 text-[#B8967D]" />
                      Organizational Intelligence Synthesis
                    </CardTitle>
                    <CardDescription>AI-generated comprehensive analysis across all dimensions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-stone max-w-none">
                      <ReactMarkdown>{latestOrg.comprehensive_insights}</ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              )}

              {latestCEO?.ai_insights && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Briefcase className="w-5 h-5 text-[#B8967D]" />
                      Leadership Effectiveness Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-stone max-w-none">
                      <ReactMarkdown>{latestCEO.ai_insights}</ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              )}

              {latestOrgAI?.comprehensive_synthesis && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="w-5 h-5 text-[#B8967D]" />
                      Collective Voice & Vision
                    </CardTitle>
                    <CardDescription>From {latestOrgAI.total_participants} employee contributors</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-stone max-w-none">
                      <ReactMarkdown>{latestOrgAI.comprehensive_synthesis}</ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="people">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Workforce Distribution</CardTitle>
                  <CardDescription>Employees by department</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={deptData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#B8967D" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Personality Distribution</CardTitle>
                  <CardDescription>Myers-Briggs types across organization</CardDescription>
                </CardHeader>
                <CardContent>
                  {personalityData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={personalityData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                          outerRadius={80}
                          dataKey="value"
                        >
                          {personalityData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-stone-400">
                      Insufficient assessment data
                    </div>
                  )}
                </CardContent>
              </Card>

              {latestOrg?.hr_capability_analysis && (
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Human Capital Analysis</CardTitle>
                    <CardDescription>Integrated assessment-based insights</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="p-4 bg-stone-50 rounded-lg">
                        <p className="text-sm text-stone-600 mb-1">Assessment Coverage</p>
                        <p className="text-2xl font-bold text-[#B8967D]">
                          {latestOrg.hr_capability_analysis.assessed_employees}/{latestOrg.hr_capability_analysis.total_employees}
                        </p>
                      </div>
                      <div className="p-4 bg-stone-50 rounded-lg">
                        <p className="text-sm text-stone-600 mb-1">Average Life Satisfaction</p>
                        <p className="text-2xl font-bold text-orange-500">
                          {latestOrg.hr_capability_analysis.average_life_satisfaction}%
                        </p>
                      </div>
                      <div className="p-4 bg-stone-50 rounded-lg">
                        <p className="text-sm text-stone-600 mb-1">Unique Strengths</p>
                        <p className="text-2xl font-bold text-amber-500">
                          {Object.keys(latestOrg.hr_capability_analysis.strength_distribution || {}).length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="strategy">
            <div className="space-y-6">
              {latestOrg?.integral_organizational_health && orgHealthData.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Integral Organizational Health</CardTitle>
                    <CardDescription>Four quadrant assessment of organizational vitality</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <RadarChart data={orgHealthData}>
                        <PolarGrid />
                        <PolarAngleAxis dataKey="subject" />
                        <PolarRadiusAxis domain={[0, 100]} />
                        <Radar name="Score" dataKey="value" stroke="#B8967D" fill="#B8967D" fillOpacity={0.6} />
                        <Tooltip />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}

              {latestOrg?.recommendations && latestOrg.recommendations.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="w-5 h-5 text-[#B8967D]" />
                      Strategic Recommendations
                    </CardTitle>
                    <CardDescription>Prioritized actions for maximum organizational impact</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestOrg.recommendations.map((rec, idx) => (
                        <div key={idx} className="p-4 border-2 border-stone-200 rounded-lg hover:border-[#B8967D]/30 transition-colors">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-[#B8967D]/10 text-[#B8967D] rounded-full flex items-center justify-center font-bold">
                                {idx + 1}
                              </div>
                              <div>
                                <span className="font-semibold text-stone-800">{rec.category}</span>
                                {rec.priority && (
                                  <Badge className={`ml-2 ${
                                    rec.priority === 'high' ? 'bg-red-100 text-red-700' :
                                    rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                                    'bg-green-100 text-green-700'
                                  }`}>
                                    {rec.priority} priority
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          <p className="text-stone-700 mb-2">{rec.action}</p>
                          {rec.impact && (
                            <p className="text-sm text-stone-600">
                              <span className="font-medium">Expected Impact:</span> {rec.impact}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {latestOrgAI?.strategic_priorities && (
                <Card>
                  <CardHeader>
                    <CardTitle>Employee-Driven Strategic Priorities</CardTitle>
                    <CardDescription>Synthesized from {latestOrgAI.total_participants} contributors</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestOrgAI.strategic_priorities.map((priority, idx) => (
                        <div key={idx} className="p-4 bg-stone-50 rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold text-stone-800">{priority.priority}</h4>
                            <Badge className="bg-[#B8967D]">{priority.alignment_percentage}% aligned</Badge>
                          </div>
                          <div className="flex flex-wrap gap-2 mb-2">
                            {priority.supporting_departments?.map((dept, i) => (
                              <Badge key={i} variant="outline" className="text-xs">{dept}</Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="culture">
            <div className="space-y-6">
              {latestOrgAI?.unified_vision && (
                <Card className="border-2 border-[#B8967D]/20 bg-gradient-to-r from-stone-50 to-amber-50/50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-2xl">
                      <Heart className="w-6 h-6 text-[#B8967D]" />
                      Unified Organizational Vision
                    </CardTitle>
                    <CardDescription>Synthesized from the collective voice of your workforce</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl text-stone-800 leading-relaxed italic">"{latestOrgAI.unified_vision}"</p>
                  </CardContent>
                </Card>
              )}

              {latestOrgAI?.cultural_insights && (
                <Card>
                  <CardHeader>
                    <CardTitle>Cultural Intelligence</CardTitle>
                    <CardDescription>Insights from organizational appreciative inquiry</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-stone max-w-none">
                      <ReactMarkdown>{latestOrgAI.cultural_insights}</ReactMarkdown>
                    </div>
                  </CardContent>
                </Card>
              )}

              {deptAI.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Department Insights</CardTitle>
                    <CardDescription>{deptAI.length} departments analyzed</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                      {deptAI.map((dept) => (
                        <div key={dept.id} className="p-4 border border-stone-200 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold text-stone-800">{dept.department}</h4>
                            <Badge>{dept.participant_count} contributors</Badge>
                          </div>
                          <p className="text-sm text-stone-600 mb-3 italic">"{dept.shared_vision}"</p>
                          <div className="space-y-1">
                            <p className="text-xs text-stone-500">Top Strength:</p>
                            <p className="text-sm font-medium text-[#B8967D]">
                              {dept.collective_strengths?.[0] || 'Not specified'}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}