import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, FileText, User, BarChart3, BookOpen, Target } from "lucide-react";
import AIContentGenerator from "../components/content/AIContentGenerator";

export default function AIContentStudio() {
  const [moduleContext, setModuleContext] = useState({
    skillName: "",
    currentLevel: "beginner",
    careerGoal: ""
  });
  const [courseContext, setCourseContext] = useState({
    courseTitle: "",
    difficulty: "intermediate",
    duration: "15"
  });
  const [selectedUser, setSelectedUser] = useState("");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: users } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['userSkillsForContent', selectedUser],
    queryFn: () => base44.entities.UserSkill.filter({ user_email: selectedUser }),
    enabled: !!selectedUser,
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['userAssessments', selectedUser],
    queryFn: () => base44.entities.Assessment.filter({ user_email: selectedUser }),
    enabled: !!selectedUser,
    initialData: [],
  });

  const { data: latestAudit } = useQuery({
    queryKey: ['latestSkillAudit'],
    queryFn: async () => {
      const audits = await base44.entities.SkillGapAudit.list('-audit_date', 1);
      return audits[0] || null;
    },
  });

  const selectedUserData = users.find(u => u.email === selectedUser);
  const selectedUserAssessment = assessments?.[0];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-light text-white mb-2">AI Content Studio</h1>
          <p className="text-gray-400">Generate personalized content across the platform</p>
        </div>

        <Tabs defaultValue="modules" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="modules"><BookOpen className="w-4 h-4 mr-1" />Learning Modules</TabsTrigger>
            <TabsTrigger value="courses"><FileText className="w-4 h-4 mr-1" />Course Descriptions</TabsTrigger>
            <TabsTrigger value="profiles"><User className="w-4 h-4 mr-1" />User Profiles</TabsTrigger>
            <TabsTrigger value="reports"><BarChart3 className="w-4 h-4 mr-1" />Skill Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="modules">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Module Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Skill/Topic Name</label>
                    <Input
                      value={moduleContext.skillName}
                      onChange={(e) => setModuleContext({...moduleContext, skillName: e.target.value})}
                      placeholder="e.g., Advanced SQL Queries"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Target Level</label>
                    <Select value={moduleContext.currentLevel} onValueChange={(v) => setModuleContext({...moduleContext, currentLevel: v})}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Career Context</label>
                    <Input
                      value={moduleContext.careerGoal}
                      onChange={(e) => setModuleContext({...moduleContext, careerGoal: e.target.value})}
                      placeholder="e.g., Become a Data Analyst"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                </CardContent>
              </Card>

              <AIContentGenerator
                contentType="learning_module"
                context={moduleContext}
              />
            </div>
          </TabsContent>

          <TabsContent value="courses">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Course Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Course Title</label>
                    <Input
                      value={courseContext.courseTitle}
                      onChange={(e) => setCourseContext({...courseContext, courseTitle: e.target.value})}
                      placeholder="e.g., Advanced React Patterns"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Difficulty</label>
                    <Select value={courseContext.difficulty} onValueChange={(v) => setCourseContext({...courseContext, difficulty: v})}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Duration (hours)</label>
                    <Input
                      type="number"
                      value={courseContext.duration}
                      onChange={(e) => setCourseContext({...courseContext, duration: e.target.value})}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                </CardContent>
              </Card>

              <AIContentGenerator
                contentType="course_description"
                context={courseContext}
              />
            </div>
          </TabsContent>

          <TabsContent value="profiles">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Select User</CardTitle>
                </CardHeader>
                <CardContent>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Choose a user..." />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map(u => (
                        <SelectItem key={u.email} value={u.email}>
                          {u.full_name || u.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedUserData && (
                    <div className="mt-4 p-3 bg-gray-800 rounded-lg text-sm">
                      <p className="text-gray-400">Role: {selectedUserData.job_title || 'N/A'}</p>
                      <p className="text-gray-400">Department: {selectedUserData.department || 'N/A'}</p>
                      <p className="text-gray-400">Skills: {userSkills.length}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {selectedUser && (
                <AIContentGenerator
                  contentType="profile_summary"
                  context={{
                    userName: selectedUserData?.full_name || selectedUser,
                    role: selectedUserData?.job_title,
                    department: selectedUserData?.department,
                    skills: userSkills,
                    personalityType: selectedUserAssessment?.myers_briggs?.type,
                    achievements: [
                      ...(selectedUserAssessment?.strengths?.top_strengths?.slice(0, 3).map(s => s.name) || []),
                      "Completed comprehensive assessment"
                    ],
                    careerGoals: "Professional growth and development"
                  }}
                />
              )}
            </div>
          </TabsContent>

          <TabsContent value="reports">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Report Context</CardTitle>
                </CardHeader>
                <CardContent>
                  {latestAudit ? (
                    <div className="space-y-3 text-sm">
                      <div className="p-3 bg-gray-800 rounded">
                        <p className="text-gray-400">Audit Date</p>
                        <p className="text-white">{new Date(latestAudit.audit_date).toLocaleDateString()}</p>
                      </div>
                      <div className="p-3 bg-gray-800 rounded">
                        <p className="text-gray-400">Overall Readiness</p>
                        <p className="text-white font-bold">{latestAudit.overall_readiness_score}%</p>
                      </div>
                      <div className="p-3 bg-gray-800 rounded">
                        <p className="text-gray-400">Critical Gaps</p>
                        <p className="text-white font-bold">{latestAudit.critical_gaps?.length || 0}</p>
                      </div>
                      <div className="p-3 bg-gray-800 rounded">
                        <p className="text-gray-400">Departments Analyzed</p>
                        <p className="text-white font-bold">{latestAudit.department_breakdown?.length || 0}</p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-400 text-sm">No audit data available. Run a skill gap audit first.</p>
                  )}
                </CardContent>
              </Card>

              {latestAudit && (
                <AIContentGenerator
                  contentType="skill_gap_report"
                  context={{
                    organizationName: "Organization",
                    auditDate: new Date(latestAudit.audit_date).toLocaleDateString(),
                    overallReadiness: latestAudit.overall_readiness_score,
                    criticalGaps: latestAudit.critical_gaps,
                    predictions: latestAudit.future_shortage_predictions,
                    departments: latestAudit.department_breakdown
                  }}
                />
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}