import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, Mail, Building2, Shield, CheckCircle2 } from "lucide-react";

export default function AuthSetup() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="w-20 h-20 mx-auto mb-6">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
              alt="Luminous Prosperity" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-4xl font-bold text-stone-800 mb-4">Authentication Setup Guide</h1>
          <p className="text-xl text-stone-600">Configure enterprise authentication for Luminous Prosperity</p>
        </div>

        <Alert className="mb-8 border-[#B8967D]/30 bg-amber-50">
          <Sparkles className="w-5 h-5 text-[#B8967D]" />
          <AlertDescription className="text-stone-700">
            <strong>Platform Integration:</strong> Base44 handles authentication automatically. Follow these steps to configure your authentication methods in the Base44 dashboard.
          </AlertDescription>
        </Alert>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-[#B8967D]" />
                1. Google OAuth Setup
              </CardTitle>
              <CardDescription>Enable Google sign-in for your organization</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-stone-50 p-4 rounded-lg">
                <h4 className="font-semibold text-stone-800 mb-3">Configuration Steps:</h4>
                <ol className="space-y-2 text-sm text-stone-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Go to <strong>Base44 Dashboard → Settings → Authentication</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Enable "Google OAuth" provider</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Configure your Google OAuth credentials (Client ID & Secret)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Set allowed domains (e.g., yourcompany.com)</span>
                  </li>
                </ol>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                <p className="text-sm text-blue-900">
                  <strong>User Role Assignment:</strong> When users sign in with Google, they'll be assigned the "employee" role by default. Update their user_role field to "manager", "executive", or "c_suite" as needed.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-[#B8967D]" />
                2. Company Email Domain Setup
              </CardTitle>
              <CardDescription>Configure email domain restrictions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-stone-50 p-4 rounded-lg">
                <h4 className="font-semibold text-stone-800 mb-3">Domain Configuration:</h4>
                <ol className="space-y-2 text-sm text-stone-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>In Base44 Dashboard → Settings → Authentication</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Add your company email domain(s) to the whitelist</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Enable "Domain Restriction" to only allow company emails</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#B8967D] mt-0.5 flex-shrink-0" />
                    <span>Configure email verification requirements</span>
                  </li>
                </ol>
              </div>

              <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
                <p className="text-sm text-green-900">
                  <strong>Example:</strong> If your company domain is "acme.com", only users with @acme.com email addresses will be able to sign in.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#B8967D]" />
                3. User Role Management
              </CardTitle>
              <CardDescription>Configure role-based access control</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-stone-50 p-4 rounded-lg">
                <h4 className="font-semibold text-stone-800 mb-3">Available Roles:</h4>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-stone-800">employee</p>
                      <p className="text-sm text-stone-600">Access to personal assessments, results, and profile</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-stone-800">manager</p>
                      <p className="text-sm text-stone-600">Employee access + team management and operational dashboards</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-stone-800">executive</p>
                      <p className="text-sm text-stone-600">Manager access + executive dashboard and leadership assessments</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-[#B8967D] rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-stone-800">c_suite</p>
                      <p className="text-sm text-stone-600">Full access including C-Suite Intelligence Center with comprehensive organizational synthesis</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg">
                <p className="text-sm text-amber-900">
                  <strong>To Update Roles:</strong> Go to Base44 Dashboard → Data → User → Select user → Update "user_role" field
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#B8967D]" />
                4. Portal Routing Logic
              </CardTitle>
              <CardDescription>How users are directed to their appropriate portal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-stone-50 p-4 rounded-lg">
                <p className="text-sm text-stone-700 mb-4">
                  The Layout component automatically shows navigation based on user roles:
                </p>
                <div className="space-y-2 text-sm">
                  <p className="text-stone-700">
                    <strong>All users see:</strong> Home, My Portal, Assessment, Results, Profile
                  </p>
                  <p className="text-stone-700">
                    <strong>Managers+ see:</strong> Organization Overview, Team Optimization, Team Management, Organizational AI
                  </p>
                  <p className="text-stone-700">
                    <strong>Executives see:</strong> Executive Portal, Executive Dashboard, Leadership Assessment, Strategic Analysis
                  </p>
                  <p className="text-stone-700">
                    <strong>C-Suite sees:</strong> All of the above + C-Suite Intelligence Center
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="bg-gradient-to-r from-stone-100 to-amber-100/50 border-2 border-[#B8967D]/30 rounded-xl p-6">
            <h3 className="text-lg font-bold text-stone-800 mb-3">✨ Next Steps</h3>
            <ol className="space-y-2 text-sm text-stone-700">
              <li>1. Configure authentication in Base44 Dashboard</li>
              <li>2. Invite users via Base44's user invitation system</li>
              <li>3. Assign appropriate user_role values to each user</li>
              <li>4. Users will automatically see their role-appropriate portal and navigation</li>
              <li>5. Monitor adoption through Organization Dashboard metrics</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}