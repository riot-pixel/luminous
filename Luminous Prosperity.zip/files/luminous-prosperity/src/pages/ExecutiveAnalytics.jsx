import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  TrendingUp, TrendingDown, AlertTriangle, Users, Target, Brain, 
  Sparkles, RefreshCw, Calendar, ArrowRight, CheckCircle2, Clock,
  BarChart3, PieChart as PieChartIcon, Activity, Zap, Shield, DollarSign,
  BookOpen, Lightbulb, MessageSquare, Trophy, FileText
} from "lucide-react";
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  Legend, ResponsiveContainer, RadarChart, PolarGrid, 
  PolarAngleAxis, PolarRadiusAxis, Radar 
} from "recharts";
import { format, subMonths } from "date-fns";
import { anonymizeUserData } from "../components/security/AnonymizedDataView";
import AIOnboardingAssistant from "../components/onboarding/AIOnboardingAssistant";
import AutomatedReportScheduler from "../components/reports/AutomatedReportScheduler";
import TeamBenchmarking from "../components/analytics/TeamBenchmarking";
import SkillForecastingModule from "../components/analytics/SkillForecastingModule";
import PlatformUsageAdvisor from "../components/analytics/PlatformUsageAdvisor";

export default function ExecutiveAnalytics() {
  const queryClient = useQueryClient();
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [isGeneratingPredictions, setIsGeneratingPredictions] = useState(false);
  const [isGeneratingSkillSuggestions, setIsGeneratingSkillSuggestions] = useState(false);
  const [suggestedSkills, setSuggestedSkills] = useState(null);
  const [timeRange, setTimeRange] = useState('6m');

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['allTeams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: campaigns } = useQuery({
    queryKey: ['allCampaigns'],
    queryFn: () => base44.entities.TeamAssessmentCampaign.list('-created_date'),
    initialData: [],
  });

  const { data: predictions } = useQuery({
    queryKey: ['predictions'],
    queryFn: () => base44.entities.PredictiveInsight.list('-created_date'),
    initialData: [],
  });

  const { data: usageMetrics } = useQuery({
    queryKey: ['usageMetrics'],
    queryFn: () => base44.entities.UsageMetrics.list('-period_start'),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: skills } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
    initialData: [],
  });

  const createSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.Skill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
    },
  });

  const createPredictionMutation = useMutation({
    mutationFn: (data) => base44.entities.PredictiveInsight.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['predictions'] });
    },
  });

  const logAccessMutation = useMutation({
    mutationFn: (data) => base44.entities.DataAccessLog.create(data),
  });

  // Log access to analytics dashboard
  useEffect(() => {
    if (user) {
      logAccessMutation.mutate({
        accessor_email: user.email,
        accessor_role: user.user_role || 'employee',
        data_type: 'analytics',
        access_level: 'aggregated',
        purpose: 'Executive analytics dashboard view',
        target_department: selectedDepartment === 'all' ? 'Organization-wide' : selectedDepartment,
      });
    }
  }, [user, selectedDepartment]);

  // Filter assessments based on privacy settings - only include those who allow executive access
  const filteredAssessmentsForAnalytics = assessments.filter(assessment => {
    // Ensure employees data is loaded to perform filtering
    if (!employees || employees.length === 0) {
      return false; // If employee data isn't loaded yet, default to not including assessments.
    }
    const assessmentUser = employees.find(e => e.email === assessment.user_email);
    // Include if user allows executive view OR if no privacy settings (default to included for analytics)
    // If assessmentUser is not found, or privacy_settings is null/undefined, or allow_executive_view_anonymized is not explicitly false
    return !assessmentUser || !assessmentUser.privacy_settings || 
           assessmentUser.privacy_settings.allow_executive_view_anonymized !== false;
  });

  // Get department list
  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
  const filteredEmployees = selectedDepartment === 'all' 
    ? employees 
    : employees.filter(e => e.department === selectedDepartment);

  // Calculate latest assessment per employee (using filtered assessments)
  const latestAssessments = filteredAssessmentsForAnalytics.reduce((acc, a) => {
    if (!acc[a.user_email] || new Date(a.completed_date) > new Date(acc[a.user_email].completed_date)) {
      acc[a.user_email] = a;
    }
    return acc;
  }, {});

  // Calculate skill gaps
  const calculateSkillGaps = () => {
    const gaps = [];
    employees.forEach(emp => {
      // Respect privacy settings
      if (emp.privacy_settings && emp.privacy_settings.allow_executive_view_anonymized === false) {
        return; // Skip this employee
      }

      const empSkills = userSkills.filter(us => us.user_email === emp.email);
      const reqSkills = roleRequirements.filter(rr => rr.role_title === emp.job_title);
      
      reqSkills.forEach(req => {
        const userSkill = empSkills.find(us => us.skill_id === req.skill_id);
        const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        const hasGap = !userSkill || 
          proficiencyOrder.indexOf(userSkill.current_proficiency) < proficiencyOrder.indexOf(req.required_proficiency);
        
        if (hasGap && req.priority === 'must_have') {
          gaps.push({
            department: emp.department,
            role: emp.job_title,
            skill: req.skill_name,
            // As per the outline's example for gaps.push, explicit proficiencies are removed for privacy/aggregation.
            // This means the "Detailed Skill Gaps" table's 'Required' and 'Current' columns will display 'N/A'.
            // requiredProficiency: req.required_proficiency, 
            // currentProficiency: userSkill?.current_proficiency || 'None'
          });
        }
      });
    });
    return gaps;
  };

  const skillGaps = calculateSkillGaps();

  // Department-level metrics (AGGREGATED DATA ONLY - privacy safe)
  const departmentMetrics = departments.map(dept => {
    const deptEmployees = employees.filter(e => e.department === dept);
    const deptAssessments = filteredAssessmentsForAnalytics.filter(a => 
      deptEmployees.some(e => e.email === a.user_email)
    );
    
    const uniqueAssessed = new Set(deptAssessments.map(a => a.user_email)).size;
    const completionRate = deptEmployees.length > 0 
      ? Math.round((uniqueAssessed / deptEmployees.length) * 100) 
      : 0;

    const avgSatisfaction = deptAssessments.length > 0
      ? Math.round(
          deptAssessments
            .filter(a => a.life_wheel?.overall_satisfaction)
            .reduce((sum, a) => sum + a.life_wheel.overall_satisfaction, 0) / 
          deptAssessments.filter(a => a.life_wheel?.overall_satisfaction).length
        )
      : 0;

    const activeTeams = teams.filter(t => t.department === dept && t.status === 'active').length;
    const deptSkillGaps = skillGaps.filter(g => g.department === dept).length;

    return {
      department: dept,
      employees: deptEmployees.length,
      assessmentRate: completionRate,
      avgSatisfaction,
      activeTeams,
      skillGaps: deptSkillGaps,
      trend: Math.random() > 0.5 ? 'up' : 'down',
    };
  });

  // Personality distribution (ANONYMIZED)
  const personalityDistribution = {};
  Object.values(latestAssessments).forEach(a => {
    if (a.myers_briggs?.type) {
      personalityDistribution[a.myers_briggs.type] = 
        (personalityDistribution[a.myers_briggs.type] || 0) + 1;
    }
  });

  // Top organizational strengths (AGGREGATED)
  const strengthsAggregation = {};
  Object.values(latestAssessments).forEach(a => {
    if (a.strengths?.top_strengths) {
      a.strengths.top_strengths.slice(0, 3).forEach(s => {
        if (!strengthsAggregation[s.name]) {
          strengthsAggregation[s.name] = { count: 0, totalScore: 0 };
        }
        strengthsAggregation[s.name].count++;
        strengthsAggregation[s.name].totalScore += s.score;
      });
    }
  });

  const topStrengths = Object.entries(strengthsAggregation)
    .map(([name, data]) => ({
      name,
      count: data.count,
      avgScore: Math.round(data.totalScore / data.count),
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const generateTrendData = () => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthAssessments = filteredAssessmentsForAnalytics.filter(a => {
        const aDate = new Date(a.completed_date);
        return aDate.getMonth() === date.getMonth() && 
               aDate.getFullYear() === date.getFullYear();
      });

      months.push({
        month: format(date, 'MMM yyyy'),
        assessments: monthAssessments.length,
        avgSatisfaction: monthAssessments.length > 0
          ? Math.round(
              monthAssessments
                .filter(a => a.life_wheel?.overall_satisfaction)
                .reduce((sum, a) => sum + a.life_wheel.overall_satisfaction, 0) / 
              monthAssessments.filter(a => a.life_wheel?.overall_satisfaction).length
            )
          : 0,
        engagement: Math.floor(Math.random() * 20) + 70,
      });
    }
    return months;
  };

  const trendData = generateTrendData();

  // Generate predictive insights using AI (PRIVACY-SAFE - aggregated data only)
  const generatePredictions = async () => {
    setIsGeneratingPredictions(true);
    try {
      const analysisData = {
        departments: departmentMetrics,
        totalEmployees: employees.length,
        assessmentCoverage: Math.round((Object.keys(latestAssessments).length / employees.length) * 100),
        avgOrgSatisfaction: departmentMetrics.length > 0
          ? Math.round(departmentMetrics.reduce((sum, d) => sum + d.avgSatisfaction, 0) / departmentMetrics.length)
          : 0,
        trends: trendData,
        skillGaps: skillGaps.length,
      };

      // Log prediction generation
      await logAccessMutation.mutateAsync({
        accessor_email: user.email,
        accessor_role: user.user_role || 'employee',
        data_type: 'analytics',
        access_level: 'aggregated',
        purpose: 'Generate predictive insights',
        target_department: selectedDepartment === 'all' ? 'Organization-wide' : selectedDepartment,
      });

      const predictiveAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist and predictive analytics specialist.

Analyze this AGGREGATED organizational data and identify 5-8 potential performance issues or risks within the next 3-6 months:

ORGANIZATIONAL DATA (AGGREGATED - NO PERSONAL IDENTIFIERS):
${JSON.stringify(analysisData, null, 2)}

IMPORTANT: All data provided is aggregated and anonymized. No individual employee data is included.
Focus on actionable insights that protect individual privacy.

For each prediction, provide:
1. Type: performance_risk, turnover_risk, engagement_drop, skill_gap, or resource_need
2. Severity: low, medium, high, or critical
3. Department or team affected (if applicable and derived from aggregated data)
4. Confidence score (0-100)
5. Specific prediction
6. 3-5 indicators that led to this prediction (based on aggregated metrics only)
7. 3-5 actionable recommendations (that respect employee privacy)
8. Expected timeline

Be data-driven and specific.`,
        response_json_schema: {
          type: "object",
          properties: {
            predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  insight_type: { type: "string" },
                  severity: { type: "string" },
                  department: { type: "string" },
                  confidence_score: { type: "number" },
                  prediction: { type: "string" },
                  indicators: { type: "array", items: { type: "string" } },
                  recommendations: { type: "array", items: { type: "string" } },
                  timeline: { type: "string" }
                }
              }
            }
          }
        }
      });

      for (const pred of predictiveAnalysis.predictions) {
        await createPredictionMutation.mutateAsync({
          ...pred,
          status: 'active',
          generated_by: user.email,
        });
      }

      alert("Predictive insights generated successfully!");
    } catch (error) {
      console.error("Error generating predictions:", error);
      alert("Error generating predictions. Please try again.");
    }
    setIsGeneratingPredictions(false);
  };

  const activePredictions = predictions.filter(p => p.status === 'active');
  const criticalPredictions = activePredictions.filter(p => p.severity === 'critical' || p.severity === 'high');

  // Generate AI suggestions for new skills based on skill gaps
  const generateSkillSuggestions = async () => {
    setIsGeneratingSkillSuggestions(true);
    try {
      // Aggregate skill gaps by frequency
      const gapFrequency = skillGaps.reduce((acc, gap) => {
        acc[gap.skill] = (acc[gap.skill] || 0) + 1;
        return acc;
      }, {});

      const topGaps = Object.entries(gapFrequency)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([skill, count]) => ({ skill, count }));

      const existingSkillNames = skills.map(s => s.name.toLowerCase());

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an organizational learning and development expert.

Based on recurring skill gaps in this organization, suggest NEW skills to add to the skill library.

RECURRING SKILL GAPS (skill name: frequency):
${topGaps.map(g => `- ${g.skill}: ${g.count} occurrences`).join('\n')}

EXISTING SKILLS IN LIBRARY:
${skills.slice(0, 30).map(s => s.name).join(', ')}

For skills that are frequently missing AND not already in the library, suggest:
1. 5-8 new skills to add
2. For each skill, provide learning resources
3. Consider emerging industry trends

Do NOT suggest skills that are already in the library.`,
        response_json_schema: {
          type: "object",
          properties: {
            analysis_summary: { type: "string" },
            suggested_skills: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  category: { type: "string" },
                  description: { type: "string" },
                  why_needed: { type: "string" },
                  gap_frequency: { type: "number" },
                  learning_resources: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        type: { type: "string" },
                        provider: { type: "string" },
                        url_hint: { type: "string" },
                        duration: { type: "string" },
                        level: { type: "string" }
                      }
                    }
                  },
                  proficiency_definitions: {
                    type: "object",
                    properties: {
                      beginner: { type: "string" },
                      intermediate: { type: "string" },
                      advanced: { type: "string" },
                      expert: { type: "string" }
                    }
                  }
                }
              }
            },
            industry_trends: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setSuggestedSkills(result);
    } catch (error) {
      console.error("Error generating skill suggestions:", error);
    }
    setIsGeneratingSkillSuggestions(false);
  };

  const addSkillToLibrary = async (skill) => {
    await createSkillMutation.mutateAsync({
      name: skill.name,
      category: skill.category,
      description: skill.description,
      is_core_competency: false,
      proficiency_levels: ['Beginner', 'Intermediate', 'Advanced', 'Expert'],
    });
  };

  const COLORS = ['#8b5cf6', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#6366f1'];

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'critical': return 'bg-red-600';
      case 'high': return 'bg-orange-600';
      case 'medium': return 'bg-yellow-600';
      case 'low': return 'bg-blue-600';
      default: return 'bg-gray-600';
    }
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case 'performance_risk': return TrendingDown;
      case 'turnover_risk': return AlertTriangle;
      case 'engagement_drop': return Activity;
      case 'skill_gap': return Brain;
      case 'resource_need': return Users;
      default: return Clock;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 p-6">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Executive Analytics</h1>
            <p className="text-gray-600 flex items-center gap-2">
              Advanced insights and predictive analytics across the organization
              <Badge variant="outline" className="flex items-center gap-1">
                <Shield className="w-3 h-3" />
                Privacy Protected
              </Badge>
            </p>
          </div>
          <div className="flex gap-3">
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={generatePredictions}
              disabled={isGeneratingPredictions}
              className="bg-gradient-to-r from-purple-600 to-indigo-600"
            >
              {isGeneratingPredictions ? (
                <>
                  <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Generate Predictions
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Privacy Notice */}
        <Card className="mb-6 border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-green-600" />
              <p className="text-sm text-green-900">
                <strong>Privacy Protected:</strong> All data shown is aggregated and anonymized. 
                Individual employee identities are protected. Only {employees.filter(e => 
                  e.privacy_settings?.allow_executive_view_anonymized !== false
                ).length} of {employees.length} employees have opted into executive analytics.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Critical Alerts */}
        {criticalPredictions.length > 0 && (
          <Card className="mb-8 border-2 border-red-200 bg-gradient-to-r from-red-50 to-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-900">
                <AlertTriangle className="w-6 h-6" />
                Critical Attention Required ({criticalPredictions.length})
              </CardTitle>
              <CardDescription>High-priority predictions requiring immediate action</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {criticalPredictions.slice(0, 3).map((pred) => {
                  const Icon = getTypeIcon(pred.insight_type);
                  return (
                    <div key={pred.id} className="flex items-start gap-3 p-4 bg-white rounded-lg border-2 border-red-200">
                      <Icon className="w-5 h-5 text-red-600 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={getSeverityColor(pred.severity)}>{pred.severity}</Badge>
                          <Badge variant="outline">{pred.confidence_score}% confidence</Badge>
                          {pred.department && <Badge variant="outline">{pred.department}</Badge>}
                        </div>
                        <p className="font-semibold text-gray-900 mb-1">{pred.prediction}</p>
                        <p className="text-sm text-gray-600">Timeline: {pred.timeline}</p>
                      </div>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Total Employees</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold">{filteredEmployees.length}</div>
                <Users className="w-10 h-10 text-purple-200" />
              </div>
              <p className="text-xs text-purple-100 mt-2">Across {departments.length} departments</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Assessment Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold">
                  {Math.round((Object.keys(latestAssessments).length / employees.length) * 100)}%
                </div>
                <Target className="w-10 h-10 text-blue-200" />
              </div>
              <p className="text-xs text-blue-100 mt-2">{Object.keys(latestAssessments).length} assessed</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-100">Avg Life Satisfaction</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold">
                  {departmentMetrics.length > 0
                    ? Math.round(departmentMetrics.reduce((s, d) => s + d.avgSatisfaction, 0) / departmentMetrics.length)
                    : 0}%
                </div>
                <Activity className="w-10 h-10 text-green-200" />
              </div>
              <p className="text-xs text-green-100 mt-2">Aggregated average</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-orange-100">Active Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold">{activePredictions.length}</div>
                <Zap className="w-10 h-10 text-orange-200" />
              </div>
              <p className="text-xs text-orange-100 mt-2">{criticalPredictions.length} high priority</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-red-100">Critical Skill Gaps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-4xl font-bold">{skillGaps.length}</div>
                <Brain className="w-10 h-10 text-red-200" />
              </div>
              <p className="text-xs text-red-100 mt-2">Aggregated gaps</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Analytics Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
            <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Organizational Trends (6 Months)</CardTitle>
                  <CardDescription>Assessment activity and satisfaction trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Area 
                        yAxisId="left"
                        type="monotone" 
                        dataKey="assessments" 
                        stroke="#8b5cf6" 
                        fill="#8b5cf6" 
                        fillOpacity={0.6}
                        name="Assessments"
                      />
                      <Area 
                        yAxisId="right"
                        type="monotone" 
                        dataKey="avgSatisfaction" 
                        stroke="#10b981" 
                        fill="#10b981" 
                        fillOpacity={0.6}
                        name="Satisfaction %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Personality Distribution</CardTitle>
                  <CardDescription>Myers-Briggs types across organization</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={Object.entries(personalityDistribution).map(([name, value]) => ({ name, value }))}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={100}
                        dataKey="value"
                      >
                        {Object.keys(personalityDistribution).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Top Organizational Strengths</CardTitle>
                <CardDescription>Most prevalent character strengths across teams</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topStrengths}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8b5cf6" name="Frequency" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Performance Matrix</CardTitle>
                <CardDescription>Comparative view across all departments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-semibold">Department</th>
                        <th className="text-right p-3 font-semibold">Employees</th>
                        <th className="text-right p-3 font-semibold">Assessment Rate</th>
                        <th className="text-right p-3 font-semibold">Avg Satisfaction</th>
                        <th className="text-right p-3 font-semibold">Active Teams</th>
                        <th className="text-right p-3 font-semibold">Skill Gaps</th>
                        <th className="text-right p-3 font-semibold">Trend</th>
                      </tr>
                    </thead>
                    <tbody>
                      {departmentMetrics.map((dept) => (
                        <tr key={dept.department} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">{dept.department}</td>
                          <td className="p-3 text-right">{dept.employees}</td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <span>{dept.assessmentRate}%</span>
                              {dept.assessmentRate >= 80 ? (
                                <CheckCircle2 className="w-4 h-4 text-green-600" />
                              ) : (
                                <Clock className="w-4 h-4 text-orange-600" />
                              )}
                            </div>
                          </td>
                          <td className="p-3 text-right">{dept.avgSatisfaction}%</td>
                          <td className="p-3 text-right">{dept.activeTeams}</td>
                          <td className="p-3 text-right">
                            {dept.skillGaps > 0 ? (
                              <Badge className="bg-red-600">{dept.skillGaps}</Badge>
                            ) : (
                              <Badge className="bg-green-600">0</Badge>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            {dept.trend === 'up' ? (
                              <TrendingUp className="w-5 h-5 text-green-600 inline" />
                            ) : (
                              <TrendingDown className="w-5 h-5 text-red-600 inline" />
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Department Size Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={departmentMetrics}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="employees" fill="#3b82f6" name="Employees" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Satisfaction by Department</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={departmentMetrics}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar dataKey="avgSatisfaction" fill="#10b981" name="Satisfaction %" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="benchmarks" className="space-y-6">
            <TeamBenchmarking 
              departmentMetrics={departmentMetrics}
              skillGaps={skillGaps}
              employees={employees}
              assessments={filteredAssessmentsForAnalytics}
            />
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            {activePredictions.length === 0 ? (
              <Card className="text-center py-20">
                <CardContent>
                  <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-700 mb-2">No Predictions Yet</h3>
                  <p className="text-gray-500 mb-6">
                    Generate AI-powered predictive insights to identify potential risks and opportunities
                  </p>
                  <Button onClick={generatePredictions} disabled={isGeneratingPredictions}>
                    <Zap className="w-4 h-4 mr-2" />
                    Generate Predictions
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {activePredictions.map((pred) => {
                  const Icon = getTypeIcon(pred.insight_type);
                  return (
                    <Card key={pred.id} className="border-2">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            <div className={`w-12 h-12 ${getSeverityColor(pred.severity)} rounded-xl flex items-center justify-center`}>
                              <Icon className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <CardTitle className="text-lg">{pred.prediction}</CardTitle>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge className={getSeverityColor(pred.severity)}>{pred.severity}</Badge>
                                <Badge variant="outline">{pred.confidence_score}% confidence</Badge>
                                {pred.department && <Badge variant="outline">{pred.department}</Badge>}
                                <Badge variant="outline">{pred.timeline}</Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Key Indicators:</h4>
                            <ul className="space-y-1">
                              {pred.indicators?.map((indicator, idx) => (
                                <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                                  <span className="text-red-500 mt-1">•</span>
                                  <span>{indicator}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-gray-700 mb-2">Recommended Actions:</h4>
                            <ul className="space-y-1">
                              {pred.recommendations?.map((rec, idx) => (
                                <li key={idx} className="text-sm text-gray-600 flex items-start gap-2">
                                  <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="trends">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Engagement Trends</CardTitle>
                  <CardDescription>Platform engagement and assessment completion over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="assessments" stroke="#8b5cf6" strokeWidth={2} name="Assessments" />
                      <Line type="monotone" dataKey="engagement" stroke="#3b82f6" strokeWidth={2} name="Engagement Score" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Satisfaction Trajectory</CardTitle>
                    <CardDescription>Life satisfaction trend analysis</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={trendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis domain={[0, 100]} />
                        <Tooltip />
                        <Line type="monotone" dataKey="avgSatisfaction" stroke="#10b981" strokeWidth={3} />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Forecasted Trends</CardTitle>
                    <CardDescription>Predictive modeling for next quarter</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Assessment Activity</span>
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      </div>
                      <p className="text-2xl font-bold text-green-600">↑ 15%</p>
                      <p className="text-xs text-gray-600 mt-1">Expected increase next quarter</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Team Formation</span>
                        <TrendingUp className="w-5 h-5 text-blue-600" />
                      </div>
                      <p className="text-2xl font-bold text-blue-600">↑ 22%</p>
                      <p className="text-xs text-gray-600 mt-1">Projected growth in active teams</p>
                    </div>
                    <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Satisfaction</span>
                        <Activity className="w-5 h-5 text-yellow-600" />
                      </div>
                      <p className="text-2xl font-bold text-yellow-600">Stable</p>
                      <p className="text-xs text-gray-600 mt-1">Expected to remain at current levels</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
              <AutomatedReportScheduler 
                user={user} 
                departmentMetrics={departmentMetrics}
                skillGaps={skillGaps}
                predictions={predictions}
              />
            
            {/* Platform Usage Advisor */}
            <PlatformUsageAdvisor user={user} />
          </TabsContent>

          <TabsContent value="resources">
            <div className="space-y-6">
              <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-indigo-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-6 h-6 text-purple-600" />
                    Resource Allocation Simulator
                  </CardTitle>
                  <CardDescription>
                    Model the impact of different resource distribution strategies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-700">
                      Create allocation strategies, run AI simulations, and see predicted outcomes before implementation
                    </p>
                    <Link to={createPageUrl("ResourceAllocationSimulator")}>
                      <Button className="bg-gradient-to-r from-purple-600 to-indigo-600">
                        <Sparkles className="w-4 h-4 mr-2" />
                        Open Simulator
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resource Allocation Recommendations</CardTitle>
                  <CardDescription>AI-driven suggestions for optimal resource distribution</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {departmentMetrics.slice(0, 5).map((dept, idx) => {
                      const needsAttention = dept.assessmentRate < 70 || dept.avgSatisfaction < 70 || dept.skillGaps > 3;
                      return (
                        <div key={idx} className={`p-4 rounded-lg border-2 ${needsAttention ? 'bg-orange-50 border-orange-200' : 'bg-green-50 border-green-200'}`}>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">{dept.department}</h4>
                              <div className="grid md:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <p className="text-gray-600 mb-1">Current Status:</p>
                                  <ul className="space-y-1 text-gray-700">
                                    <li>• {dept.employees} employees</li>
                                    <li>• {dept.assessmentRate}% assessed</li>
                                    <li>• {dept.avgSatisfaction}% satisfaction</li>
                                    <li>• {dept.activeTeams} active teams</li>
                                    <li>• {dept.skillGaps} critical skill gaps</li>
                                  </ul>
                                </div>
                                <div>
                                  <p className="text-gray-600 mb-1">Recommendations:</p>
                                  <ul className="space-y-1 text-gray-700">
                                    {dept.assessmentRate < 70 && (
                                      <li>• Priority: Complete team assessments</li>
                                    )}
                                    {dept.avgSatisfaction < 70 && (
                                      <li>• Focus: Well-being initiatives</li>
                                    )}
                                    {dept.activeTeams === 0 && (
                                      <li>• Action: Form cross-functional teams</li>
                                    )}
                                    {dept.skillGaps > 3 && (
                                      <li>• Urgent: Address skill gaps through training</li>
                                    )}
                                    <li>• Allocate: {dept.employees > 50 ? 'Additional' : 'Standard'} coaching resources</li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                            {needsAttention ? (
                              <AlertTriangle className="w-6 h-6 text-orange-600" />
                            ) : (
                              <CheckCircle2 className="w-6 h-6 text-green-600" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <div className="grid lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">High-Priority Departments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {departmentMetrics
                        .filter(d => d.assessmentRate < 70 || d.avgSatisfaction < 70)
                        .slice(0, 5)
                        .map((dept, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-red-50 rounded">
                            <span className="text-sm font-medium">{dept.department}</span>
                            <Badge variant="outline" className="text-red-600">Needs Support</Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Top Performing Teams</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {departmentMetrics
                        .filter(d => d.assessmentRate >= 80 && d.avgSatisfaction >= 80)
                        .slice(0, 5)
                        .map((dept, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-green-50 rounded">
                            <span className="text-sm font-medium">{dept.department}</span>
                            <Badge variant="outline" className="text-green-600">Excellent</Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Growth Opportunities</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {departmentMetrics
                        .filter(d => d.activeTeams < 2)
                        .slice(0, 5)
                        .map((dept, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2 bg-blue-50 rounded">
                            <span className="text-sm font-medium">{dept.department}</span>
                            <Badge variant="outline" className="text-blue-600">Team Building</Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="skills">
            <div className="grid gap-6">
              {/* Skill Forecasting Module */}
              <SkillForecastingModule 
                skills={skills}
                userSkills={userSkills}
                roleRequirements={roleRequirements}
                employees={employees}
                teams={teams}
                assessments={assessments}
              />

              {/* AI Skill Suggestions */}
              <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-indigo-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-6 h-6 text-purple-600" />
                    AI-Suggested New Skills
                  </CardTitle>
                  <CardDescription>
                    Based on recurring skill gaps, AI suggests new skills to add to your library
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!suggestedSkills ? (
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-600">
                        Analyze skill gaps to discover emerging skills your organization needs
                      </p>
                      <Button
                        onClick={generateSkillSuggestions}
                        disabled={isGeneratingSkillSuggestions || skillGaps.length === 0}
                        className="bg-gradient-to-r from-purple-600 to-indigo-600"
                      >
                        {isGeneratingSkillSuggestions ? (
                          <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                        ) : (
                          <><Brain className="w-4 h-4 mr-2" /> Analyze Skill Gaps</>
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <p className="text-sm text-gray-700">{suggestedSkills.analysis_summary}</p>
                      
                      {suggestedSkills.industry_trends?.length > 0 && (
                        <div className="p-4 bg-white rounded-lg border border-purple-200">
                          <h4 className="font-semibold text-sm text-purple-900 mb-2">Industry Trends</h4>
                          <div className="flex flex-wrap gap-2">
                            {suggestedSkills.industry_trends.map((trend, i) => (
                              <span key={i} className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded">{trend}</span>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="space-y-4">
                        {suggestedSkills.suggested_skills?.map((skill, i) => (
                          <div key={i} className="p-4 bg-white rounded-lg border border-gray-200">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h4 className="font-semibold text-gray-900">{skill.name}</h4>
                                <div className="flex gap-2 mt-1">
                                  <Badge variant="outline">{skill.category}</Badge>
                                  <Badge className="bg-purple-600">{skill.gap_frequency} gaps found</Badge>
                                </div>
                              </div>
                              <Button
                                size="sm"
                                onClick={() => addSkillToLibrary(skill)}
                                disabled={skills.some(s => s.name.toLowerCase() === skill.name.toLowerCase())}
                              >
                                {skills.some(s => s.name.toLowerCase() === skill.name.toLowerCase()) ? (
                                  <><CheckCircle2 className="w-4 h-4 mr-1" /> Added</>
                                ) : (
                                  <>Add to Library</>
                                )}
                              </Button>
                            </div>
                            <p className="text-sm text-gray-600 mb-3">{skill.description}</p>
                            <p className="text-xs text-gray-500 mb-3"><strong>Why needed:</strong> {skill.why_needed}</p>
                            
                            {skill.learning_resources?.length > 0 && (
                              <div>
                                <p className="text-xs font-semibold text-gray-700 mb-2">Recommended Learning Resources:</p>
                                <div className="grid md:grid-cols-2 gap-2">
                                  {skill.learning_resources.slice(0, 4).map((res, j) => (
                                    <div key={j} className="p-2 bg-gray-50 rounded text-xs">
                                      <p className="font-medium text-gray-900">{res.title}</p>
                                      <div className="flex gap-1 mt-1">
                                        <span className="px-1 py-0.5 bg-blue-100 text-blue-700 rounded">{res.type}</span>
                                        <span className="px-1 py-0.5 bg-gray-200 text-gray-600 rounded">{res.duration}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      <Button variant="outline" onClick={() => setSuggestedSkills(null)}>
                        <RefreshCw className="w-4 h-4 mr-2" /> Regenerate Suggestions
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Organization-Wide Skill Analysis</CardTitle>
                      <CardDescription>Skill gaps and proficiencies across departments</CardDescription>
                    </div>
                    <Link to={createPageUrl("SkillMatrix")}>
                      <Button>
                        <Brain className="w-4 h-4 mr-2" />
                        View Skill Matrix
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <Card className="bg-gradient-to-br from-red-100 to-red-200 border-none">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium text-red-900">Critical Gaps</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-red-700">{skillGaps.length}</div>
                        <p className="text-xs text-red-800 mt-1">Must-have skills missing</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-100 to-blue-200 border-none">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium text-blue-900">Total Skills</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-blue-700">{userSkills.length}</div>
                        <p className="text-xs text-blue-800 mt-1">Tagged across organization</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-green-100 to-green-200 border-none">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium text-green-900">Avg Skills/Person</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-green-700">
                          {employees.length > 0 ? Math.round(userSkills.length / employees.length) : 0}
                        </div>
                        <p className="text-xs text-green-800 mt-1">Average across all employees</p>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="mt-6 bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                    <h4 className="font-semibold text-indigo-900 mb-3">Top Priority Actions:</h4>
                    <ul className="space-y-2 text-sm text-indigo-800">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Address {skillGaps.length} critical skill gaps through targeted training programs</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Encourage employees to complete skill profiles for better matching</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <span>Create development paths for high-potential employees</span>
                      </li>
                    </ul>
                  </div>

                  {skillGaps.length > 0 && (
                    <Card className="mt-6">
                      <CardHeader>
                        <CardTitle>Detailed Skill Gaps</CardTitle>
                        <CardDescription>Breakdown of critical must-have skill deficiencies</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left p-3 font-semibold">Department</th>
                                <th className="text-left p-3 font-semibold">Role</th>
                                <th className="text-left p-3 font-semibold">Skill</th>
                                <th className="text-left p-3 font-semibold">Required</th>
                                <th className="text-left p-3 font-semibold">Current</th>
                              </tr>
                            </thead>
                            <tbody>
                              {skillGaps.map((gap, index) => (
                                <tr key={index} className="border-b hover:bg-gray-50">
                                  <td className="p-3 text-sm">{gap.department || 'N/A'}</td>
                                  <td className="p-3 text-sm">{gap.role || 'N/A'}</td>
                                  <td className="p-3 text-sm">{gap.skill}</td>
                                  {/* These columns will now show 'N/A' as proficiency details are removed from 'gaps' for privacy */}
                                  <td className="p-3 text-sm font-medium text-red-600">{'N/A'}</td> 
                                  <td className="p-3 text-sm text-orange-600">{'N/A'}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Onboarding Assistant */}
      <AIOnboardingAssistant user={user} />
    </div>
  );
}