import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import QuickLeadershipSection from "../components/quick-executive/QuickLeadershipSection";
import QuickVisionSection from "../components/quick-executive/QuickVisionSection";
import QuickStakeholderSection from "../components/quick-executive/QuickStakeholderSection";
import QuickCultureSection from "../components/quick-executive/QuickCultureSection";
import ProgressTracker from "../components/assessment/ProgressTracker";
import { useQuery } from "@tanstack/react-query";

export default function QuickExecutiveAssessment() {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [assessmentData, setAssessmentData] = useState({
    leadership: null,
    vision: null,
    stakeholders: null,
    culture: null,
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const sections = [
    { name: "Leadership Approach", key: "leadership", component: QuickLeadershipSection },
    { name: "Strategic Vision", key: "vision", component: QuickVisionSection },
    { name: "Stakeholder Focus", key: "stakeholders", component: QuickStakeholderSection },
    { name: "Culture & Values", key: "culture", component: QuickCultureSection },
  ];

  const CurrentSectionComponent = sections[currentSection].component;

  const handleSectionComplete = (data) => {
    const key = sections[currentSection].key;
    setAssessmentData(prev => ({
      ...prev,
      [key]: data,
    }));

    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      completeAssessment({
        ...assessmentData,
        [key]: data,
      });
    }
  };

  const completeAssessment = async (finalData) => {
    setIsProcessing(true);
    try {
      const user = await base44.auth.me();
      
      // AI analyzes executive responses and generates structured profile
      const executiveProfile = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert executive coach. Analyze these leadership responses and generate a comprehensive executive profile.

LEADERSHIP APPROACH:
${JSON.stringify(finalData.leadership.responses, null, 2)}

STRATEGIC VISION:
${JSON.stringify(finalData.vision.responses, null, 2)}

STAKEHOLDER ORIENTATION:
${JSON.stringify(finalData.stakeholders.responses, null, 2)}

ORGANIZATIONAL CULTURE:
${JSON.stringify(finalData.culture.responses, null, 2)}

Generate a complete executive leadership profile including leadership style, strategic vision, stakeholder orientation, decision-making approach, integral perspective, and appreciative inquiry framework.`,
        response_json_schema: {
          type: "object",
          properties: {
            leadership_style: {
              type: "object",
              properties: {
                primary_approach: { type: "string" },
                decision_making: { type: "string" },
                team_empowerment: { type: "string" },
                change_management: { type: "string" }
              }
            },
            strategic_vision: {
              type: "object",
              properties: {
                vision_statement: { type: "string" },
                strategic_priorities: { type: "array", items: { type: "string" } },
                innovation_approach: { type: "string" },
                competitive_advantage: { type: "string" },
                time_horizon: { type: "string" }
              }
            },
            stakeholder_orientation: {
              type: "object",
              properties: {
                shareholder_priority: { type: "number" },
                employee_priority: { type: "number" },
                customer_priority: { type: "number" },
                community_priority: { type: "number" },
                engagement_philosophy: { type: "string" },
                sustainability_commitment: { type: "string" }
              }
            },
            decision_making_approach: {
              type: "object",
              properties: {
                style: { type: "string" },
                data_vs_intuition: { type: "string" },
                risk_tolerance: { type: "string" }
              }
            },
            integral_perspective: {
              type: "object",
              properties: {
                individual_interior: { type: "number" },
                individual_exterior: { type: "number" },
                collective_interior: { type: "number" },
                collective_exterior: { type: "number" },
                systems_thinking: { type: "string" },
                complexity_navigation: { type: "string" }
              }
            },
            appreciative_inquiry: {
              type: "object",
              properties: {
                define: {
                  type: "object",
                  properties: {
                    core_topic: { type: "string" },
                    focus_area: { type: "string" }
                  }
                },
                discover: {
                  type: "object",
                  properties: {
                    organizational_strengths: { type: "array", items: { type: "string" } },
                    success_factors: { type: "array", items: { type: "string" } }
                  }
                },
                dream: {
                  type: "object",
                  properties: {
                    ideal_future: { type: "string" },
                    aspirations: { type: "array", items: { type: "string" } }
                  }
                },
                design: {
                  type: "object",
                  properties: {
                    strategic_commitments: { type: "array", items: { type: "string" } }
                  }
                },
                destiny: {
                  type: "object",
                  properties: {
                    implementation_steps: { type: "array", items: { type: "string" } }
                  }
                }
              }
            }
          }
        }
      });

      const insights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert executive coach providing strategic leadership insights.

Based on this executive's responses, provide comprehensive insights (400-500 words):

RESPONSES:
${JSON.stringify(finalData, null, 2)}

PROFILE:
${JSON.stringify(executiveProfile, null, 2)}

Provide insights on:
1. Leadership effectiveness and style
2. Strategic thinking capabilities
3. Stakeholder management approach
4. Organizational culture alignment
5. Capacity for transformation
6. Key strengths to leverage
7. Development opportunities
8. Specific recommendations for maximizing impact

Write in a professional, empowering tone. Be specific and actionable.`,
      });

      const orgId = organizations.length > 0 ? organizations[0].id : null;

      await base44.entities.CEOAssessment.create({
        user_email: user.email,
        organization_id: orgId,
        completed_date: new Date().toISOString(),
        leadership_style: executiveProfile.leadership_style,
        strategic_vision: executiveProfile.strategic_vision,
        stakeholder_orientation: executiveProfile.stakeholder_orientation,
        decision_making_approach: executiveProfile.decision_making_approach,
        integral_perspective: executiveProfile.integral_perspective,
        appreciative_inquiry: executiveProfile.appreciative_inquiry,
        ai_insights: insights,
      });

      navigate(createPageUrl("CEODashboard"));
    } catch (error) {
      console.error("Error saving executive assessment:", error);
      alert("There was an error processing your assessment. Please try again.");
    }
    setIsProcessing(false);
  };

  const handleBack = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <ProgressTracker 
          sections={sections.map(s => s.name)} 
          currentSection={currentSection}
          completedSections={Object.keys(assessmentData).filter(k => assessmentData[k] !== null).length}
        />

        <div className="mt-12">
          <CurrentSectionComponent
            onComplete={handleSectionComplete}
            onBack={currentSection > 0 ? handleBack : null}
            initialData={assessmentData[sections[currentSection].key]}
            isProcessing={isProcessing}
          />
        </div>
      </div>
    </div>
  );
}