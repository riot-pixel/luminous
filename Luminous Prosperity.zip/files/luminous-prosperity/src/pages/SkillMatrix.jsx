import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Target, TrendingUp, Users, AlertCircle, CheckCircle2, Sparkles, BarChart3, Filter, Search, SortAsc, SortDesc, ArrowUpDown } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import SkillTrendsChart from "../components/skills/SkillTrendsChart";
import SkillGapAuditEngine from "../components/analytics/SkillGapAuditEngine";
import SkillForecastingModule from "../components/analytics/SkillForecastingModule";

export default function SkillMatrix() {
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedRole, setSelectedRole] = useState('all');
  const [selectedSkillCategory, setSelectedSkillCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState('skill');
  const [sortDirection, setSortDirection] = useState('asc');
  const [proficiencyFilter, setProficiencyFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: skills } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['userSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['allLearningJourneys'],
    queryFn: () => base44.entities.LearningJourney.list(),
    initialData: [],
  });

  const { data: usageInsights } = useQuery({
    queryKey: ['platformUsageForSkills'],
    queryFn: async () => {
      const analyses = await base44.entities.PlatformUsageAnalytics.list('-analysis_date', 1);
      return analyses[0] || null;
    },
  });

  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
  const roles = [...new Set(employees.map(e => e.job_title).filter(Boolean))];
  const skillCategories = ['all', 'technical', 'leadership', 'communication', 'analytical', 'creative', 'operational', 'strategic'];

  // Filter employees
  const filteredEmployees = employees.filter(e => {
    const deptMatch = selectedDepartment === 'all' || e.department === selectedDepartment;
    const roleMatch = selectedRole === 'all' || e.job_title === selectedRole;
    return deptMatch && roleMatch;
  });

  // Calculate skill gaps
  const calculateSkillGaps = () => {
    const gaps = [];

    filteredEmployees.forEach(employee => {
      const employeeSkills = userSkills.filter(us => us.user_email === employee.email);
      const requiredSkills = roleRequirements.filter(rr => rr.role_title === employee.job_title);

      requiredSkills.forEach(req => {
        const userSkill = employeeSkills.find(us => us.skill_id === req.skill_id);
        
        const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        const hasGap = !userSkill || 
          proficiencyOrder.indexOf(userSkill.current_proficiency) < proficiencyOrder.indexOf(req.required_proficiency);

        if (hasGap) {
          gaps.push({
            employee: employee.full_name || employee.email,
            email: employee.email,
            department: employee.department,
            role: employee.job_title,
            skill: req.skill_name,
            required: req.required_proficiency,
            current: userSkill?.current_proficiency || 'None',
            priority: req.priority,
          });
        }
      });
    });

    return gaps;
  };

  // Calculate skill coverage by department
  const calculateSkillCoverage = () => {
    return departments.map(dept => {
      const deptEmployees = employees.filter(e => e.department === dept);
      const deptUserSkills = userSkills.filter(us => 
        deptEmployees.some(e => e.email === us.user_email)
      );

      const skillCounts = {};
      deptUserSkills.forEach(us => {
        if (!skillCounts[us.skill_name]) {
          skillCounts[us.skill_name] = 0;
        }
        skillCounts[us.skill_name]++;
      });

      const topSkills = Object.entries(skillCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);

      return {
        department: dept,
        employees: deptEmployees.length,
        totalSkills: deptUserSkills.length,
        avgSkillsPerEmployee: deptEmployees.length > 0 
          ? Math.round(deptUserSkills.length / deptEmployees.length) 
          : 0,
        topSkills,
      };
    });
  };

  // Skill proficiency distribution
  const getSkillProficiencyData = () => {
    const filteredSkills = selectedSkillCategory === 'all' 
      ? userSkills 
      : userSkills.filter(us => us.skill_category === selectedSkillCategory);

    const proficiencyCounts = {
      Beginner: 0,
      Intermediate: 0,
      Advanced: 0,
      Expert: 0,
    };

    filteredSkills.forEach(us => {
      if (proficiencyCounts[us.current_proficiency] !== undefined) {
        proficiencyCounts[us.current_proficiency]++;
      }
    });

    return Object.entries(proficiencyCounts).map(([level, count]) => ({
      level,
      count,
    }));
  };

  const skillGaps = calculateSkillGaps();
  const skillCoverage = calculateSkillCoverage();
  const proficiencyData = getSkillProficiencyData();

  // Advanced filtering and sorting for skill gaps
  const filteredAndSortedGaps = useMemo(() => {
    let gaps = [...skillGaps];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      gaps = gaps.filter(g => 
        g.employee.toLowerCase().includes(query) ||
        g.skill.toLowerCase().includes(query) ||
        g.role?.toLowerCase().includes(query) ||
        g.department?.toLowerCase().includes(query)
      );
    }

    // Proficiency filter
    if (proficiencyFilter !== 'all') {
      gaps = gaps.filter(g => g.current === proficiencyFilter);
    }

    // Priority filter
    if (priorityFilter !== 'all') {
      gaps = gaps.filter(g => g.priority === priorityFilter);
    }

    // Sorting
    gaps.sort((a, b) => {
      let aVal, bVal;
      switch (sortField) {
        case 'skill': aVal = a.skill; bVal = b.skill; break;
        case 'employee': aVal = a.employee; bVal = b.employee; break;
        case 'department': aVal = a.department || ''; bVal = b.department || ''; break;
        case 'priority': 
          const priorityOrder = { 'must_have': 0, 'should_have': 1, 'nice_to_have': 2 };
          aVal = priorityOrder[a.priority] || 3;
          bVal = priorityOrder[b.priority] || 3;
          break;
        case 'proficiency':
          const profOrder = { 'None': 0, 'Beginner': 1, 'Intermediate': 2, 'Advanced': 3, 'Expert': 4 };
          aVal = profOrder[a.current] || 0;
          bVal = profOrder[b.current] || 0;
          break;
        default: aVal = a.skill; bVal = b.skill;
      }
      if (typeof aVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });

    return gaps;
  }, [skillGaps, searchQuery, proficiencyFilter, priorityFilter, sortField, sortDirection]);

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const criticalGaps = skillGaps.filter(g => g.priority === 'must_have');
  const coveragePercentage = filteredEmployees.length > 0
    ? Math.round(((filteredEmployees.length - new Set(skillGaps.map(g => g.email)).size) / filteredEmployees.length) * 100)
    : 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Skill Matrix</h1>
            <p className="text-gray-600">Organization-wide skill proficiency and gap analysis</p>
          </div>
          <Link to={createPageUrl("SkillManagement")}>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600">
              <Brain className="w-4 h-4 mr-2" />
              Manage Skills
            </Button>
          </Link>
        </div>

        {/* AI Usage Insight Banner */}
        {usageInsights?.underutilized_features?.some(f => f.feature_name === "Skill Matrix") && (
          <Card className="bg-gradient-to-r from-orange-100 to-yellow-100 border-orange-300 mb-6">
            <CardContent className="p-4 flex items-center gap-4">
              <Lightbulb className="w-8 h-8 text-orange-600" />
              <div className="flex-1">
                <p className="text-orange-900 font-semibold">💡 AI Recommendation</p>
                <p className="text-gray-700 text-sm">
                  {usageInsights.underutilized_features.find(f => f.feature_name === "Skill Matrix")?.promotion_strategy}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {usageInsights?.popular_features?.some(f => f.feature_name === "Skill Matrix") && (
          <Card className="bg-gradient-to-r from-green-100 to-emerald-100 border-green-300 mb-6">
            <CardContent className="p-4 flex items-center gap-4">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <div className="flex-1">
                <p className="text-green-900 font-semibold">🚀 High Engagement Feature</p>
                <p className="text-gray-700 text-sm">
                  Skill Matrix is highly valued by your team. Consider: {usageInsights.popular_features.find(f => f.feature_name === "Skill Matrix")?.expansion_opportunities?.[0]}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {roles.map(role => (
                    <SelectItem key={role} value={role}>{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedSkillCategory} onValueChange={setSelectedSkillCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {skillCategories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat === 'all' ? 'All Categories' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Skill Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{coveragePercentage}%</div>
              <p className="text-xs text-blue-100 mt-1">employees meeting requirements</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Total Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{userSkills.length}</div>
              <p className="text-xs text-purple-100 mt-1">across {employees.length} employees</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-orange-100">Skill Gaps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{skillGaps.length}</div>
              <p className="text-xs text-orange-100 mt-1">{criticalGaps.length} critical</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-100">Avg Skills/Person</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {employees.length > 0 ? Math.round(userSkills.length / employees.length) : 0}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="gaps" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="gaps">Skill Gaps</TabsTrigger>
            <TabsTrigger value="audit">AI Audit</TabsTrigger>
            <TabsTrigger value="forecast">Forecasting</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="coverage">Coverage</TabsTrigger>
            <TabsTrigger value="proficiency">Proficiency</TabsTrigger>
            <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
          </TabsList>

          <TabsContent value="gaps">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Identified Skill Gaps</CardTitle>
                    <CardDescription>
                      Employees not meeting required proficiency levels for their roles
                    </CardDescription>
                  </div>
                  <Badge className="bg-gray-600">{filteredAndSortedGaps.length} gaps</Badge>
                </div>
              </CardHeader>
              <CardContent>
                {/* Advanced Filters */}
                <div className="flex flex-wrap items-center gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                    <Search className="w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Search skills, employees, departments..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="border-gray-200"
                    />
                  </div>
                  <Select value={proficiencyFilter} onValueChange={setProficiencyFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Proficiency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="None">None</SelectItem>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="must_have">Must Have</SelectItem>
                      <SelectItem value="should_have">Should Have</SelectItem>
                      <SelectItem value="nice_to_have">Nice to Have</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {filteredAndSortedGaps.length === 0 ? (
                  <div className="text-center py-12">
                    <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <p className="text-gray-600">
                      {skillGaps.length === 0 
                        ? "No skill gaps identified! All employees meet requirements."
                        : "No gaps match your filters."
                      }
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-3 font-semibold cursor-pointer hover:bg-gray-50" onClick={() => toggleSort('employee')}>
                            <div className="flex items-center gap-1">
                              Employee
                              {sortField === 'employee' && (sortDirection === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
                              {sortField !== 'employee' && <ArrowUpDown className="w-3 h-3 text-gray-300" />}
                            </div>
                          </th>
                          <th className="text-left p-3 font-semibold cursor-pointer hover:bg-gray-50" onClick={() => toggleSort('department')}>
                            <div className="flex items-center gap-1">
                              Department
                              {sortField === 'department' && (sortDirection === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
                            </div>
                          </th>
                          <th className="text-left p-3 font-semibold cursor-pointer hover:bg-gray-50" onClick={() => toggleSort('skill')}>
                            <div className="flex items-center gap-1">
                              Skill
                              {sortField === 'skill' && (sortDirection === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
                            </div>
                          </th>
                          <th className="text-left p-3 font-semibold cursor-pointer hover:bg-gray-50" onClick={() => toggleSort('proficiency')}>
                            <div className="flex items-center gap-1">
                              Current
                              {sortField === 'proficiency' && (sortDirection === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
                            </div>
                          </th>
                          <th className="text-left p-3 font-semibold">Required</th>
                          <th className="text-left p-3 font-semibold cursor-pointer hover:bg-gray-50" onClick={() => toggleSort('priority')}>
                            <div className="flex items-center gap-1">
                              Priority
                              {sortField === 'priority' && (sortDirection === 'asc' ? <SortAsc className="w-3 h-3" /> : <SortDesc className="w-3 h-3" />)}
                            </div>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredAndSortedGaps.map((gap, idx) => (
                          <tr key={idx} className="border-b hover:bg-gray-50">
                            <td className="p-3">
                              <p className="font-medium text-sm">{gap.employee}</p>
                              <p className="text-xs text-gray-500">{gap.role}</p>
                            </td>
                            <td className="p-3 text-sm">{gap.department}</td>
                            <td className="p-3 text-sm font-medium">{gap.skill}</td>
                            <td className="p-3">
                              <Badge variant="outline" className="text-xs">
                                {gap.current}
                              </Badge>
                            </td>
                            <td className="p-3">
                              <Badge className="bg-blue-600 text-xs">
                                {gap.required}
                              </Badge>
                            </td>
                            <td className="p-3">
                              <Badge className={
                                gap.priority === 'must_have' ? 'bg-red-600' :
                                gap.priority === 'should_have' ? 'bg-orange-600' :
                                'bg-blue-600'
                              }>
                                {gap.priority.replace('_', ' ')}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audit">
            <SkillGapAuditEngine
              skills={skills}
              userSkills={userSkills}
              roleRequirements={roleRequirements}
              employees={employees}
              teams={teams}
              learningJourneys={learningJourneys}
            />
          </TabsContent>

          <TabsContent value="forecast">
            <SkillForecastingModule
              skills={skills}
              userSkills={userSkills}
              roleRequirements={roleRequirements}
              employees={employees}
              teams={teams}
              assessments={assessments}
            />
          </TabsContent>

          <TabsContent value="trends">
            <SkillTrendsChart 
              userSkills={userSkills} 
              skills={skills}
              assessments={assessments}
            />
          </TabsContent>

          <TabsContent value="coverage">
            <Card>
              <CardHeader>
                <CardTitle>Skill Coverage by Department</CardTitle>
                <CardDescription>Average skills per employee and top skills</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={skillCoverage}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="avgSkillsPerEmployee" fill="#3b82f6" name="Avg Skills/Person" />
                    </BarChart>
                  </ResponsiveContainer>

                  <div className="grid md:grid-cols-2 gap-4">
                    {skillCoverage.map((dept) => (
                      <div key={dept.department} className="p-4 border rounded-lg">
                        <h4 className="font-semibold text-gray-900 mb-3">{dept.department}</h4>
                        <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                          <div>
                            <p className="text-gray-600">Employees</p>
                            <p className="font-bold">{dept.employees}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Avg Skills</p>
                            <p className="font-bold">{dept.avgSkillsPerEmployee}</p>
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-2">Top Skills:</p>
                          <div className="flex flex-wrap gap-1">
                            {dept.topSkills.map(([skill, count], idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {skill} ({count})
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="proficiency">
            <Card>
              <CardHeader>
                <CardTitle>Proficiency Level Distribution</CardTitle>
                <CardDescription>
                  Skill proficiency levels across {selectedSkillCategory === 'all' ? 'all categories' : selectedSkillCategory}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={proficiencyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="level" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8b5cf6" name="Number of Skills" />
                  </BarChart>
                </ResponsiveContainer>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  {proficiencyData.map((item) => (
                    <div key={item.level} className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg text-center">
                      <p className="text-2xl font-bold text-purple-600">{item.count}</p>
                      <p className="text-sm text-gray-600">{item.level}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="heatmap">
            <Card>
              <CardHeader>
                <CardTitle>Department Skill Heatmap</CardTitle>
                <CardDescription>Visual representation of skill distribution</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr>
                        <th className="p-3 text-left font-semibold border">Department</th>
                        {skills.slice(0, 10).map(skill => (
                          <th key={skill.id} className="p-3 text-center font-semibold border text-xs" style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
                            {skill.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {departments.map(dept => {
                        const deptEmployees = employees.filter(e => e.department === dept);
                        return (
                          <tr key={dept}>
                            <td className="p-3 font-medium border">{dept}</td>
                            {skills.slice(0, 10).map(skill => {
                              const skillCount = userSkills.filter(us => 
                                us.skill_id === skill.id &&
                                deptEmployees.some(e => e.email === us.user_email)
                              ).length;
                              const percentage = deptEmployees.length > 0 
                                ? (skillCount / deptEmployees.length) * 100 
                                : 0;
                              
                              return (
                                <td 
                                  key={skill.id} 
                                  className="p-3 border text-center text-xs font-semibold"
                                  style={{
                                    backgroundColor: percentage > 75 ? '#10b981' :
                                                    percentage > 50 ? '#3b82f6' :
                                                    percentage > 25 ? '#f59e0b' :
                                                    percentage > 0 ? '#ef4444' : '#f3f4f6',
                                    color: percentage > 25 ? 'white' : '#374151'
                                  }}
                                >
                                  {Math.round(percentage)}%
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <div className="flex items-center gap-4 mt-4 text-xs">
                    <span className="text-gray-600">Coverage:</span>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4" style={{ backgroundColor: '#10b981' }}></div>
                      <span>75%+ (Excellent)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4" style={{ backgroundColor: '#3b82f6' }}></div>
                      <span>50-75% (Good)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4" style={{ backgroundColor: '#f59e0b' }}></div>
                      <span>25-50% (Fair)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4" style={{ backgroundColor: '#ef4444' }}></div>
                      <span>1-25% (Low)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4" style={{ backgroundColor: '#f3f4f6' }}></div>
                      <span>0% (None)</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Critical Gaps Alert */}
        {criticalGaps.length > 0 && (
          <Card className="mt-6 border-2 border-red-200 bg-gradient-to-r from-red-50 to-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-900">
                <AlertCircle className="w-6 h-6" />
                Critical Skill Gaps ({criticalGaps.length})
              </CardTitle>
              <CardDescription>Must-have skills missing for role requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-3">
                {criticalGaps.slice(0, 6).map((gap, idx) => (
                  <div key={idx} className="p-3 bg-white rounded-lg border-2 border-red-200">
                    <p className="font-semibold text-sm text-gray-900">{gap.employee}</p>
                    <p className="text-xs text-gray-600">{gap.role} • {gap.department}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-medium text-red-600">{gap.skill}</span>
                      <Badge className="bg-red-600 text-xs">Required: {gap.required}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}