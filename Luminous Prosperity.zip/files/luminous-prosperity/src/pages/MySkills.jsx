import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Plus, Target, TrendingUp, Sparkles, CheckCircle2, AlertCircle, ArrowRight, Brain, Search } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from "recharts";

export default function MySkills() {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showPathDialog, setShowPathDialog] = useState(false);
  const [isGeneratingPath, setIsGeneratingPath] = useState(false);
  const [skillSearchTerm, setSkillSearchTerm] = useState('');
  const [isAddingCustomSkill, setIsAddingCustomSkill] = useState(false);
  const [customSkillName, setCustomSkillName] = useState('');
  const [customSkillCategory, setCustomSkillCategory] = useState('technical');
  
  const [newUserSkill, setNewUserSkill] = useState({
    skill_id: '',
    skill_name: '',
    skill_category: '',
    current_proficiency: 'Beginner',
    target_proficiency: 'Intermediate',
    years_experience: 0,
    notes: '',
  });
  
  const [pathGoal, setPathGoal] = useState({
    target_role: '',
    timeline: '6 months',
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: skills } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
    initialData: [],
  });

  const { data: mySkills } = useQuery({
    queryKey: ['mySkills'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.UserSkill.filter({ user_email: currentUser.email });
    },
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['myRoleRequirements'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      if (!currentUser.job_title) return [];
      return base44.entities.RoleSkillRequirement.filter({ role_title: currentUser.job_title });
    },
    initialData: [],
  });

  const { data: developmentPaths } = useQuery({
    queryKey: ['myPaths'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.SkillDevelopmentPath.filter({ user_email: currentUser.email }, '-created_date');
    },
    initialData: [],
  });

  const createSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.Skill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
    },
  });

  const createUserSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.UserSkill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySkills'] });
      setShowAddDialog(false);
      resetSkillForm();
    },
  });

  const createPathMutation = useMutation({
    mutationFn: (data) => base44.entities.SkillDevelopmentPath.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myPaths'] });
      setShowPathDialog(false);
    },
  });

  const resetSkillForm = () => {
    setNewUserSkill({ skill_id: '', skill_name: '', skill_category: '', current_proficiency: 'Beginner', target_proficiency: 'Intermediate', years_experience: 0, notes: '' });
    setSkillSearchTerm('');
    setIsAddingCustomSkill(false);
    setCustomSkillName('');
    setCustomSkillCategory('technical');
  };

  const skillCategories = ['technical', 'leadership', 'communication', 'analytical', 'creative', 'operational', 'strategic'];

  const filteredSkills = skills.filter(skill => 
    skill.name.toLowerCase().includes(skillSearchTerm.toLowerCase()) ||
    skill.category.toLowerCase().includes(skillSearchTerm.toLowerCase())
  );

  const handleSelectSkill = (skillId) => {
    const selectedSkill = skills.find(s => s.id === skillId);
    if (selectedSkill) {
      setNewUserSkill({
        ...newUserSkill,
        skill_id: skillId,
        skill_name: selectedSkill.name,
        skill_category: selectedSkill.category,
      });
    }
  };

  const handleAddCustomSkill = async () => {
    if (!customSkillName.trim()) return;

    // First create the skill in the system
    const newSkill = await createSkillMutation.mutateAsync({
      name: customSkillName.trim(),
      category: customSkillCategory,
      description: `Custom skill added by ${user?.full_name || user?.email}`,
    });

    // Then set it as selected
    setNewUserSkill({
      ...newUserSkill,
      skill_id: newSkill.id,
      skill_name: newSkill.name,
      skill_category: newSkill.category,
    });
    
    setIsAddingCustomSkill(false);
    setCustomSkillName('');
  };

  const handleAddSkill = () => {
    if (!newUserSkill.skill_id || !newUserSkill.skill_name) {
      alert("Please select or create a skill");
      return;
    }

    createUserSkillMutation.mutate({
      ...newUserSkill,
      user_email: user.email,
      self_assessed: true,
    });
  };

  const generateDevelopmentPath = async () => {
    setIsGeneratingPath(true);
    try {
      const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
      const gaps = roleRequirements
        .map(req => {
          const userSkill = mySkills.find(us => us.skill_id === req.skill_id);
          const currentIdx = userSkill ? proficiencyOrder.indexOf(userSkill.current_proficiency) : -1;
          const requiredIdx = proficiencyOrder.indexOf(req.required_proficiency);
          
          return {
            skill_name: req.skill_name,
            current_level: userSkill?.current_proficiency || 'None',
            required_level: req.required_proficiency,
            gap_severity: currentIdx < requiredIdx ? 
              (requiredIdx - currentIdx > 2 ? 'high' : requiredIdx - currentIdx > 1 ? 'medium' : 'low') : 'none',
            priority: req.priority,
          };
        })
        .filter(g => g.gap_severity !== 'none');

      const pathRecommendations = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert career development coach.

Create a personalized skill development path:

CURRENT ROLE: ${user.job_title}
TARGET ROLE: ${pathGoal.target_role}
TIMELINE: ${pathGoal.timeline}
DEPARTMENT: ${user.department}

CURRENT SKILLS:
${JSON.stringify(mySkills.map(s => ({
  skill: s.skill_name,
  proficiency: s.current_proficiency,
  experience: s.years_experience,
})), null, 2)}

SKILL GAPS:
${JSON.stringify(gaps, null, 2)}

Create a development path with prioritized skill gaps, specific actions with resources, and milestones.`,
        response_json_schema: {
          type: "object",
          properties: {
            skill_gaps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_name: { type: "string" },
                  current_level: { type: "string" },
                  required_level: { type: "string" },
                  gap_severity: { type: "string" }
                }
              }
            },
            recommended_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  action: { type: "string" },
                  resources: { type: "array", items: { type: "string" } },
                  estimated_time: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  target_date: { type: "string" },
                  skills_addressed: { type: "array", items: { type: "string" } },
                  status: { type: "string" }
                }
              }
            },
            confidence: { type: "number" }
          }
        }
      });

      await createPathMutation.mutateAsync({
        user_email: user.email,
        path_name: `Path to ${pathGoal.target_role}`,
        target_role: pathGoal.target_role,
        timeline: pathGoal.timeline,
        skill_gaps: pathRecommendations.skill_gaps,
        recommended_actions: pathRecommendations.recommended_actions,
        milestones: pathRecommendations.milestones,
        generated_by_ai: true,
        ai_confidence: pathRecommendations.confidence,
        status: 'active',
      });

    } catch (error) {
      console.error("Error generating path:", error);
    }
    setIsGeneratingPath(false);
  };

  const roleReadiness = roleRequirements.length > 0
    ? Math.round((roleRequirements.filter(req => {
        const userSkill = mySkills.find(us => us.skill_id === req.skill_id);
        if (!userSkill) return false;
        const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        return proficiencyOrder.indexOf(userSkill.current_proficiency) >= proficiencyOrder.indexOf(req.required_proficiency);
      }).length / roleRequirements.length) * 100)
    : 100;

  const categoryData = skillCategories.map(cat => ({
    category: cat.charAt(0).toUpperCase() + cat.slice(1),
    count: mySkills.filter(s => s.skill_category === cat).length,
  }));

  const chartColors = {
    grid: 'rgba(255,255,255,0.05)',
    stroke: '#fff',
    fill: 'rgba(255,255,255,0.1)',
  };

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">My Skills</h1>
            <p className="text-gray-500">Manage your skills and development path</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => setShowPathDialog(true)} variant="outline" className="border-white/10 text-gray-400 hover:bg-white/5 hover:text-white text-xs uppercase tracking-widest">
              <Target className="w-4 h-4 mr-2" />
              Generate Path
            </Button>
            <Button onClick={() => setShowAddDialog(true)} className="bg-white text-black hover:bg-gray-200 text-xs uppercase tracking-widest">
              <Plus className="w-4 h-4 mr-2" />
              Add Skill
            </Button>
          </div>
        </div>

        {/* Role Readiness */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-light text-white">Role Readiness: {user?.job_title || 'Not Set'}</h2>
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-500">Proficiency Match</span>
                <span className="text-white">{roleReadiness}%</span>
              </div>
              <Progress value={roleReadiness} className="h-2 bg-white/10" />
            </div>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                <p className="text-3xl font-light text-emerald-400">
                  {roleRequirements.filter(req => {
                    const us = mySkills.find(s => s.skill_id === req.skill_id);
                    const order = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
                    return us && order.indexOf(us.current_proficiency) >= order.indexOf(req.required_proficiency);
                  }).length}
                </p>
                <p className="text-xs text-gray-500 mt-1">Skills Met</p>
              </div>
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                <p className="text-3xl font-light text-amber-400">
                  {roleRequirements.length - roleRequirements.filter(req => {
                    const us = mySkills.find(s => s.skill_id === req.skill_id);
                    const order = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
                    return us && order.indexOf(us.current_proficiency) >= order.indexOf(req.required_proficiency);
                  }).length}
                </p>
                <p className="text-xs text-gray-500 mt-1">Gaps Remaining</p>
              </div>
              <div className="p-4 bg-white/5 border border-white/10 rounded-xl">
                <p className="text-3xl font-light text-white">{mySkills.length}</p>
                <p className="text-xs text-gray-500 mt-1">Total Skills</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* My Skills List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-lg font-light text-white mb-6">My Skills ({mySkills.length})</h3>
              
              {mySkills.length === 0 ? (
                <div className="text-center py-12">
                  <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">No skills added yet</p>
                  <Button onClick={() => setShowAddDialog(true)} className="bg-white text-black hover:bg-gray-200">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Skill
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {mySkills.map((skill) => (
                    <div key={skill.id} className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-xl hover:border-white/10 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <p className="text-white font-medium">{skill.skill_name}</p>
                          <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400 uppercase">{skill.skill_category}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-gray-500">Current:</span>
                            <span className="text-emerald-400">{skill.current_proficiency}</span>
                          </div>
                          {skill.target_proficiency && skill.target_proficiency !== skill.current_proficiency && (
                            <div className="flex items-center gap-2">
                              <ArrowRight className="w-3 h-3 text-gray-500" />
                              <span className="text-amber-400">{skill.target_proficiency}</span>
                            </div>
                          )}
                          {skill.years_experience > 0 && (
                            <span className="text-xs text-gray-500">{skill.years_experience} years</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Skill Distribution Radar */}
              {mySkills.length > 0 && (
                <div className="mt-8">
                  <h4 className="text-sm text-gray-500 mb-4 uppercase tracking-widest">Skill Distribution</h4>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={categoryData.filter(c => c.count > 0)}>
                      <PolarGrid stroke={chartColors.grid} />
                      <PolarAngleAxis dataKey="category" tick={{ fill: '#a1a1aa', fontSize: 11 }} />
                      <PolarRadiusAxis tick={{ fill: '#525252', fontSize: 10 }} />
                      <Radar name="Skills" dataKey="count" stroke={chartColors.stroke} fill={chartColors.fill} strokeWidth={2} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Development Paths */}
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-sm text-gray-500 uppercase tracking-widest mb-4">Development Paths</h3>
              {developmentPaths.length === 0 ? (
                <div className="text-center py-8">
                  <Target className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-sm text-gray-500 mb-3">No paths yet</p>
                  <Button size="sm" onClick={() => setShowPathDialog(true)} className="bg-white text-black hover:bg-gray-200 text-xs">
                    Generate Path
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {developmentPaths.map((path) => (
                    <Link key={path.id} to={createPageUrl("SkillDevelopmentPath") + `?path=${path.id}`}>
                      <div className="p-4 bg-white/5 border border-white/5 rounded-xl hover:border-amber-500/30 transition-colors cursor-pointer">
                        <p className="text-white font-medium text-sm">{path.path_name}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className={`text-[10px] px-2 py-0.5 rounded ${
                            path.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-gray-400'
                          }`}>{path.status}</span>
                          <span className="text-[10px] text-gray-500">{path.timeline}</span>
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-xs text-gray-500">
                            {path.skill_gaps?.length || 0} gaps • {path.recommended_actions?.length || 0} actions
                          </span>
                          <ArrowRight className="w-4 h-4 text-amber-400" />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Role Requirements */}
            <div className="glass-panel rounded-2xl p-6">
              <h3 className="text-sm text-gray-500 uppercase tracking-widest mb-4">Role Requirements</h3>
              <div className="space-y-2">
                {roleRequirements.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No requirements defined for your role
                  </p>
                ) : (
                  roleRequirements.map((req) => {
                    const hasSkill = mySkills.find(us => us.skill_id === req.skill_id);
                    const order = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
                    const meetsReq = hasSkill && order.indexOf(hasSkill.current_proficiency) >= order.indexOf(req.required_proficiency);

                    return (
                      <div key={req.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div className="flex-1">
                          <p className="text-sm text-white">{req.skill_name}</p>
                          <p className="text-xs text-gray-500">Required: {req.required_proficiency}</p>
                        </div>
                        {meetsReq ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-amber-400" />
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Add Skill Dialog */}
        <Dialog open={showAddDialog} onOpenChange={(open) => { setShowAddDialog(open); if (!open) resetSkillForm(); }}>
          <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-white">Add Skill</DialogTitle>
              <DialogDescription className="text-gray-500">Add an existing skill or create a custom one</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {/* Skill Selection */}
              {!isAddingCustomSkill ? (
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <Input
                      value={skillSearchTerm}
                      onChange={(e) => setSkillSearchTerm(e.target.value)}
                      placeholder="Search skills..."
                      className="pl-10 bg-black border-white/10 text-white"
                    />
                  </div>
                  
                  {/* Skill List */}
                  <div className="max-h-48 overflow-y-auto border border-white/10 rounded-lg">
                    {filteredSkills.length > 0 ? (
                      filteredSkills.slice(0, 20).map(skill => (
                        <div
                          key={skill.id}
                          onClick={() => handleSelectSkill(skill.id)}
                          className={`p-3 cursor-pointer hover:bg-white/5 flex justify-between items-center ${
                            newUserSkill.skill_id === skill.id ? 'bg-emerald-500/10 border-l-2 border-emerald-500' : ''
                          }`}
                        >
                          <div>
                            <p className="text-white text-sm">{skill.name}</p>
                            <p className="text-xs text-gray-500">{skill.category}</p>
                          </div>
                          {newUserSkill.skill_id === skill.id && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-gray-500 text-sm">
                        No skills found matching "{skillSearchTerm}"
                      </div>
                    )}
                  </div>

                  {/* Add Custom Option */}
                  <Button
                    variant="outline"
                    onClick={() => setIsAddingCustomSkill(true)}
                    className="w-full border-dashed border-white/20 text-gray-400 hover:bg-white/5 hover:text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Custom Skill
                  </Button>
                </div>
              ) : (
                /* Custom Skill Form */
                <div className="space-y-3 p-4 bg-white/5 rounded-lg border border-white/10">
                  <p className="text-sm text-gray-400">Create a new skill</p>
                  <Input
                    value={customSkillName}
                    onChange={(e) => setCustomSkillName(e.target.value)}
                    placeholder="Skill name (e.g., 'React Development')"
                    className="bg-black border-white/10 text-white"
                  />
                  <Select value={customSkillCategory} onValueChange={setCustomSkillCategory}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {skillCategories.map(cat => (
                        <SelectItem key={cat} value={cat} className="text-white hover:bg-white/5 capitalize">
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setIsAddingCustomSkill(false)} className="flex-1 border-white/10 text-gray-400">
                      Cancel
                    </Button>
                    <Button onClick={handleAddCustomSkill} disabled={!customSkillName.trim()} className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-black">
                      Create Skill
                    </Button>
                  </div>
                </div>
              )}

              {/* Selected Skill Display */}
              {newUserSkill.skill_name && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                  <p className="text-sm text-emerald-400">Selected: <span className="text-white">{newUserSkill.skill_name}</span></p>
                </div>
              )}

              {/* Proficiency Selection */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Current Level</label>
                  <Select value={newUserSkill.current_proficiency} onValueChange={(v) => setNewUserSkill({ ...newUserSkill, current_proficiency: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {['Beginner', 'Intermediate', 'Advanced', 'Expert'].map(level => (
                        <SelectItem key={level} value={level} className="text-white hover:bg-white/5">{level}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Target Level</label>
                  <Select value={newUserSkill.target_proficiency} onValueChange={(v) => setNewUserSkill({ ...newUserSkill, target_proficiency: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {['Beginner', 'Intermediate', 'Advanced', 'Expert'].map(level => (
                        <SelectItem key={level} value={level} className="text-white hover:bg-white/5">{level}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Years of Experience</label>
                <Input
                  type="number"
                  value={newUserSkill.years_experience}
                  onChange={(e) => setNewUserSkill({ ...newUserSkill, years_experience: parseFloat(e.target.value) || 0 })}
                  placeholder="0"
                  min="0"
                  step="0.5"
                  className="bg-black border-white/10 text-white"
                />
              </div>

              <div>
                <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Notes (Optional)</label>
                <Textarea
                  value={newUserSkill.notes}
                  onChange={(e) => setNewUserSkill({ ...newUserSkill, notes: e.target.value })}
                  placeholder="Add context, examples, or certifications..."
                  rows={2}
                  className="bg-black border-white/10 text-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)} className="border-white/10 text-gray-400 hover:bg-white/5">
                  Cancel
                </Button>
                <Button onClick={handleAddSkill} disabled={!newUserSkill.skill_id} className="bg-white text-black hover:bg-gray-200">
                  Add Skill
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Generate Path Dialog */}
        <Dialog open={showPathDialog} onOpenChange={setShowPathDialog}>
          <DialogContent className="bg-[#0a0a0a] border-white/10 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">Generate Development Path</DialogTitle>
              <DialogDescription className="text-gray-500">AI will create a personalized learning roadmap</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Target Role</label>
                <Input
                  value={pathGoal.target_role}
                  onChange={(e) => setPathGoal({ ...pathGoal, target_role: e.target.value })}
                  placeholder="e.g., Senior Engineer, Team Lead"
                  className="bg-black border-white/10 text-white"
                />
              </div>

              <div>
                <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Timeline</label>
                <Select value={pathGoal.timeline} onValueChange={(v) => setPathGoal({ ...pathGoal, timeline: v })}>
                  <SelectTrigger className="bg-black border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-white/10">
                    <SelectItem value="3 months" className="text-white hover:bg-white/5">3 Months</SelectItem>
                    <SelectItem value="6 months" className="text-white hover:bg-white/5">6 Months</SelectItem>
                    <SelectItem value="1 year" className="text-white hover:bg-white/5">1 Year</SelectItem>
                    <SelectItem value="2 years" className="text-white hover:bg-white/5">2 Years</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <p className="text-sm text-amber-400 mb-2">AI will analyze:</p>
                <ul className="text-xs text-gray-400 space-y-1">
                  <li>• Your current skills and proficiency levels</li>
                  <li>• Requirements for your target role</li>
                  <li>• Identified skill gaps</li>
                  <li>• Your career goals and timeline</li>
                </ul>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <Button variant="outline" onClick={() => setShowPathDialog(false)} className="border-white/10 text-gray-400 hover:bg-white/5">
                  Cancel
                </Button>
                <Button 
                  onClick={generateDevelopmentPath} 
                  disabled={!pathGoal.target_role || isGeneratingPath}
                  className="bg-white text-black hover:bg-gray-200"
                >
                  {isGeneratingPath ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                  ) : (
                    <><Sparkles className="w-4 h-4 mr-2" /> Generate Path</>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}