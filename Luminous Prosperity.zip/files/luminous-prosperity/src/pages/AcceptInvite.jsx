import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Building2, Mail, Briefcase, Users, CheckCircle2, AlertCircle } from "lucide-react";

export default function AcceptInvite() {
  const navigate = useNavigate();
  const [inviteCode, setInviteCode] = useState("");
  const [fullName, setFullName] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    if (code) {
      setInviteCode(code);
    }
  }, []);

  const { data: invite, isLoading, error } = useQuery({
    queryKey: ['invite', inviteCode],
    queryFn: async () => {
      if (!inviteCode) return null;
      const invites = await base44.entities.OrganizationInvite.filter({ invite_code: inviteCode });
      return invites[0];
    },
    enabled: !!inviteCode,
  });

  const { data: organization } = useQuery({
    queryKey: ['inviteOrg', invite?.organization_id],
    queryFn: () => base44.entities.Organization.filter({ id: invite.organization_id }),
    enabled: !!invite?.organization_id,
  });

  const acceptMutation = useMutation({
    mutationFn: async () => {
      const user = await base44.auth.me();
      
      // Update user with organization details
      await base44.auth.updateMe({
        organization_id: invite.organization_id,
        user_role: invite.role,
        department: invite.department,
        job_title: invite.job_title,
        full_name: fullName || user.full_name,
      });

      // Mark invite as accepted
      await base44.entities.OrganizationInvite.update(invite.id, {
        status: 'accepted',
        accepted_at: new Date().toISOString(),
      });

      // Update subscription seat count
      const subs = await base44.entities.Subscription.filter({ organization_id: invite.organization_id });
      if (subs.length > 0) {
        const sub = subs[0];
        await base44.entities.Subscription.update(sub.id, {
          seats_used: (sub.seats_used || 0) + 1,
        });
      }

      return true;
    },
    onSuccess: () => {
      alert('Welcome! Your account has been set up.');
      navigate(createPageUrl("EmployeePortal"));
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading invitation...</p>
      </div>
    );
  }

  if (!invite || invite.status !== 'pending') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <AlertCircle className="w-8 h-8 text-red-500" />
              <CardTitle>Invalid or Expired Invitation</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-stone-600 mb-4">
              This invitation link is invalid or has already been used.
            </p>
            <Button onClick={() => window.location.href = '/'}>
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const org = organization?.[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20 flex items-center justify-center p-6">
      <Card className="max-w-2xl w-full">
        <CardHeader>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-xl flex items-center justify-center">
              <Building2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl">You're Invited!</CardTitle>
              <CardDescription>Join {org?.name || 'the organization'} on Luminous Prosperity</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4 p-4 bg-stone-50 rounded-lg">
            <div>
              <p className="text-xs text-stone-600 mb-1">Organization</p>
              <p className="font-semibold">{org?.name}</p>
            </div>
            <div>
              <p className="text-xs text-stone-600 mb-1">Your Email</p>
              <p className="font-semibold">{invite.email}</p>
            </div>
            <div>
              <p className="text-xs text-stone-600 mb-1">Role</p>
              <Badge className="capitalize">{invite.role.replace('_', ' ')}</Badge>
            </div>
            {invite.department && (
              <div>
                <p className="text-xs text-stone-600 mb-1">Department</p>
                <p className="font-semibold">{invite.department}</p>
              </div>
            )}
            {invite.job_title && (
              <div className="md:col-span-2">
                <p className="text-xs text-stone-600 mb-1">Job Title</p>
                <p className="font-semibold">{invite.job_title}</p>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Your Full Name</label>
            <Input
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="John Doe"
            />
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-sm text-amber-900">
              <strong>What happens next?</strong>
              <ul className="mt-2 space-y-1 text-xs">
                <li>✓ Your account will be linked to {org?.name}</li>
                <li>✓ You'll gain access to organizational features</li>
                <li>✓ You can start your assessment journey</li>
                <li>✓ Join your team's collaborative insights</li>
              </ul>
            </p>
          </div>

          <Button
            onClick={() => acceptMutation.mutate()}
            disabled={acceptMutation.isLoading || !fullName}
            className="w-full bg-gradient-to-r from-[#B8967D] to-[#A68364] text-lg py-6"
          >
            {acceptMutation.isLoading ? (
              'Setting up your account...'
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 mr-2" />
                Accept Invitation & Join
              </>
            )}
          </Button>

          <p className="text-xs text-center text-stone-500">
            Invited by {invite.invited_by} • Expires {new Date(invite.expires_at).toLocaleDateString()}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}