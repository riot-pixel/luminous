import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  FileText, Plus, Download, Send, Sparkles, BarChart3, 
  PieChart, LineChart as LineChartIcon, Table, Calendar as CalendarIcon,
  Filter, Play, Save, Trash2, Copy, Clock, CheckCircle2
} from "lucide-react";
import { 
  BarChart, Bar, LineChart, Line, PieChart as RechartsPie, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { format } from "date-fns";

const REPORT_TYPES = [
  { value: "leadership_evolution", label: "Leadership Evolution", color: "#8b5cf6" },
  { value: "brand_alchemy", label: "Brand Alchemy", color: "#ec4899" },
  { value: "wellness", label: "Wellness Companion", color: "#10b981" },
  { value: "impact_ledger", label: "Impact Ledger", color: "#f59e0b" },
  { value: "ecosystem", label: "Ecosystem Network", color: "#3b82f6" },
  { value: "skills", label: "Skills & Development", color: "#06b6d4" },
  { value: "assessments", label: "Assessments", color: "#8b5cf6" },
  { value: "custom", label: "Custom Report", color: "#6b7280" }
];

const DATA_SOURCES = [
  { id: "LeadershipEvolution", label: "Leadership Evolution" },
  { id: "WellnessLog", label: "Wellness Logs" },
  { id: "ContributionRecord", label: "Impact Contributions" },
  { id: "Assessment", label: "Assessments" },
  { id: "UserSkill", label: "User Skills" },
  { id: "Team", label: "Teams" },
  { id: "SharedChallenge", label: "Ecosystem Challenges" },
  { id: "CollaborativeProject", label: "Collaborative Projects" }
];

const CHART_COLORS = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ec4899", "#06b6d4"];

export default function CustomReportBuilder() {
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedReport, setGeneratedReport] = useState(null);
  const [newReport, setNewReport] = useState({
    name: "",
    description: "",
    report_type: "",
    data_sources: [],
    date_range: { start: null, end: null }
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: reports } = useQuery({
    queryKey: ['customReports'],
    queryFn: () => base44.entities.CustomReport.list('-created_date'),
    initialData: [],
  });

  const { data: myReports } = useQuery({
    queryKey: ['myReports', user?.email],
    queryFn: () => base44.entities.CustomReport.filter({ created_by: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const createReportMutation = useMutation({
    mutationFn: (data) => base44.entities.CustomReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customReports'] });
      queryClient.invalidateQueries({ queryKey: ['myReports'] });
      setShowCreateDialog(false);
    },
  });

  const updateReportMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CustomReport.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customReports'] });
    },
  });

  const toggleDataSource = (sourceId) => {
    setNewReport(prev => ({
      ...prev,
      data_sources: prev.data_sources.includes(sourceId)
        ? prev.data_sources.filter(s => s !== sourceId)
        : [...prev.data_sources, sourceId]
    }));
  };

  const createReport = async () => {
    await createReportMutation.mutateAsync({
      name: newReport.name,
      description: newReport.description,
      report_type: newReport.report_type,
      data_sources: newReport.data_sources,
      filters: {
        date_range: newReport.date_range
      },
      created_by: user.email,
      status: "draft"
    });
    setNewReport({ name: "", description: "", report_type: "", data_sources: [], date_range: { start: null, end: null } });
  };

  const generateReport = async (report) => {
    setIsGenerating(true);
    setSelectedReport(report);
    
    try {
      // Fetch data from selected sources
      const dataPromises = (report.data_sources || []).map(async (source) => {
        try {
          const data = await base44.entities[source].list('-created_date', 100);
          return { source, data };
        } catch (e) {
          return { source, data: [] };
        }
      });
      
      const allData = await Promise.all(dataPromises);
      const dataContext = allData.reduce((acc, { source, data }) => {
        acc[source] = data.length;
        return acc;
      }, {});

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a comprehensive business report based on this data context:

REPORT: ${report.name}
TYPE: ${report.report_type}
DESCRIPTION: ${report.description}

DATA SOURCES & COUNTS:
${Object.entries(dataContext).map(([source, count]) => `- ${source}: ${count} records`).join('\n')}

Generate:
1. Executive summary (3-4 sentences)
2. 5-8 key findings with specific insights
3. 4-6 actionable recommendations with priority levels
4. Suggested visualizations with sample data
5. Areas requiring attention

Be specific, data-driven, and actionable.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            key_findings: { type: "array", items: { type: "string" } },
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  recommendation: { type: "string" },
                  priority: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            visualizations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  type: { type: "string" },
                  data: { type: "array", items: { type: "object" } }
                }
              }
            },
            attention_areas: { type: "array", items: { type: "string" } }
          }
        }
      });

      setGeneratedReport(result);
      
      // Save generated content to report
      await updateReportMutation.mutateAsync({
        id: report.id,
        data: { 
          generated_content: result,
          last_generated: new Date().toISOString(),
          status: "active"
        }
      });
    } catch (error) {
      console.error("Error generating report:", error);
    }
    setIsGenerating(false);
  };

  const exportReport = (format) => {
    if (!generatedReport) return;
    
    if (format === 'csv') {
      const csvContent = [
        ["Key Findings"],
        ...generatedReport.key_findings.map(f => [f]),
        [""],
        ["Recommendations", "Priority", "Impact"],
        ...generatedReport.recommendations.map(r => [r.recommendation, r.priority, r.impact])
      ].map(row => row.join(",")).join("\n");
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedReport?.name || 'report'}_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      a.click();
    } else {
      // For PDF, we'd typically use a library, but we'll do a simple text export
      const textContent = `
${selectedReport?.name || 'Report'}
Generated: ${format(new Date(), 'PPP')}

EXECUTIVE SUMMARY
${generatedReport.summary}

KEY FINDINGS
${generatedReport.key_findings.map((f, i) => `${i + 1}. ${f}`).join('\n')}

RECOMMENDATIONS
${generatedReport.recommendations.map((r, i) => `${i + 1}. [${r.priority}] ${r.recommendation} - Impact: ${r.impact}`).join('\n')}

ATTENTION AREAS
${generatedReport.attention_areas?.map((a, i) => `${i + 1}. ${a}`).join('\n') || 'None identified'}
      `;
      
      const blob = new Blob([textContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedReport?.name || 'report'}_${format(new Date(), 'yyyy-MM-dd')}.txt`;
      a.click();
    }
  };

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Custom Report Builder</h1>
            <p className="text-gray-400">Create and generate custom reports across all platform features</p>
          </div>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" />
                New Report
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
              <DialogHeader>
                <DialogTitle>Create Custom Report</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Report Type</label>
                  <Select value={newReport.report_type} onValueChange={(v) => setNewReport({...newReport, report_type: v})}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {REPORT_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Report Name</label>
                  <Input
                    value={newReport.name}
                    onChange={(e) => setNewReport({...newReport, name: e.target.value})}
                    placeholder="Q4 Leadership Progress Report"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Description</label>
                  <Textarea
                    value={newReport.description}
                    onChange={(e) => setNewReport({...newReport, description: e.target.value})}
                    placeholder="What should this report cover?"
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Data Sources</label>
                  <div className="grid grid-cols-2 gap-2">
                    {DATA_SOURCES.map(source => (
                      <div
                        key={source.id}
                        onClick={() => toggleDataSource(source.id)}
                        className={`p-2 rounded border cursor-pointer text-sm transition-all ${
                          newReport.data_sources.includes(source.id)
                            ? 'bg-purple-900/50 border-purple-600 text-purple-200'
                            : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-600'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {newReport.data_sources.includes(source.id) && <CheckCircle2 className="w-3 h-3" />}
                          {source.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <Button 
                  onClick={createReport} 
                  disabled={!newReport.name || !newReport.report_type}
                  className="w-full bg-white text-black hover:bg-gray-200"
                >
                  Create Report
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Report List */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">My Reports</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {myReports?.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No reports yet</p>
                ) : (
                  myReports?.map(report => {
                    const typeConfig = REPORT_TYPES.find(t => t.value === report.report_type);
                    return (
                      <div
                        key={report.id}
                        onClick={() => setSelectedReport(report)}
                        className={`p-4 rounded-lg border cursor-pointer transition-all ${
                          selectedReport?.id === report.id
                            ? 'bg-purple-900/30 border-purple-600'
                            : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="text-white font-medium">{report.name}</h4>
                            <Badge 
                              className="mt-1"
                              style={{ backgroundColor: typeConfig?.color || '#6b7280' }}
                            >
                              {typeConfig?.label || report.report_type}
                            </Badge>
                          </div>
                          <Badge className={report.status === 'active' ? 'bg-green-600' : 'bg-gray-600'}>
                            {report.status}
                          </Badge>
                        </div>
                        {report.last_generated && (
                          <p className="text-gray-500 text-xs mt-2">
                            <Clock className="w-3 h-3 inline mr-1" />
                            Generated {format(new Date(report.last_generated), 'PP')}
                          </p>
                        )}
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>

            {/* Report Templates */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-lg">Quick Templates</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {REPORT_TYPES.slice(0, 5).map(type => (
                  <Button 
                    key={type.value}
                    variant="outline" 
                    className="w-full justify-start border-gray-700 text-gray-300 hover:bg-gray-800"
                    onClick={() => {
                      setNewReport({
                        name: `${type.label} Report`,
                        description: `Automated ${type.label.toLowerCase()} analysis report`,
                        report_type: type.value,
                        data_sources: [],
                        date_range: { start: null, end: null }
                      });
                      setShowCreateDialog(true);
                    }}
                  >
                    <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: type.color }} />
                    {type.label}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Report Builder / Viewer */}
          <div className="lg:col-span-2">
            {selectedReport ? (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="border-b border-gray-800">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-white">{selectedReport.name}</CardTitle>
                      <CardDescription className="text-gray-400 mt-1">{selectedReport.description}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => generateReport(selectedReport)}
                        disabled={isGenerating}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {isGenerating ? (
                          <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                        ) : (
                          <><Play className="w-4 h-4 mr-2" /> Generate</>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {generatedReport || selectedReport.generated_content ? (
                    <div className="space-y-6">
                      {/* Export Buttons */}
                      <div className="flex gap-2 justify-end">
                        <Button size="sm" variant="outline" onClick={() => exportReport('csv')} className="border-gray-700 text-gray-300">
                          <Download className="w-4 h-4 mr-1" /> CSV
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => exportReport('pdf')} className="border-gray-700 text-gray-300">
                          <Download className="w-4 h-4 mr-1" /> PDF
                        </Button>
                        <Button size="sm" variant="outline" className="border-gray-700 text-gray-300">
                          <Send className="w-4 h-4 mr-1" /> Email
                        </Button>
                      </div>

                      {/* Summary */}
                      <div className="p-4 bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-lg border border-purple-800">
                        <h3 className="text-purple-300 text-sm font-medium mb-2">EXECUTIVE SUMMARY</h3>
                        <p className="text-gray-200">{(generatedReport || selectedReport.generated_content)?.summary}</p>
                      </div>

                      {/* Key Findings */}
                      <div>
                        <h3 className="text-white font-medium mb-3">Key Findings</h3>
                        <div className="space-y-2">
                          {(generatedReport || selectedReport.generated_content)?.key_findings?.map((finding, i) => (
                            <div key={i} className="flex items-start gap-3 p-3 bg-gray-800 rounded-lg">
                              <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                                {i + 1}
                              </div>
                              <p className="text-gray-300 text-sm">{finding}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Visualizations */}
                      {(generatedReport || selectedReport.generated_content)?.visualizations?.length > 0 && (
                        <div>
                          <h3 className="text-white font-medium mb-3">Visualizations</h3>
                          <div className="grid md:grid-cols-2 gap-4">
                            {(generatedReport || selectedReport.generated_content)?.visualizations?.slice(0, 4).map((viz, i) => (
                              <Card key={i} className="bg-gray-800 border-gray-700">
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-sm text-gray-300">{viz.title}</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  {viz.data && viz.data.length > 0 && (
                                    <ResponsiveContainer width="100%" height={150}>
                                      <BarChart data={viz.data}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                        <XAxis dataKey="name" stroke="#666" tick={{ fontSize: 10 }} />
                                        <YAxis stroke="#666" tick={{ fontSize: 10 }} />
                                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                                        <Bar dataKey="value" fill={CHART_COLORS[i % CHART_COLORS.length]} />
                                      </BarChart>
                                    </ResponsiveContainer>
                                  )}
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Recommendations */}
                      <div>
                        <h3 className="text-white font-medium mb-3">Recommendations</h3>
                        <div className="space-y-3">
                          {(generatedReport || selectedReport.generated_content)?.recommendations?.map((rec, i) => (
                            <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-purple-600">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge className={
                                  rec.priority === 'high' ? 'bg-red-600' :
                                  rec.priority === 'medium' ? 'bg-yellow-600' : 'bg-green-600'
                                }>
                                  {rec.priority}
                                </Badge>
                                <span className="text-gray-500 text-xs">Impact: {rec.impact}</span>
                              </div>
                              <p className="text-gray-200">{rec.recommendation}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Attention Areas */}
                      {(generatedReport || selectedReport.generated_content)?.attention_areas?.length > 0 && (
                        <div className="p-4 bg-red-900/20 rounded-lg border border-red-800">
                          <h3 className="text-red-300 text-sm font-medium mb-2">AREAS REQUIRING ATTENTION</h3>
                          <ul className="space-y-1">
                            {(generatedReport || selectedReport.generated_content)?.attention_areas?.map((area, i) => (
                              <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                                <span className="text-red-400">•</span>
                                {area}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-20">
                      <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">Click "Generate" to create this report</p>
                      <p className="text-gray-500 text-sm mt-2">
                        Data sources: {selectedReport.data_sources?.join(', ') || 'None selected'}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-gray-900 border-gray-800 h-full flex items-center justify-center">
                <div className="text-center py-20">
                  <BarChart3 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Select a report to view or generate</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}