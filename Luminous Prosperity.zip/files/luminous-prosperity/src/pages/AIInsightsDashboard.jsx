import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, Sparkles, TrendingUp, TrendingDown, AlertTriangle, 
  Smile, Meh, Frown, RefreshCw, Target, Users, Heart,
  Lightbulb, Activity, BarChart3, PieChart as PieChartIcon,
  Eye, ChevronRight, Zap, Shield, Award, Globe
} from "lucide-react";
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { format, subDays } from "date-fns";

const SENTIMENT_COLORS = {
  positive: "#10b981",
  neutral: "#f59e0b",
  negative: "#ef4444"
};

const CHART_COLORS = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ec4899", "#06b6d4"];

export default function AIInsightsDashboard() {
  const queryClient = useQueryClient();
  const [period, setPeriod] = useState("weekly");
  const [isAggregating, setIsAggregating] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: insights } = useQuery({
    queryKey: ['aiInsights', period],
    queryFn: () => base44.entities.AIInsightAggregate.filter({ period }, '-aggregation_date', 10),
    initialData: [],
  });

  const { data: wellnessLogs } = useQuery({
    queryKey: ['allWellnessLogs'],
    queryFn: () => base44.entities.WellnessLog.list('-log_date', 500),
    initialData: [],
  });

  const { data: contributions } = useQuery({
    queryKey: ['allContributions'],
    queryFn: () => base44.entities.ContributionRecord.list('-contribution_date', 500),
    initialData: [],
  });

  const { data: leadershipEvolutions } = useQuery({
    queryKey: ['leadershipEvolutions'],
    queryFn: () => base44.entities.LeadershipEvolution.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessmentsForInsights'],
    queryFn: () => base44.entities.Assessment.list('-completed_date', 200),
    initialData: [],
  });

  const { data: challenges } = useQuery({
    queryKey: ['allChallenges'],
    queryFn: () => base44.entities.SharedChallenge.list(),
    initialData: [],
  });

  const createInsightMutation = useMutation({
    mutationFn: (data) => base44.entities.AIInsightAggregate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['aiInsights'] });
    },
  });

  const aggregateInsights = async () => {
    setIsAggregating(true);
    try {
      // Calculate wellness metrics
      const avgMood = wellnessLogs.length > 0 
        ? wellnessLogs.reduce((s, l) => s + (l.mood_score || 5), 0) / wellnessLogs.length 
        : 0;
      const avgEnergy = wellnessLogs.length > 0 
        ? wellnessLogs.reduce((s, l) => s + (l.energy_level || 5), 0) / wellnessLogs.length 
        : 0;
      const avgStress = wellnessLogs.length > 0 
        ? wellnessLogs.reduce((s, l) => s + (l.stress_level || 5), 0) / wellnessLogs.length 
        : 0;

      // Calculate impact metrics
      const totalContributions = contributions.length;
      const totalPoints = contributions.reduce((s, c) => s + (c.final_points || 0), 0);
      const categoryCount = contributions.reduce((acc, c) => {
        const cat = c.impact_unit_name || 'other';
        acc[cat] = (acc[cat] || 0) + 1;
        return acc;
      }, {});
      const topCategories = Object.entries(categoryCount)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([cat]) => cat);

      // Leadership evolution stages
      const stageDistribution = leadershipEvolutions.reduce((acc, l) => {
        const stage = l.evolution_stage || 'reactive';
        acc[stage] = (acc[stage] || 0) + 1;
        return acc;
      }, {});

      // Aggregate themes from contributions
      const allThemes = contributions
        .flatMap(c => c.ai_analysis?.themes || [])
        .reduce((acc, theme) => {
          acc[theme] = (acc[theme] || 0) + 1;
          return acc;
        }, {});
      
      const recurringThemes = Object.entries(allThemes)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([theme, freq]) => ({ theme, frequency: freq, sources: ['contributions'], sentiment: 'neutral', trend: 'stable' }));

      // Generate AI recommendations
      const aiAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this organizational data and provide strategic recommendations:

WELLNESS METRICS:
- Average Mood: ${avgMood.toFixed(1)}/10
- Average Energy: ${avgEnergy.toFixed(1)}/10
- Average Stress: ${avgStress.toFixed(1)}/10
- Total Wellness Logs: ${wellnessLogs.length}

IMPACT METRICS:
- Total Contributions: ${totalContributions}
- Total Impact Points: ${totalPoints}
- Top Categories: ${topCategories.join(', ')}

LEADERSHIP EVOLUTION:
${Object.entries(stageDistribution).map(([stage, count]) => `- ${stage}: ${count} leaders`).join('\n')}

RECURRING THEMES:
${recurringThemes.slice(0, 5).map(t => `- ${t.theme}: ${t.frequency} occurrences`).join('\n')}

ECOSYSTEM:
- Open Challenges: ${challenges.filter(c => c.status === 'open').length}
- Total Assessments: ${assessments.length}

Provide:
1. Overall sentiment assessment
2. 5 strategic recommendations with priority and impact area
3. Any anomalies or concerns detected
4. Specific actions for each insight area`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_sentiment: { type: "string" },
            sentiment_score: { type: "number" },
            strategic_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  recommendation: { type: "string" },
                  priority: { type: "string" },
                  impact_area: { type: "string" },
                  supporting_data: { type: "array", items: { type: "string" } }
                }
              }
            },
            anomalies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  description: { type: "string" },
                  severity: { type: "string" },
                  recommended_action: { type: "string" }
                }
              }
            }
          }
        }
      });

      // Create insight aggregate
      await createInsightMutation.mutateAsync({
        aggregation_date: new Date().toISOString(),
        period,
        sentiment_analysis: {
          overall_sentiment: aiAnalysis.overall_sentiment,
          sentiment_score: aiAnalysis.sentiment_score,
          positive_count: wellnessLogs.filter(l => (l.mood_score || 5) >= 7).length,
          neutral_count: wellnessLogs.filter(l => (l.mood_score || 5) >= 4 && (l.mood_score || 5) < 7).length,
          negative_count: wellnessLogs.filter(l => (l.mood_score || 5) < 4).length,
          trend: avgMood > 6 ? 'improving' : avgMood < 4 ? 'declining' : 'stable'
        },
        recurring_themes: recurringThemes,
        wellness_insights: {
          avg_mood: avgMood,
          avg_energy: avgEnergy,
          avg_stress: avgStress,
          engagement_rate: wellnessLogs.length > 0 ? 75 : 0
        },
        impact_insights: {
          total_contributions: totalContributions,
          total_points: totalPoints,
          top_categories: topCategories,
          ripple_effect_count: contributions.filter(c => c.ripple_effects?.length > 0).length
        },
        leadership_insights: {
          evolution_stages_distribution: stageDistribution,
          avg_progress: 45
        },
        strategic_recommendations: aiAnalysis.strategic_recommendations,
        anomalies_detected: aiAnalysis.anomalies,
        data_quality_score: 85
      });

    } catch (error) {
      console.error("Error aggregating insights:", error);
    }
    setIsAggregating(false);
  };

  const latestInsight = insights?.[0];
  
  // Prepare chart data
  const sentimentTrendData = insights?.slice(0, 7).reverse().map(i => ({
    date: format(new Date(i.aggregation_date), 'MMM d'),
    positive: i.sentiment_analysis?.positive_count || 0,
    neutral: i.sentiment_analysis?.neutral_count || 0,
    negative: i.sentiment_analysis?.negative_count || 0
  })) || [];

  const wellnessTrendData = insights?.slice(0, 7).reverse().map(i => ({
    date: format(new Date(i.aggregation_date), 'MMM d'),
    mood: i.wellness_insights?.avg_mood || 0,
    energy: i.wellness_insights?.avg_energy || 0,
    stress: i.wellness_insights?.avg_stress || 0
  })) || [];

  const themesData = latestInsight?.recurring_themes?.slice(0, 8).map(t => ({
    name: t.theme,
    value: t.frequency
  })) || [];

  const leadershipStageData = latestInsight?.leadership_insights?.evolution_stages_distribution
    ? Object.entries(latestInsight.leadership_insights.evolution_stages_distribution).map(([stage, count]) => ({
        name: stage,
        value: count
      }))
    : [];

  const getSentimentIcon = (sentiment) => {
    switch(sentiment) {
      case 'positive': return <Smile className="w-5 h-5 text-green-500" />;
      case 'neutral': return <Meh className="w-5 h-5 text-yellow-500" />;
      case 'negative': return <Frown className="w-5 h-5 text-red-500" />;
      default: return <Meh className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">AI Insights Dashboard</h1>
            <p className="text-gray-400">Aggregated intelligence from all platform AI analyses</p>
          </div>
          <div className="flex gap-3">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-32 bg-gray-900 border-gray-800 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={aggregateInsights}
              disabled={isAggregating}
              className="bg-white text-black hover:bg-gray-200"
            >
              {isAggregating ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><RefreshCw className="w-4 h-4 mr-2" /> Refresh Insights</>
              )}
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-purple-900 to-purple-950 border-purple-800">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-300 text-sm">Sentiment Score</p>
                  <p className="text-3xl font-bold text-white">
                    {latestInsight?.sentiment_analysis?.sentiment_score?.toFixed(0) || '--'}%
                  </p>
                </div>
                {getSentimentIcon(latestInsight?.sentiment_analysis?.overall_sentiment)}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900 to-green-950 border-green-800">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-300 text-sm">Avg Wellness</p>
                  <p className="text-3xl font-bold text-white">
                    {latestInsight?.wellness_insights?.avg_mood?.toFixed(1) || '--'}/10
                  </p>
                </div>
                <Heart className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900 to-blue-950 border-blue-800">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-sm">Total Impact</p>
                  <p className="text-3xl font-bold text-white">
                    {latestInsight?.impact_insights?.total_points?.toLocaleString() || '--'}
                  </p>
                </div>
                <Zap className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900 to-orange-950 border-orange-800">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-300 text-sm">Themes Tracked</p>
                  <p className="text-3xl font-bold text-white">
                    {latestInsight?.recurring_themes?.length || '--'}
                  </p>
                </div>
                <Lightbulb className="w-8 h-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-900 to-cyan-950 border-cyan-800">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-cyan-300 text-sm">Data Quality</p>
                  <p className="text-3xl font-bold text-white">
                    {latestInsight?.data_quality_score || '--'}%
                  </p>
                </div>
                <Shield className="w-8 h-8 text-cyan-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Anomalies Alert */}
        {latestInsight?.anomalies_detected?.length > 0 && (
          <Card className="bg-gradient-to-r from-red-900/30 to-orange-900/30 border-red-800 mb-6">
            <CardHeader>
              <CardTitle className="text-red-300 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Anomalies Detected ({latestInsight.anomalies_detected.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {latestInsight.anomalies_detected.map((anomaly, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 bg-gray-900 rounded-lg">
                    <Badge className={
                      anomaly.severity === 'high' ? 'bg-red-600' :
                      anomaly.severity === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'
                    }>
                      {anomaly.severity}
                    </Badge>
                    <div>
                      <p className="text-white font-medium">{anomaly.type}</p>
                      <p className="text-gray-400 text-sm">{anomaly.description}</p>
                      <p className="text-blue-400 text-xs mt-1">→ {anomaly.recommended_action}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="sentiment">Sentiment</TabsTrigger>
            <TabsTrigger value="themes">Themes</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            <TabsTrigger value="drilldown">Drill Down</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Sentiment Trend */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Sentiment Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={sentimentTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="date" stroke="#666" />
                      <YAxis stroke="#666" />
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                      <Legend />
                      <Area type="monotone" dataKey="positive" stackId="1" stroke={SENTIMENT_COLORS.positive} fill={SENTIMENT_COLORS.positive} fillOpacity={0.6} />
                      <Area type="monotone" dataKey="neutral" stackId="1" stroke={SENTIMENT_COLORS.neutral} fill={SENTIMENT_COLORS.neutral} fillOpacity={0.6} />
                      <Area type="monotone" dataKey="negative" stackId="1" stroke={SENTIMENT_COLORS.negative} fill={SENTIMENT_COLORS.negative} fillOpacity={0.6} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Wellness Metrics */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Wellness Metrics Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={wellnessTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="date" stroke="#666" />
                      <YAxis domain={[0, 10]} stroke="#666" />
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                      <Legend />
                      <Line type="monotone" dataKey="mood" stroke="#8b5cf6" strokeWidth={2} name="Mood" />
                      <Line type="monotone" dataKey="energy" stroke="#f59e0b" strokeWidth={2} name="Energy" />
                      <Line type="monotone" dataKey="stress" stroke="#ef4444" strokeWidth={2} name="Stress" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Recurring Themes */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Top Recurring Themes</CardTitle>
                </CardHeader>
                <CardContent>
                  {themesData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={themesData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                        <XAxis type="number" stroke="#666" />
                        <YAxis dataKey="name" type="category" stroke="#666" width={100} tick={{ fontSize: 11 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                        <Bar dataKey="value" fill="#8b5cf6" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center py-12 text-gray-500">No themes data available</div>
                  )}
                </CardContent>
              </Card>

              {/* Leadership Stages */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Leadership Evolution Stages</CardTitle>
                </CardHeader>
                <CardContent>
                  {leadershipStageData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={250}>
                      <PieChart>
                        <Pie
                          data={leadershipStageData}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={90}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {leadershipStageData.map((_, idx) => (
                            <Cell key={idx} fill={CHART_COLORS[idx % CHART_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center py-12 text-gray-500">No leadership data available</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sentiment">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Sentiment Analysis Deep Dive</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="p-6 bg-green-900/30 rounded-lg border border-green-800 text-center">
                    <Smile className="w-12 h-12 text-green-400 mx-auto mb-3" />
                    <p className="text-3xl font-bold text-white">{latestInsight?.sentiment_analysis?.positive_count || 0}</p>
                    <p className="text-green-300">Positive Signals</p>
                  </div>
                  <div className="p-6 bg-yellow-900/30 rounded-lg border border-yellow-800 text-center">
                    <Meh className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
                    <p className="text-3xl font-bold text-white">{latestInsight?.sentiment_analysis?.neutral_count || 0}</p>
                    <p className="text-yellow-300">Neutral Signals</p>
                  </div>
                  <div className="p-6 bg-red-900/30 rounded-lg border border-red-800 text-center">
                    <Frown className="w-12 h-12 text-red-400 mx-auto mb-3" />
                    <p className="text-3xl font-bold text-white">{latestInsight?.sentiment_analysis?.negative_count || 0}</p>
                    <p className="text-red-300">Negative Signals</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="themes">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Recurring Themes Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {latestInsight?.recurring_themes?.map((theme, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 bg-gray-800 rounded-lg">
                      <div className="w-10 h-10 rounded-lg bg-purple-900 flex items-center justify-center">
                        <Lightbulb className="w-5 h-5 text-purple-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium">{theme.theme}</p>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="text-xs border-gray-600 text-gray-400">
                            {theme.frequency} occurrences
                          </Badge>
                          <Badge className={
                            theme.trend === 'rising' ? 'bg-green-600' :
                            theme.trend === 'declining' ? 'bg-red-600' : 'bg-gray-600'
                          }>
                            {theme.trend}
                          </Badge>
                        </div>
                      </div>
                      <div className="w-32">
                        <Progress value={(theme.frequency / (latestInsight?.recurring_themes?.[0]?.frequency || 1)) * 100} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Strategic Recommendations</CardTitle>
                <CardDescription className="text-gray-400">AI-generated recommendations based on aggregated insights</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {latestInsight?.strategic_recommendations?.map((rec, i) => (
                    <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-purple-600">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={
                          rec.priority === 'high' ? 'bg-red-600' :
                          rec.priority === 'medium' ? 'bg-yellow-600' : 'bg-green-600'
                        }>
                          {rec.priority}
                        </Badge>
                        <Badge variant="outline" className="border-gray-600 text-gray-400">
                          {rec.impact_area}
                        </Badge>
                      </div>
                      <p className="text-white">{rec.recommendation}</p>
                      {rec.supporting_data?.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {rec.supporting_data.map((data, j) => (
                            <span key={j} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{data}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )) || (
                    <div className="text-center py-12 text-gray-500">
                      Click "Refresh Insights" to generate recommendations
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="drilldown">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { title: "Wellness Data", icon: Heart, count: wellnessLogs.length, color: "green" },
                { title: "Impact Contributions", icon: Zap, count: contributions.length, color: "blue" },
                { title: "Leadership Profiles", icon: Award, count: leadershipEvolutions.length, color: "purple" },
                { title: "Assessments", icon: Target, count: assessments.length, color: "orange" },
                { title: "Ecosystem Challenges", icon: Globe, count: challenges.length, color: "cyan" }
              ].map((item, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800 hover:border-gray-700 cursor-pointer transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">{item.title}</p>
                        <p className="text-3xl font-bold text-white mt-1">{item.count}</p>
                        <p className="text-gray-500 text-xs mt-1">records available</p>
                      </div>
                      <item.icon className={`w-10 h-10 text-${item.color}-400`} />
                    </div>
                    <Button variant="ghost" className="w-full mt-4 text-gray-400 hover:text-white">
                      <Eye className="w-4 h-4 mr-2" /> View Details
                      <ChevronRight className="w-4 h-4 ml-auto" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}