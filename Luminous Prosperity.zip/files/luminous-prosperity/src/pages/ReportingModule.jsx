import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  FileText, Plus, Download, Calendar, Clock, BarChart3, Users, Target,
  TrendingUp, Brain, Settings, Play, Trash2, Edit, RefreshCw, FileDown, ClipboardCheck
} from "lucide-react";

export default function ReportingModule() {
  const [isCreating, setIsCreating] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [generatingReport, setGeneratingReport] = useState(null);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [newReport, setNewReport] = useState({
    name: "",
    description: "",
    report_type: "custom",
    data_sources: [],
    metrics: [],
    schedule: { frequency: "manual", enabled: false },
    filters: {}
  });

  const queryClient = useQueryClient();

  const { data: reports } = useQuery({
    queryKey: ['customReports'],
    queryFn: () => base44.entities.CustomReport.list('-created_date'),
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const createReportMutation = useMutation({
    mutationFn: (data) => base44.entities.CustomReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customReports'] });
      setIsCreating(false);
      setNewReport({ name: "", description: "", report_type: "custom", data_sources: [], metrics: [], schedule: { frequency: "manual", enabled: false }, filters: {} });
    }
  });

  const deleteReportMutation = useMutation({
    mutationFn: (id) => base44.entities.CustomReport.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['customReports'] })
  });

  const reportTypes = [
    { value: "performance", label: "Employee Performance", icon: TrendingUp },
    { value: "performance_reviews", label: "Performance Reviews", icon: ClipboardCheck },
    { value: "team_dynamics", label: "Team Dynamics", icon: Users },
    { value: "skills", label: "Skill Gaps Analysis", icon: Target },
    { value: "growth", label: "Growth Trajectories", icon: BarChart3 },
    { value: "wellness", label: "Wellness Overview", icon: Brain },
    { value: "custom", label: "Custom Report", icon: FileText },
  ];

  const dataSources = [
    { id: "assessments", label: "Assessments" },
    { id: "skills", label: "User Skills" },
    { id: "coaching", label: "Coaching Sessions" },
    { id: "learning", label: "Learning Journeys" },
    { id: "wellness", label: "Wellness Logs" },
    { id: "teams", label: "Teams" },
    { id: "performance_reviews", label: "Performance Reviews" },
  ];

  const metrics = [
    { id: "avg_fulfillment", label: "Average Fulfillment Score" },
    { id: "avg_operational", label: "Average Operational Score" },
    { id: "skill_coverage", label: "Skill Coverage %" },
    { id: "skill_gaps", label: "Critical Skill Gaps" },
    { id: "high_performers", label: "High Performers Count" },
    { id: "at_risk", label: "At-Risk Employees" },
    { id: "learning_completion", label: "Learning Completion Rate" },
    { id: "coaching_progress", label: "Coaching Progress" },
  ];

  const generateReport = async (report) => {
    setGeneratingReport(report.id);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a comprehensive ${report.report_type} report based on the following configuration:
        
Report Name: ${report.name}
Description: ${report.description}
Data Sources: ${report.data_sources?.join(', ') || 'All available'}
Metrics: ${report.metrics?.map(m => m.metric_name).join(', ') || 'Standard metrics'}

Generate a detailed report with:
1. Executive Summary
2. Key Findings (5-7 bullet points)
3. Detailed Analysis by category
4. Recommendations (prioritized)
5. Action Items with owners and timelines
6. Risk Assessment
7. Trend Analysis`,
        response_json_schema: {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            key_findings: { type: "array", items: { type: "string" } },
            detailed_analysis: { type: "array", items: { type: "object", properties: { category: { type: "string" }, analysis: { type: "string" }, score: { type: "number" } } } },
            recommendations: { type: "array", items: { type: "object", properties: { recommendation: { type: "string" }, priority: { type: "string" }, impact: { type: "string" } } } },
            action_items: { type: "array", items: { type: "object", properties: { action: { type: "string" }, owner: { type: "string" }, timeline: { type: "string" } } } },
            risk_assessment: { type: "array", items: { type: "object", properties: { risk: { type: "string" }, likelihood: { type: "string" }, mitigation: { type: "string" } } } },
            trends: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, direction: { type: "string" }, change: { type: "string" } } } }
          }
        }
      });
      setGeneratedContent({ report, content: result });
    } catch (error) {
      console.error("Error generating report:", error);
    }
    setGeneratingReport(null);
  };

  const exportToPDF = () => {
    if (!generatedContent) return;
    const content = generatedContent.content;
    let text = `${generatedContent.report.name}\n${'='.repeat(50)}\n\n`;
    text += `EXECUTIVE SUMMARY\n${content.executive_summary}\n\n`;
    text += `KEY FINDINGS\n${content.key_findings?.map((f, i) => `${i + 1}. ${f}`).join('\n')}\n\n`;
    text += `RECOMMENDATIONS\n${content.recommendations?.map(r => `• [${r.priority}] ${r.recommendation}`).join('\n')}\n\n`;
    text += `ACTION ITEMS\n${content.action_items?.map(a => `• ${a.action} (${a.owner} - ${a.timeline})`).join('\n')}`;
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generatedContent.report.name.replace(/\s+/g, '_')}_Report.txt`;
    a.click();
  };

  const exportToCSV = () => {
    if (!generatedContent) return;
    const content = generatedContent.content;
    let csv = "Category,Item,Details,Priority/Score\n";
    content.key_findings?.forEach((f, i) => csv += `Key Finding,${i + 1},"${f}",\n`);
    content.recommendations?.forEach(r => csv += `Recommendation,"${r.recommendation}","${r.impact}",${r.priority}\n`);
    content.action_items?.forEach(a => csv += `Action Item,"${a.action}","${a.owner}",${a.timeline}\n`);
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${generatedContent.report.name.replace(/\s+/g, '_')}_Report.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide flex items-center gap-3">
              <FileText className="w-8 h-8 text-purple-400" />
              Reporting Module
            </h1>
            <p className="text-gray-400 mt-1">Create, customize, and schedule automated reports</p>
          </div>
          <Dialog open={isCreating} onOpenChange={setIsCreating}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" /> Create Report
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-800 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white">Create New Report</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <Input
                  placeholder="Report Name"
                  value={newReport.name}
                  onChange={(e) => setNewReport({ ...newReport, name: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <Textarea
                  placeholder="Description"
                  value={newReport.description}
                  onChange={(e) => setNewReport({ ...newReport, description: e.target.value })}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <Select value={newReport.report_type} onValueChange={(v) => setNewReport({ ...newReport, report_type: v })}>
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                    <SelectValue placeholder="Report Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {reportTypes.map(t => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div>
                  <p className="text-gray-400 text-sm mb-2">Data Sources</p>
                  <div className="flex flex-wrap gap-2">
                    {dataSources.map(ds => (
                      <label key={ds.id} className="flex items-center gap-2 text-sm text-gray-300">
                        <Checkbox
                          checked={newReport.data_sources.includes(ds.id)}
                          onCheckedChange={(checked) => {
                            setNewReport({
                              ...newReport,
                              data_sources: checked
                                ? [...newReport.data_sources, ds.id]
                                : newReport.data_sources.filter(d => d !== ds.id)
                            });
                          }}
                        />
                        {ds.label}
                      </label>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-2">Schedule</p>
                  <Select
                    value={newReport.schedule.frequency}
                    onValueChange={(v) => setNewReport({ ...newReport, schedule: { ...newReport.schedule, frequency: v, enabled: v !== 'manual' } })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual Only</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={() => createReportMutation.mutate({ ...newReport, created_by: user?.email, status: 'active' })}
                  disabled={!newReport.name}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  Create Report
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="reports" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="reports">My Reports</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
          </TabsList>

          <TabsContent value="reports">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {reports.map(report => (
                <Card key={report.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white text-lg">{report.name}</CardTitle>
                        <CardDescription className="text-gray-500">{report.description}</CardDescription>
                      </div>
                      <Badge className={report.report_type === 'performance' ? 'bg-green-600' : report.report_type === 'skills' ? 'bg-blue-600' : 'bg-purple-600'}>
                        {report.report_type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {report.data_sources?.slice(0, 3).map(ds => (
                        <Badge key={ds} variant="outline" className="text-[10px] border-gray-700 text-gray-400">{ds}</Badge>
                      ))}
                    </div>
                    {report.schedule?.enabled && (
                      <p className="text-gray-500 text-xs mb-3 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {report.schedule.frequency}
                      </p>
                    )}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => generateReport(report)}
                        disabled={generatingReport === report.id}
                        className="flex-1 bg-purple-600 hover:bg-purple-700"
                      >
                        {generatingReport === report.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3 mr-1" />}
                        Generate
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteReportMutation.mutate(report.id)} className="text-red-400 hover:text-red-300">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {reports.length === 0 && (
                <Card className="bg-gray-900 border-gray-800 col-span-full">
                  <CardContent className="py-12 text-center">
                    <FileText className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400">No reports yet. Create your first report to get started.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="templates">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {reportTypes.map(type => (
                <Card key={type.value} className="bg-gray-900 border-gray-800 hover:border-purple-600 cursor-pointer transition-colors"
                  onClick={() => { setNewReport({ ...newReport, report_type: type.value, name: type.label }); setIsCreating(true); }}>
                  <CardContent className="p-6 text-center">
                    <type.icon className="w-10 h-10 text-purple-400 mx-auto mb-3" />
                    <p className="text-white font-medium">{type.label}</p>
                    <p className="text-gray-500 text-sm mt-1">Click to use template</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="scheduled">
            <div className="space-y-3">
              {reports.filter(r => r.schedule?.enabled).map(report => (
                <Card key={report.id} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Calendar className="w-5 h-5 text-purple-400" />
                      <div>
                        <p className="text-white">{report.name}</p>
                        <p className="text-gray-500 text-sm">Runs {report.schedule.frequency}</p>
                      </div>
                    </div>
                    <Badge className="bg-green-600">Active</Badge>
                  </CardContent>
                </Card>
              ))}
              {reports.filter(r => r.schedule?.enabled).length === 0 && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-12 text-center">
                    <Clock className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400">No scheduled reports. Set a schedule when creating a report.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Generated Report View */}
        {generatedContent && (
          <Card className="bg-gray-900 border-gray-800 mt-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">{generatedContent.report.name} - Generated Report</CardTitle>
                <div className="flex gap-2">
                  <Button size="sm" onClick={exportToPDF} className="bg-red-600 hover:bg-red-700">
                    <FileDown className="w-4 h-4 mr-1" /> PDF/TXT
                  </Button>
                  <Button size="sm" onClick={exportToCSV} className="bg-green-600 hover:bg-green-700">
                    <FileDown className="w-4 h-4 mr-1" /> CSV
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setGeneratedContent(null)} className="text-gray-400">✕</Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <div className="space-y-6">
                  <div className="p-4 bg-purple-900/20 border border-purple-800 rounded-lg">
                    <h3 className="text-purple-400 font-medium mb-2">Executive Summary</h3>
                    <p className="text-gray-300">{generatedContent.content.executive_summary}</p>
                  </div>
                  <div>
                    <h3 className="text-white font-medium mb-3">Key Findings</h3>
                    <ul className="space-y-2">
                      {generatedContent.content.key_findings?.map((f, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <span className="text-purple-400">•</span> {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-800 rounded-lg">
                      <h3 className="text-amber-400 font-medium mb-3">Recommendations</h3>
                      {generatedContent.content.recommendations?.map((r, i) => (
                        <div key={i} className="mb-2 pb-2 border-b border-gray-700 last:border-0">
                          <div className="flex items-center gap-2">
                            <Badge className={r.priority === 'high' ? 'bg-red-600' : r.priority === 'medium' ? 'bg-amber-600' : 'bg-blue-600'}>{r.priority}</Badge>
                            <span className="text-gray-300 text-sm">{r.recommendation}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 bg-gray-800 rounded-lg">
                      <h3 className="text-cyan-400 font-medium mb-3">Action Items</h3>
                      {generatedContent.content.action_items?.map((a, i) => (
                        <div key={i} className="mb-2 text-sm">
                          <p className="text-gray-300">{a.action}</p>
                          <p className="text-gray-500 text-xs">{a.owner} • {a.timeline}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}