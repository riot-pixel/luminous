import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, Plus, Calendar, CheckCircle2, Clock, TrendingUp, Sparkles, Mail, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function TeamAssessments() {
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    description: '',
    department: '',
    team_id: '',
    target_emails: [],
    assessment_type: 'quick',
    due_date: '',
  });
  const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['myCampaigns'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.TeamAssessmentCampaign.filter({ manager_email: currentUser.email }, '-created_date');
    },
    initialData: [],
  });

  const { data: directReports } = useQuery({
    queryKey: ['directReports'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.User.filter({ manager_email: currentUser.email });
    },
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['managerTeams'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Team.filter({ leader_email: currentUser.email });
    },
    initialData: [],
  });

  const { data: allAssessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const createCampaignMutation = useMutation({
    mutationFn: (data) => base44.entities.TeamAssessmentCampaign.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myCampaigns'] });
      setShowCreateDialog(false);
      resetForm();
    },
  });

  const sendNotificationsMutation = useMutation({
    mutationFn: async (campaign) => {
      const notifications = campaign.target_emails.map(email => 
        base44.integrations.Core.SendEmail({
          from_name: user?.full_name || 'Your Manager',
          to: email,
          subject: `Team Assessment Request: ${campaign.name}`,
          body: `
Hello,

Your manager has requested that you complete a team assessment as part of "${campaign.name}".

${campaign.description}

Assessment Type: ${campaign.assessment_type === 'quick' ? 'Quick Assessment (15-20 min)' : 'Comprehensive Assessment (45-60 min)'}
${campaign.due_date ? `Due Date: ${format(new Date(campaign.due_date), 'MMMM d, yyyy')}` : ''}

Please log in to the Luminous Prosperity platform to complete your assessment:
${window.location.origin}

Your participation helps us build a stronger, more aligned team.

Thank you,
${user?.full_name || 'Your Manager'}
          `
        })
      );

      await Promise.all(notifications);

      // Mark notifications as sent
      await base44.entities.TeamAssessmentCampaign.update(campaign.id, {
        notification_sent: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myCampaigns'] });
    },
  });

  const resetForm = () => {
    setNewCampaign({
      name: '',
      description: '',
      department: '',
      team_id: '',
      target_emails: [],
      assessment_type: 'quick',
      due_date: '',
    });
    setSelectedTeamMembers([]);
  };

  const handleTeamSelect = (teamId) => {
    const team = teams.find(t => t.id === teamId);
    if (team) {
      setSelectedTeamMembers(team.member_emails || []);
      setNewCampaign({
        ...newCampaign,
        team_id: teamId,
        department: team.department,
        target_emails: team.member_emails || [],
      });
    }
  };

  const handleCreateCampaign = async () => {
    if (!newCampaign.name || newCampaign.target_emails.length === 0) {
      alert("Please provide a campaign name and select team members");
      return;
    }

    const campaign = await createCampaignMutation.mutateAsync({
      ...newCampaign,
      manager_email: user.email,
      status: 'active',
      completed_count: 0,
    });

    // Send notifications
    await sendNotificationsMutation.mutateAsync(campaign);
  };

  const getCampaignProgress = (campaign) => {
    const completedAssessments = allAssessments.filter(a => 
      campaign.target_emails.includes(a.user_email) &&
      new Date(a.completed_date) >= new Date(campaign.created_date)
    );

    return {
      completed: completedAssessments.length,
      total: campaign.target_emails.length,
      percentage: Math.round((completedAssessments.length / campaign.target_emails.length) * 100),
    };
  };

  const getStatusBadge = (campaign) => {
    const progress = getCampaignProgress(campaign);
    
    if (campaign.status === 'completed') {
      return <Badge className="bg-green-600">Completed</Badge>;
    }
    if (campaign.status === 'cancelled') {
      return <Badge variant="outline" className="text-gray-500">Cancelled</Badge>;
    }
    if (progress.percentage === 100) {
      return <Badge className="bg-blue-600">Ready for Insights</Badge>;
    }
    if (campaign.due_date && new Date(campaign.due_date) < new Date()) {
      return <Badge className="bg-orange-600">Overdue</Badge>;
    }
    return <Badge className="bg-indigo-600">Active</Badge>;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Sparkles className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Team Assessments</h1>
            <p className="text-gray-600">Initiate and manage team assessment campaigns</p>
          </div>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-gradient-to-r from-indigo-600 to-purple-600"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Campaign
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Active Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-indigo-600">
                {campaigns.filter(c => c.status === 'active').length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Team Members</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">
                {directReports.length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Completed This Month</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {campaigns.filter(c => c.status === 'completed' && 
                  new Date(c.created_date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
                ).length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Avg Completion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                {campaigns.length > 0
                  ? Math.round(
                      campaigns.reduce((sum, c) => sum + getCampaignProgress(c).percentage, 0) / campaigns.length
                    )
                  : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Campaigns List */}
        <div className="space-y-6">
          {campaigns.length === 0 ? (
            <Card className="text-center py-20">
              <CardContent>
                <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">No Campaigns Yet</h3>
                <p className="text-gray-500 mb-6">
                  Create your first team assessment campaign to gather insights from your team
                </p>
                <Button onClick={() => setShowCreateDialog(true)}>
                  <Plus className="w-5 h-5 mr-2" />
                  Create First Campaign
                </Button>
              </CardContent>
            </Card>
          ) : (
            campaigns.map((campaign) => {
              const progress = getCampaignProgress(campaign);
              return (
                <Card key={campaign.id} className="border-2 hover:border-indigo-200 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CardTitle className="text-xl">{campaign.name}</CardTitle>
                          {getStatusBadge(campaign)}
                        </div>
                        <CardDescription className="text-base">{campaign.description}</CardDescription>
                        <div className="flex items-center gap-4 mt-3 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            <span>{campaign.target_emails.length} members</span>
                          </div>
                          {campaign.department && (
                            <div className="flex items-center gap-1">
                              <Badge variant="outline">{campaign.department}</Badge>
                            </div>
                          )}
                          {campaign.due_date && (
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              <span>Due {format(new Date(campaign.due_date), 'MMM d, yyyy')}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link to={createPageUrl("TeamInsights") + `?campaign=${campaign.id}`}>
                          <Button variant="outline" size="sm">
                            <TrendingUp className="w-4 h-4 mr-2" />
                            View Insights
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-600">
                            Completion Progress: {progress.completed} / {progress.total}
                          </span>
                          <span className="font-semibold text-indigo-600">{progress.percentage}%</span>
                        </div>
                        <Progress value={progress.percentage} className="h-3" />
                      </div>

                      {!campaign.notification_sent && (
                        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 flex items-center gap-2">
                          <AlertCircle className="w-5 h-5 text-orange-600" />
                          <span className="text-sm text-orange-800">
                            Notifications not sent yet. They will be sent automatically.
                          </span>
                        </div>
                      )}

                      {campaign.notification_sent && progress.percentage < 100 && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Mail className="w-4 h-4" />
                          <span>Invitations sent to {campaign.target_emails.length} team members</span>
                        </div>
                      )}

                      {progress.percentage === 100 && !campaign.insights_generated && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                            <span className="text-sm text-green-800">
                              All assessments complete! Generate team insights now.
                            </span>
                          </div>
                          <Link to={createPageUrl("TeamInsights") + `?campaign=${campaign.id}`}>
                            <Button size="sm" className="bg-green-600 hover:bg-green-700">
                              Generate Insights
                            </Button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Create Campaign Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Team Assessment Campaign</DialogTitle>
              <DialogDescription>
                Invite your team members to complete assessments and gather insights
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Campaign Name *</label>
                <Input
                  value={newCampaign.name}
                  onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })}
                  placeholder="e.g., Q1 Team Development Assessment"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <Textarea
                  value={newCampaign.description}
                  onChange={(e) => setNewCampaign({ ...newCampaign, description: e.target.value })}
                  placeholder="Explain the purpose and goals of this assessment..."
                  rows={3}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Assessment Type</label>
                  <Select
                    value={newCampaign.assessment_type}
                    onValueChange={(value) => setNewCampaign({ ...newCampaign, assessment_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="quick">Quick Assessment (15-20 min)</SelectItem>
                      <SelectItem value="comprehensive">Comprehensive (45-60 min)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Due Date</label>
                  <Input
                    type="date"
                    value={newCampaign.due_date}
                    onChange={(e) => setNewCampaign({ ...newCampaign, due_date: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Select Team (Optional)</label>
                <Select onValueChange={handleTeamSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a team or select individuals below" />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((team) => (
                      <SelectItem key={team.id} value={team.id}>
                        {team.name} ({team.member_emails?.length || 0} members)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Team Members * ({selectedTeamMembers.length} selected)</label>
                <div className="border rounded-lg p-4 max-h-64 overflow-y-auto space-y-2">
                  {directReports.map((member) => (
                    <label key={member.id} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedTeamMembers.includes(member.email)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedTeamMembers([...selectedTeamMembers, member.email]);
                            setNewCampaign({
                              ...newCampaign,
                              target_emails: [...selectedTeamMembers, member.email],
                            });
                          } else {
                            const updated = selectedTeamMembers.filter(email => email !== member.email);
                            setSelectedTeamMembers(updated);
                            setNewCampaign({
                              ...newCampaign,
                              target_emails: updated,
                            });
                          }
                        }}
                        className="w-4 h-4"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{member.full_name || member.email}</p>
                        <p className="text-xs text-gray-500">{member.job_title || member.department}</p>
                      </div>
                    </label>
                  ))}
                  {directReports.length === 0 && (
                    <p className="text-sm text-gray-500 text-center py-4">
                      No direct reports found. Make sure team members have you listed as their manager.
                    </p>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-900 text-sm mb-2">What happens next?</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Team members receive email invitations</li>
                  <li>• You can track completion progress in real-time</li>
                  <li>• Once complete, generate aggregated team insights</li>
                  <li>• Use insights for team development and optimization</li>
                </ul>
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateCampaign}
                  disabled={!newCampaign.name || selectedTeamMembers.length === 0}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Create & Send Invitations
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}