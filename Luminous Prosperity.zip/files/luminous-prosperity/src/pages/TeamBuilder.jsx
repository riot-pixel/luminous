import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Users, Target, Brain, TrendingUp, AlertCircle, CheckCircle2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function TeamBuilder() {
  const queryClient = useQueryClient();
  const [teamGoals, setTeamGoals] = useState("");
  const [requiredSkills, setRequiredSkills] = useState("");
  const [teamSize, setTeamSize] = useState("5");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendations, setRecommendations] = useState(null);

  const { data: employees, isLoading: loadingEmployees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments, isLoading: loadingAssessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const createTeamMutation = useMutation({
    mutationFn: (teamData) => base44.entities.Team.create(teamData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
    },
  });

  if (loadingEmployees || loadingAssessments) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading data...</p>
        </div>
      </div>
    );
  }

  // Get latest assessment per employee
  const latestAssessments = assessments.reduce((acc, assessment) => {
    if (!acc[assessment.user_email] || new Date(assessment.completed_date) > new Date(acc[assessment.user_email].completed_date)) {
      acc[assessment.user_email] = assessment;
    }
    return acc;
  }, {});

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      // Prepare data for AI analysis
      const employeeData = employees.map(emp => ({
        email: emp.email,
        name: emp.full_name,
        department: emp.department,
        job_title: emp.job_title,
        skills: emp.skills || [],
        career_goals: emp.career_goals || [],
        assessment: latestAssessments[emp.email] ? {
          personality_type: latestAssessments[emp.email].myers_briggs?.type,
          top_strengths: latestAssessments[emp.email].strengths?.top_strengths?.map(s => s.name) || [],
          primary_intelligence: latestAssessments[emp.email].integral_theory?.primary_line,
        } : null,
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist and team composition specialist.

Analyze the following employee data and team requirements to recommend the optimal team composition.

TEAM REQUIREMENTS:
- Goals: ${teamGoals}
- Required Skills: ${requiredSkills}
- Target Team Size: ${teamSize} members

EMPLOYEE POOL:
${JSON.stringify(employeeData, null, 2)}

ANALYSIS CRITERIA:
1. Complementary personality types (Myers-Briggs diversity)
2. Balanced strength distribution
3. Skill alignment with requirements
4. Career goals alignment with team mission
5. Cognitive diversity (different intelligence lines)
6. Potential for synergy and collaboration

Provide recommendations in the following structure:
1. Recommended team members (emails) with justification for each
2. Team composition analysis (personality balance, skill coverage, etc.)
3. Potential challenges and mitigation strategies
4. Expected team dynamics and performance indicators
5. Individual development opportunities within this team context

Be specific, actionable, and data-driven in your recommendations.`,
        response_json_schema: {
          type: "object",
          properties: {
            recommended_members: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  email: { type: "string" },
                  name: { type: "string" },
                  role_in_team: { type: "string" },
                  justification: { type: "string" },
                  key_contributions: { type: "array", items: { type: "string" } }
                }
              }
            },
            team_analysis: {
              type: "object",
              properties: {
                personality_balance: { type: "string" },
                skill_coverage: { type: "string" },
                synergy_score: { type: "number" },
                diversity_score: { type: "number" }
              }
            },
            challenges: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  challenge: { type: "string" },
                  mitigation: { type: "string" }
                }
              }
            },
            expected_outcomes: { type: "string" },
            development_opportunities: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setRecommendations(result);
    } catch (error) {
      console.error("Error analyzing team:", error);
    }
    setIsAnalyzing(false);
  };

  const handleCreateTeam = async () => {
    if (!recommendations) return;

    const teamName = prompt("Enter team name:");
    if (!teamName) return;

    const memberEmails = recommendations.recommended_members.map(m => m.email);

    await createTeamMutation.mutateAsync({
      name: teamName,
      description: teamGoals,
      department: "Cross-functional",
      leader_email: memberEmails[0],
      member_emails: memberEmails,
      goals: teamGoals.split('\n').filter(g => g.trim()),
      required_skills: requiredSkills.split(',').map(s => s.trim()).filter(s => s),
      status: "planning",
    });

    alert("Team created successfully!");
    setRecommendations(null);
    setTeamGoals("");
    setRequiredSkills("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI-Powered Team Builder</h1>
          <p className="text-gray-600">Create optimal team compositions based on personality, strengths, and goals alignment</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-purple-600" />
                  Team Requirements
                </CardTitle>
                <CardDescription>Define what you need from this team</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Team Goals & Purpose
                  </label>
                  <Textarea
                    placeholder="e.g., Develop new product feature, improve customer experience, strategic planning..."
                    value={teamGoals}
                    onChange={(e) => setTeamGoals(e.target.value)}
                    rows={4}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Required Skills (comma-separated)
                  </label>
                  <Input
                    placeholder="e.g., Python, Leadership, Data Analysis, Design Thinking"
                    value={requiredSkills}
                    onChange={(e) => setRequiredSkills(e.target.value)}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Target Team Size
                  </label>
                  <Select value={teamSize} onValueChange={setTeamSize}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 members</SelectItem>
                      <SelectItem value="4">4 members</SelectItem>
                      <SelectItem value="5">5 members</SelectItem>
                      <SelectItem value="6">6 members</SelectItem>
                      <SelectItem value="7">7 members</SelectItem>
                      <SelectItem value="8">8 members</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleAnalyze}
                  disabled={!teamGoals || isAnalyzing}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  size="lg"
                >
                  {isAnalyzing ? (
                    <>
                      <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Brain className="w-5 h-5 mr-2" />
                      Generate Recommendations
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-blue-600" />
                  Available Talent Pool
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-3xl font-bold text-blue-600">{employees.length}</div>
                    <p className="text-xs text-gray-600">Total Employees</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-green-600">{Object.keys(latestAssessments).length}</div>
                    <p className="text-xs text-gray-600">With Assessments</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div>
            {!recommendations && !isAnalyzing && (
              <Card className="h-full flex items-center justify-center border-2 border-dashed border-gray-200">
                <CardContent className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-2">No recommendations yet</p>
                  <p className="text-sm text-gray-400">Fill in the requirements and click Generate</p>
                </CardContent>
              </Card>
            )}

            {isAnalyzing && (
              <Card>
                <CardContent className="py-20 text-center">
                  <Sparkles className="w-16 h-16 text-purple-600 animate-spin mx-auto mb-4" />
                  <p className="text-gray-600">Analyzing personalities, strengths, and compatibility...</p>
                  <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
                </CardContent>
              </Card>
            )}

            {recommendations && (
              <div className="space-y-6">
                <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                      Recommended Team Composition
                    </CardTitle>
                    <CardDescription>AI-optimized based on assessment data</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {recommendations.recommended_members?.map((member, idx) => (
                      <div key={idx} className="p-4 bg-white rounded-lg border border-purple-100">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="font-semibold text-gray-900">{member.name}</p>
                            <p className="text-sm text-purple-600 font-medium">{member.role_in_team}</p>
                          </div>
                          <Badge className="bg-purple-100 text-purple-700">Member {idx + 1}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{member.justification}</p>
                        <div className="flex flex-wrap gap-2">
                          {member.key_contributions?.map((contrib, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {contrib}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Team Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {recommendations.team_analysis && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
                            <div className="text-3xl font-bold text-green-600">
                              {recommendations.team_analysis.synergy_score || 'N/A'}
                            </div>
                            <p className="text-xs text-gray-600">Synergy Score</p>
                          </div>
                          <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
                            <div className="text-3xl font-bold text-blue-600">
                              {recommendations.team_analysis.diversity_score || 'N/A'}
                            </div>
                            <p className="text-xs text-gray-600">Diversity Score</p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div>
                            <p className="text-sm font-medium text-gray-700">Personality Balance:</p>
                            <p className="text-sm text-gray-600">{recommendations.team_analysis.personality_balance}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700">Skill Coverage:</p>
                            <p className="text-sm text-gray-600">{recommendations.team_analysis.skill_coverage}</p>
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>

                {recommendations.challenges && recommendations.challenges.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <AlertCircle className="w-5 h-5 text-amber-600" />
                        Potential Challenges
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {recommendations.challenges.map((item, idx) => (
                        <div key={idx} className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                          <p className="text-sm font-medium text-gray-900 mb-1">{item.challenge}</p>
                          <p className="text-sm text-gray-600">
                            <span className="font-medium text-green-700">Mitigation:</span> {item.mitigation}
                          </p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                <Button
                  onClick={handleCreateTeam}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  size="lg"
                >
                  <CheckCircle2 className="w-5 h-5 mr-2" />
                  Create This Team
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}