import React from "react";
import { useSearchParams, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Circle, Target, Calendar, Sparkles, ArrowLeft, Book, Award } from "lucide-react";
import { format, addMonths } from "date-fns";

export default function SkillDevelopmentPath() {
  const [searchParams] = useSearchParams();
  const pathId = searchParams.get('path');
  const queryClient = useQueryClient();

  const { data: path } = useQuery({
    queryKey: ['developmentPath', pathId],
    queryFn: async () => {
      if (!pathId) return null;
      const paths = await base44.entities.SkillDevelopmentPath.list();
      return paths.find(p => p.id === pathId);
    },
    enabled: !!pathId,
  });

  const updatePathMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SkillDevelopmentPath.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['developmentPath', pathId] });
    },
  });

  const toggleMilestone = async (milestoneIndex) => {
    if (!path) return;
    
    const updatedMilestones = [...path.milestones];
    const currentStatus = updatedMilestones[milestoneIndex].status;
    updatedMilestones[milestoneIndex].status = currentStatus === 'completed' ? 'in_progress' : 'completed';

    await updatePathMutation.mutateAsync({
      id: path.id,
      data: { milestones: updatedMilestones },
    });
  };

  if (!path) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md text-center p-8">
          <Target className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Path Not Found</h2>
          <p className="text-gray-600 mb-6">The requested development path could not be found</p>
          <Link to={createPageUrl("MySkills")}>
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to My Skills
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const completedMilestones = path.milestones?.filter(m => m.status === 'completed').length || 0;
  const totalMilestones = path.milestones?.length || 0;
  const progress = totalMilestones > 0 ? (completedMilestones / totalMilestones) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-5xl mx-auto">
        <Link to={createPageUrl("MySkills")} className="text-sm text-indigo-600 hover:text-indigo-700 mb-4 inline-flex items-center gap-1">
          <ArrowLeft className="w-4 h-4" />
          Back to My Skills
        </Link>

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-xl flex items-center justify-center">
              <Target className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{path.path_name}</h1>
              <p className="text-gray-600">Timeline: {path.timeline}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Badge className={
              path.status === 'completed' ? 'bg-green-600' :
              path.status === 'in_progress' ? 'bg-blue-600' :
              path.status === 'active' ? 'bg-indigo-600' :
              'bg-gray-600'
            }>
              {path.status.replace('_', ' ')}
            </Badge>
            {path.generated_by_ai && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                AI Generated ({path.ai_confidence}% confidence)
              </Badge>
            )}
          </div>
        </div>

        {/* Progress */}
        <Card className="mb-8 border-2 border-indigo-200">
          <CardHeader>
            <CardTitle>Overall Progress</CardTitle>
            <CardDescription>
              {completedMilestones} of {totalMilestones} milestones completed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={progress} className="h-4 mb-2" />
            <p className="text-sm text-gray-600 text-right">{Math.round(progress)}%</p>
          </CardContent>
        </Card>

        {/* Skill Gaps */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Skill Gaps to Address</CardTitle>
            <CardDescription>{path.skill_gaps?.length || 0} skills to develop</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {path.skill_gaps?.map((gap, idx) => (
                <div key={idx} className="p-4 bg-gray-50 rounded-lg border">
                  <p className="font-semibold text-gray-900">{gap.skill_name}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline">{gap.current_level}</Badge>
                    <span className="text-gray-400">→</span>
                    <Badge className="bg-green-600">{gap.required_level}</Badge>
                  </div>
                  <Badge className={`mt-2 ${
                    gap.gap_severity === 'high' ? 'bg-red-600' :
                    gap.gap_severity === 'medium' ? 'bg-orange-600' :
                    'bg-blue-600'
                  }`}>
                    {gap.gap_severity} priority
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recommended Actions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Recommended Learning Actions</CardTitle>
            <CardDescription>Step-by-step development plan</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {path.recommended_actions?.map((action, idx) => (
                <div key={idx} className="p-4 border-2 rounded-lg hover:border-indigo-200 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                        {idx + 1}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">{action.skill}</h4>
                        <p className="text-sm text-gray-700 mb-2">{action.action}</p>
                        <div className="flex items-center gap-2">
                          <Badge className={
                            action.priority === 'high' ? 'bg-red-600' :
                            action.priority === 'medium' ? 'bg-orange-600' :
                            'bg-blue-600'
                          }>
                            {action.priority} priority
                          </Badge>
                          <Badge variant="outline">{action.estimated_time}</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  {action.resources && action.resources.length > 0 && (
                    <div className="ml-11">
                      <p className="text-xs font-medium text-gray-700 mb-2">Recommended Resources:</p>
                      <ul className="space-y-1">
                        {action.resources.map((resource, ridx) => (
                          <li key={ridx} className="text-xs text-gray-600 flex items-start gap-2">
                            <Book className="w-3 h-3 mt-0.5 flex-shrink-0 text-indigo-600" />
                            <span>{resource}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Milestones */}
        <Card>
          <CardHeader>
            <CardTitle>Development Milestones</CardTitle>
            <CardDescription>Track your progress with these key checkpoints</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {path.milestones?.map((milestone, idx) => {
                const isCompleted = milestone.status === 'completed';
                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      isCompleted
                        ? 'bg-green-50 border-green-200'
                        : 'bg-white border-gray-200 hover:border-indigo-200'
                    }`}
                    onClick={() => toggleMilestone(idx)}
                  >
                    <div className="flex items-start gap-3">
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-6 h-6 text-gray-400 flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <h4 className={`font-semibold ${isCompleted ? 'text-green-900' : 'text-gray-900'}`}>
                          {milestone.name}
                        </h4>
                        <div className="flex items-center gap-2 mt-2 mb-2">
                          {milestone.target_date && (
                            <div className="flex items-center gap-1 text-xs text-gray-600">
                              <Calendar className="w-3 h-3" />
                              <span>Target: {milestone.target_date}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {milestone.skills_addressed?.map((skill, sidx) => (
                            <Badge key={sidx} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
              <Award className="w-12 h-12 text-blue-600 mx-auto mb-3" />
              <p className="text-sm text-blue-900 font-medium mb-2">
                Complete all milestones to achieve your development goals!
              </p>
              <p className="text-xs text-blue-700">
                Click on milestones to mark them as complete
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}