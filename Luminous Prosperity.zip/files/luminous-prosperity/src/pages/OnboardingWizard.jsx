import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, Sparkles, Building2, User, Rocket, ArrowRight, ArrowLeft } from "lucide-react";

export default function OnboardingWizard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const [userData, setUserData] = useState({
    department: '',
    job_title: '',
    user_role: 'employee',
  });

  const [orgData, setOrgData] = useState({
    name: '',
    location: '',
    industry: '',
    size: 'medium',
    mission: '',
    vision: '',
  });

  const [needsOrgSetup, setNeedsOrgSetup] = useState(false);

  useEffect(() => {
    if (user && organizations) {
      // Check if user already has an organization
      const userOrg = organizations.find(o => o.id === user.organization_id);
      if (!userOrg || organizations.length === 0) {
        setNeedsOrgSetup(true);
      }
      
      // Pre-fill user data if available
      if (user.department) setUserData(prev => ({ ...prev, department: user.department }));
      if (user.job_title) setUserData(prev => ({ ...prev, job_title: user.job_title }));
      if (user.user_role) setUserData(prev => ({ ...prev, user_role: user.user_role }));
    }
  }, [user, organizations]);

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const createOrgMutation = useMutation({
    mutationFn: (data) => base44.entities.Organization.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
    },
  });

  const handleComplete = async () => {
    setIsSubmitting(true);
    try {
      // Step 1: Create organization if needed
      let organizationId = user.organization_id;
      
      if (needsOrgSetup && orgData.name) {
        const newOrg = await createOrgMutation.mutateAsync({
          ...orgData,
          admin_emails: [user.email],
          status: 'active',
          onboarding_completed: true,
        });
        organizationId = newOrg.id;
      }

      // Step 2: Update user profile
      await updateUserMutation.mutateAsync({
        ...userData,
        organization_id: organizationId,
        onboarding_completed: true,
        onboarding_tasks: {
          completed_profile: true,
          completed_assessment: false,
          viewed_results: false,
          generated_report: false,
          explored_portal: false,
        },
        tutorials_seen: {
          assessment_tutorial: false,
          report_tutorial: false,
          dashboard_tutorial: false,
        },
      });

      // Navigate to appropriate portal
      if (userData.user_role === 'executive' || userData.user_role === 'c_suite') {
        navigate(createPageUrl("ExecutivePortal"));
      } else {
        navigate(createPageUrl("EmployeePortal"));
      }
    } catch (error) {
      console.error("Error completing onboarding:", error);
      alert("Error completing onboarding. Please try again.");
    }
    setIsSubmitting(false);
  };

  const totalSteps = needsOrgSetup ? 3 : 2;

  const renderStep1 = () => (
    <Card className="border-2 border-indigo-200">
      <CardHeader>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Welcome to Luminous Prosperity!</CardTitle>
            <CardDescription>Let's set up your profile</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-900">
            <strong>Hi {user?.full_name || user?.email}!</strong> We're excited to have you here. 
            Let's get you started with a quick setup process.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Your Department</label>
            <Input
              value={userData.department}
              onChange={(e) => setUserData({ ...userData, department: e.target.value })}
              placeholder="e.g., Engineering, Sales, Marketing"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Your Job Title</label>
            <Input
              value={userData.job_title}
              onChange={(e) => setUserData({ ...userData, job_title: e.target.value })}
              placeholder="e.g., Software Engineer, Marketing Manager"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Your Role in the Organization</label>
            <Select value={userData.user_role} onValueChange={(value) => setUserData({ ...userData, user_role: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employee">Employee</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="executive">Executive</SelectItem>
                <SelectItem value="c_suite">C-Suite</SelectItem>
                <SelectItem value="org_admin">Organization Admin</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-1">This determines what features and dashboards you'll see</p>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <Button
            onClick={() => needsOrgSetup ? setCurrentStep(2) : setCurrentStep(2)}
            disabled={!userData.department || !userData.job_title}
            className="bg-gradient-to-r from-indigo-600 to-purple-600"
          >
            Next: {needsOrgSetup ? 'Organization Setup' : 'Finish'}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderStep2 = () => (
    <Card className="border-2 border-amber-200">
      <CardHeader>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-600 to-orange-600 rounded-xl flex items-center justify-center">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Organization Setup</CardTitle>
            <CardDescription>Tell us about your organization</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm text-amber-900">
            <strong>First time here?</strong> Let's create your organization profile. 
            This information helps us provide better insights and recommendations.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Organization Name *</label>
            <Input
              value={orgData.name}
              onChange={(e) => setOrgData({ ...orgData, name: e.target.value })}
              placeholder="e.g., Acme Corporation"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Location *</label>
              <Input
                value={orgData.location}
                onChange={(e) => setOrgData({ ...orgData, location: e.target.value })}
                placeholder="e.g., San Francisco, CA"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Industry *</label>
              <Input
                value={orgData.industry}
                onChange={(e) => setOrgData({ ...orgData, industry: e.target.value })}
                placeholder="e.g., Technology, Healthcare"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Organization Size</label>
            <Select value={orgData.size} onValueChange={(value) => setOrgData({ ...orgData, size: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small (1-50 employees)</SelectItem>
                <SelectItem value="medium">Medium (51-200 employees)</SelectItem>
                <SelectItem value="large">Large (201-1000 employees)</SelectItem>
                <SelectItem value="enterprise">Enterprise (1000+ employees)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Mission Statement</label>
            <Textarea
              value={orgData.mission}
              onChange={(e) => setOrgData({ ...orgData, mission: e.target.value })}
              placeholder="What is your organization's purpose?"
              rows={3}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Vision</label>
            <Textarea
              value={orgData.vision}
              onChange={(e) => setOrgData({ ...orgData, vision: e.target.value })}
              placeholder="Where do you see your organization going?"
              rows={3}
            />
          </div>
        </div>

        <div className="flex justify-between gap-3 pt-4">
          <Button variant="outline" onClick={() => setCurrentStep(1)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            onClick={() => setCurrentStep(3)}
            disabled={!orgData.name || !orgData.location || !orgData.industry}
            className="bg-gradient-to-r from-amber-600 to-orange-600"
          >
            Next: Review
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderStep3 = () => (
    <Card className="border-2 border-green-200">
      <CardHeader>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center">
            <Rocket className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">You're All Set!</CardTitle>
            <CardDescription>Review and complete your setup</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-sm text-green-900">
            <strong>Great!</strong> Here's a summary of your setup. Click "Complete Setup" to get started.
          </p>
        </div>

        <div className="space-y-4">
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <User className="w-4 h-4" />
              Your Profile
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Department:</span>
                <span className="font-medium">{userData.department}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Job Title:</span>
                <span className="font-medium">{userData.job_title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Role:</span>
                <span className="font-medium capitalize">{userData.user_role.replace('_', ' ')}</span>
              </div>
            </div>
          </div>

          {needsOrgSetup && (
            <div className="border rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Organization
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium">{orgData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Location:</span>
                  <span className="font-medium">{orgData.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Industry:</span>
                  <span className="font-medium">{orgData.industry}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Size:</span>
                  <span className="font-medium capitalize">{orgData.size}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2">What's Next?</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Take your first assessment to unlock insights
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Explore your personalized dashboard
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Generate professional reports
              </li>
              {(userData.user_role === 'manager' || userData.user_role === 'executive' || userData.user_role === 'c_suite') && (
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Access executive analytics and team insights
                </li>
              )}
            </ul>
          </div>
        </div>

        <div className="flex justify-between gap-3 pt-4">
          <Button variant="outline" onClick={() => setCurrentStep(needsOrgSetup ? 2 : 1)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            onClick={handleComplete}
            disabled={isSubmitting}
            className="bg-gradient-to-r from-green-600 to-emerald-600"
          >
            {isSubmitting ? (
              <>
                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                Setting up...
              </>
            ) : (
              <>
                <Rocket className="w-4 h-4 mr-2" />
                Complete Setup
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-3xl mx-auto py-12">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Setup Progress</h2>
            <span className="text-sm text-gray-600">
              Step {currentStep} of {totalSteps}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-indigo-600 to-purple-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && needsOrgSetup && renderStep2()}
        {currentStep === 2 && !needsOrgSetup && renderStep3()}
        {currentStep === 3 && renderStep3()}
      </div>
    </div>
  );
}