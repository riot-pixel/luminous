import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  GitBranch, Users, MessageSquare, CheckCircle2, Clock, Plus,
  Send, History, ThumbsUp, ThumbsDown, Edit3, Eye, Sparkles,
  AlertCircle, FileText, Palette, Package, Target, Brain
} from "lucide-react";
import { format } from "date-fns";

const WORKFLOW_TYPES = [
  { value: "brand_alchemy", label: "Brand Alchemy", icon: Palette },
  { value: "product_development", label: "Product Development", icon: Package },
  { value: "strategic_clarity", label: "Strategic Clarity", icon: Target },
  { value: "leadership_evolution", label: "Leadership Evolution", icon: Brain },
  { value: "custom", label: "Custom Workflow", icon: FileText }
];

const STATUS_COLORS = {
  draft: "bg-gray-600",
  in_review: "bg-yellow-600",
  approved: "bg-green-600",
  rejected: "bg-red-600",
  archived: "bg-gray-500"
};

export default function CollaborativeWorkflows() {
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [newComment, setNewComment] = useState("");
  const [newWorkflow, setNewWorkflow] = useState({
    title: "",
    description: "",
    workflow_type: "",
    reviewers: ""
  });
  const [isGeneratingContent, setIsGeneratingContent] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: workflows } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.CollaborativeWorkflow.list('-created_date'),
    initialData: [],
  });

  const { data: myWorkflows } = useQuery({
    queryKey: ['myWorkflows', user?.email],
    queryFn: () => base44.entities.CollaborativeWorkflow.filter({ created_by: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const createWorkflowMutation = useMutation({
    mutationFn: (data) => base44.entities.CollaborativeWorkflow.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      queryClient.invalidateQueries({ queryKey: ['myWorkflows'] });
      setShowCreateDialog(false);
      setNewWorkflow({ title: "", description: "", workflow_type: "", reviewers: "" });
    },
  });

  const updateWorkflowMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CollaborativeWorkflow.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      if (selectedWorkflow) {
        refetchWorkflow();
      }
    },
  });

  const refetchWorkflow = async () => {
    if (selectedWorkflow?.id) {
      const updated = await base44.entities.CollaborativeWorkflow.filter({ id: selectedWorkflow.id });
      if (updated[0]) setSelectedWorkflow(updated[0]);
    }
  };

  const createWorkflow = async () => {
    const reviewerEmails = newWorkflow.reviewers.split(',').map(e => e.trim()).filter(Boolean);
    await createWorkflowMutation.mutateAsync({
      title: newWorkflow.title,
      description: newWorkflow.description,
      workflow_type: newWorkflow.workflow_type,
      created_by: user.email,
      status: "draft",
      current_version: 1,
      versions: [{
        version_number: 1,
        content: {},
        ai_output: {},
        created_by: user.email,
        created_date: new Date().toISOString(),
        change_summary: "Initial version"
      }],
      reviewers: reviewerEmails.map(email => ({ email, status: "pending" })),
      contributors: [{ email: user.email, role: "owner", joined_date: new Date().toISOString() }],
      comments: []
    });
  };

  const addComment = async () => {
    if (!newComment.trim() || !selectedWorkflow) return;
    const updatedComments = [
      ...(selectedWorkflow.comments || []),
      {
        id: Date.now().toString(),
        user_email: user.email,
        content: newComment,
        timestamp: new Date().toISOString(),
        resolved: false,
        replies: []
      }
    ];
    await updateWorkflowMutation.mutateAsync({
      id: selectedWorkflow.id,
      data: { comments: updatedComments }
    });
    setNewComment("");
  };

  const submitForReview = async (workflow) => {
    await updateWorkflowMutation.mutateAsync({
      id: workflow.id,
      data: { status: "in_review" }
    });
  };

  const approveWorkflow = async (workflow) => {
    const updatedReviewers = (workflow.reviewers || []).map(r => 
      r.email === user.email 
        ? { ...r, status: "approved", reviewed_date: new Date().toISOString() }
        : r
    );
    const allApproved = updatedReviewers.every(r => r.status === "approved");
    await updateWorkflowMutation.mutateAsync({
      id: workflow.id,
      data: { 
        reviewers: updatedReviewers,
        status: allApproved ? "approved" : "in_review"
      }
    });
  };

  const rejectWorkflow = async (workflow, feedback) => {
    const updatedReviewers = (workflow.reviewers || []).map(r => 
      r.email === user.email 
        ? { ...r, status: "rejected", reviewed_date: new Date().toISOString(), feedback }
        : r
    );
    await updateWorkflowMutation.mutateAsync({
      id: workflow.id,
      data: { reviewers: updatedReviewers, status: "rejected" }
    });
  };

  const generateWorkflowContent = async (workflow) => {
    setIsGeneratingContent(true);
    try {
      let prompt = "";
      let schema = {};

      if (workflow.workflow_type === "brand_alchemy") {
        prompt = `You are a brand strategist. Generate a comprehensive Brand Alchemy output for: "${workflow.title}"

Description: ${workflow.description}

Create:
1. Brand archetype analysis (primary and secondary archetypes)
2. Brand essence and core values
3. Brand voice and personality traits
4. Visual identity recommendations
5. Brand story narrative
6. Target audience psychographics
7. Competitive positioning statement`;
        schema = {
          type: "object",
          properties: {
            brand_archetype: {
              type: "object",
              properties: {
                primary: { type: "string" },
                secondary: { type: "string" },
                archetype_description: { type: "string" }
              }
            },
            brand_essence: { type: "string" },
            core_values: { type: "array", items: { type: "string" } },
            brand_voice: {
              type: "object",
              properties: {
                tone: { type: "string" },
                personality_traits: { type: "array", items: { type: "string" } },
                communication_style: { type: "string" }
              }
            },
            visual_identity: {
              type: "object",
              properties: {
                color_palette: { type: "array", items: { type: "string" } },
                typography_style: { type: "string" },
                imagery_direction: { type: "string" }
              }
            },
            brand_story: { type: "string" },
            target_audience: {
              type: "object",
              properties: {
                demographics: { type: "string" },
                psychographics: { type: "string" },
                pain_points: { type: "array", items: { type: "string" } },
                aspirations: { type: "array", items: { type: "string" } }
              }
            },
            positioning_statement: { type: "string" }
          }
        };
      } else if (workflow.workflow_type === "product_development") {
        prompt = `You are a product strategist. Generate a comprehensive Product Development outline for: "${workflow.title}"

Description: ${workflow.description}

Create:
1. Product vision and mission
2. Problem statement and solution hypothesis
3. Target user personas
4. Key features and MVP scope
5. Success metrics and KPIs
6. Competitive analysis summary
7. Go-to-market strategy outline
8. Risk assessment and mitigation`;
        schema = {
          type: "object",
          properties: {
            product_vision: { type: "string" },
            product_mission: { type: "string" },
            problem_statement: { type: "string" },
            solution_hypothesis: { type: "string" },
            user_personas: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  role: { type: "string" },
                  goals: { type: "array", items: { type: "string" } },
                  pain_points: { type: "array", items: { type: "string" } }
                }
              }
            },
            key_features: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  feature: { type: "string" },
                  priority: { type: "string" },
                  user_value: { type: "string" }
                }
              }
            },
            mvp_scope: { type: "array", items: { type: "string" } },
            success_metrics: { type: "array", items: { type: "string" } },
            competitive_analysis: { type: "string" },
            gtm_strategy: { type: "string" },
            risks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  likelihood: { type: "string" },
                  mitigation: { type: "string" }
                }
              }
            }
          }
        };
      } else {
        prompt = `Generate a strategic project outline for: "${workflow.title}"

Type: ${workflow.workflow_type}
Description: ${workflow.description}

Create:
1. Executive summary
2. Objectives and key results
3. Stakeholders and responsibilities
4. Timeline and milestones
5. Resource requirements
6. Success criteria
7. Risks and mitigations`;
        schema = {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            objectives: { type: "array", items: { type: "string" } },
            key_results: { type: "array", items: { type: "string" } },
            stakeholders: { type: "array", items: { type: "object", properties: { role: { type: "string" }, responsibility: { type: "string" } } } },
            timeline: { type: "array", items: { type: "object", properties: { milestone: { type: "string" }, target_date: { type: "string" } } } },
            resources: { type: "array", items: { type: "string" } },
            success_criteria: { type: "array", items: { type: "string" } },
            risks: { type: "array", items: { type: "object", properties: { risk: { type: "string" }, mitigation: { type: "string" } } } }
          }
        };
      }

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: schema
      });

      const newVersion = {
        version_number: (workflow.current_version || 0) + 1,
        content: { prompt, type: workflow.workflow_type },
        ai_output: result,
        created_by: user.email,
        created_date: new Date().toISOString(),
        change_summary: "AI-generated initial draft"
      };

      await updateWorkflowMutation.mutateAsync({
        id: workflow.id,
        data: {
          versions: [...(workflow.versions || []), newVersion],
          current_version: newVersion.version_number
        }
      });

      await refetchWorkflow();
    } catch (error) {
      console.error("Error generating content:", error);
    }
    setIsGeneratingContent(false);
  };

  const pendingReviews = workflows?.filter(w => 
    w.status === "in_review" && 
    w.reviewers?.some(r => r.email === user?.email && r.status === "pending")
  ) || [];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Collaborative Workflows</h1>
            <p className="text-gray-400">Work together on AI-generated content with version control and reviews</p>
          </div>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" />
                New Workflow
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-800 text-white">
              <DialogHeader>
                <DialogTitle>Create Collaborative Workflow</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Workflow Type</label>
                  <Select value={newWorkflow.workflow_type} onValueChange={(v) => setNewWorkflow({...newWorkflow, workflow_type: v})}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {WORKFLOW_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Title</label>
                  <Input
                    value={newWorkflow.title}
                    onChange={(e) => setNewWorkflow({...newWorkflow, title: e.target.value})}
                    placeholder="Workflow title"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Description</label>
                  <Textarea
                    value={newWorkflow.description}
                    onChange={(e) => setNewWorkflow({...newWorkflow, description: e.target.value})}
                    placeholder="What is this workflow about?"
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Reviewers (comma-separated emails)</label>
                  <Input
                    value={newWorkflow.reviewers}
                    onChange={(e) => setNewWorkflow({...newWorkflow, reviewers: e.target.value})}
                    placeholder="reviewer1@company.com, reviewer2@company.com"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <Button onClick={createWorkflow} disabled={!newWorkflow.title || !newWorkflow.workflow_type} className="w-full bg-white text-black hover:bg-gray-200">
                  Create Workflow
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pending Reviews Alert */}
        {pendingReviews.length > 0 && (
          <Card className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border-yellow-800 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400" />
                <span className="text-yellow-200">You have {pendingReviews.length} workflow(s) awaiting your review</span>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Workflow List */}
          <div className="lg:col-span-1">
            <Tabs defaultValue="all" className="space-y-4">
              <TabsList className="bg-gray-900 border border-gray-800 w-full">
                <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
                <TabsTrigger value="mine" className="flex-1">Mine</TabsTrigger>
                <TabsTrigger value="review" className="flex-1">To Review</TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-3 pr-4">
                    {workflows?.map(workflow => (
                      <WorkflowCard 
                        key={workflow.id} 
                        workflow={workflow} 
                        onClick={() => setSelectedWorkflow(workflow)}
                        isSelected={selectedWorkflow?.id === workflow.id}
                      />
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="mine">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-3 pr-4">
                    {myWorkflows?.map(workflow => (
                      <WorkflowCard 
                        key={workflow.id} 
                        workflow={workflow} 
                        onClick={() => setSelectedWorkflow(workflow)}
                        isSelected={selectedWorkflow?.id === workflow.id}
                      />
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="review">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-3 pr-4">
                    {pendingReviews.map(workflow => (
                      <WorkflowCard 
                        key={workflow.id} 
                        workflow={workflow} 
                        onClick={() => setSelectedWorkflow(workflow)}
                        isSelected={selectedWorkflow?.id === workflow.id}
                      />
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>

          {/* Workflow Detail */}
          <div className="lg:col-span-2">
            {selectedWorkflow ? (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="border-b border-gray-800">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-white flex items-center gap-2">
                        {selectedWorkflow.title}
                        <Badge className={STATUS_COLORS[selectedWorkflow.status]}>{selectedWorkflow.status}</Badge>
                      </CardTitle>
                      <CardDescription className="text-gray-400 mt-1">{selectedWorkflow.description}</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {selectedWorkflow.status === "draft" && selectedWorkflow.created_by === user?.email && (
                        <Button size="sm" onClick={() => submitForReview(selectedWorkflow)} className="bg-blue-600 hover:bg-blue-700">
                          <Send className="w-4 h-4 mr-1" /> Submit for Review
                        </Button>
                      )}
                      {selectedWorkflow.status === "in_review" && selectedWorkflow.reviewers?.some(r => r.email === user?.email && r.status === "pending") && (
                        <>
                          <Button size="sm" onClick={() => approveWorkflow(selectedWorkflow)} className="bg-green-600 hover:bg-green-700">
                            <ThumbsUp className="w-4 h-4 mr-1" /> Approve
                          </Button>
                          <Button size="sm" onClick={() => rejectWorkflow(selectedWorkflow, "Needs revisions")} variant="destructive">
                            <ThumbsDown className="w-4 h-4 mr-1" /> Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <Tabs defaultValue="content" className="w-full">
                    <TabsList className="w-full justify-start rounded-none border-b border-gray-800 bg-transparent h-auto p-0">
                      <TabsTrigger value="content" className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-500 data-[state=active]:bg-transparent">
                        <FileText className="w-4 h-4 mr-2" /> Content
                      </TabsTrigger>
                      <TabsTrigger value="versions" className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-500 data-[state=active]:bg-transparent">
                        <History className="w-4 h-4 mr-2" /> Versions ({selectedWorkflow.versions?.length || 0})
                      </TabsTrigger>
                      <TabsTrigger value="comments" className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-500 data-[state=active]:bg-transparent">
                        <MessageSquare className="w-4 h-4 mr-2" /> Comments ({selectedWorkflow.comments?.length || 0})
                      </TabsTrigger>
                      <TabsTrigger value="reviewers" className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-500 data-[state=active]:bg-transparent">
                        <Users className="w-4 h-4 mr-2" /> Reviewers
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="content" className="p-6">
                      {selectedWorkflow.versions?.[selectedWorkflow.current_version - 1]?.ai_output && 
                       Object.keys(selectedWorkflow.versions[selectedWorkflow.current_version - 1].ai_output).length > 0 ? (
                        <div className="space-y-4">
                          <div className="flex justify-end">
                            <Button 
                              size="sm" 
                              onClick={() => generateWorkflowContent(selectedWorkflow)}
                              disabled={isGeneratingContent}
                              variant="outline"
                              className="border-gray-700 text-gray-300"
                            >
                              {isGeneratingContent ? <Sparkles className="w-4 h-4 mr-1 animate-spin" /> : <Sparkles className="w-4 h-4 mr-1" />}
                              Regenerate
                            </Button>
                          </div>
                          <AIOutputDisplay output={selectedWorkflow.versions[selectedWorkflow.current_version - 1].ai_output} type={selectedWorkflow.workflow_type} />
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <Sparkles className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                          <p className="text-gray-400 mb-2">No AI-generated content yet</p>
                          <p className="text-gray-500 text-sm mb-4">Generate an initial draft based on your workflow type</p>
                          <Button 
                            onClick={() => generateWorkflowContent(selectedWorkflow)}
                            disabled={isGeneratingContent}
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            {isGeneratingContent ? (
                              <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                            ) : (
                              <><Sparkles className="w-4 h-4 mr-2" /> Generate {selectedWorkflow.workflow_type === 'brand_alchemy' ? 'Brand Alchemy' : selectedWorkflow.workflow_type === 'product_development' ? 'Product Outline' : 'Content'}</>
                            )}
                          </Button>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="versions" className="p-6">
                      <div className="space-y-4">
                        {selectedWorkflow.versions?.map((version, idx) => (
                          <div key={idx} className="flex items-start gap-4 p-4 bg-gray-800 rounded-lg">
                            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center font-bold text-white">
                              v{version.version_number}
                            </div>
                            <div className="flex-1">
                              <p className="text-white font-medium">Version {version.version_number}</p>
                              <p className="text-gray-400 text-sm">{version.change_summary}</p>
                              <p className="text-gray-500 text-xs mt-1">
                                by {version.created_by} • {format(new Date(version.created_date), 'PPp')}
                              </p>
                            </div>
                            <Button size="sm" variant="outline" className="border-gray-700 text-gray-400">
                              <Eye className="w-4 h-4 mr-1" /> View
                            </Button>
                          </div>
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="comments" className="p-6">
                      <div className="space-y-4 mb-4">
                        {selectedWorkflow.comments?.length === 0 ? (
                          <p className="text-gray-500 text-center py-8">No comments yet</p>
                        ) : (
                          selectedWorkflow.comments?.map(comment => (
                            <div key={comment.id} className="p-4 bg-gray-800 rounded-lg">
                              <div className="flex items-start gap-3">
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback className="bg-purple-600 text-xs">{comment.user_email?.[0]?.toUpperCase()}</AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className="text-white font-medium text-sm">{comment.user_email}</span>
                                    <span className="text-gray-500 text-xs">{format(new Date(comment.timestamp), 'PPp')}</span>
                                  </div>
                                  <p className="text-gray-300 text-sm mt-1">{comment.content}</p>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          placeholder="Add a comment..."
                          className="bg-gray-800 border-gray-700 text-white"
                          onKeyPress={(e) => e.key === 'Enter' && addComment()}
                        />
                        <Button onClick={addComment} className="bg-purple-600 hover:bg-purple-700">
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="reviewers" className="p-6">
                      <div className="space-y-3">
                        {selectedWorkflow.reviewers?.map((reviewer, idx) => (
                          <div key={idx} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback className="bg-blue-600">{reviewer.email?.[0]?.toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-white">{reviewer.email}</p>
                                {reviewer.feedback && <p className="text-gray-400 text-sm">{reviewer.feedback}</p>}
                              </div>
                            </div>
                            <Badge className={
                              reviewer.status === "approved" ? "bg-green-600" :
                              reviewer.status === "rejected" ? "bg-red-600" :
                              "bg-gray-600"
                            }>
                              {reviewer.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-gray-900 border-gray-800 h-full flex items-center justify-center">
                <div className="text-center py-20">
                  <GitBranch className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Select a workflow to view details</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function AIOutputDisplay({ output, type }) {
  if (type === "brand_alchemy") {
    return (
      <div className="space-y-6">
        {output.brand_archetype && (
          <div className="p-4 bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg border border-purple-800">
            <h3 className="text-purple-300 font-medium mb-2">Brand Archetype</h3>
            <p className="text-white text-lg font-semibold">{output.brand_archetype.primary} / {output.brand_archetype.secondary}</p>
            <p className="text-gray-400 text-sm mt-1">{output.brand_archetype.archetype_description}</p>
          </div>
        )}
        {output.brand_essence && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Brand Essence</h3>
            <p className="text-white">{output.brand_essence}</p>
          </div>
        )}
        {output.core_values?.length > 0 && (
          <div>
            <h3 className="text-gray-400 font-medium mb-2">Core Values</h3>
            <div className="flex flex-wrap gap-2">
              {output.core_values.map((v, i) => (
                <Badge key={i} className="bg-purple-600">{v}</Badge>
              ))}
            </div>
          </div>
        )}
        {output.brand_voice && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Brand Voice</h3>
            <p className="text-white mb-2"><strong>Tone:</strong> {output.brand_voice.tone}</p>
            <p className="text-white mb-2"><strong>Style:</strong> {output.brand_voice.communication_style}</p>
            <div className="flex flex-wrap gap-1 mt-2">
              {output.brand_voice.personality_traits?.map((t, i) => (
                <Badge key={i} variant="outline" className="border-gray-600 text-gray-300">{t}</Badge>
              ))}
            </div>
          </div>
        )}
        {output.brand_story && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Brand Story</h3>
            <p className="text-gray-300">{output.brand_story}</p>
          </div>
        )}
        {output.positioning_statement && (
          <div className="p-4 bg-gradient-to-r from-blue-900/30 to-cyan-900/30 rounded-lg border border-blue-800">
            <h3 className="text-blue-300 font-medium mb-2">Positioning Statement</h3>
            <p className="text-white italic">"{output.positioning_statement}"</p>
          </div>
        )}
      </div>
    );
  }

  if (type === "product_development") {
    return (
      <div className="space-y-6">
        {output.product_vision && (
          <div className="p-4 bg-gradient-to-r from-blue-900/30 to-indigo-900/30 rounded-lg border border-blue-800">
            <h3 className="text-blue-300 font-medium mb-2">Product Vision</h3>
            <p className="text-white">{output.product_vision}</p>
          </div>
        )}
        {output.problem_statement && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Problem Statement</h3>
            <p className="text-gray-300">{output.problem_statement}</p>
          </div>
        )}
        {output.solution_hypothesis && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Solution Hypothesis</h3>
            <p className="text-gray-300">{output.solution_hypothesis}</p>
          </div>
        )}
        {output.key_features?.length > 0 && (
          <div>
            <h3 className="text-gray-400 font-medium mb-2">Key Features</h3>
            <div className="space-y-2">
              {output.key_features.map((f, i) => (
                <div key={i} className="p-3 bg-gray-800 rounded-lg flex items-start justify-between">
                  <div>
                    <p className="text-white font-medium">{f.feature}</p>
                    <p className="text-gray-400 text-sm">{f.user_value}</p>
                  </div>
                  <Badge className={f.priority === 'high' ? 'bg-red-600' : f.priority === 'medium' ? 'bg-yellow-600' : 'bg-green-600'}>
                    {f.priority}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}
        {output.mvp_scope?.length > 0 && (
          <div>
            <h3 className="text-gray-400 font-medium mb-2">MVP Scope</h3>
            <ul className="list-disc list-inside text-gray-300 space-y-1">
              {output.mvp_scope.map((s, i) => <li key={i}>{s}</li>)}
            </ul>
          </div>
        )}
        {output.gtm_strategy && (
          <div className="p-4 bg-gray-800 rounded-lg">
            <h3 className="text-gray-400 font-medium mb-2">Go-to-Market Strategy</h3>
            <p className="text-gray-300">{output.gtm_strategy}</p>
          </div>
        )}
      </div>
    );
  }

  // Default display for other types
  return (
    <div className="space-y-4">
      {output.executive_summary && (
        <div className="p-4 bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg">
          <h3 className="text-gray-400 font-medium mb-2">Executive Summary</h3>
          <p className="text-gray-300">{output.executive_summary}</p>
        </div>
      )}
      {output.objectives?.length > 0 && (
        <div>
          <h3 className="text-gray-400 font-medium mb-2">Objectives</h3>
          <ul className="list-disc list-inside text-gray-300 space-y-1">
            {output.objectives.map((o, i) => <li key={i}>{o}</li>)}
          </ul>
        </div>
      )}
      {output.timeline?.length > 0 && (
        <div>
          <h3 className="text-gray-400 font-medium mb-2">Timeline</h3>
          <div className="space-y-2">
            {output.timeline.map((t, i) => (
              <div key={i} className="flex items-center justify-between p-2 bg-gray-800 rounded">
                <span className="text-gray-300">{t.milestone}</span>
                <Badge variant="outline" className="border-gray-600 text-gray-400">{t.target_date}</Badge>
              </div>
            ))}
          </div>
        </div>
      )}
      <details className="mt-4">
        <summary className="text-gray-500 text-sm cursor-pointer">View raw JSON</summary>
        <pre className="bg-gray-800 p-4 rounded-lg overflow-auto text-sm text-gray-300 mt-2">
          {JSON.stringify(output, null, 2)}
        </pre>
      </details>
    </div>
  );
}

function WorkflowCard({ workflow, onClick, isSelected }) {
  const TypeIcon = WORKFLOW_TYPES.find(t => t.value === workflow.workflow_type)?.icon || FileText;
  return (
    <div 
      onClick={onClick}
      className={`p-4 rounded-lg border cursor-pointer transition-all ${
        isSelected 
          ? 'bg-purple-900/30 border-purple-600' 
          : 'bg-gray-900 border-gray-800 hover:border-gray-700'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
          <TypeIcon className="w-5 h-5 text-purple-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="text-white font-medium truncate">{workflow.title}</h4>
            <Badge className={`${STATUS_COLORS[workflow.status]} text-xs`}>{workflow.status}</Badge>
          </div>
          <p className="text-gray-500 text-xs mt-1">
            v{workflow.current_version} • {workflow.comments?.length || 0} comments
          </p>
        </div>
      </div>
    </div>
  );
}