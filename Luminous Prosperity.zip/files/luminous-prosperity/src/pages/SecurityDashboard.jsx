import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Eye, Lock, Users, AlertTriangle, CheckCircle2, Activity, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { format } from "date-fns";

export default function SecurityDashboard() {
  const [timeRange, setTimeRange] = useState('7d');

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: accessLogs } = useQuery({
    queryKey: ['accessLogs', timeRange],
    queryFn: () => base44.entities.DataAccessLog.list('-created_date', 1000),
    initialData: [],
  });

  // Only org admins and platform owner can access
  const isAuthorized = user?.user_role === 'org_admin' || 
                       user?.role === 'admin' || 
                       user?.email === 'ammanuldesta@gmail.com';

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md text-center p-8">
          <Lock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600">Only organization administrators can access the security dashboard</p>
        </Card>
      </div>
    );
  }

  // Privacy settings analysis
  const privacyStats = {
    managerAccessEnabled: employees.filter(e => e.privacy_settings?.allow_manager_view_assessment).length,
    executiveAccessEnabled: employees.filter(e => e.privacy_settings?.allow_executive_view_anonymized).length,
    teamInsightsEnabled: employees.filter(e => e.privacy_settings?.share_with_team_insights).length,
    hrAccessEnabled: employees.filter(e => e.privacy_settings?.visible_to_hr).length,
  };

  const privacyData = [
    { name: 'Manager Access', value: privacyStats.managerAccessEnabled, color: '#3b82f6' },
    { name: 'Executive Access', value: privacyStats.executiveAccessEnabled, color: '#8b5cf6' },
    { name: 'Team Insights', value: privacyStats.teamInsightsEnabled, color: '#10b981' },
    { name: 'HR Access', value: privacyStats.hrAccessEnabled, color: '#f59e0b' },
  ];

  // Access logs analysis
  const accessByType = accessLogs.reduce((acc, log) => {
    acc[log.data_type] = (acc[log.data_type] || 0) + 1;
    return acc;
  }, {});

  const accessByLevel = accessLogs.reduce((acc, log) => {
    acc[log.access_level] = (acc[log.access_level] || 0) + 1;
    return acc;
  }, {});

  const accessTypeData = Object.entries(accessByType).map(([name, value]) => ({ name, value }));
  const accessLevelData = Object.entries(accessByLevel).map(([name, value]) => ({ name, value }));

  const COLORS = ['#8b5cf6', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Security & Privacy Dashboard</h1>
                <p className="text-gray-600">Monitor data access and privacy compliance</p>
              </div>
            </div>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
              <SelectItem value="90d">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-100">Privacy Compliance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {Math.round((employees.filter(e => e.privacy_settings).length / employees.length) * 100)}%
              </div>
              <p className="text-xs text-green-100 mt-1">employees configured</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Access Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{accessLogs.length}</div>
              <p className="text-xs text-blue-100 mt-1">in selected period</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Anonymized Access</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {accessLogs.filter(l => l.access_level === 'anonymized').length}
              </div>
              <p className="text-xs text-purple-100 mt-1">protected views</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-amber-100">Team Insights Opt-in</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {Math.round((privacyStats.teamInsightsEnabled / employees.length) * 100)}%
              </div>
              <p className="text-xs text-amber-100 mt-1">sharing with teams</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="access">Access Logs</TabsTrigger>
            <TabsTrigger value="privacy">Privacy Settings</TabsTrigger>
            <TabsTrigger value="compliance">Compliance</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Access by Data Type</CardTitle>
                  <CardDescription>What data is being accessed</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={accessTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={100}
                        dataKey="value"
                      >
                        {accessTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Access Levels</CardTitle>
                  <CardDescription>How data is being viewed</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={accessLevelData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#8b5cf6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Privacy Preferences Distribution</CardTitle>
                <CardDescription>Employee privacy setting adoption</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={privacyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="access">
            <Card>
              <CardHeader>
                <CardTitle>Recent Access Events</CardTitle>
                <CardDescription>Detailed access log for {timeRange}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3 font-semibold text-sm">Time</th>
                        <th className="text-left p-3 font-semibold text-sm">Accessor</th>
                        <th className="text-left p-3 font-semibold text-sm">Role</th>
                        <th className="text-left p-3 font-semibold text-sm">Data Type</th>
                        <th className="text-left p-3 font-semibold text-sm">Access Level</th>
                        <th className="text-left p-3 font-semibold text-sm">Target</th>
                      </tr>
                    </thead>
                    <tbody>
                      {accessLogs.slice(0, 50).map((log) => (
                        <tr key={log.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 text-sm">{format(new Date(log.created_date), 'MMM d, HH:mm')}</td>
                          <td className="p-3 text-sm font-medium">{log.accessor_email}</td>
                          <td className="p-3 text-sm">
                            <Badge variant="outline">{log.accessor_role}</Badge>
                          </td>
                          <td className="p-3 text-sm">{log.data_type}</td>
                          <td className="p-3">
                            <Badge className={
                              log.access_level === 'identified' ? 'bg-blue-600' :
                              log.access_level === 'anonymized' ? 'bg-purple-600' :
                              'bg-green-600'
                            }>
                              {log.access_level}
                            </Badge>
                          </td>
                          <td className="p-3 text-sm text-gray-600">
                            {log.target_user_email || log.target_department || 'Organization-wide'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {accessLogs.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <Activity className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p>No access events in selected period</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy">
            <Card>
              <CardHeader>
                <CardTitle>Employee Privacy Settings Overview</CardTitle>
                <CardDescription>Summary of privacy preferences across organization</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <div className="space-y-3">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Manager Access Granted</span>
                        <Badge className="bg-blue-600">{privacyStats.managerAccessEnabled}</Badge>
                      </div>
                      <div className="w-full bg-blue-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${(privacyStats.managerAccessEnabled / employees.length) * 100}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-600 mt-2">
                        {Math.round((privacyStats.managerAccessEnabled / employees.length) * 100)}% of employees
                      </p>
                    </div>

                    <div className="p-4 bg-purple-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Executive Anonymized Access</span>
                        <Badge className="bg-purple-600">{privacyStats.executiveAccessEnabled}</Badge>
                      </div>
                      <div className="w-full bg-purple-200 rounded-full h-2">
                        <div
                          className="bg-purple-600 h-2 rounded-full"
                          style={{ width: `${(privacyStats.executiveAccessEnabled / employees.length) * 100}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-600 mt-2">
                        {Math.round((privacyStats.executiveAccessEnabled / employees.length) * 100)}% of employees
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">Team Insights Sharing</span>
                        <Badge className="bg-green-600">{privacyStats.teamInsightsEnabled}</Badge>
                      </div>
                      <div className="w-full bg-green-200 rounded-full h-2">
                        <div
                          className="bg-green-600 h-2 rounded-full"
                          style={{ width: `${(privacyStats.teamInsightsEnabled / employees.length) * 100}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-600 mt-2">
                        {Math.round((privacyStats.teamInsightsEnabled / employees.length) * 100)}% of employees
                      </p>
                    </div>

                    <div className="p-4 bg-amber-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-gray-900">HR Access Granted</span>
                        <Badge className="bg-amber-600">{privacyStats.hrAccessEnabled}</Badge>
                      </div>
                      <div className="w-full bg-amber-200 rounded-full h-2">
                        <div
                          className="bg-amber-600 h-2 rounded-full"
                          style={{ width: `${(privacyStats.hrAccessEnabled / employees.length) * 100}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-600 mt-2">
                        {Math.round((privacyStats.hrAccessEnabled / employees.length) * 100)}% of employees
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                  <h4 className="font-semibold text-indigo-900 mb-2">Privacy Best Practices:</h4>
                  <ul className="text-sm text-indigo-800 space-y-1">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Default settings protect employee privacy while enabling team insights
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      All executive analytics use anonymized data unless explicitly granted
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Access is logged and auditable for compliance
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Users maintain full control over their data sharing preferences
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="compliance">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Data Protection Compliance</CardTitle>
                  <CardDescription>GDPR and privacy regulation adherence</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">User Consent & Control</h4>
                        <p className="text-sm text-gray-700">
                          All users have granular control over data sharing through Privacy Settings. 
                          Default settings prioritize privacy while enabling organizational insights.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">Access Logging & Auditing</h4>
                        <p className="text-sm text-gray-700">
                          Every data access event is logged with timestamp, accessor, data type, and access level. 
                          Logs are retained for compliance and available for audit.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">Automatic Anonymization</h4>
                        <p className="text-sm text-gray-700">
                          Executive and organizational analytics automatically anonymize employee data. 
                          Individual identities are replaced with anonymous IDs unless explicit permission is granted.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">Role-Based Access Control</h4>
                        <p className="text-sm text-gray-700">
                          Access to data is strictly controlled by role. Employees see their own data, 
                          managers see team aggregates (with opt-in for individual), executives see anonymized analytics.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">Data Minimization</h4>
                        <p className="text-sm text-gray-700">
                          Team insights and organizational analytics aggregate data, showing patterns 
                          and trends without exposing individual responses or personal details.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Security Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {privacyStats.teamInsightsEnabled < employees.length * 0.7 && (
                      <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-lg border border-orange-200">
                        <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Low Team Insights Participation</h4>
                          <p className="text-sm text-gray-700">
                            Consider encouraging employees to enable team insights sharing for better 
                            organizational planning (while maintaining anonymity).
                          </p>
                        </div>
                      </div>
                    )}

                    {employees.filter(e => !e.privacy_settings).length > 0 && (
                      <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">Employees Without Privacy Configuration</h4>
                          <p className="text-sm text-gray-700">
                            {employees.filter(e => !e.privacy_settings).length} employees haven't configured 
                            privacy settings yet. They're using secure defaults.
                          </p>
                        </div>
                      </div>
                    )}

                    {accessLogs.filter(l => l.access_level === 'identified').length > accessLogs.length * 0.3 && (
                      <div className="flex items-start gap-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                        <Eye className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">High Identified Access Rate</h4>
                          <p className="text-sm text-gray-700">
                            {Math.round((accessLogs.filter(l => l.access_level === 'identified').length / accessLogs.length) * 100)}% 
                            of accesses are viewing identified data. Review if this aligns with privacy policies.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}