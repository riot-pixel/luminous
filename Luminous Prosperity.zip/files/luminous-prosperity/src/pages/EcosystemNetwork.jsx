import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { 
  Globe, Users, Lightbulb, MessageCircle, Plus, Search, 
  Sparkles, CheckCircle2, Clock, UserPlus, Building2,
  Target, Brain, Handshake, Award, Shield, Send,
  ThumbsUp, Eye, Lock, Unlock, BarChart3, Mail, PieChart, Database, Copy, Heart
} from "lucide-react";
import EcosystemSynergyAnalyzer from "../components/ecosystem/EcosystemSynergyAnalyzer";
import PartnerOutreachAI from "../components/ecosystem/PartnerOutreachAI";
import PartnershipKPIDashboard from "../components/ecosystem/PartnershipKPIDashboard";
import SuggestedConnectionsAI from "../components/ecosystem/SuggestedConnectionsAI";
import PartnerOnboardingFlow from "../components/ecosystem/PartnerOnboardingFlow";
import ChallengeSolutionSystem from "../components/ecosystem/ChallengeSolutionSystem";
import CRMSyncManager from "../components/ecosystem/CRMSyncManager";
import ConnectionHealthAnalyzer from "../components/ecosystem/ConnectionHealthAnalyzer";
import ProjectAIAssistant from "../components/ecosystem/ProjectAIAssistant";
import PartnerFeedbackSystem from "../components/ecosystem/PartnerFeedbackSystem";
import CRMContactSuggestions from "../components/ecosystem/CRMContactSuggestions";
import AutomatedCRMTasks from "../components/ecosystem/AutomatedCRMTasks";

const CHALLENGE_CATEGORIES = [
  { value: "technology", label: "Technology", icon: Brain },
  { value: "culture", label: "Culture", icon: Users },
  { value: "process", label: "Process", icon: Target },
  { value: "strategy", label: "Strategy", icon: Lightbulb },
  { value: "leadership", label: "Leadership", icon: Award },
  { value: "innovation", label: "Innovation", icon: Sparkles },
  { value: "sustainability", label: "Sustainability", icon: Globe },
  { value: "talent", label: "Talent", icon: UserPlus }
];

export default function EcosystemNetwork() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [showChallengeDialog, setShowChallengeDialog] = useState(false);
  const [showMatchDialog, setShowMatchDialog] = useState(false);
  const [isMatching, setIsMatching] = useState(false);
  const [matchResults, setMatchResults] = useState(null);
  const [selectedChallenge, setSelectedChallenge] = useState(null);
  const [newChallenge, setNewChallenge] = useState({
    title: "",
    description: "",
    category: "",
    skills_needed: "",
    visibility: "public"
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: organization } = useQuery({
    queryKey: ['myOrganization'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      return orgs[0] || null;
    },
  });

  const { data: connections } = useQuery({
    queryKey: ['myConnections', user?.email],
    queryFn: () => base44.entities.EcosystemConnection.filter({ requester_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: incomingConnections } = useQuery({
    queryKey: ['incomingConnections', user?.email],
    queryFn: () => base44.entities.EcosystemConnection.filter({ recipient_email: user?.email, status: 'pending' }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: challenges } = useQuery({
    queryKey: ['sharedChallenges'],
    queryFn: () => base44.entities.SharedChallenge.filter({ status: 'open' }, '-created_date'),
    initialData: [],
  });

  const { data: myChallenges } = useQuery({
    queryKey: ['myChallenges', user?.email],
    queryFn: () => base44.entities.SharedChallenge.filter({ posted_by_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: projects } = useQuery({
    queryKey: ['collaborativeProjects'],
    queryFn: () => base44.entities.CollaborativeProject.filter({ status: 'active' }),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['mySkills', user?.email],
    queryFn: () => base44.entities.UserSkill.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: orgAI } = useQuery({
    queryKey: ['orgAIForEcosystem'],
    queryFn: async () => {
      const results = await base44.entities.OrganizationAI.list('-compilation_date', 1);
      return results[0] || null;
    },
  });

  const { data: ecosystemReports } = useQuery({
    queryKey: ['ecosystemReports'],
    queryFn: () => base44.entities.EcosystemOpportunityReport.list('-generation_date', 10),
    initialData: [],
  });

  const { data: outreaches } = useQuery({
    queryKey: ['partnerOutreaches'],
    queryFn: () => base44.entities.PartnerOutreach.list('-created_date', 50),
    initialData: [],
  });

  const createChallengeMutation = useMutation({
    mutationFn: (data) => base44.entities.SharedChallenge.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedChallenges'] });
      queryClient.invalidateQueries({ queryKey: ['myChallenges'] });
      setShowChallengeDialog(false);
      setNewChallenge({ title: "", description: "", category: "", skills_needed: "", visibility: "public" });
    },
  });

  const createConnectionMutation = useMutation({
    mutationFn: (data) => base44.entities.EcosystemConnection.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
    },
  });

  const updateConnectionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EcosystemConnection.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
      queryClient.invalidateQueries({ queryKey: ['incomingConnections'] });
    },
  });

  const submitChallenge = async () => {
    await createChallengeMutation.mutateAsync({
      title: newChallenge.title,
      description: newChallenge.description,
      category: newChallenge.category,
      posted_by_email: user.email,
      posted_by_org: organization?.name || user.organization_name,
      skills_needed: newChallenge.skills_needed.split(',').map(s => s.trim()).filter(Boolean),
      visibility: newChallenge.visibility,
      status: "open"
    });
  };

  const findMatches = async () => {
    setIsMatching(true);
    try {
      const mySkillNames = userSkills?.map(s => `${s.skill_name} (${s.current_proficiency || 'Intermediate'})`) || [];
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert AI matchmaker for a cross-organizational professional network. Provide DETAILED, ACTIONABLE matching insights.

USER PROFILE:
- Name: ${user?.full_name || 'Professional'}
- Organization: ${organization?.name || 'Unknown'}
- Skills with proficiency: ${mySkillNames.join(', ') || 'General business skills'}
- Department: ${user?.department || 'Unknown'}

AVAILABLE CHALLENGES:
${challenges?.slice(0, 10).map(c => `
CHALLENGE: "${c.title}"
- Category: ${c.category}
- Posted by: ${c.posted_by_org || 'Organization'}
- Description: ${c.description?.substring(0, 200)}
- Skills needed: ${c.skills_needed?.join(', ') || 'Various'}
- Status: ${c.status}
`).join('\n---\n')}

For EACH of the top 5 matching challenges, provide:

1. DETAILED SKILL ALIGNMENT BREAKDOWN:
   - Map each of the user's skills to specific challenge requirements
   - Explain HOW each skill applies (e.g., "User's Python expertise directly enables the data pipeline work needed")
   - Rate each skill match (Strong/Moderate/Partial)

2. POTENTIAL IMPACT ASSESSMENT:
   - What specific outcomes could the user drive?
   - Quantify potential impact where possible
   - Timeline for meaningful contribution

3. PRE-WRITTEN ENGAGEMENT MESSAGE:
   - A personalized, ready-to-send message draft
   - Include specific references to the challenge
   - Highlight the user's relevant experience
   - Propose concrete next steps
   - Keep it professional but warm (150-200 words)`,
        response_json_schema: {
          type: "object",
          properties: {
            matches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  challenge_title: { type: "string" },
                  match_score: { type: "number" },
                  skill_alignment_breakdown: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        user_skill: { type: "string" },
                        challenge_need: { type: "string" },
                        alignment_strength: { type: "string" },
                        application_explanation: { type: "string" }
                      }
                    }
                  },
                  impact_assessment: {
                    type: "object",
                    properties: {
                      potential_outcomes: { type: "array", items: { type: "string" } },
                      estimated_impact: { type: "string" },
                      contribution_timeline: { type: "string" },
                      unique_value_add: { type: "string" }
                    }
                  },
                  engagement_message_draft: { type: "string" },
                  match_reason: { type: "string" },
                  recommended_approach: { type: "string" }
                }
              }
            },
            overall_recommendation: { type: "string" },
            priority_action: { type: "string" }
          }
        }
      });

      setMatchResults(result);
      setShowMatchDialog(true);
    } catch (error) {
      console.error("Error finding matches:", error);
    }
    setIsMatching(false);
  };

  const acceptConnection = async (connectionId) => {
    await updateConnectionMutation.mutateAsync({
      id: connectionId,
      data: { status: 'accepted', mutual_consent_date: new Date().toISOString() }
    });
  };

  const filteredChallenges = challenges?.filter(c => 
    !searchQuery || 
    c.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const acceptedConnections = connections?.filter(c => c.status === 'accepted') || [];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Ecosystem Network</h1>
            <p className="text-gray-400">Connect, collaborate, and solve challenges across organizations</p>
          </div>
          <div className="flex gap-3">
            <PartnerOnboardingFlow 
              user={user} 
              organization={organization}
              onComplete={() => queryClient.invalidateQueries({ queryKey: ['myConnections'] })}
            />
            <Button 
              onClick={findMatches} 
              disabled={isMatching}
              variant="outline" 
              className="border-purple-600 text-purple-400 hover:bg-purple-900/30"
            >
              {isMatching ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Finding Matches...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> AI Match</>
              )}
            </Button>
            <Dialog open={showChallengeDialog} onOpenChange={setShowChallengeDialog}>
              <DialogTrigger asChild>
                <Button className="bg-white text-black hover:bg-gray-200">
                  <Plus className="w-4 h-4 mr-2" />
                  Post Challenge
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
                <DialogHeader>
                  <DialogTitle>Post a Challenge</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Category</label>
                    <Select value={newChallenge.category} onValueChange={(v) => setNewChallenge({...newChallenge, category: v})}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {CHALLENGE_CATEGORIES.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Title</label>
                    <Input
                      value={newChallenge.title}
                      onChange={(e) => setNewChallenge({...newChallenge, title: e.target.value})}
                      placeholder="What challenge are you facing?"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Description</label>
                    <Textarea
                      value={newChallenge.description}
                      onChange={(e) => setNewChallenge({...newChallenge, description: e.target.value})}
                      placeholder="Describe the challenge in detail..."
                      className="bg-gray-800 border-gray-700 text-white h-32"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Skills Needed (comma-separated)</label>
                    <Input
                      value={newChallenge.skills_needed}
                      onChange={(e) => setNewChallenge({...newChallenge, skills_needed: e.target.value})}
                      placeholder="e.g., data analysis, leadership, UX design"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Visibility</label>
                    <Select value={newChallenge.visibility} onValueChange={(v) => setNewChallenge({...newChallenge, visibility: v})}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public - Anyone can see</SelectItem>
                        <SelectItem value="verified_orgs_only">Verified Organizations Only</SelectItem>
                        <SelectItem value="invite_only">Invite Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    onClick={submitChallenge} 
                    disabled={!newChallenge.title || !newChallenge.category}
                    className="w-full bg-white text-black hover:bg-gray-200"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Post Challenge
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-900 flex items-center justify-center">
                  <Handshake className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Connections</p>
                  <p className="text-2xl font-bold text-white">{acceptedConnections.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                  <Lightbulb className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Open Challenges</p>
                  <p className="text-2xl font-bold text-white">{challenges?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-green-900 flex items-center justify-center">
                  <Target className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Active Projects</p>
                  <p className="text-2xl font-bold text-white">{projects?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-orange-900 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-orange-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Pending Requests</p>
                  <p className="text-2xl font-bold text-white">{incomingConnections?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Connection Requests */}
        {incomingConnections?.length > 0 && (
          <Card className="bg-gradient-to-r from-orange-900/30 to-orange-950/30 border-orange-800 mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-orange-400" />
                Pending Connection Requests ({incomingConnections.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {incomingConnections.map(conn => (
                  <div key={conn.id} className="flex items-center justify-between p-4 bg-gray-900 rounded-lg">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarFallback className="bg-orange-600">{conn.requester_email?.[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-white font-medium">{conn.requester_email}</p>
                        <p className="text-gray-400 text-sm">{conn.requester_org} • {conn.connection_type}</p>
                        {conn.ai_match_reason && (
                          <p className="text-purple-400 text-xs mt-1">{conn.ai_match_reason}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => acceptConnection(conn.id)} className="bg-green-600 hover:bg-green-700">
                        Accept
                      </Button>
                      <Button size="sm" variant="outline" className="border-gray-700 text-gray-400">
                        Decline
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="synergy" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="synergy">
              <BarChart3 className="w-4 h-4 mr-1" />
              Synergy Analysis
            </TabsTrigger>
            <TabsTrigger value="outreach">
              <Mail className="w-4 h-4 mr-1" />
              AI Outreach
            </TabsTrigger>
            <TabsTrigger value="kpi">
              <PieChart className="w-4 h-4 mr-1" />
              KPI Dashboard
            </TabsTrigger>
            <TabsTrigger value="suggested">
              <Sparkles className="w-4 h-4 mr-1" />
              Suggested
            </TabsTrigger>
            <TabsTrigger value="health">
              <Heart className="w-4 h-4 mr-1" />
              Connection Health
            </TabsTrigger>
            <TabsTrigger value="challenges">Challenge Board</TabsTrigger>
            <TabsTrigger value="connections">My Connections</TabsTrigger>
            <TabsTrigger value="projects">Collaborative Projects</TabsTrigger>
            <TabsTrigger value="my-challenges">My Challenges</TabsTrigger>
            <TabsTrigger value="crm">
              <Database className="w-4 h-4 mr-1" />
              CRM Sync
            </TabsTrigger>
          </TabsList>

          <TabsContent value="synergy">
            <EcosystemSynergyAnalyzer
              connections={connections}
              projects={projects}
              challenges={challenges}
              organization={organization}
              userSkills={userSkills}
              orgAI={orgAI}
            />
          </TabsContent>

          <TabsContent value="outreach">
            <PartnerOutreachAI ecosystemReports={ecosystemReports} />
          </TabsContent>

          <TabsContent value="kpi">
            <PartnershipKPIDashboard 
              connections={connections}
              projects={projects}
              reports={ecosystemReports}
              outreaches={outreaches}
            />
          </TabsContent>

          <TabsContent value="suggested">
            <SuggestedConnectionsAI
              user={user}
              organization={organization}
              userSkills={userSkills}
              challenges={challenges}
              projects={projects}
              connections={connections}
            />
          </TabsContent>

          <TabsContent value="health">
            <ConnectionHealthAnalyzer
              connections={connections}
              projects={projects}
              user={user}
            />
          </TabsContent>

          <TabsContent value="challenges">
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search challenges..."
                  className="bg-gray-900 border-gray-800 text-white pl-10"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredChallenges?.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <Lightbulb className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No challenges found</p>
                  <p className="text-gray-500 text-sm">Be the first to post a challenge!</p>
                </div>
              ) : (
                filteredChallenges?.map(challenge => {
                  const CategoryIcon = CHALLENGE_CATEGORIES.find(c => c.value === challenge.category)?.icon || Lightbulb;
                  return (
                    <Card key={challenge.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors">
                      <CardContent className="p-5">
                        <div className="flex items-start justify-between mb-3">
                          <div className="w-10 h-10 rounded-lg bg-purple-900 flex items-center justify-center">
                            <CategoryIcon className="w-5 h-5 text-purple-400" />
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="border-gray-700 text-gray-400 capitalize">
                              {challenge.category}
                            </Badge>
                            {challenge.visibility === 'public' ? (
                              <Unlock className="w-4 h-4 text-green-500" />
                            ) : (
                              <Lock className="w-4 h-4 text-orange-500" />
                            )}
                          </div>
                        </div>
                        <h3 className="text-white font-medium mb-2">{challenge.title}</h3>
                        <p className="text-gray-400 text-sm line-clamp-3 mb-3">{challenge.description}</p>
                        <div className="flex flex-wrap gap-1 mb-4">
                          {challenge.skills_needed?.slice(0, 3).map((skill, i) => (
                            <span key={i} className="text-xs px-2 py-0.5 bg-gray-800 text-gray-300 rounded">{skill}</span>
                          ))}
                        </div>
                        <div className="flex items-center justify-between pt-3 border-t border-gray-800">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6">
                              <AvatarFallback className="text-xs bg-gray-700">{challenge.posted_by_email?.[0]?.toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <span className="text-gray-500 text-xs">{challenge.posted_by_org}</span>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="border-purple-600 text-purple-400 hover:bg-purple-900/30"
                            onClick={() => setSelectedChallenge(challenge)}
                          >
                            <MessageCircle className="w-3 h-3 mr-1" />
                            Engage
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
              </div>

              {/* Selected Challenge Solutions */}
              {selectedChallenge && (
              <Card className="bg-gray-900 border-gray-800 mt-6">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-white">{selectedChallenge.title}</CardTitle>
                      <CardDescription className="text-gray-400">{selectedChallenge.description}</CardDescription>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setSelectedChallenge(null)}
                      className="text-gray-400"
                    >
                      ✕
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ChallengeSolutionSystem
                    challenge={selectedChallenge}
                    user={user}
                    organization={organization}
                    userSkills={userSkills}
                  />
                </CardContent>
              </Card>
              )}
              </TabsContent>

              <TabsContent value="connections">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">My Connections</CardTitle>
                <CardDescription className="text-gray-400">People you're connected with across organizations</CardDescription>
              </CardHeader>
              <CardContent>
                {acceptedConnections.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No connections yet</p>
                    <p className="text-gray-500 text-sm">Use AI Match to find people to connect with!</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {acceptedConnections.map(conn => (
                      <div key={conn.id} className="flex items-center gap-4 p-4 bg-gray-800 rounded-lg">
                        <Avatar>
                          <AvatarFallback className="bg-blue-600">{conn.recipient_email?.[0]?.toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="text-white font-medium">{conn.recipient_email}</p>
                          <p className="text-gray-400 text-sm">{conn.recipient_org}</p>
                          <Badge variant="outline" className="text-xs border-gray-700 text-gray-500 mt-1">{conn.connection_type}</Badge>
                        </div>
                        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                          <MessageCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Collaborative Projects</CardTitle>
                <CardDescription className="text-gray-400">Cross-organizational projects you're part of</CardDescription>
              </CardHeader>
              <CardContent>
                {projects?.length === 0 ? (
                  <div className="text-center py-12">
                    <Target className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No active projects</p>
                    <p className="text-gray-500 text-sm">Engage with challenges to start collaborating!</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {projects.map(project => (
                      <Card key={project.id} className="bg-gray-800 border-gray-700">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="text-white font-medium">{project.name}</h4>
                              <p className="text-gray-400 text-sm">{project.description}</p>
                            </div>
                            <Badge className={project.status === 'active' ? 'bg-green-600' : project.status === 'completed' ? 'bg-blue-600' : 'bg-gray-600'}>
                              {project.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mb-4">
                            <div className="flex -space-x-2">
                              {project.members?.slice(0, 4).map((m, i) => (
                                <Avatar key={i} className="w-8 h-8 border-2 border-gray-800">
                                  <AvatarFallback className="text-xs bg-purple-600">{m.email?.[0]?.toUpperCase()}</AvatarFallback>
                                </Avatar>
                              ))}
                            </div>
                            <span className="text-gray-500 text-sm">{project.members?.length || 0} members</span>
                            <span className="text-gray-500 text-sm">{project.organizations_involved?.length || 0} organizations</span>
                          </div>
                          
                          {/* AI Assistant & Feedback */}
                          <div className="border-t border-gray-700 pt-4 space-y-4">
                            <ProjectAIAssistant project={project} connections={connections} userSkills={userSkills} user={user} />
                            {(project.status === 'completed' || project.status === 'active') && (
                              <PartnerFeedbackSystem project={project} user={user} />
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="my-challenges">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">My Posted Challenges</CardTitle>
              </CardHeader>
              <CardContent>
                {myChallenges?.length === 0 ? (
                  <div className="text-center py-12">
                    <Lightbulb className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">You haven't posted any challenges</p>
                    <Button onClick={() => setShowChallengeDialog(true)} className="mt-4 bg-white text-black hover:bg-gray-200">
                      <Plus className="w-4 h-4 mr-2" />
                      Post Your First Challenge
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {myChallenges.map(challenge => (
                      <div key={challenge.id} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="text-white font-medium">{challenge.title}</h4>
                            <p className="text-gray-400 text-sm mt-1">{challenge.description}</p>
                          </div>
                          <Badge className={challenge.status === 'open' ? 'bg-green-600' : 'bg-gray-600'}>
                            {challenge.status}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {challenge.solutions_count || 0} solutions
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            {challenge.discussion_count || 0} discussions
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="crm">
            <div className="space-y-6">
              <CRMSyncManager 
                connections={connections}
                outreaches={outreaches}
                reports={ecosystemReports}
              />
              <div className="grid md:grid-cols-2 gap-6">
                <CRMContactSuggestions 
                  connections={connections}
                  outreaches={outreaches}
                  reports={ecosystemReports}
                  user={user}
                />
                <AutomatedCRMTasks 
                  connections={connections}
                  feedback={[]}
                  user={user}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Enhanced AI Match Results Dialog */}
        <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
          <DialogContent className="max-w-2xl bg-gray-900 border-gray-800 text-white max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                AI Match Results - Detailed Insights
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {matchResults?.overall_recommendation && (
                <div className="p-3 bg-purple-900/30 border border-purple-800 rounded-lg">
                  <p className="text-gray-300 text-sm">{matchResults.overall_recommendation}</p>
                  {matchResults.priority_action && (
                    <p className="text-purple-400 text-sm mt-2 font-medium">→ {matchResults.priority_action}</p>
                  )}
                </div>
              )}
              
              {matchResults?.matches?.map((match, i) => (
                <div key={i} className="p-4 bg-gray-800 rounded-lg space-y-4">
                  <div className="flex items-start justify-between">
                    <h4 className="text-white font-medium">{match.challenge_title}</h4>
                    <Badge className="bg-purple-600">{match.match_score}% match</Badge>
                  </div>
                  
                  {/* Skill Alignment Breakdown */}
                  {match.skill_alignment_breakdown?.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-gray-400 text-xs font-medium uppercase">Skill Alignment</p>
                      {match.skill_alignment_breakdown.map((skill, j) => (
                        <div key={j} className="flex items-start gap-3 p-2 bg-gray-700 rounded text-sm">
                          <Badge className={
                            skill.alignment_strength === 'Strong' ? 'bg-green-600' :
                            skill.alignment_strength === 'Moderate' ? 'bg-yellow-600' : 'bg-blue-600'
                          } variant="outline">
                            {skill.alignment_strength}
                          </Badge>
                          <div className="flex-1">
                            <p className="text-white">
                              <span className="text-purple-400">{skill.user_skill}</span> → <span className="text-cyan-400">{skill.challenge_need}</span>
                            </p>
                            <p className="text-gray-400 text-xs">{skill.application_explanation}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Impact Assessment */}
                  {match.impact_assessment && (
                    <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg">
                      <p className="text-green-400 text-xs font-medium uppercase mb-2">Potential Impact</p>
                      <ul className="space-y-1">
                        {match.impact_assessment.potential_outcomes?.map((outcome, j) => (
                          <li key={j} className="text-gray-300 text-sm flex items-start gap-2">
                            <CheckCircle2 className="w-3 h-3 mt-1 text-green-500 flex-shrink-0" />
                            {outcome}
                          </li>
                        ))}
                      </ul>
                      <div className="flex gap-4 mt-2 text-xs">
                        <span className="text-gray-400">Timeline: <span className="text-white">{match.impact_assessment.contribution_timeline}</span></span>
                        <span className="text-gray-400">Impact: <span className="text-green-400">{match.impact_assessment.estimated_impact}</span></span>
                      </div>
                    </div>
                  )}

                  {/* Engagement Message Draft */}
                  {match.engagement_message_draft && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-gray-400 text-xs font-medium uppercase">Ready-to-Send Message</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-gray-400 hover:text-white h-6"
                          onClick={() => {
                            navigator.clipboard.writeText(match.engagement_message_draft);
                          }}
                        >
                          <Copy className="w-3 h-3 mr-1" />
                          Copy
                        </Button>
                      </div>
                      <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                        <p className="text-gray-300 text-sm whitespace-pre-wrap">{match.engagement_message_draft}</p>
                      </div>
                    </div>
                  )}

                  {match.recommended_approach && (
                    <p className="text-cyan-400 text-xs">💡 {match.recommended_approach}</p>
                  )}
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}