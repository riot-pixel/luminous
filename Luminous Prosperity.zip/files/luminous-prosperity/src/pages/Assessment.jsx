import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import IntegralTheorySection from "../components/assessment/IntegralTheorySection";
import MyersBriggsSection from "../components/assessment/MyersBriggsSection";
import StrengthsSection from "../components/assessment/StrengthsSection";
import LifeWheelSection from "../components/assessment/LifeWheelSection";
import AppreciativeInquirySection from "../components/assessment/AppreciativeInquirySection";
import DepartmentalAISection from "../components/assessment/DepartmentalAISection";
import ProgressTracker from "../components/assessment/ProgressTracker";
import AssessmentTutorial from "../components/onboarding/AssessmentTutorial";

export default function Assessment() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [currentSection, setCurrentSection] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  const [showTutorial, setShowTutorial] = useState(false);
  
  const [assessmentData, setAssessmentData] = useState({
    integralTheory: null,
    myersBriggs: null,
    strengths: null,
    lifeWheel: null,
    appreciativeInquiry: null,
    departmentalAI: null,
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  useEffect(() => {
    const loadUserInfo = async () => {
      try {
        const user = await base44.auth.me();
        setUserInfo(user);

        // Show tutorial if not seen before
        if (!user.tutorials_seen?.assessment_tutorial) {
          setShowTutorial(true);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUserInfo();
  }, []);

  const sections = [
    { name: "Integral Theory", key: "integralTheory", component: IntegralTheorySection },
    { name: "Myers-Briggs", key: "myersBriggs", component: MyersBriggsSection },
    { name: "Character Strengths", key: "strengths", component: StrengthsSection },
    { name: "Life Balance", key: "lifeWheel", component: LifeWheelSection },
    { name: "Personal AI", key: "appreciativeInquiry", component: AppreciativeInquirySection },
    { name: "Departmental AI", key: "departmentalAI", component: DepartmentalAISection },
  ];

  const CurrentSectionComponent = sections[currentSection].component;

  const handleSectionComplete = (data) => {
    const key = sections[currentSection].key;
    setAssessmentData(prev => ({
      ...prev,
      [key]: data,
    }));

    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      completeAssessment({
        ...assessmentData,
        [key]: data,
      });
    }
  };

  const completeAssessment = async (finalData) => {
    setIsProcessing(true);
    try {
      const user = await base44.auth.me();
      
      const insights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist and career development specialist.

Analyze this comprehensive employee assessment and provide integrated insights (350-400 words):

PERSONAL ASSESSMENT:
${JSON.stringify({
  integral_theory: finalData.integralTheory,
  myers_briggs: finalData.myersBriggs,
  strengths: finalData.strengths,
  life_wheel: finalData.lifeWheel,
  appreciative_inquiry: finalData.appreciativeInquiry
}, null, 2)}

ORGANIZATIONAL CONTEXT:
Department: ${user.department || 'Not specified'}
Role: ${user.job_title || 'Not specified'}

DEPARTMENTAL CONTRIBUTION:
${JSON.stringify(finalData.departmentalAI, null, 2)}

Provide insights on:
1. Core personality and strength patterns
2. Alignment between personal values and organizational role
3. Development opportunities within current department
4. How to leverage strengths for departmental excellence
5. Contribution potential to organizational goals
6. Balance between personal growth and professional impact
7. Specific recommendations for maximizing effectiveness in current role

Write in an empowering, professional coaching tone.`,
      });

      await base44.entities.Assessment.create({
        user_email: user.email,
        department: user.department,
        role: user.job_title,
        completed_date: new Date().toISOString(),
        integral_theory: finalData.integralTheory,
        myers_briggs: finalData.myersBriggs,
        strengths: finalData.strengths,
        life_wheel: finalData.lifeWheel,
        appreciative_inquiry: finalData.appreciativeInquiry,
        departmental_ai: finalData.departmentalAI,
        overall_insights: insights,
      });

      // Update onboarding tasks
      await updateUserMutation.mutateAsync({
        onboarding_tasks: {
          ...user.onboarding_tasks,
          completed_assessment: true,
        },
      });

      navigate(createPageUrl("Results"));
    } catch (error) {
      console.error("Error saving assessment:", error);
    }
    setIsProcessing(false);
  };

  const handleBack = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <AssessmentTutorial 
        isOpen={showTutorial} 
        onClose={() => setShowTutorial(false)}
        user={userInfo}
      />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <ProgressTracker 
          sections={sections.map(s => s.name)} 
          currentSection={currentSection}
          completedSections={Object.keys(assessmentData).filter(k => assessmentData[k] !== null).length}
        />

        <div className="mt-12">
          <CurrentSectionComponent
            onComplete={handleSectionComplete}
            onBack={currentSection > 0 ? handleBack : null}
            initialData={assessmentData[sections[currentSection].key]}
            isProcessing={isProcessing}
            userDepartment={userInfo?.department || 'Your Department'}
            userRole={userInfo?.job_title || 'Your Role'}
          />
        </div>
      </div>
    </div>
  );
}