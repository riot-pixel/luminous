import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Building2, Sparkles, TrendingUp, Users, Target, RefreshCw, Heart,
  Briefcase, Globe, Leaf, DollarSign, Scale, Brain, Lightbulb,
  BarChart3, Shield, Zap, Bell, Calendar, CheckCircle2, AlertTriangle,
  ArrowRight, Handshake, PieChart, Activity, Sun, Moon, Coffee,
  Megaphone, Award, BookOpen, HeartHandshake, TreePine, Building, Landmark
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, AreaChart, Area, LineChart, Line, Legend } from "recharts";
import ReactMarkdown from "react-markdown";
import { format } from "date-fns";

const ANALYSIS_SECTIONS = [
  { id: "job_satisfaction", label: "Job Satisfaction", icon: Briefcase, color: "#3b82f6" },
  { id: "productivity", label: "Productivity & Performance", icon: TrendingUp, color: "#10b981" },
  { id: "market_dynamics", label: "Market Dynamics", icon: BarChart3, color: "#8b5cf6" },
  { id: "economic_factors", label: "Economic & Financial", icon: DollarSign, color: "#f59e0b" },
  { id: "political_landscape", label: "Political & Regulatory", icon: Landmark, color: "#ef4444" },
  { id: "social_issues", label: "Social Issues & Causes", icon: HeartHandshake, color: "#ec4899" },
  { id: "environmental", label: "Environmental Impact", icon: TreePine, color: "#22c55e" },
  { id: "wellness", label: "Employee Wellness", icon: Heart, color: "#06b6d4" },
  { id: "innovation", label: "Innovation & Technology", icon: Lightbulb, color: "#a855f7" },
  { id: "culture", label: "Culture & Values", icon: Users, color: "#f97316" }
];

const SECTOR_INTERSECTIONS = [
  { sectors: ["organization", "government"], label: "Public-Private Partnership" },
  { sectors: ["organization", "community"], label: "Community Engagement" },
  { sectors: ["organization", "environment"], label: "Sustainability Initiatives" },
  { sectors: ["organization", "education"], label: "Workforce Development" },
  { sectors: ["organization", "healthcare"], label: "Employee Health Programs" },
  { sectors: ["organization", "technology"], label: "Digital Transformation" },
  { sectors: ["organization", "finance"], label: "Economic Growth" },
  { sectors: ["organization", "nonprofits"], label: "Social Impact" },
  { sectors: ["employees", "community"], label: "Volunteer Programs" },
  { sectors: ["employees", "environment"], label: "Green Workforce" },
  { sectors: ["innovation", "sustainability"], label: "Clean Tech" },
  { sectors: ["culture", "productivity"], label: "Engaged Workforce" }
];

const COLORS = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899', '#22c55e', '#06b6d4', '#a855f7', '#f97316'];

export default function OrganizationalAI() {
  const queryClient = useQueryClient();
  const [isCompiling, setIsCompiling] = useState(false);
  const [compilationProgress, setCompilationProgress] = useState(0);
  const [compilationStep, setCompilationStep] = useState("");
  const [dailyBriefingEnabled, setDailyBriefingEnabled] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [activeSection, setActiveSection] = useState("overview");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments, isLoading } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: orgAI, isLoading: loadingOrgAI } = useQuery({
    queryKey: ['orgAI'],
    queryFn: () => base44.entities.OrganizationAI.list('-compilation_date'),
    initialData: [],
  });

  const { data: deptAI, isLoading: loadingDeptAI } = useQuery({
    queryKey: ['deptAI'],
    queryFn: () => base44.entities.DepartmentAI.list('-compilation_date'),
    initialData: [],
  });

  const { data: wellnessLogs } = useQuery({
    queryKey: ['orgWellnessLogs'],
    queryFn: () => base44.entities.WellnessLog.list('-log_date', 500),
    initialData: [],
  });

  const { data: contributions } = useQuery({
    queryKey: ['orgContributions'],
    queryFn: () => base44.entities.ContributionRecord.list('-contribution_date', 500),
    initialData: [],
  });

  const createOrgAIMutation = useMutation({
    mutationFn: (data) => base44.entities.OrganizationAI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orgAI'] });
    },
  });

  const createDeptAIMutation = useMutation({
    mutationFn: (data) => base44.entities.DepartmentAI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deptAI'] });
    },
  });

  // Check and send daily briefing notification
  useEffect(() => {
    if (dailyBriefingEnabled && notificationsEnabled && user?.email) {
      const lastBriefing = localStorage.getItem('lastDailyBriefing');
      const today = format(new Date(), 'yyyy-MM-dd');
      
      if (lastBriefing !== today && orgAI[0]) {
        sendDailyBriefing();
        localStorage.setItem('lastDailyBriefing', today);
      }
    }
  }, [dailyBriefingEnabled, notificationsEnabled, user, orgAI]);

  const sendDailyBriefing = async () => {
    if (!user?.email || !orgAI[0]) return;
    
    try {
      const latest = orgAI[0];
      const briefingContent = `
DAILY ORGANIZATIONAL INTELLIGENCE BRIEFING
${format(new Date(), 'PPPP')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 KEY METRICS
• Total Participants: ${latest.total_participants || 0}
• Departments Analyzed: ${latest.departments_included?.length || 0}
• Strategic Priorities: ${latest.strategic_priorities?.length || 0}

🎯 TODAY'S FOCUS
${latest.strategic_priorities?.[0]?.priority || 'Continue building organizational alignment'}

💡 TOP INSIGHT
${latest.comprehensive_synthesis?.slice(0, 300) || 'Analysis in progress...'}

🤝 WIN-WIN OPPORTUNITY OF THE DAY
${latest.synergy_scenarios?.[0]?.title || 'Cross-functional collaboration opportunities being identified'}

📈 WELLNESS INDEX: ${latest.wellness_analysis?.overall_score || 'Calculating...'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

View full analysis at your Organizational AI dashboard.

This is an automated briefing from Luminous Prosperity.
      `;

      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `[Luminous] Daily Intelligence Briefing - ${format(new Date(), 'MMM d, yyyy')}`,
        body: briefingContent
      });
    } catch (error) {
      console.error("Error sending daily briefing:", error);
    }
  };

  const handleCompile = async () => {
    setIsCompiling(true);
    setCompilationProgress(0);
    
    try {
      const relevantAssessments = assessments.filter(a => a.departmental_ai && a.department);
      
      if (relevantAssessments.length === 0) {
        alert("No departmental AI data available yet.");
        setIsCompiling(false);
        return;
      }

      const byDepartment = relevantAssessments.reduce((acc, assessment) => {
        const dept = assessment.department;
        if (!acc[dept]) acc[dept] = [];
        acc[dept].push(assessment);
        return acc;
      }, {});

      // Step 1: Department Analysis
      setCompilationStep("Analyzing departments...");
      setCompilationProgress(10);
      
      for (const [department, deptAssessments] of Object.entries(byDepartment)) {
        const allStrengths = deptAssessments.flatMap(a => a.departmental_ai.department_strengths?.filter(s => s) || []);
        const allAspirations = deptAssessments.flatMap(a => a.departmental_ai.department_aspirations?.filter(s => s) || []);

        const deptSynthesis = await base44.integrations.Core.InvokeLLM({
          prompt: `Synthesize departmental appreciative inquiry for ${department} (${deptAssessments.length} participants):
STRENGTHS: ${allStrengths.join(', ')}
ASPIRATIONS: ${allAspirations.join(', ')}

Provide collective_strengths (5), collective_aspirations (5), collaboration_themes (5), shared_vision, key_initiatives (5 with priority and alignment_score), synthesis (200 words).`,
          response_json_schema: {
            type: "object",
            properties: {
              collective_strengths: { type: "array", items: { type: "string" } },
              collective_aspirations: { type: "array", items: { type: "string" } },
              collaboration_themes: { type: "array", items: { type: "string" } },
              shared_vision: { type: "string" },
              key_initiatives: { type: "array", items: { type: "object", properties: { initiative: { type: "string" }, priority: { type: "string" }, alignment_score: { type: "number" } } } },
              synthesis: { type: "string" }
            }
          }
        });

        await createDeptAIMutation.mutateAsync({
          department,
          compilation_date: new Date().toISOString(),
          participant_count: deptAssessments.length,
          ...deptSynthesis
        });
      }

      setCompilationProgress(20);

      // Step 2: Job Satisfaction Analysis
      setCompilationStep("Analyzing job satisfaction...");
      const jobSatisfactionAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze job satisfaction across ${relevantAssessments.length} employees in ${Object.keys(byDepartment).length} departments.

Assessment data indicators:
- Life satisfaction scores available
- Departmental engagement data
- Career aspiration patterns

Provide comprehensive analysis of:
1. Overall satisfaction index (0-100)
2. Key satisfaction drivers (top 8)
3. Areas of concern (top 5)
4. Department-level satisfaction comparison
5. Recommendations for improvement (8-10)
6. Predicted trends
7. Benchmark comparisons`,
        response_json_schema: {
          type: "object",
          properties: {
            satisfaction_index: { type: "number" },
            key_drivers: { type: "array", items: { type: "object", properties: { driver: { type: "string" }, impact_score: { type: "number" }, trend: { type: "string" } } } },
            concerns: { type: "array", items: { type: "object", properties: { concern: { type: "string" }, severity: { type: "string" }, affected_percentage: { type: "number" } } } },
            department_comparison: { type: "array", items: { type: "object", properties: { department: { type: "string" }, score: { type: "number" }, change: { type: "string" } } } },
            recommendations: { type: "array", items: { type: "object", properties: { recommendation: { type: "string" }, priority: { type: "string" }, expected_impact: { type: "string" }, timeline: { type: "string" } } } },
            trends: { type: "array", items: { type: "string" } },
            benchmarks: { type: "object", properties: { industry_avg: { type: "number" }, top_performers: { type: "number" }, our_position: { type: "string" } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(30);

      // Step 3: Productivity Analysis
      setCompilationStep("Analyzing productivity metrics...");
      const productivityAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze organizational productivity based on:
- ${contributions.length} impact contributions logged
- ${Object.keys(byDepartment).length} departments
- ${relevantAssessments.length} employee assessments

Provide:
1. Productivity index (0-100)
2. Output quality metrics
3. Efficiency indicators
4. Collaboration effectiveness
5. Innovation rate
6. Time utilization patterns
7. Resource optimization opportunities
8. Performance bottlenecks
9. Best practices identified
10. Improvement roadmap`,
        response_json_schema: {
          type: "object",
          properties: {
            productivity_index: { type: "number" },
            quality_metrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, score: { type: "number" }, benchmark: { type: "number" } } } },
            efficiency_indicators: { type: "array", items: { type: "object", properties: { indicator: { type: "string" }, current: { type: "number" }, target: { type: "number" }, gap: { type: "string" } } } },
            collaboration_score: { type: "number" },
            innovation_rate: { type: "number" },
            bottlenecks: { type: "array", items: { type: "object", properties: { bottleneck: { type: "string" }, impact: { type: "string" }, solution: { type: "string" } } } },
            best_practices: { type: "array", items: { type: "string" } },
            improvement_roadmap: { type: "array", items: { type: "object", properties: { phase: { type: "string" }, actions: { type: "array", items: { type: "string" } }, timeline: { type: "string" }, expected_gain: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(40);

      // Step 4: Market Dynamics Analysis
      setCompilationStep("Analyzing market dynamics...");
      const marketAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze market dynamics and competitive positioning for an organization with ${relevantAssessments.length} employees across ${Object.keys(byDepartment).length} departments.

Provide comprehensive market intelligence:
1. Market position assessment
2. Competitive landscape analysis
3. Industry trends impact
4. Customer/client dynamics
5. Market opportunities
6. Competitive threats
7. Differentiation strategies
8. Market share projections
9. Growth vectors
10. Strategic recommendations`,
        response_json_schema: {
          type: "object",
          properties: {
            market_position: { type: "object", properties: { current: { type: "string" }, target: { type: "string" }, gap_analysis: { type: "string" } } },
            competitive_landscape: { type: "array", items: { type: "object", properties: { competitor_type: { type: "string" }, threat_level: { type: "string" }, our_advantage: { type: "string" } } } },
            industry_trends: { type: "array", items: { type: "object", properties: { trend: { type: "string" }, impact: { type: "string" }, our_readiness: { type: "string" }, action_required: { type: "string" } } } },
            opportunities: { type: "array", items: { type: "object", properties: { opportunity: { type: "string" }, potential_value: { type: "string" }, feasibility: { type: "string" }, timeline: { type: "string" } } } },
            threats: { type: "array", items: { type: "object", properties: { threat: { type: "string" }, likelihood: { type: "string" }, mitigation: { type: "string" } } } },
            differentiation_strategies: { type: "array", items: { type: "string" } },
            growth_vectors: { type: "array", items: { type: "object", properties: { vector: { type: "string" }, potential: { type: "string" }, investment_required: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(50);

      // Step 5: Economic & Financial Analysis
      setCompilationStep("Analyzing economic factors...");
      const economicAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze economic and financial implications for organizational strategy:

Consider:
- Workforce of ${relevantAssessments.length} employees
- ${Object.keys(byDepartment).length} departments
- Impact contributions: ${contributions.length}

Provide:
1. Economic impact assessment
2. Financial sustainability metrics
3. Investment priorities
4. Cost optimization opportunities
5. Revenue enhancement strategies
6. Risk-adjusted ROI projections
7. Capital allocation recommendations
8. Economic scenario planning
9. Budget alignment strategies
10. Financial resilience indicators`,
        response_json_schema: {
          type: "object",
          properties: {
            economic_impact: { type: "object", properties: { direct_value: { type: "string" }, indirect_value: { type: "string" }, multiplier_effect: { type: "string" } } },
            sustainability_metrics: { type: "array", items: { type: "object", properties: { metric: { type: "string" }, status: { type: "string" }, trend: { type: "string" } } } },
            investment_priorities: { type: "array", items: { type: "object", properties: { area: { type: "string" }, priority: { type: "string" }, expected_roi: { type: "string" }, payback_period: { type: "string" } } } },
            cost_optimization: { type: "array", items: { type: "object", properties: { opportunity: { type: "string" }, potential_savings: { type: "string" }, implementation_effort: { type: "string" } } } },
            revenue_strategies: { type: "array", items: { type: "object", properties: { strategy: { type: "string" }, potential: { type: "string" }, timeline: { type: "string" } } } },
            scenario_planning: { type: "array", items: { type: "object", properties: { scenario: { type: "string" }, probability: { type: "string" }, impact: { type: "string" }, response: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(55);

      // Step 6: Political & Regulatory Analysis
      setCompilationStep("Analyzing political landscape...");
      const politicalAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze political and regulatory landscape affecting organizational operations:

Provide:
1. Regulatory compliance status
2. Policy changes impact assessment
3. Government relations opportunities
4. Political risk factors
5. Advocacy priorities
6. Public affairs strategy
7. Stakeholder engagement map
8. Compliance roadmap
9. Regulatory forecast
10. Mitigation strategies`,
        response_json_schema: {
          type: "object",
          properties: {
            compliance_status: { type: "object", properties: { overall_score: { type: "number" }, areas_of_excellence: { type: "array", items: { type: "string" } }, gaps: { type: "array", items: { type: "string" } } } },
            policy_impacts: { type: "array", items: { type: "object", properties: { policy: { type: "string" }, impact: { type: "string" }, timeline: { type: "string" }, preparation_status: { type: "string" } } } },
            government_opportunities: { type: "array", items: { type: "object", properties: { opportunity: { type: "string" }, value: { type: "string" }, approach: { type: "string" } } } },
            political_risks: { type: "array", items: { type: "object", properties: { risk: { type: "string" }, likelihood: { type: "string" }, impact: { type: "string" }, mitigation: { type: "string" } } } },
            advocacy_priorities: { type: "array", items: { type: "object", properties: { issue: { type: "string" }, position: { type: "string" }, stakeholders: { type: "array", items: { type: "string" } } } } },
            regulatory_forecast: { type: "array", items: { type: "object", properties: { regulation: { type: "string" }, expected_date: { type: "string" }, preparedness: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(60);

      // Step 7: Social Issues & Causes Analysis
      setCompilationStep("Analyzing social impact...");
      const socialAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze social responsibility and community impact:

Provide:
1. Social impact score (0-100)
2. DEI assessment
3. Community engagement metrics
4. Social causes alignment
5. Stakeholder impact analysis
6. Corporate citizenship rating
7. Social value creation
8. Philanthropic effectiveness
9. Employee volunteerism
10. Social innovation opportunities`,
        response_json_schema: {
          type: "object",
          properties: {
            social_impact_score: { type: "number" },
            dei_assessment: { type: "object", properties: { diversity_score: { type: "number" }, equity_score: { type: "number" }, inclusion_score: { type: "number" }, initiatives: { type: "array", items: { type: "string" } }, gaps: { type: "array", items: { type: "string" } } } },
            community_engagement: { type: "array", items: { type: "object", properties: { initiative: { type: "string" }, impact: { type: "string" }, reach: { type: "string" } } } },
            causes_alignment: { type: "array", items: { type: "object", properties: { cause: { type: "string" }, alignment_score: { type: "number" }, current_involvement: { type: "string" }, opportunity: { type: "string" } } } },
            stakeholder_impact: { type: "array", items: { type: "object", properties: { stakeholder: { type: "string" }, positive_impact: { type: "string" }, areas_for_improvement: { type: "string" } } } },
            social_value_creation: { type: "object", properties: { total_value: { type: "string" }, breakdown: { type: "array", items: { type: "object", properties: { category: { type: "string" }, value: { type: "string" } } } } } },
            social_innovation: { type: "array", items: { type: "object", properties: { innovation: { type: "string" }, social_benefit: { type: "string" }, business_benefit: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(65);

      // Step 8: Environmental Analysis
      setCompilationStep("Analyzing environmental impact...");
      const environmentalAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze environmental sustainability and impact:

Provide:
1. Environmental score (0-100)
2. Carbon footprint assessment
3. Sustainability initiatives
4. Green practices adoption
5. Resource efficiency
6. Circular economy opportunities
7. Climate risk assessment
8. Environmental compliance
9. Biodiversity impact
10. Net-zero roadmap`,
        response_json_schema: {
          type: "object",
          properties: {
            environmental_score: { type: "number" },
            carbon_assessment: { type: "object", properties: { current_footprint: { type: "string" }, reduction_target: { type: "string" }, progress: { type: "number" }, initiatives: { type: "array", items: { type: "string" } } } },
            sustainability_initiatives: { type: "array", items: { type: "object", properties: { initiative: { type: "string" }, status: { type: "string" }, impact: { type: "string" }, investment: { type: "string" } } } },
            green_practices: { type: "array", items: { type: "object", properties: { practice: { type: "string" }, adoption_rate: { type: "number" }, benefit: { type: "string" } } } },
            resource_efficiency: { type: "array", items: { type: "object", properties: { resource: { type: "string" }, efficiency_score: { type: "number" }, improvement_opportunity: { type: "string" } } } },
            circular_economy: { type: "array", items: { type: "object", properties: { opportunity: { type: "string" }, potential_impact: { type: "string" }, feasibility: { type: "string" } } } },
            climate_risks: { type: "array", items: { type: "object", properties: { risk: { type: "string" }, severity: { type: "string" }, adaptation_strategy: { type: "string" } } } },
            net_zero_roadmap: { type: "array", items: { type: "object", properties: { milestone: { type: "string" }, target_date: { type: "string" }, actions: { type: "array", items: { type: "string" } } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(70);

      // Step 9: Wellness Analysis
      setCompilationStep("Analyzing employee wellness...");
      const avgMood = wellnessLogs.length > 0 ? wellnessLogs.reduce((s, l) => s + (l.mood_score || 5), 0) / wellnessLogs.length : 5;
      const avgEnergy = wellnessLogs.length > 0 ? wellnessLogs.reduce((s, l) => s + (l.energy_level || 5), 0) / wellnessLogs.length : 5;
      const avgStress = wellnessLogs.length > 0 ? wellnessLogs.reduce((s, l) => s + (l.stress_level || 5), 0) / wellnessLogs.length : 5;

      const wellnessAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze comprehensive employee wellness:

DATA:
- ${wellnessLogs.length} wellness logs
- Average Mood: ${avgMood.toFixed(1)}/10
- Average Energy: ${avgEnergy.toFixed(1)}/10
- Average Stress: ${avgStress.toFixed(1)}/10
- ${relevantAssessments.length} employees assessed

Provide:
1. Overall wellness score (0-100)
2. Physical health indicators
3. Mental health assessment
4. Work-life balance analysis
5. Burnout risk evaluation
6. Wellness program effectiveness
7. Health trends
8. Intervention priorities
9. Support resources needed
10. Wellness ROI projections`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_score: { type: "number" },
            physical_health: { type: "object", properties: { score: { type: "number" }, indicators: { type: "array", items: { type: "string" } }, recommendations: { type: "array", items: { type: "string" } } } },
            mental_health: { type: "object", properties: { score: { type: "number" }, indicators: { type: "array", items: { type: "string" } }, support_needed: { type: "array", items: { type: "string" } } } },
            work_life_balance: { type: "object", properties: { score: { type: "number" }, strengths: { type: "array", items: { type: "string" } }, challenges: { type: "array", items: { type: "string" } } } },
            burnout_risk: { type: "object", properties: { risk_level: { type: "string" }, at_risk_percentage: { type: "number" }, warning_signs: { type: "array", items: { type: "string" } }, prevention_strategies: { type: "array", items: { type: "string" } } } },
            program_effectiveness: { type: "array", items: { type: "object", properties: { program: { type: "string" }, effectiveness: { type: "number" }, participation: { type: "number" }, improvement: { type: "string" } } } },
            intervention_priorities: { type: "array", items: { type: "object", properties: { intervention: { type: "string" }, urgency: { type: "string" }, expected_impact: { type: "string" }, cost: { type: "string" } } } },
            wellness_roi: { type: "object", properties: { current_roi: { type: "string" }, projected_roi: { type: "string" }, savings_areas: { type: "array", items: { type: "string" } } } },
            narrative: { type: "string" }
          }
        }
      });
      setCompilationProgress(75);

      // Step 10: Generate Synergy Scenarios (3 pages worth)
      setCompilationStep("Generating win-win synergy scenarios...");
      const synergyAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate comprehensive WIN-WIN SYNERGY SCENARIOS between our organization and all external sectors.

For each intersection, create detailed plans that benefit BOTH parties while meeting business objectives.

SECTORS TO ANALYZE:
1. Government & Public Sector
2. Local Community
3. Environmental Organizations
4. Educational Institutions
5. Healthcare Providers
6. Technology Partners
7. Financial Institutions
8. Non-profit Organizations
9. Industry Associations
10. Media & Communications
11. Suppliers & Vendors
12. Research Institutions

For EACH sector intersection, provide:
- Title of the synergy opportunity
- Detailed description
- Benefits to our organization (including bottom-line impact)
- Benefits to the external sector
- Implementation plan with phases
- Resource requirements
- Timeline
- Success metrics
- Risk mitigation
- Sustainability of the partnership

Create at least 12 comprehensive synergy scenarios (one per sector) with full implementation details.`,
        response_json_schema: {
          type: "object",
          properties: {
            synergy_scenarios: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  sector: { type: "string" },
                  description: { type: "string" },
                  our_benefits: { type: "array", items: { type: "object", properties: { benefit: { type: "string" }, financial_impact: { type: "string" }, timeline: { type: "string" } } } },
                  partner_benefits: { type: "array", items: { type: "string" } },
                  implementation_plan: { type: "array", items: { type: "object", properties: { phase: { type: "string" }, actions: { type: "array", items: { type: "string" } }, duration: { type: "string" }, resources: { type: "string" } } } },
                  investment_required: { type: "string" },
                  expected_roi: { type: "string" },
                  success_metrics: { type: "array", items: { type: "string" } },
                  risks: { type: "array", items: { type: "object", properties: { risk: { type: "string" }, mitigation: { type: "string" } } } },
                  sustainability_plan: { type: "string" },
                  quick_wins: { type: "array", items: { type: "string" } },
                  long_term_vision: { type: "string" }
                }
              }
            },
            cross_sector_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  sectors_involved: { type: "array", items: { type: "string" } },
                  opportunity: { type: "string" },
                  synergy_multiplier: { type: "string" },
                  implementation_approach: { type: "string" }
                }
              }
            },
            ecosystem_strategy: { type: "string" },
            total_potential_value: { type: "string" }
          }
        }
      });
      setCompilationProgress(85);

      // Step 11: Core Appreciative Inquiry Synthesis
      setCompilationStep("Synthesizing organizational intelligence...");
      const allDeptStrengths = Object.values(byDepartment).flatMap(depts => depts.flatMap(a => a.departmental_ai.department_strengths?.filter(s => s) || []));
      const allDeptAspirations = Object.values(byDepartment).flatMap(depts => depts.flatMap(a => a.departmental_ai.department_aspirations?.filter(s => s) || []));

      const orgSynthesis = await base44.integrations.Core.InvokeLLM({
        prompt: `Create comprehensive organization-wide appreciative inquiry synthesis:

TOTAL PARTICIPANTS: ${relevantAssessments.length}
DEPARTMENTS: ${Object.keys(byDepartment).join(', ')}
STRENGTHS: ${allDeptStrengths.slice(0, 50).join(', ')}
ASPIRATIONS: ${allDeptAspirations.slice(0, 50).join(', ')}

Provide extensive analysis including:
1. Top 10 organizational strengths with frequency and departments
2. Top 10 organizational aspirations with frequency and departments
3. Cross-functional collaboration opportunities (10+)
4. Unified organizational vision (compelling 3-4 sentences)
5. Strategic priorities (8-10 with detailed alignment and actions)
6. Cultural insights (deep analysis)
7. Comprehensive executive synthesis (800+ words covering all aspects)`,
        response_json_schema: {
          type: "object",
          properties: {
            organizational_strengths: { type: "array", items: { type: "object", properties: { strength: { type: "string" }, frequency: { type: "number" }, departments: { type: "array", items: { type: "string" } } } } },
            organizational_aspirations: { type: "array", items: { type: "object", properties: { aspiration: { type: "string" }, frequency: { type: "number" }, departments: { type: "array", items: { type: "string" } } } } },
            cross_functional_opportunities: { type: "array", items: { type: "string" } },
            unified_vision: { type: "string" },
            strategic_priorities: { type: "array", items: { type: "object", properties: { priority: { type: "string" }, supporting_departments: { type: "array", items: { type: "string" } }, alignment_percentage: { type: "number" }, recommended_actions: { type: "array", items: { type: "string" } } } } },
            cultural_insights: { type: "string" },
            comprehensive_synthesis: { type: "string" }
          }
        }
      });
      setCompilationProgress(95);

      // Step 12: Save Complete Analysis
      setCompilationStep("Saving comprehensive analysis...");
      await createOrgAIMutation.mutateAsync({
        compilation_date: new Date().toISOString(),
        total_participants: relevantAssessments.length,
        departments_included: Object.keys(byDepartment),
        ...orgSynthesis,
        job_satisfaction_analysis: jobSatisfactionAnalysis,
        productivity_analysis: productivityAnalysis,
        market_analysis: marketAnalysis,
        economic_analysis: economicAnalysis,
        political_analysis: politicalAnalysis,
        social_analysis: socialAnalysis,
        environmental_analysis: environmentalAnalysis,
        wellness_analysis: wellnessAnalysis,
        synergy_scenarios: synergyAnalysis.synergy_scenarios,
        cross_sector_opportunities: synergyAnalysis.cross_sector_opportunities,
        ecosystem_strategy: synergyAnalysis.ecosystem_strategy,
        total_synergy_value: synergyAnalysis.total_potential_value
      });

      setCompilationProgress(100);
      setCompilationStep("Complete!");

      // Send notification if enabled
      if (notificationsEnabled && user?.email) {
        await base44.integrations.Core.SendEmail({
          to: user.email,
          subject: "[Luminous] Organizational Analysis Complete",
          body: `Your comprehensive organizational analysis has been completed.\n\nKey Highlights:\n- ${relevantAssessments.length} participants analyzed\n- ${Object.keys(byDepartment).length} departments included\n- ${synergyAnalysis.synergy_scenarios?.length || 0} synergy scenarios generated\n\nView the full analysis in your Organizational AI dashboard.`
        });
      }

    } catch (error) {
      console.error("Error compiling:", error);
      alert("Error during compilation. Please try again.");
    }
    setIsCompiling(false);
    setCompilationProgress(0);
    setCompilationStep("");
  };

  if (isLoading || loadingOrgAI || loadingDeptAI) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <Sparkles className="w-12 h-12 text-purple-500 animate-spin" />
      </div>
    );
  }

  const latestOrgAI = orgAI[0];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Organizational Intelligence</h1>
            <p className="text-gray-400">Comprehensive Multidisciplinary Analysis & Win-Win Synergy Planning</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Notifications</span>
              <Switch checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">Daily Briefings</span>
              <Switch checked={dailyBriefingEnabled} onCheckedChange={setDailyBriefingEnabled} />
            </div>
            <Button
              onClick={handleCompile}
              disabled={isCompiling}
              className="bg-white text-black hover:bg-gray-200"
            >
              {isCompiling ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> {compilationStep}</>
              ) : (
                <><RefreshCw className="w-4 h-4 mr-2" /> Compile Full Analysis</>
              )}
            </Button>
          </div>
        </div>

        {/* Compilation Progress */}
        {isCompiling && (
          <Card className="bg-gray-900 border-gray-800 mb-6">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-medium">{compilationStep}</span>
                <span className="text-purple-400">{compilationProgress}%</span>
              </div>
              <Progress value={compilationProgress} className="h-2" />
            </CardContent>
          </Card>
        )}

        {!latestOrgAI ? (
          <Card className="bg-gray-900 border-gray-800 text-center py-20">
            <CardContent>
              <Brain className="w-20 h-20 text-gray-600 mx-auto mb-6" />
              <h3 className="text-2xl font-light text-white mb-4">Begin Your Organizational Intelligence Journey</h3>
              <p className="text-gray-400 mb-6 max-w-lg mx-auto">
                Compile comprehensive multidisciplinary analysis across 10 key dimensions with win-win synergy scenarios
              </p>
              <p className="text-sm text-gray-500 mb-6">
                Assessments with departmental data: {assessments.filter(a => a.departmental_ai).length}
              </p>
              <Button onClick={handleCompile} disabled={assessments.filter(a => a.departmental_ai).length === 0} className="bg-purple-600 hover:bg-purple-700">
                <Sparkles className="w-5 h-5 mr-2" />
                Generate Comprehensive Analysis
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card className="bg-gradient-to-br from-blue-900 to-blue-950 border-blue-800">
                <CardContent className="p-4">
                  <p className="text-blue-300 text-xs mb-1">Participants</p>
                  <p className="text-3xl font-bold text-white">{latestOrgAI.total_participants}</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-green-900 to-green-950 border-green-800">
                <CardContent className="p-4">
                  <p className="text-green-300 text-xs mb-1">Satisfaction</p>
                  <p className="text-3xl font-bold text-white">{latestOrgAI.job_satisfaction_analysis?.satisfaction_index || '--'}%</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-purple-900 to-purple-950 border-purple-800">
                <CardContent className="p-4">
                  <p className="text-purple-300 text-xs mb-1">Productivity</p>
                  <p className="text-3xl font-bold text-white">{latestOrgAI.productivity_analysis?.productivity_index || '--'}%</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-cyan-900 to-cyan-950 border-cyan-800">
                <CardContent className="p-4">
                  <p className="text-cyan-300 text-xs mb-1">Wellness</p>
                  <p className="text-3xl font-bold text-white">{latestOrgAI.wellness_analysis?.overall_score || '--'}%</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-orange-900 to-orange-950 border-orange-800">
                <CardContent className="p-4">
                  <p className="text-orange-300 text-xs mb-1">Synergies</p>
                  <p className="text-3xl font-bold text-white">{latestOrgAI.synergy_scenarios?.length || '--'}</p>
                </CardContent>
              </Card>
            </div>

            {/* Unified Vision */}
            {latestOrgAI.unified_vision && (
              <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Heart className="w-5 h-5 text-purple-400" />
                    <span className="text-purple-300 font-medium">Unified Organizational Vision</span>
                  </div>
                  <p className="text-xl text-white italic leading-relaxed">"{latestOrgAI.unified_vision}"</p>
                </CardContent>
              </Card>
            )}

            {/* Main Tabs */}
            <Tabs defaultValue="overview" className="space-y-6">
              <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="satisfaction">Job Satisfaction</TabsTrigger>
                <TabsTrigger value="productivity">Productivity</TabsTrigger>
                <TabsTrigger value="market">Market</TabsTrigger>
                <TabsTrigger value="economic">Economic</TabsTrigger>
                <TabsTrigger value="political">Political</TabsTrigger>
                <TabsTrigger value="social">Social</TabsTrigger>
                <TabsTrigger value="environmental">Environmental</TabsTrigger>
                <TabsTrigger value="wellness">Wellness</TabsTrigger>
                <TabsTrigger value="synergies">Win-Win Synergies</TabsTrigger>
                <TabsTrigger value="departments">Departments</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <div className="grid lg:grid-cols-2 gap-6">
                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader>
                      <CardTitle className="text-white">Executive Synthesis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[400px] pr-4">
                        <div className="prose prose-invert max-w-none text-gray-300">
                          <ReactMarkdown>{latestOrgAI.comprehensive_synthesis}</ReactMarkdown>
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader>
                      <CardTitle className="text-white">Strategic Priorities</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[400px] pr-4">
                        <div className="space-y-4">
                          {latestOrgAI.strategic_priorities?.map((p, i) => (
                            <div key={i} className="p-4 bg-gray-800 rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <h4 className="text-white font-medium">{p.priority}</h4>
                                <Badge className="bg-purple-600">{p.alignment_percentage}%</Badge>
                              </div>
                              <div className="flex flex-wrap gap-1 mb-2">
                                {p.supporting_departments?.map((d, j) => (
                                  <Badge key={j} variant="outline" className="text-xs border-gray-600 text-gray-400">{d}</Badge>
                                ))}
                              </div>
                              <ul className="text-sm text-gray-400 space-y-1">
                                {p.recommended_actions?.slice(0, 3).map((a, j) => (
                                  <li key={j} className="flex items-start gap-2">
                                    <CheckCircle2 className="w-3 h-3 mt-1 text-green-500 flex-shrink-0" />
                                    {a}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="satisfaction">
                <AnalysisSectionDisplay title="Job Satisfaction Analysis" data={latestOrgAI.job_satisfaction_analysis} icon={Briefcase} color="blue" />
              </TabsContent>

              <TabsContent value="productivity">
                <AnalysisSectionDisplay title="Productivity & Performance" data={latestOrgAI.productivity_analysis} icon={TrendingUp} color="green" />
              </TabsContent>

              <TabsContent value="market">
                <AnalysisSectionDisplay title="Market Dynamics" data={latestOrgAI.market_analysis} icon={BarChart3} color="purple" />
              </TabsContent>

              <TabsContent value="economic">
                <AnalysisSectionDisplay title="Economic & Financial Analysis" data={latestOrgAI.economic_analysis} icon={DollarSign} color="yellow" />
              </TabsContent>

              <TabsContent value="political">
                <AnalysisSectionDisplay title="Political & Regulatory Landscape" data={latestOrgAI.political_analysis} icon={Landmark} color="red" />
              </TabsContent>

              <TabsContent value="social">
                <AnalysisSectionDisplay title="Social Issues & Causes" data={latestOrgAI.social_analysis} icon={HeartHandshake} color="pink" />
              </TabsContent>

              <TabsContent value="environmental">
                <AnalysisSectionDisplay title="Environmental Impact" data={latestOrgAI.environmental_analysis} icon={TreePine} color="emerald" />
              </TabsContent>

              <TabsContent value="wellness">
                <AnalysisSectionDisplay title="Employee Wellness" data={latestOrgAI.wellness_analysis} icon={Heart} color="cyan" />
              </TabsContent>

              <TabsContent value="synergies">
                <SynergyScenariosDisplay scenarios={latestOrgAI.synergy_scenarios} crossSector={latestOrgAI.cross_sector_opportunities} strategy={latestOrgAI.ecosystem_strategy} totalValue={latestOrgAI.total_synergy_value} />
              </TabsContent>

              <TabsContent value="departments">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {deptAI.map((dept) => (
                    <Card key={dept.id} className="bg-gray-900 border-gray-800">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center justify-between">
                          <span>{dept.department}</span>
                          <Badge className="bg-purple-600">{dept.participant_count}</Badge>
                        </CardTitle>
                        <CardDescription className="text-gray-400">{dept.shared_vision}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Top Strengths</p>
                          <div className="flex flex-wrap gap-1">
                            {dept.collective_strengths?.slice(0, 3).map((s, i) => (
                              <Badge key={i} variant="outline" className="text-xs border-blue-800 text-blue-400">{s}</Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Key Initiatives</p>
                          {dept.key_initiatives?.slice(0, 2).map((init, i) => (
                            <p key={i} className="text-xs text-gray-400">• {init.initiative}</p>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
}

function AnalysisSectionDisplay({ title, data, icon: Icon, color }) {
  if (!data) return (
    <Card className="bg-gray-900 border-gray-800 text-center py-12">
      <CardContent>
        <p className="text-gray-500">No {title.toLowerCase()} data available. Run a full compilation to generate.</p>
      </CardContent>
    </Card>
  );

  const colorClasses = {
    blue: "from-blue-900/30 to-blue-950/30 border-blue-800",
    green: "from-green-900/30 to-green-950/30 border-green-800",
    purple: "from-purple-900/30 to-purple-950/30 border-purple-800",
    yellow: "from-yellow-900/30 to-yellow-950/30 border-yellow-800",
    red: "from-red-900/30 to-red-950/30 border-red-800",
    pink: "from-pink-900/30 to-pink-950/30 border-pink-800",
    emerald: "from-emerald-900/30 to-emerald-950/30 border-emerald-800",
    cyan: "from-cyan-900/30 to-cyan-950/30 border-cyan-800"
  };

  return (
    <div className="space-y-6">
      <Card className={`bg-gradient-to-r ${colorClasses[color]} border`}>
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Icon className="w-6 h-6" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.narrative && (
            <div className="prose prose-invert max-w-none text-gray-300 mb-6">
              <ReactMarkdown>{data.narrative}</ReactMarkdown>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(data).filter(([k, v]) => k !== 'narrative' && v && typeof v === 'object').map(([key, value], i) => (
          <Card key={i} className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-gray-400 capitalize">{key.replace(/_/g, ' ')}</CardTitle>
            </CardHeader>
            <CardContent>
              {Array.isArray(value) ? (
                <ScrollArea className="h-[200px]">
                  <div className="space-y-2">
                    {value.slice(0, 10).map((item, j) => (
                      <div key={j} className="p-2 bg-gray-800 rounded text-sm">
                        {typeof item === 'string' ? (
                          <p className="text-gray-300">{item}</p>
                        ) : (
                          <div>
                            {Object.entries(item).slice(0, 3).map(([k, v], m) => (
                              <p key={m} className="text-gray-400">
                                <span className="text-gray-500 capitalize">{k.replace(/_/g, ' ')}:</span> {String(v)}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : typeof value === 'object' ? (
                <div className="space-y-1">
                  {Object.entries(value).slice(0, 5).map(([k, v], j) => (
                    <p key={j} className="text-sm">
                      <span className="text-gray-500 capitalize">{k.replace(/_/g, ' ')}:</span>
                      <span className="text-gray-300 ml-1">{Array.isArray(v) ? v.join(', ') : String(v)}</span>
                    </p>
                  ))}
                </div>
              ) : (
                <p className="text-2xl font-bold text-white">{String(value)}</p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SynergyScenariosDisplay({ scenarios, crossSector, strategy, totalValue }) {
  if (!scenarios || scenarios.length === 0) {
    return (
      <Card className="bg-gray-900 border-gray-800 text-center py-12">
        <CardContent>
          <Handshake className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500">No synergy scenarios generated yet. Run a full compilation.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-800">
          <CardContent className="p-6 text-center">
            <Handshake className="w-10 h-10 text-green-400 mx-auto mb-2" />
            <p className="text-3xl font-bold text-white">{scenarios.length}</p>
            <p className="text-green-300 text-sm">Win-Win Scenarios</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border-blue-800">
          <CardContent className="p-6 text-center">
            <Globe className="w-10 h-10 text-blue-400 mx-auto mb-2" />
            <p className="text-3xl font-bold text-white">{crossSector?.length || 0}</p>
            <p className="text-blue-300 text-sm">Cross-Sector Opportunities</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-800">
          <CardContent className="p-6 text-center">
            <DollarSign className="w-10 h-10 text-purple-400 mx-auto mb-2" />
            <p className="text-xl font-bold text-white">{totalValue || 'Significant'}</p>
            <p className="text-purple-300 text-sm">Total Potential Value</p>
          </CardContent>
        </Card>
      </div>

      {/* Ecosystem Strategy */}
      {strategy && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              Ecosystem Strategy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300">{strategy}</p>
          </CardContent>
        </Card>
      )}

      {/* Detailed Synergy Scenarios */}
      <div className="space-y-4">
        <h3 className="text-xl font-medium text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-yellow-400" />
          Detailed Win-Win Synergy Scenarios
        </h3>
        
        {scenarios.map((scenario, i) => (
          <Card key={i} className="bg-gray-900 border-gray-800">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <Badge className="bg-blue-600 mb-2">{scenario.sector}</Badge>
                  <CardTitle className="text-white">{scenario.title}</CardTitle>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="border-green-600 text-green-400">{scenario.expected_roi}</Badge>
                </div>
              </div>
              <CardDescription className="text-gray-400">{scenario.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Benefits Grid */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-900/20 rounded-lg border border-green-800">
                  <h4 className="text-green-400 font-medium mb-3 flex items-center gap-2">
                    <Building2 className="w-4 h-4" /> Our Benefits
                  </h4>
                  <div className="space-y-2">
                    {scenario.our_benefits?.map((b, j) => (
                      <div key={j} className="text-sm">
                        <p className="text-white">{b.benefit}</p>
                        <p className="text-green-400 text-xs">💰 {b.financial_impact} • ⏱ {b.timeline}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
                  <h4 className="text-blue-400 font-medium mb-3 flex items-center gap-2">
                    <Users className="w-4 h-4" /> Partner Benefits
                  </h4>
                  <ul className="space-y-1">
                    {scenario.partner_benefits?.map((b, j) => (
                      <li key={j} className="text-sm text-gray-300">• {b}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Implementation Plan */}
              <div>
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <ArrowRight className="w-4 h-4 text-purple-400" /> Implementation Plan
                </h4>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {scenario.implementation_plan?.map((phase, j) => (
                    <div key={j} className="p-3 bg-gray-800 rounded-lg">
                      <Badge className="bg-purple-600 mb-2">{phase.phase}</Badge>
                      <p className="text-xs text-gray-500 mb-2">{phase.duration} • {phase.resources}</p>
                      <ul className="text-xs text-gray-400 space-y-1">
                        {phase.actions?.slice(0, 3).map((a, k) => (
                          <li key={k}>• {a}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Wins & Metrics */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-400" /> Quick Wins
                  </h4>
                  <ul className="text-sm text-gray-400 space-y-1">
                    {scenario.quick_wins?.map((w, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3 h-3 mt-1 text-green-500 flex-shrink-0" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Target className="w-4 h-4 text-blue-400" /> Success Metrics
                  </h4>
                  <ul className="text-sm text-gray-400 space-y-1">
                    {scenario.success_metrics?.map((m, j) => (
                      <li key={j}>• {m}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Risks & Sustainability */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-orange-400" /> Risks & Mitigation
                  </h4>
                  <div className="space-y-2">
                    {scenario.risks?.slice(0, 3).map((r, j) => (
                      <div key={j} className="text-sm">
                        <p className="text-orange-400">{r.risk}</p>
                        <p className="text-gray-500 text-xs">→ {r.mitigation}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-400" /> Sustainability
                  </h4>
                  <p className="text-sm text-gray-400">{scenario.sustainability_plan}</p>
                  {scenario.long_term_vision && (
                    <p className="text-sm text-purple-400 mt-2 italic">"{scenario.long_term_vision}"</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Cross-Sector Opportunities */}
      {crossSector?.length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-cyan-400" />
              Cross-Sector Multiplier Opportunities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {crossSector.map((opp, i) => (
                <div key={i} className="p-4 bg-gray-800 rounded-lg">
                  <div className="flex flex-wrap gap-1 mb-2">
                    {opp.sectors_involved?.map((s, j) => (
                      <Badge key={j} variant="outline" className="text-xs border-cyan-600 text-cyan-400">{s}</Badge>
                    ))}
                  </div>
                  <p className="text-white font-medium">{opp.opportunity}</p>
                  <p className="text-cyan-400 text-sm mt-1">Multiplier: {opp.synergy_multiplier}</p>
                  <p className="text-gray-500 text-xs mt-2">{opp.implementation_approach}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}