import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Mail, Calendar, FileText, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Profile() {
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments, isLoading: assessmentsLoading } = useQuery({
    queryKey: ['user-assessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  if (userLoading || assessmentsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Sparkles className="w-12 h-12 text-purple-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Profile</h1>
          <p className="text-gray-600">Manage your account and view your assessment history</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
              <User className="w-10 h-10 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Name</p>
                <p className="font-semibold text-gray-900">{user?.full_name || 'Not set'}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <Mail className="w-10 h-10 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="font-semibold text-gray-900">{user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-indigo-50 rounded-lg">
              <Calendar className="w-10 h-10 text-indigo-600" />
              <div>
                <p className="text-sm text-gray-600">Member Since</p>
                <p className="font-semibold text-gray-900">
                  {user?.created_date ? format(new Date(user.created_date), "MMMM d, yyyy") : 'Unknown'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Assessment History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {assessments.length === 0 ? (
              <div className="text-center py-12">
                <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 mb-6">You haven't completed any assessments yet</p>
                <Link to={createPageUrl("Assessment")}>
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
                    Take Your First Assessment
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {assessments.map((assessment) => (
                  <div
                    key={assessment.id}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div>
                      <p className="font-semibold text-gray-900">
                        Complete Assessment
                      </p>
                      <p className="text-sm text-gray-600">
                        Completed on {format(new Date(assessment.completed_date), "MMMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                    <Link to={createPageUrl("Results")}>
                      <Button variant="outline" size="sm">
                        View Results
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Sparkles className="w-12 h-12 text-purple-600" />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Ready for another assessment?</h3>
                <p className="text-sm text-gray-600">Track your growth and development over time</p>
              </div>
              <Link to={createPageUrl("Assessment")}>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
                  Start New Assessment
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}