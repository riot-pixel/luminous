import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Users, Target, TrendingUp, Brain, Award, Sparkles } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from "recharts";
import EmployeeGrid from "../components/org/EmployeeGrid";

export default function OrganizationDashboard() {
  const { data: employees, isLoading: loadingEmployees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments, isLoading: loadingAssessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: teams, isLoading: loadingTeams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  if (loadingEmployees || loadingAssessments || loadingTeams) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading organization data...</p>
        </div>
      </div>
    );
  }

  // Get latest assessment per employee
  const latestAssessments = assessments.reduce((acc, assessment) => {
    if (!acc[assessment.user_email] || new Date(assessment.completed_date) > new Date(acc[assessment.user_email].completed_date)) {
      acc[assessment.user_email] = assessment;
    }
    return acc;
  }, {});

  const completionRate = (Object.keys(latestAssessments).length / employees.length) * 100;

  // Calculate department distribution
  const departmentCounts = employees.reduce((acc, emp) => {
    const dept = emp.department || 'Unassigned';
    acc[dept] = (acc[dept] || 0) + 1;
    return acc;
  }, {});

  const departmentData = Object.entries(departmentCounts).map(([name, value]) => ({
    name,
    value,
  }));

  // Calculate aggregate strengths across organization
  const aggregateStrengths = {};
  Object.values(latestAssessments).forEach(assessment => {
    if (assessment.strengths?.top_strengths) {
      assessment.strengths.top_strengths.forEach(strength => {
        if (!aggregateStrengths[strength.name]) {
          aggregateStrengths[strength.name] = { count: 0, totalScore: 0 };
        }
        aggregateStrengths[strength.name].count++;
        aggregateStrengths[strength.name].totalScore += strength.score;
      });
    }
  });

  const topOrgStrengths = Object.entries(aggregateStrengths)
    .map(([name, data]) => ({
      name,
      count: data.count,
      avgScore: Math.round(data.totalScore / data.count),
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  // Calculate personality type distribution
  const personalityTypes = {};
  Object.values(latestAssessments).forEach(assessment => {
    if (assessment.myers_briggs?.type) {
      const type = assessment.myers_briggs.type;
      personalityTypes[type] = (personalityTypes[type] || 0) + 1;
    }
  });

  const personalityData = Object.entries(personalityTypes).map(([name, value]) => ({
    name,
    value,
  }));

  const COLORS = ['#8b5cf6', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#6366f1'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Organization Dashboard</h1>
          <p className="text-gray-600">Comprehensive insights across your entire organization</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Total Employees</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-4xl font-bold">{employees.length}</div>
                <Users className="w-10 h-10 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Assessment Completion</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-4xl font-bold">{Math.round(completionRate)}%</div>
                <Target className="w-10 h-10 text-blue-200" />
              </div>
              <p className="text-xs text-blue-100 mt-2">{Object.keys(latestAssessments).length} completed</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-indigo-100">Active Teams</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-4xl font-bold">{teams.filter(t => t.status === 'active').length}</div>
                <TrendingUp className="w-10 h-10 text-indigo-200" />
              </div>
              <p className="text-xs text-indigo-100 mt-2">{teams.length} total teams</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-violet-500 to-violet-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-violet-100">Unique Strengths</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-4xl font-bold">{Object.keys(aggregateStrengths).length}</div>
                <Award className="w-10 h-10 text-violet-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Personality Type Distribution
              </CardTitle>
              <CardDescription>Myers-Briggs types across organization</CardDescription>
            </CardHeader>
            <CardContent>
              {personalityData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={personalityData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {personalityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-400">
                  No assessment data available yet
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Department Distribution
              </CardTitle>
              <CardDescription>Employees by department</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={departmentData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Top Organizational Strengths */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-violet-600" />
              Top Organizational Strengths
            </CardTitle>
            <CardDescription>Most common strengths across your team</CardDescription>
          </CardHeader>
          <CardContent>
            {topOrgStrengths.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topOrgStrengths} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={150} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#8b5cf6" name="Number of Employees" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                No strength data available yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Employee Grid */}
        <EmployeeGrid employees={employees} assessments={latestAssessments} />
      </div>
    </div>
  );
}