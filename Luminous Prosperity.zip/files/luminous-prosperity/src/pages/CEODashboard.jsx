import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, Sparkles, TrendingUp, Users, Target, BarChart3, Plus } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function CEODashboard() {
  const { data: ceoAssessments, isLoading: loadingCEO } = useQuery({
    queryKey: ['ceoAssessments'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.CEOAssessment.filter({ user_email: user.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: orgAssessments, isLoading: loadingOrg } = useQuery({
    queryKey: ['orgAssessments'],
    queryFn: () => base44.entities.OrganizationalAssessment.list('-completed_date'),
    initialData: [],
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  if (loadingCEO || loadingOrg) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading executive dashboard...</p>
        </div>
      </div>
    );
  }

  const latestCEOAssessment = ceoAssessments[0];
  const latestOrgAssessment = orgAssessments[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Executive Dashboard</h1>
            <p className="text-gray-600">Strategic leadership insights and organizational alignment</p>
          </div>
          <div className="flex gap-3">
            <Link to={createPageUrl("CEOAssessment")}>
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                <Plus className="w-5 h-5 mr-2" />
                CEO Assessment
              </Button>
            </Link>
            <Link to={createPageUrl("OrganizationalAnalysis")}>
              <Button variant="outline" className="border-indigo-600 text-indigo-600 hover:bg-indigo-50">
                <Building2 className="w-5 h-5 mr-2" />
                Org Analysis
              </Button>
            </Link>
          </div>
        </div>

        {/* Executive Coaching Section */}
        <Card className="mb-8 border-2 border-amber-400 bg-gradient-to-r from-amber-50 to-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Users className="w-6 h-6 text-amber-600" />
              Executive Coaching
            </CardTitle>
            <CardDescription>
              Personalized leadership coaching based on your assessment results
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 space-y-2">
                <p className="text-sm text-gray-700">
                  <strong>Deep-dive coaching sessions:</strong> Work with executive coaches to translate 
                  your assessment insights into actionable leadership strategies.
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Topics include:</strong> Strategic vision alignment, stakeholder management, 
                  organizational transformation, and personal leadership development.
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Duration:</strong> 60-90 minutes | <strong>Format:</strong> Secure video conference
                </p>
              </div>
              <div className="flex flex-col gap-3 md:w-64">
                <Button 
                  className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                  onClick={() => window.open('https://ammanuel.as.me/Welcome', '_blank')}
                >
                  Schedule Coaching
                </Button>
                <Button 
                  variant="outline"
                  className="border-amber-600 text-amber-600 hover:bg-amber-50"
                  onClick={() => window.open('mailto:ammanuel@luminousprosperity.com?subject=Executive Coaching Request', '_blank')}
                >
                  Contact Executive Coach
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {!latestCEOAssessment && !latestOrgAssessment ? (
          <Card className="text-center py-20">
            <CardContent>
              <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No Assessments Yet</h3>
              <p className="text-gray-500 mb-6">Complete your CEO assessment and organizational analysis to unlock insights</p>
              <div className="flex gap-3 justify-center">
                <Link to={createPageUrl("CEOAssessment")}>
                  <Button>Start CEO Assessment</Button>
                </Link>
                <Link to={createPageUrl("OrganizationalAnalysis")}>
                  <Button variant="outline">Analyze Organization</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Key Metrics */}
            {latestOrgAssessment && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white border-none">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-green-100">Alignment Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">{latestOrgAssessment.alignment_score || 'N/A'}</div>
                    <p className="text-xs text-green-100 mt-1">Leadership-Strategy-People</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-500 to-cyan-600 text-white border-none">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-blue-100">Ecological Impact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {latestOrgAssessment.sustainability_metrics?.ecological_impact || 'N/A'}
                    </div>
                    <p className="text-xs text-blue-100 mt-1">Environmental Score</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500 to-violet-600 text-white border-none">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-purple-100">Social Responsibility</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {latestOrgAssessment.sustainability_metrics?.social_responsibility || 'N/A'}
                    </div>
                    <p className="text-xs text-purple-100 mt-1">Social Impact Score</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white border-none">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-amber-100">Economic Sustainability</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold">
                      {latestOrgAssessment.sustainability_metrics?.economic_sustainability || 'N/A'}
                    </div>
                    <p className="text-xs text-amber-100 mt-1">Financial Health</p>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* AI Insights */}
            {latestCEOAssessment?.ai_insights && (
              <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Sparkles className="w-6 h-6 text-indigo-600" />
                    Your Leadership Insights
                  </CardTitle>
                  <CardDescription>AI-generated analysis of your leadership effectiveness</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-indigo max-w-none">
                    <ReactMarkdown>{latestCEOAssessment.ai_insights}</ReactMarkdown>
                  </div>
                </CardContent>
              </Card>
            )}

            {latestOrgAssessment?.comprehensive_insights && (
              <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-2xl">
                    <Building2 className="w-6 h-6 text-purple-600" />
                    Organizational Insights
                  </CardTitle>
                  <CardDescription>Comprehensive analysis of organizational health and opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-purple max-w-none">
                    <ReactMarkdown>{latestOrgAssessment.comprehensive_insights}</ReactMarkdown>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Strategic Recommendations */}
            {latestOrgAssessment?.recommendations && latestOrgAssessment.recommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-indigo-600" />
                    Strategic Recommendations
                  </CardTitle>
                  <CardDescription>Prioritized actions for maximum impact</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {latestOrgAssessment.recommendations.map((rec, idx) => (
                      <div key={idx} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-indigo-100 text-indigo-700 rounded-full flex items-center justify-center font-bold">
                              {idx + 1}
                            </div>
                            <div>
                              <span className="font-semibold text-gray-900">{rec.category}</span>
                              {rec.priority && (
                                <span className={`ml-2 text-xs px-2 py-1 rounded-full ${
                                  rec.priority === 'high' ? 'bg-red-100 text-red-700' :
                                  rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-green-100 text-green-700'
                                }`}>
                                  {rec.priority} priority
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <p className="text-gray-700 mb-2">{rec.action}</p>
                        {rec.impact && (
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Expected Impact:</span> {rec.impact}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}