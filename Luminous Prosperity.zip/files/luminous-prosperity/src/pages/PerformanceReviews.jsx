import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import {
  ClipboardCheck, Plus, Users, Target, Star, Clock, CheckCircle2,
  AlertTriangle, Send, Edit, Eye, BarChart3, TrendingUp, MessageSquare
} from "lucide-react";
import ReviewForm from "@/components/reviews/ReviewForm";
import PeerFeedbackForm from "@/components/reviews/PeerFeedbackForm";
import ReviewDetails from "@/components/reviews/ReviewDetails";

export default function PerformanceReviews() {
  const [isCreating, setIsCreating] = useState(false);
  const [selectedReview, setSelectedReview] = useState(null);
  const [viewMode, setViewMode] = useState("manager"); // manager, employee, peer
  const [filterStatus, setFilterStatus] = useState("all");

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: reviews } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list('-created_date'),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.PerformanceReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['performanceReviews'] });
      setIsCreating(false);
    }
  });

  const updateReviewMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PerformanceReview.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['performanceReviews'] })
  });

  // Filter reviews based on user role and view
  const myReviews = reviews.filter(r => r.reviewer_email === user?.email);
  const reviewsAboutMe = reviews.filter(r => r.employee_email === user?.email);
  const pendingPeerFeedback = reviews.filter(r => 
    r.peer_feedback_requests?.some(p => p.peer_email === user?.email && p.status === 'pending')
  );

  const filteredReviews = (viewMode === "manager" ? myReviews : viewMode === "employee" ? reviewsAboutMe : pendingPeerFeedback)
    .filter(r => filterStatus === "all" || r.status === filterStatus);

  // Stats
  const stats = {
    total: myReviews.length,
    completed: myReviews.filter(r => r.status === 'completed').length,
    inProgress: myReviews.filter(r => ['in_progress', 'pending_peer_feedback', 'pending_employee_acknowledgment'].includes(r.status)).length,
    draft: myReviews.filter(r => r.status === 'draft').length,
    pendingPeer: pendingPeerFeedback.length,
  };

  const statusColors = {
    draft: 'bg-gray-600',
    in_progress: 'bg-blue-600',
    pending_peer_feedback: 'bg-amber-600',
    pending_employee_acknowledgment: 'bg-purple-600',
    completed: 'bg-green-600',
    cancelled: 'bg-red-600',
  };

  const statusLabels = {
    draft: 'Draft',
    in_progress: 'In Progress',
    pending_peer_feedback: 'Awaiting Peer Feedback',
    pending_employee_acknowledgment: 'Awaiting Acknowledgment',
    completed: 'Completed',
    cancelled: 'Cancelled',
  };

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide flex items-center gap-3">
              <ClipboardCheck className="w-8 h-8 text-green-400" />
              Performance Reviews
            </h1>
            <p className="text-gray-400 mt-1">Manage employee performance evaluations and feedback</p>
          </div>
          <Dialog open={isCreating} onOpenChange={setIsCreating}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" /> Initiate Review
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-800 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white">Initiate Performance Review</DialogTitle>
              </DialogHeader>
              <ReviewForm
                employees={employees}
                userSkills={userSkills}
                currentUser={user}
                onSubmit={(data) => createReviewMutation.mutate(data)}
                onCancel={() => setIsCreating(false)}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-white">{stats.total}</p>
              <p className="text-gray-500 text-xs">Total Reviews</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-green-400">{stats.completed}</p>
              <p className="text-gray-500 text-xs">Completed</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-blue-400">{stats.inProgress}</p>
              <p className="text-gray-500 text-xs">In Progress</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-gray-400">{stats.draft}</p>
              <p className="text-gray-500 text-xs">Drafts</p>
            </CardContent>
          </Card>
          <Card className="bg-amber-900/30 border-amber-800">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-amber-400">{stats.pendingPeer}</p>
              <p className="text-gray-500 text-xs">Peer Feedback Pending</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="manager" className="space-y-6" onValueChange={setViewMode}>
          <div className="flex items-center justify-between">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="manager">As Manager ({myReviews.length})</TabsTrigger>
              <TabsTrigger value="employee">My Reviews ({reviewsAboutMe.length})</TabsTrigger>
              <TabsTrigger value="peer">Peer Feedback ({pendingPeerFeedback.length})</TabsTrigger>
            </TabsList>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48 bg-gray-900 border-gray-800 text-white">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="pending_peer_feedback">Pending Peer Feedback</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="manager">
            {selectedReview ? (
              <ReviewDetails
                review={selectedReview}
                employees={employees}
                userSkills={userSkills}
                currentUser={user}
                onBack={() => setSelectedReview(null)}
                onUpdate={(data) => updateReviewMutation.mutate({ id: selectedReview.id, data })}
                isManager={true}
              />
            ) : (
              <div className="space-y-3">
                {filteredReviews.map(review => (
                  <Card key={review.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 cursor-pointer" onClick={() => setSelectedReview(review)}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Avatar className="w-10 h-10">
                            <AvatarFallback className="bg-green-600 text-white">
                              {review.employee_name?.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-white font-medium">{review.employee_name}</p>
                            <p className="text-gray-500 text-sm">{review.review_period} {review.review_year}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {review.overall_rating && (
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                              <span className="text-white font-medium">{review.overall_rating}/5</span>
                            </div>
                          )}
                          <Badge className={statusColors[review.status]}>{statusLabels[review.status]}</Badge>
                          {review.due_date && new Date(review.due_date) < new Date() && review.status !== 'completed' && (
                            <Badge className="bg-red-600">Overdue</Badge>
                          )}
                        </div>
                      </div>
                      {review.goals_assessment?.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-800">
                          <p className="text-gray-500 text-xs mb-1">Goals Progress</p>
                          <Progress value={review.goals_assessment.reduce((sum, g) => sum + (g.achievement_percentage || 0), 0) / review.goals_assessment.length} className="h-2" />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
                {filteredReviews.length === 0 && (
                  <Card className="bg-gray-900 border-gray-800">
                    <CardContent className="py-12 text-center">
                      <ClipboardCheck className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">No reviews found. Initiate a review to get started.</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="employee">
            <div className="space-y-3">
              {filteredReviews.map(review => (
                <Card key={review.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 cursor-pointer" onClick={() => setSelectedReview(review)}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">{review.review_period} {review.review_year} Review</p>
                        <p className="text-gray-500 text-sm">Reviewed by: {review.reviewer_name}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {review.overall_rating && (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                            <span className="text-white font-medium">{review.overall_rating}/5</span>
                          </div>
                        )}
                        <Badge className={statusColors[review.status]}>{statusLabels[review.status]}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {filteredReviews.length === 0 && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-12 text-center">
                    <p className="text-gray-400">No reviews about you yet.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="peer">
            <div className="space-y-3">
              {pendingPeerFeedback.map(review => (
                <PeerFeedbackForm
                  key={review.id}
                  review={review}
                  currentUser={user}
                  onSubmit={(feedback) => {
                    const updatedPeerFeedback = [...(review.peer_feedback || []), feedback];
                    const updatedRequests = review.peer_feedback_requests.map(r =>
                      r.peer_email === user?.email ? { ...r, status: 'completed', submitted_date: new Date().toISOString() } : r
                    );
                    updateReviewMutation.mutate({
                      id: review.id,
                      data: {
                        peer_feedback: updatedPeerFeedback,
                        peer_feedback_requests: updatedRequests,
                        status: updatedRequests.every(r => r.status === 'completed') ? 'pending_employee_acknowledgment' : 'pending_peer_feedback'
                      }
                    });
                  }}
                />
              ))}
              {pendingPeerFeedback.length === 0 && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-12 text-center">
                    <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400">No pending peer feedback requests.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}