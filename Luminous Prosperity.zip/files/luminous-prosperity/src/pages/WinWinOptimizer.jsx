import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sparkles, Users, Target, BarChart3, Heart, ArrowRight, ArrowLeftRight,
  TrendingUp, TrendingDown, Zap, Brain, RefreshCw, CheckCircle2, 
  AlertTriangle, Scale, Building2, Star, Lightbulb, Award, Shuffle, Activity, Play
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ScatterChart, Scatter, ZAxis } from "recharts";
import ReassignmentSimulator from "../components/optimizer/ReassignmentSimulator";
import TalentPoolExplorer from "../components/optimizer/TalentPoolExplorer";
import OrganizationalHealthScore from "../components/optimizer/OrganizationalHealthScore";
import EmergentWinWinScenarios from "../components/optimizer/EmergentWinWinScenarios";
import PredictivePerformanceAnalytics from "../components/optimizer/PredictivePerformanceAnalytics";
import SuccessionPlanningAI from "../components/optimizer/SuccessionPlanningAI";
import TeamDynamicsAI from "../components/optimizer/TeamDynamicsAI";

export default function WinWinOptimizer() {
  const [balanceSlider, setBalanceSlider] = useState([50]);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationResults, setOptimizationResults] = useState(null);
  const [selectedReassignment, setSelectedReassignment] = useState(null);
  const [simulatingReassignment, setSimulatingReassignment] = useState(null);

  // Fetch all employees
  const { data: employees } = useQuery({
    queryKey: ['allEmployeesForOptimizer'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  // Fetch all assessments
  const { data: assessments } = useQuery({
    queryKey: ['allAssessmentsForOptimizer'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  // Fetch all user skills
  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkillsForOptimizer'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  // Fetch role requirements
  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirementsForOptimizer'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  // Fetch coaching sessions
  const { data: coachingSessions } = useQuery({
    queryKey: ['coachingSessionsForOptimizer'],
    queryFn: () => base44.entities.CoachingSession.list(),
    initialData: [],
  });

  // Fetch learning journeys
  const { data: learningJourneys } = useQuery({
    queryKey: ['learningJourneysForOptimizer'],
    queryFn: () => base44.entities.LearningJourney.list(),
    initialData: [],
  });

  // Fetch wellness logs
  const { data: wellnessLogs } = useQuery({
    queryKey: ['wellnessLogsForOptimizer'],
    queryFn: () => base44.entities.WellnessLog.list('-created_date', 500),
    initialData: [],
  });

  // Fetch teams
  const { data: teams } = useQuery({
    queryKey: ['teamsForOptimizer'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  // Calculate employee fulfillment scores based on all data points
  const employeeProfiles = useMemo(() => {
    return employees.map(emp => {
      const empAssessments = assessments.filter(a => a.created_by === emp.email);
      const latestAssessment = empAssessments[0];
      const empSkills = userSkills.filter(s => s.user_email === emp.email);
      const empCoaching = coachingSessions.filter(c => c.user_email === emp.email);
      const empJourneys = learningJourneys.filter(j => j.user_email === emp.email);
      const empWellness = wellnessLogs.filter(w => w.user_email === emp.email);

      // Calculate fulfillment metrics
      const lifeWheel = latestAssessment?.life_wheel || {};
      const careerSatisfaction = (lifeWheel.career || 5) * 10;
      const personalGrowth = (lifeWheel.personal_growth || 5) * 10;
      const workLifeBalance = (lifeWheel.health || 5) * 10;
      const relationships = (lifeWheel.relationships || 5) * 10;

      // Wellness trend
      const recentWellness = empWellness.slice(0, 10);
      const avgMood = recentWellness.length > 0 
        ? recentWellness.reduce((sum, w) => sum + (w.mood_score || 5), 0) / recentWellness.length * 10
        : 50;
      const avgEnergy = recentWellness.length > 0
        ? recentWellness.reduce((sum, w) => sum + (w.energy_level || 5), 0) / recentWellness.length * 10
        : 50;
      const avgStress = recentWellness.length > 0
        ? 100 - (recentWellness.reduce((sum, w) => sum + (w.stress_level || 5), 0) / recentWellness.length * 10)
        : 50;

      // Learning engagement
      const completedJourneys = empJourneys.filter(j => j.status === 'completed').length;
      const avgJourneyProgress = empJourneys.length > 0
        ? empJourneys.reduce((sum, j) => sum + (j.progress_percentage || 0), 0) / empJourneys.length
        : 0;

      // Coaching performance
      const avgCoachingScore = empCoaching.length > 0
        ? empCoaching.reduce((sum, c) => sum + (c.overall_score || 0), 0) / empCoaching.length
        : 0;

      // Skill proficiency
      const skillScores = empSkills.map(s => {
        const profMap = { 'Beginner': 25, 'Intermediate': 50, 'Advanced': 75, 'Expert': 100 };
        return profMap[s.current_proficiency] || 0;
      });
      const avgSkillLevel = skillScores.length > 0
        ? skillScores.reduce((a, b) => a + b, 0) / skillScores.length
        : 0;

      // Role fit calculation
      const currentRoleReqs = roleRequirements.filter(r => r.role_title === emp.job_title);
      let roleFit = 100;
      if (currentRoleReqs.length > 0) {
        const matchedSkills = currentRoleReqs.filter(req => {
          const userSkill = empSkills.find(s => s.skill_name === req.skill_name);
          const profOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
          return userSkill && profOrder.indexOf(userSkill.current_proficiency) >= profOrder.indexOf(req.required_proficiency);
        });
        roleFit = (matchedSkills.length / currentRoleReqs.length) * 100;
      }

      // Personality insights
      const mbti = latestAssessment?.myers_briggs?.type || 'Unknown';
      const strengths = latestAssessment?.strengths?.top_strengths?.slice(0, 3).map(s => s.name) || [];

      // Calculate overall fulfillment score
      const fulfillmentScore = Math.round(
        (careerSatisfaction * 0.25) +
        (personalGrowth * 0.15) +
        (avgMood * 0.15) +
        (avgEnergy * 0.1) +
        (avgStress * 0.1) +
        (avgJourneyProgress * 0.1) +
        (avgCoachingScore * 0.05) +
        (workLifeBalance * 0.1)
      );

      // Calculate operational value
      const operationalScore = Math.round(
        (roleFit * 0.35) +
        (avgSkillLevel * 0.3) +
        (avgCoachingScore * 0.15) +
        (completedJourneys * 5) +
        (avgJourneyProgress * 0.1)
      );

      return {
        ...emp,
        assessment: latestAssessment,
        skills: empSkills,
        skillCount: empSkills.length,
        mbti,
        strengths,
        fulfillmentScore: Math.min(100, Math.max(0, fulfillmentScore)),
        operationalScore: Math.min(100, Math.max(0, operationalScore)),
        careerSatisfaction,
        personalGrowth,
        workLifeBalance,
        avgMood,
        avgEnergy,
        avgStress,
        roleFit,
        avgSkillLevel,
        completedJourneys,
        avgJourneyProgress,
        avgCoachingScore,
        coachingCount: empCoaching.length,
        journeyCount: empJourneys.length,
      };
    }).filter(e => e.email);
  }, [employees, assessments, userSkills, roleRequirements, coachingSessions, learningJourneys, wellnessLogs]);

  // Get unique roles and departments
  const roles = [...new Set(roleRequirements.map(r => r.role_title))];
  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];

  // Run AI optimization
  const runOptimization = async () => {
    setIsOptimizing(true);
    try {
      const fulfillmentWeight = balanceSlider[0] / 100;
      const efficiencyWeight = 1 - fulfillmentWeight;

      const employeeData = employeeProfiles.slice(0, 30).map(e => ({
        name: e.full_name,
        email: e.email,
        current_role: e.job_title,
        department: e.department,
        mbti: e.mbti,
        strengths: e.strengths,
        fulfillment: e.fulfillmentScore,
        operational: e.operationalScore,
        career_satisfaction: e.careerSatisfaction,
        role_fit: e.roleFit,
        skill_level: e.avgSkillLevel,
        mood: e.avgMood,
        energy: e.avgEnergy,
        stress: e.avgStress,
        skills: e.skills.slice(0, 5).map(s => s.skill_name),
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist and operations strategist. Analyze these employees and find WIN-WIN reassignment opportunities that optimize BOTH employee fulfillment AND operational effectiveness.

OPTIMIZATION BALANCE:
- Employee Fulfillment Weight: ${(fulfillmentWeight * 100).toFixed(0)}%
- Operational Efficiency Weight: ${(efficiencyWeight * 100).toFixed(0)}%

EMPLOYEES DATA:
${JSON.stringify(employeeData, null, 2)}

AVAILABLE ROLES:
${roles.join(', ')}

DEPARTMENTS:
${departments.join(', ')}

TASK: Identify 5-8 strategic reassignments that would create WIN-WIN scenarios where:
1. The employee would be MORE fulfilled (based on their personality, strengths, satisfaction levels, wellness)
2. The organization would be MORE effective (based on skill fit, role requirements, team needs)

For each reassignment, provide:
- Why this move benefits the EMPLOYEE (psychological fit, growth, fulfillment)
- Why this move benefits the ORGANIZATION (skill utilization, team balance, operational efficiency)
- Predicted fulfillment change
- Predicted operational change
- Risk factors and mitigation
- Implementation timeline

Also provide:
- Overall organizational impact summary
- Department-level insights
- Quick wins vs strategic moves`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: {
              type: "object",
              properties: {
                current_avg_fulfillment: { type: "number" },
                current_avg_operational: { type: "number" },
                projected_avg_fulfillment: { type: "number" },
                projected_avg_operational: { type: "number" },
                total_employees_impacted: { type: "number" },
                key_insight: { type: "string" }
              }
            },
            reassignments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  employee_name: { type: "string" },
                  employee_email: { type: "string" },
                  current_role: { type: "string" },
                  current_department: { type: "string" },
                  recommended_role: { type: "string" },
                  recommended_department: { type: "string" },
                  employee_benefits: { type: "array", items: { type: "string" } },
                  organization_benefits: { type: "array", items: { type: "string" } },
                  fulfillment_change: { type: "number" },
                  operational_change: { type: "number" },
                  confidence_score: { type: "number" },
                  risk_factors: { type: "array", items: { type: "string" } },
                  mitigation_strategies: { type: "array", items: { type: "string" } },
                  timeline: { type: "string" },
                  priority: { type: "string" },
                  personality_alignment: { type: "string" },
                  strength_utilization: { type: "string" }
                }
              }
            },
            department_insights: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  department: { type: "string" },
                  current_health: { type: "number" },
                  projected_health: { type: "number" },
                  key_opportunity: { type: "string" },
                  talent_gaps: { type: "array", items: { type: "string" } },
                  talent_surplus: { type: "array", items: { type: "string" } }
                }
              }
            },
            quick_wins: { type: "array", items: { type: "string" } },
            strategic_moves: { type: "array", items: { type: "string" } },
            overall_recommendation: { type: "string" }
          }
        }
      });

      setOptimizationResults(result);
    } catch (error) {
      console.error("Error running optimization:", error);
    }
    setIsOptimizing(false);
  };

  // Calculate current org metrics
  const orgMetrics = useMemo(() => {
    if (employeeProfiles.length === 0) return null;
    
    const avgFulfillment = employeeProfiles.reduce((sum, e) => sum + e.fulfillmentScore, 0) / employeeProfiles.length;
    const avgOperational = employeeProfiles.reduce((sum, e) => sum + e.operationalScore, 0) / employeeProfiles.length;
    
    // Distribution data
    const fulfillmentDistribution = [
      { range: '0-20', count: employeeProfiles.filter(e => e.fulfillmentScore <= 20).length },
      { range: '21-40', count: employeeProfiles.filter(e => e.fulfillmentScore > 20 && e.fulfillmentScore <= 40).length },
      { range: '41-60', count: employeeProfiles.filter(e => e.fulfillmentScore > 40 && e.fulfillmentScore <= 60).length },
      { range: '61-80', count: employeeProfiles.filter(e => e.fulfillmentScore > 60 && e.fulfillmentScore <= 80).length },
      { range: '81-100', count: employeeProfiles.filter(e => e.fulfillmentScore > 80).length },
    ];

    // Scatter data for visualization
    const scatterData = employeeProfiles.map(e => ({
      x: e.fulfillmentScore,
      y: e.operationalScore,
      z: 50,
      name: e.full_name,
      department: e.department,
    }));

    // At-risk employees (low fulfillment OR low operational)
    const atRisk = employeeProfiles.filter(e => e.fulfillmentScore < 40 || e.operationalScore < 40);
    
    // High performers (high in both)
    const highPerformers = employeeProfiles.filter(e => e.fulfillmentScore > 70 && e.operationalScore > 70);

    // Misaligned (one high, one low)
    const misaligned = employeeProfiles.filter(e => 
      (e.fulfillmentScore > 70 && e.operationalScore < 50) || 
      (e.operationalScore > 70 && e.fulfillmentScore < 50)
    );

    return {
      avgFulfillment: Math.round(avgFulfillment),
      avgOperational: Math.round(avgOperational),
      totalEmployees: employeeProfiles.length,
      fulfillmentDistribution,
      scatterData,
      atRisk,
      highPerformers,
      misaligned,
    };
  }, [employeeProfiles]);

  const balanceLabel = balanceSlider[0] <= 25 ? "Maximum Efficiency" 
    : balanceSlider[0] <= 45 ? "Efficiency Focused"
    : balanceSlider[0] <= 55 ? "Balanced"
    : balanceSlider[0] <= 75 ? "Fulfillment Focused"
    : "Maximum Fulfillment";

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Scale className="w-8 h-8 text-amber-400" />
            <h1 className="text-3xl font-light text-white tracking-wide">Win-Win Optimizer</h1>
          </div>
          <p className="text-gray-400">AI-powered employee reassignment analysis for maximum fulfillment and operational effectiveness</p>
        </div>

        {/* Balance Slider */}
        <Card className="bg-gradient-to-r from-purple-900/30 via-gray-900 to-amber-900/30 border-gray-800 mb-8">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Heart className="w-6 h-6 text-purple-400" />
                <span className="text-white font-medium">Employee Fulfillment</span>
              </div>
              <div className="text-center">
                <Badge className={`text-lg px-6 py-2 ${
                  balanceSlider[0] <= 35 ? 'bg-amber-600' :
                  balanceSlider[0] >= 65 ? 'bg-purple-600' : 'bg-gradient-to-r from-purple-600 to-amber-600'
                }`}>
                  {balanceLabel}
                </Badge>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-white font-medium">Luminous Efficiency</span>
                <Zap className="w-6 h-6 text-amber-400" />
              </div>
            </div>
            
            <Slider
              value={balanceSlider}
              onValueChange={setBalanceSlider}
              max={100}
              min={0}
              step={5}
              className="mb-4"
            />
            
            <div className="flex justify-between text-xs text-gray-500">
              <span>100% Efficiency</span>
              <span>Balanced (50/50)</span>
              <span>100% Fulfillment</span>
            </div>

            <div className="mt-6 flex justify-center">
              <Button 
                onClick={runOptimization}
                disabled={isOptimizing || employeeProfiles.length === 0}
                className="bg-white text-black hover:bg-gray-200 px-12 py-6 text-sm font-bold tracking-widest"
              >
                {isOptimizing ? (
                  <><RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Analyzing {employeeProfiles.length} Employees...</>
                ) : (
                  <><Brain className="w-5 h-5 mr-2" /> Run AI Optimization</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Current State Overview */}
        {orgMetrics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                    <Heart className="w-6 h-6 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Avg Fulfillment</p>
                    <p className="text-2xl font-bold text-white">{orgMetrics.avgFulfillment}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-amber-900 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Avg Operational</p>
                    <p className="text-2xl font-bold text-white">{orgMetrics.avgOperational}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-red-900 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">At-Risk Employees</p>
                    <p className="text-2xl font-bold text-white">{orgMetrics.atRisk.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-green-900 flex items-center justify-center">
                    <Star className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">High Performers</p>
                    <p className="text-2xl font-bold text-white">{orgMetrics.highPerformers.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="health" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="health">
              <Activity className="w-4 h-4 mr-1" />Org Health
            </TabsTrigger>
            <TabsTrigger value="results">Optimization Results</TabsTrigger>
            <TabsTrigger value="talent">
              <Users className="w-4 h-4 mr-1" />Talent Pool
            </TabsTrigger>
            <TabsTrigger value="employees">Employee Matrix</TabsTrigger>
            <TabsTrigger value="departments">Department View</TabsTrigger>
            <TabsTrigger value="visualization">Visualization</TabsTrigger>
            <TabsTrigger value="emergent">
              <Sparkles className="w-4 h-4 mr-1" />Emergent Scenarios
            </TabsTrigger>
            <TabsTrigger value="predictive">
              <TrendingUp className="w-4 h-4 mr-1" />Predictive Analytics
            </TabsTrigger>
            <TabsTrigger value="succession">
              <Award className="w-4 h-4 mr-1" />Succession Planning
            </TabsTrigger>
            <TabsTrigger value="teams">
              <Users className="w-4 h-4 mr-1" />Team Dynamics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="health">
            <OrganizationalHealthScore
              employeeProfiles={employeeProfiles}
              assessments={assessments}
              wellnessLogs={wellnessLogs}
              coachingSessions={coachingSessions}
              learningJourneys={learningJourneys}
              teams={teams}
            />
          </TabsContent>

          <TabsContent value="talent">
            <TalentPoolExplorer
              employeeProfiles={employeeProfiles}
              departments={departments}
              roles={roles}
            />
          </TabsContent>

          <TabsContent value="results">
            {simulatingReassignment && (
              <div className="mb-6">
                <ReassignmentSimulator
                  reassignment={simulatingReassignment}
                  employeeProfile={employeeProfiles.find(e => e.email === simulatingReassignment.employee_email)}
                  onClose={() => setSimulatingReassignment(null)}
                />
              </div>
            )}
            {optimizationResults ? (
              <div className="space-y-6">
                {/* Summary Card */}
                <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                      Optimization Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-4 gap-6 mb-6">
                      <div className="text-center p-4 bg-white/5 rounded-xl">
                        <p className="text-gray-400 text-sm mb-1">Current Fulfillment</p>
                        <p className="text-2xl font-bold text-purple-400">{optimizationResults.summary?.current_avg_fulfillment}%</p>
                      </div>
                      <div className="text-center p-4 bg-white/5 rounded-xl">
                        <p className="text-gray-400 text-sm mb-1">Projected Fulfillment</p>
                        <div className="flex items-center justify-center gap-2">
                          <p className="text-2xl font-bold text-green-400">{optimizationResults.summary?.projected_avg_fulfillment}%</p>
                          <TrendingUp className="w-5 h-5 text-green-400" />
                        </div>
                      </div>
                      <div className="text-center p-4 bg-white/5 rounded-xl">
                        <p className="text-gray-400 text-sm mb-1">Current Operational</p>
                        <p className="text-2xl font-bold text-amber-400">{optimizationResults.summary?.current_avg_operational}%</p>
                      </div>
                      <div className="text-center p-4 bg-white/5 rounded-xl">
                        <p className="text-gray-400 text-sm mb-1">Projected Operational</p>
                        <div className="flex items-center justify-center gap-2">
                          <p className="text-2xl font-bold text-green-400">{optimizationResults.summary?.projected_avg_operational}%</p>
                          <TrendingUp className="w-5 h-5 text-green-400" />
                        </div>
                      </div>
                    </div>
                    <div className="p-4 bg-white/5 rounded-xl">
                      <p className="text-white">{optimizationResults.summary?.key_insight}</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Wins & Strategic Moves */}
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="bg-emerald-900/20 border-emerald-800">
                    <CardHeader>
                      <CardTitle className="text-emerald-400 flex items-center gap-2">
                        <Zap className="w-5 h-5" />
                        Quick Wins
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {optimizationResults.quick_wins?.map((win, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                            {win}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-900/20 border-purple-800">
                    <CardHeader>
                      <CardTitle className="text-purple-400 flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        Strategic Moves
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {optimizationResults.strategic_moves?.map((move, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                            <ArrowRight className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                            {move}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Reassignment Cards */}
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Shuffle className="w-5 h-5 text-amber-400" />
                      Recommended Reassignments ({optimizationResults.reassignments?.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {optimizationResults.reassignments?.map((r, i) => (
                        <Card 
                          key={i} 
                          className={`bg-gray-800 border-gray-700 cursor-pointer transition-all ${
                            selectedReassignment === i ? 'ring-2 ring-amber-500' : 'hover:border-gray-600'
                          }`}
                          onClick={() => setSelectedReassignment(selectedReassignment === i ? null : i)}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-4">
                                <Avatar className="w-12 h-12">
                                  <AvatarFallback className="bg-purple-600 text-white">
                                    {r.employee_name?.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-white font-medium">{r.employee_name}</p>
                                  <div className="flex items-center gap-2 text-sm">
                                    <span className="text-gray-400">{r.current_role}</span>
                                    <ArrowRight className="w-4 h-4 text-amber-400" />
                                    <span className="text-amber-400 font-medium">{r.recommended_role}</span>
                                  </div>
                                  <p className="text-gray-500 text-xs mt-1">{r.current_department} → {r.recommended_department}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="text-center">
                                  <p className="text-xs text-gray-500">Fulfillment</p>
                                  <div className={`flex items-center gap-1 ${r.fulfillment_change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {r.fulfillment_change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                                    <span className="font-bold">{r.fulfillment_change > 0 ? '+' : ''}{r.fulfillment_change}%</span>
                                  </div>
                                </div>
                                <div className="text-center">
                                  <p className="text-xs text-gray-500">Operational</p>
                                  <div className={`flex items-center gap-1 ${r.operational_change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {r.operational_change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                                    <span className="font-bold">{r.operational_change > 0 ? '+' : ''}{r.operational_change}%</span>
                                  </div>
                                </div>
                                <Badge className={
                                  r.priority === 'high' ? 'bg-red-600' :
                                  r.priority === 'medium' ? 'bg-amber-600' : 'bg-blue-600'
                                }>
                                  {r.priority}
                                </Badge>
                              </div>
                            </div>

                            {selectedReassignment === i && (
                              <div className="mt-4 pt-4 border-t border-gray-700 space-y-4">
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div className="p-3 bg-purple-900/20 border border-purple-800 rounded-lg">
                                    <p className="text-purple-400 text-xs font-medium mb-2 flex items-center gap-1">
                                      <Heart className="w-3 h-3" /> Employee Benefits
                                    </p>
                                    <ul className="space-y-1">
                                      {r.employee_benefits?.map((b, j) => (
                                        <li key={j} className="text-gray-300 text-xs flex items-start gap-2">
                                          <CheckCircle2 className="w-3 h-3 text-purple-400 mt-0.5" />{b}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                  <div className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                                    <p className="text-amber-400 text-xs font-medium mb-2 flex items-center gap-1">
                                      <Building2 className="w-3 h-3" /> Organization Benefits
                                    </p>
                                    <ul className="space-y-1">
                                      {r.organization_benefits?.map((b, j) => (
                                        <li key={j} className="text-gray-300 text-xs flex items-start gap-2">
                                          <CheckCircle2 className="w-3 h-3 text-amber-400 mt-0.5" />{b}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-gray-500 text-xs mb-1">Personality Alignment</p>
                                    <p className="text-gray-300 text-sm">{r.personality_alignment}</p>
                                  </div>
                                  <div>
                                    <p className="text-gray-500 text-xs mb-1">Strength Utilization</p>
                                    <p className="text-gray-300 text-sm">{r.strength_utilization}</p>
                                  </div>
                                </div>
                                {r.risk_factors?.length > 0 && (
                                  <div className="p-3 bg-red-900/20 border border-red-800 rounded-lg">
                                    <p className="text-red-400 text-xs font-medium mb-2">Risk Factors & Mitigation</p>
                                    <div className="grid md:grid-cols-2 gap-2">
                                      {r.risk_factors.map((risk, j) => (
                                        <div key={j} className="text-xs">
                                          <p className="text-red-300">⚠ {risk}</p>
                                          {r.mitigation_strategies?.[j] && (
                                            <p className="text-green-300 ml-3">→ {r.mitigation_strategies[j]}</p>
                                          )}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                                <div className="flex items-center justify-between text-xs">
                                  <Badge variant="outline" className="border-gray-700 text-gray-400">
                                    Confidence: {r.confidence_score}%
                                  </Badge>
                                  <Badge variant="outline" className="border-gray-700 text-gray-400">
                                    Timeline: {r.timeline}
                                  </Badge>
                                  <Button
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSimulatingReassignment(r);
                                    }}
                                    className="bg-cyan-600 hover:bg-cyan-700"
                                  >
                                    <Play className="w-3 h-3 mr-1" />Simulate
                                  </Button>
                                </div>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Overall Recommendation */}
                <Card className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 border-amber-800">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <Lightbulb className="w-8 h-8 text-amber-400 flex-shrink-0" />
                      <div>
                        <p className="text-amber-400 font-medium mb-2">Overall Recommendation</p>
                        <p className="text-gray-300">{optimizationResults.overall_recommendation}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="py-20 text-center">
                  <Scale className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-2">Adjust the balance slider and run optimization</p>
                  <p className="text-gray-500 text-sm">The AI will analyze all employee data points to find win-win scenarios</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="employees">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Employee Fulfillment & Operational Matrix</CardTitle>
                <CardDescription className="text-gray-400">All employees ranked by fulfillment and operational scores</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px]">
                  <div className="space-y-2">
                    {employeeProfiles.sort((a, b) => (b.fulfillmentScore + b.operationalScore) - (a.fulfillmentScore + a.operationalScore)).map((emp, i) => (
                      <div key={i} className="flex items-center gap-4 p-3 bg-gray-800 rounded-lg hover:bg-gray-750">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-purple-600 text-white text-xs">
                            {emp.full_name?.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-medium truncate">{emp.full_name}</p>
                          <p className="text-gray-500 text-xs truncate">{emp.job_title} • {emp.department}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="w-24">
                            <p className="text-[10px] text-gray-500 mb-1">Fulfillment</p>
                            <Progress value={emp.fulfillmentScore} className="h-2" />
                            <p className="text-[10px] text-purple-400 mt-0.5">{emp.fulfillmentScore}%</p>
                          </div>
                          <div className="w-24">
                            <p className="text-[10px] text-gray-500 mb-1">Operational</p>
                            <Progress value={emp.operationalScore} className="h-2" />
                            <p className="text-[10px] text-amber-400 mt-0.5">{emp.operationalScore}%</p>
                          </div>
                          <Badge variant="outline" className="text-xs border-gray-700 text-gray-400">{emp.mbti}</Badge>
                          <Badge className={
                            emp.fulfillmentScore < 40 || emp.operationalScore < 40 ? 'bg-red-600' :
                            emp.fulfillmentScore > 70 && emp.operationalScore > 70 ? 'bg-green-600' :
                            'bg-gray-600'
                          }>
                            {emp.fulfillmentScore < 40 || emp.operationalScore < 40 ? 'At Risk' :
                             emp.fulfillmentScore > 70 && emp.operationalScore > 70 ? 'Thriving' : 'Stable'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments">
            {optimizationResults?.department_insights ? (
              <div className="grid md:grid-cols-2 gap-6">
                {optimizationResults.department_insights.map((dept, i) => (
                  <Card key={i} className="bg-gray-900 border-gray-800">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">{dept.department}</CardTitle>
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-sm">{dept.current_health}%</span>
                          <ArrowRight className="w-4 h-4 text-gray-500" />
                          <span className="text-green-400 font-medium">{dept.projected_health}%</span>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4 p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                        <p className="text-amber-400 text-xs font-medium mb-1">Key Opportunity</p>
                        <p className="text-gray-300 text-sm">{dept.key_opportunity}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-red-400 text-xs font-medium mb-2">Talent Gaps</p>
                          {dept.talent_gaps?.map((gap, j) => (
                            <Badge key={j} variant="outline" className="mr-1 mb-1 text-xs border-red-800 text-red-400">{gap}</Badge>
                          ))}
                        </div>
                        <div>
                          <p className="text-green-400 text-xs font-medium mb-2">Talent Surplus</p>
                          {dept.talent_surplus?.map((surplus, j) => (
                            <Badge key={j} variant="outline" className="mr-1 mb-1 text-xs border-green-800 text-green-400">{surplus}</Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="py-20 text-center">
                  <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Run optimization to see department insights</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="visualization">
            {orgMetrics && (
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white">Fulfillment vs Operational (Scatter)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <ScatterChart>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis type="number" dataKey="x" name="Fulfillment" domain={[0, 100]} stroke="#9ca3af" />
                        <YAxis type="number" dataKey="y" name="Operational" domain={[0, 100]} stroke="#9ca3af" />
                        <ZAxis type="number" dataKey="z" range={[50, 200]} />
                        <Tooltip 
                          cursor={{ strokeDasharray: '3 3' }}
                          content={({ payload }) => {
                            if (payload?.[0]) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-gray-800 p-2 rounded border border-gray-700 text-xs">
                                  <p className="text-white font-medium">{data.name}</p>
                                  <p className="text-gray-400">{data.department}</p>
                                  <p className="text-purple-400">Fulfillment: {data.x}%</p>
                                  <p className="text-amber-400">Operational: {data.y}%</p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Scatter name="Employees" data={orgMetrics.scatterData} fill="#8b5cf6" />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white">Fulfillment Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={orgMetrics.fulfillmentDistribution}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="range" stroke="#9ca3af" />
                        <YAxis stroke="#9ca3af" />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }}
                          labelStyle={{ color: '#fff' }}
                        />
                        <Bar dataKey="count" fill="#8b5cf6" name="Employees" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="emergent">
            <EmergentWinWinScenarios
              employeeProfiles={employeeProfiles}
              userSkills={userSkills}
              departments={departments}
            />
          </TabsContent>

          <TabsContent value="predictive">
            <PredictivePerformanceAnalytics
              employeeProfiles={employeeProfiles}
              assessments={assessments}
              coachingSessions={coachingSessions}
              learningJourneys={learningJourneys}
              wellnessLogs={wellnessLogs}
            />
          </TabsContent>

          <TabsContent value="succession">
            <SuccessionPlanningAI
              employeeProfiles={employeeProfiles}
              roleRequirements={roleRequirements}
              assessments={assessments}
              coachingSessions={coachingSessions}
              learningJourneys={learningJourneys}
            />
          </TabsContent>

          <TabsContent value="teams">
            <TeamDynamicsAI
              teams={teams}
              employeeProfiles={employeeProfiles}
              assessments={assessments}
              coachingSessions={coachingSessions}
              learningJourneys={learningJourneys}
              wellnessLogs={wellnessLogs}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}