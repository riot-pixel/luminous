import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, Mail, CheckCircle, FileText, Phone, ExternalLink } from "lucide-react";

export default function SalesAndOnboarding() {
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  if (!currentUser || currentUser.email !== 'ammanuldesta@gmail.com') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access Sales & Onboarding resources.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const adminResources = [
    {
      title: "Platform Administration",
      description: "Create new organizations and manage subscriptions after closing a sale",
      icon: Building2,
      link: createPageUrl("PlatformAdmin"),
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "Organization Settings",
      description: "Manage existing client organizations and invite team members",
      icon: Users,
      link: createPageUrl("OrganizationSettings"),
      color: "from-purple-500 to-purple-600",
    },
  ];

  const onboardingChecklist = [
    { step: 1, task: "Deal closed and payment received" },
    { step: 2, task: "Create Organization record in Platform Admin" },
    { step: 3, task: "Create Subscription record (set plan, seats, monthly price, status)" },
    { step: 4, task: "Notify client's main contact (CEO/HR Admin) with login instructions" },
    { step: 5, task: "Send welcome email with link to Organization Settings for team invites" },
    { step: 6, task: "Schedule kickoff call to guide initial setup" },
    { step: 7, task: "Follow up after first week to ensure assessments are being completed" },
  ];

  const clientResources = [
    {
      title: "Product Documentation",
      description: "Comprehensive guides for using Luminous Prosperity",
      icon: FileText,
      external: true,
    },
    {
      title: "Support Contact",
      description: "Email: support@luminousprosperity.com",
      icon: Mail,
      external: false,
    },
    {
      title: "Schedule Demo",
      description: "Book a personalized demo for prospective clients",
      icon: Phone,
      external: true,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sales & Onboarding Hub</h1>
          <p className="text-gray-600">Central resource for client acquisition and activation</p>
        </div>

        {/* Admin Tools */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Administration Tools</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {adminResources.map((resource, idx) => {
              const Icon = resource.icon;
              return (
                <Link key={idx} to={resource.link}>
                  <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border-2 hover:border-[#B8967D]">
                    <CardHeader>
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${resource.color} flex items-center justify-center mb-3`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle>{resource.title}</CardTitle>
                      <CardDescription>{resource.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Onboarding Checklist */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Client Onboarding Checklist
            </CardTitle>
            <CardDescription>Follow these steps when activating a new enterprise client</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {onboardingChecklist.map((item) => (
                <div key={item.step} className="flex items-start gap-3 p-3 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors">
                  <div className="w-8 h-8 bg-[#B8967D] text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                    {item.step}
                  </div>
                  <p className="text-gray-700 pt-1">{item.task}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Client Resources */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Client Resources</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {clientResources.map((resource, idx) => {
              const Icon = resource.icon;
              return (
                <Card key={idx} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <Icon className="w-6 h-6 text-[#B8967D]" />
                      {resource.external && <ExternalLink className="w-4 h-4 text-gray-400" />}
                    </div>
                    <CardTitle className="text-base">{resource.title}</CardTitle>
                    <CardDescription className="text-sm">{resource.description}</CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Quick Tips */}
        <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-200">
          <CardHeader>
            <CardTitle>💡 Quick Tips for Success</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-gray-700">
              <li>• <strong>Personalize welcome messages</strong> for each organization in the subscription setup</li>
              <li>• <strong>Schedule kickoff calls</strong> within 48 hours of organization activation</li>
              <li>• <strong>Set clear expectations</strong> about assessment completion timelines with clients</li>
              <li>• <strong>Monitor usage metrics</strong> in the first 30 days to ensure adoption</li>
              <li>• <strong>Follow up regularly</strong> with C-suite contacts to share organizational insights</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}