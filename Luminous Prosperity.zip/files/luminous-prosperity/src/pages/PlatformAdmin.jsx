import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, DollarSign, Users, TrendingUp, Shield } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function PlatformAdmin() {
  const queryClient = useQueryClient();

  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // RESTRICT ACCESS TO ammanuldesta@gmail.com ONLY
  if (!currentUser || currentUser.email !== 'ammanuldesta@gmail.com') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-600" />
              Access Denied
            </CardTitle>
            <CardDescription>
              You do not have permission to access the Platform Administration dashboard.
              Only the platform owner can access this area.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const [newOrg, setNewOrg] = useState({
    name: "",
    location: "",
    industry: "",
    size: "medium",
  });

  const [newSub, setNewSub] = useState({
    organization_id: "",
    plan_name: "Enterprise",
    monthly_price: 10000,
    seats_included: 50,
    status: "active",
  });

  const { data: organizations, isLoading: loadingOrgs } = useQuery({
    queryKey: ['allOrganizations'],
    queryFn: () => base44.entities.Organization.list('-created_date'),
    initialData: [],
  });

  const { data: subscriptions, isLoading: loadingSubs } = useQuery({
    queryKey: ['allSubscriptions'],
    queryFn: () => base44.entities.Subscription.list('-created_date'),
    initialData: [],
  });

  const { data: usageMetrics } = useQuery({
    queryKey: ['allUsageMetrics'],
    queryFn: () => base44.entities.UsageMetrics.list('-date'),
    initialData: [],
  });

  const createOrgMutation = useMutation({
    mutationFn: (data) => base44.entities.Organization.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allOrganizations'] });
      setNewOrg({ name: "", location: "", industry: "", size: "medium" });
      alert("Organization created successfully!");
    },
  });

  const createSubMutation = useMutation({
    mutationFn: (data) => base44.entities.Subscription.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allSubscriptions'] });
      setNewSub({
        organization_id: "",
        plan_name: "Enterprise",
        monthly_price: 10000,
        seats_included: 50,
        status: "active",
      });
      alert("Subscription created successfully!");
    },
  });

  const handleCreateOrg = async (e) => {
    e.preventDefault();
    if (!newOrg.name || !newOrg.location) {
      alert("Please fill in required fields");
      return;
    }
    createOrgMutation.mutate(newOrg);
  };

  const handleCreateSub = async (e) => {
    e.preventDefault();
    if (!newSub.organization_id) {
      alert("Please select an organization");
      return;
    }
    createSubMutation.mutate(newSub);
  };

  const totalMRR = subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + (s.monthly_price || 0), 0);

  const activeOrgs = organizations.filter(o => o.status === 'active').length;

  if (loadingOrgs || loadingSubs) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading platform data...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Platform Administration</h1>
          <p className="text-gray-600">Manage organizations, subscriptions, and platform metrics</p>
          <Badge className="mt-2 bg-green-600">Authorized: {currentUser.email}</Badge>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Total Organizations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{organizations.length}</div>
              <p className="text-xs text-blue-100 mt-1">{activeOrgs} active</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-600 to-green-700 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-100">Monthly Recurring Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">${totalMRR.toLocaleString()}</div>
              <p className="text-xs text-green-100 mt-1">from active subscriptions</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-600 to-purple-700 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Active Subscriptions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {subscriptions.filter(s => s.status === 'active').length}
              </div>
              <p className="text-xs text-purple-100 mt-1">enterprise clients</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-600 to-orange-700 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-orange-100">Total Seats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {subscriptions.reduce((sum, s) => sum + (s.seats_included || 0), 0)}
              </div>
              <p className="text-xs text-orange-100 mt-1">across all clients</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="organizations" className="space-y-6">
          <TabsList>
            <TabsTrigger value="organizations">Organizations</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="usage">Usage Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="organizations">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5" />
                    Create New Organization
                  </CardTitle>
                  <CardDescription>Set up a new client organization after closing a sale</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateOrg} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Organization Name *</Label>
                      <Input
                        value={newOrg.name}
                        onChange={(e) => setNewOrg({ ...newOrg, name: e.target.value })}
                        placeholder="Acme Corporation"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Location *</Label>
                      <Input
                        value={newOrg.location}
                        onChange={(e) => setNewOrg({ ...newOrg, location: e.target.value })}
                        placeholder="San Francisco, CA"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Industry</Label>
                      <Input
                        value={newOrg.industry}
                        onChange={(e) => setNewOrg({ ...newOrg, industry: e.target.value })}
                        placeholder="Technology"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Size</Label>
                      <Select value={newOrg.size} onValueChange={(value) => setNewOrg({ ...newOrg, size: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">Small (1-50)</SelectItem>
                          <SelectItem value="medium">Medium (51-250)</SelectItem>
                          <SelectItem value="large">Large (251-1000)</SelectItem>
                          <SelectItem value="enterprise">Enterprise (1000+)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit" className="w-full" disabled={createOrgMutation.isPending}>
                      {createOrgMutation.isPending ? "Creating..." : "Create Organization"}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Existing Organizations</CardTitle>
                  <CardDescription>{organizations.length} total organizations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {organizations.map((org) => (
                      <div key={org.id} className="p-3 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-semibold text-gray-900">{org.name}</p>
                            <p className="text-sm text-gray-600">{org.location}</p>
                            {org.industry && <p className="text-xs text-gray-500">{org.industry}</p>}
                          </div>
                          <Badge variant={org.status === 'active' ? 'default' : 'secondary'}>
                            {org.status || 'active'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="subscriptions">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Create Subscription
                  </CardTitle>
                  <CardDescription>Activate a subscription for a client organization</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateSub} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Organization *</Label>
                      <Select
                        value={newSub.organization_id}
                        onValueChange={(value) => setNewSub({ ...newSub, organization_id: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select organization" />
                        </SelectTrigger>
                        <SelectContent>
                          {organizations.map((org) => (
                            <SelectItem key={org.id} value={org.id}>
                              {org.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Plan Name</Label>
                      <Input
                        value={newSub.plan_name}
                        onChange={(e) => setNewSub({ ...newSub, plan_name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Monthly Price ($)</Label>
                      <Input
                        type="number"
                        value={newSub.monthly_price}
                        onChange={(e) => setNewSub({ ...newSub, monthly_price: parseInt(e.target.value) })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Seats Included</Label>
                      <Input
                        type="number"
                        value={newSub.seats_included}
                        onChange={(e) => setNewSub({ ...newSub, seats_included: parseInt(e.target.value) })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select value={newSub.status} onValueChange={(value) => setNewSub({ ...newSub, status: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="trial">Trial</SelectItem>
                          <SelectItem value="suspended">Suspended</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit" className="w-full" disabled={createSubMutation.isPending}>
                      {createSubMutation.isPending ? "Creating..." : "Create Subscription"}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Active Subscriptions</CardTitle>
                  <CardDescription>{subscriptions.length} total subscriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {subscriptions.map((sub) => {
                      const org = organizations.find(o => o.id === sub.organization_id);
                      return (
                        <div key={sub.id} className="p-3 border rounded-lg hover:bg-gray-50">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-semibold text-gray-900">{org?.name || 'Unknown Org'}</p>
                              <p className="text-sm text-gray-600">{sub.plan_name}</p>
                            </div>
                            <Badge variant={sub.status === 'active' ? 'default' : 'secondary'}>
                              {sub.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-600">${sub.monthly_price?.toLocaleString()}/mo</span>
                            <span className="text-gray-600">{sub.seats_included} seats</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="usage">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Usage Metrics
                </CardTitle>
                <CardDescription>Track platform usage across organizations</CardDescription>
              </CardHeader>
              <CardContent>
                {usageMetrics.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No usage metrics recorded yet</p>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {usageMetrics.map((metric) => {
                      const org = organizations.find(o => o.id === metric.organization_id);
                      return (
                        <div key={metric.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <p className="font-semibold text-gray-900">{org?.name || 'Unknown Org'}</p>
                            <span className="text-xs text-gray-500">{new Date(metric.date).toLocaleDateString()}</span>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-gray-600">Active Users</p>
                              <p className="font-semibold">{metric.active_users || 0}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Assessments</p>
                              <p className="font-semibold">{metric.assessments_completed || 0}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">API Calls</p>
                              <p className="font-semibold">{metric.api_calls || 0}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}