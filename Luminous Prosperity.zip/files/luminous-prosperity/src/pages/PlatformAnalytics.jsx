import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, FileText, Brain, BarChart3 } from "lucide-react";
import PlatformUsageAdvisor from "../components/analytics/PlatformUsageAdvisor";

export default function PlatformAnalytics() {
  const { data: users } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: reports } = useQuery({
    queryKey: ['customReports'],
    queryFn: () => base44.entities.CustomReport.list(),
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['allLearningJourneys'],
    queryFn: () => base44.entities.LearningJourney.list(),
    initialData: [],
  });

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-light text-white mb-2">Platform Analytics</h1>
          <p className="text-gray-400">AI-powered insights into platform usage and feature optimization</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-900 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Total Users</p>
                <p className="text-2xl font-bold text-white">{users.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                <Brain className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Assessments</p>
                <p className="text-2xl font-bold text-white">{assessments.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-900 flex items-center justify-center">
                <FileText className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Reports</p>
                <p className="text-2xl font-bold text-white">{reports.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-orange-900 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-orange-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Learning Journeys</p>
                <p className="text-2xl font-bold text-white">{learningJourneys.length}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Usage Advisor */}
        <PlatformUsageAdvisor
          users={users}
          assessments={assessments}
          reports={reports}
          learningJourneys={learningJourneys}
        />
      </div>
    </div>
  );
}