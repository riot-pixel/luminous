import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Users, Target, BarChart3, Heart, Sparkles, Calendar } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import ReactMarkdown from "react-markdown";

export default function Results() {
  const queryClient = useQueryClient();
  const [selectedAssessment, setSelectedAssessment] = useState(null);

  const { data: assessments, isLoading } = useQuery({
    queryKey: ['assessments'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: user.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  useEffect(() => {
    if (assessments.length > 0 && !selectedAssessment) {
      setSelectedAssessment(assessments[0]);
    }
  }, [assessments, selectedAssessment]);

  useEffect(() => {
    const markViewed = async () => {
      if (user && assessments.length > 0 && (!user.onboarding_tasks || !user.onboarding_tasks.viewed_results)) {
        await updateUserMutation.mutateAsync({
          onboarding_tasks: {
            ...(user.onboarding_tasks || {}),
            viewed_results: true,
          },
        });
      }
    };
    markViewed();
  }, [user, assessments]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-white/30 animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm tracking-widest uppercase">Loading results...</p>
        </div>
      </div>
    );
  }

  if (assessments.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black p-6">
        <div className="glass-panel rounded-3xl max-w-md text-center p-12">
          <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-light text-white mb-4 serif">No Results Yet</h2>
          <p className="text-gray-500 mb-8">Take your first assessment to see your comprehensive results here</p>
          <Button className="bg-white text-black px-8 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm">
            Start Assessment
          </Button>
        </div>
      </div>
    );
  }

  const chartColors = {
    primary: '#ffffff',
    secondary: '#525252',
    grid: 'rgba(255,255,255,0.05)',
    fill: 'rgba(255,255,255,0.1)',
  };

  const renderIntegralTheory = () => {
    if (!selectedAssessment?.integral_theory) return null;
    
    const quadrants = selectedAssessment.integral_theory.quadrants;
    const radarData = [
      { subject: 'Individual Interior', value: quadrants.individual_interior },
      { subject: 'Individual Exterior', value: quadrants.individual_exterior },
      { subject: 'Collective Interior', value: quadrants.collective_interior },
      { subject: 'Collective Exterior', value: quadrants.collective_exterior },
    ];

    return (
      <div className="space-y-6">
        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-2">Four Quadrants of Consciousness</h3>
          <p className="text-xs text-gray-500 mb-8">Your orientation across Ken Wilber's AQAL framework</p>
          <ResponsiveContainer width="100%" height={350}>
            <RadarChart data={radarData}>
              <PolarGrid stroke={chartColors.grid} />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#a1a1aa', fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#525252', fontSize: 10 }} />
              <Radar name="Score" dataKey="value" stroke={chartColors.primary} fill={chartColors.fill} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-4">Development Levels</h3>
          <div className="flex flex-wrap gap-2">
            {selectedAssessment.integral_theory.levels?.map((level) => (
              <span key={level} className="px-4 py-2 bg-white/5 border border-white/10 text-gray-300 rounded-full text-xs tracking-wider">
                {level.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </span>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-4">Primary Intelligence Line</h3>
          <p className="text-3xl font-light gold-gradient-text">
            {selectedAssessment.integral_theory.primary_line?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </p>
        </div>
      </div>
    );
  };

  const renderMyersBriggs = () => {
    if (!selectedAssessment?.myers_briggs) return null;

    return (
      <div className="space-y-6">
        <div className="glass-panel rounded-2xl p-12 text-center">
          <p className="text-xs text-gray-500 uppercase tracking-widest mb-4">Your Personality Type</p>
          <p className="text-7xl font-light text-white mb-4">{selectedAssessment.myers_briggs.type}</p>
          <p className="text-gray-500">Extended Myers-Briggs Type</p>
        </div>

        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-6">Cognitive Functions</h3>
          <div className="space-y-3">
            {selectedAssessment.myers_briggs.cognitive_functions?.map((func, index) => (
              <div key={index} className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                <div className="w-8 h-8 bg-white text-black rounded-full flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
                <span className="text-gray-300">{func}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderStrengths = () => {
    if (!selectedAssessment?.strengths) return null;

    const categoryData = Object.entries(selectedAssessment.strengths.strength_categories || {}).map(([name, value]) => ({
      name: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      score: value,
    }));

    return (
      <div className="space-y-6">
        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-6">Your Top 5 Signature Strengths</h3>
          <div className="space-y-3">
            {selectedAssessment.strengths.top_strengths?.map((strength, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-white to-gray-400 text-black rounded-lg flex items-center justify-center font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-white">{strength.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{strength.category}</p>
                  </div>
                </div>
                <div className="text-2xl font-light text-white">{strength.score}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-6">Strength Categories</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fill: '#525252', fontSize: 10 }} />
              <YAxis domain={[0, 100]} tick={{ fill: '#525252', fontSize: 10 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(20,20,20,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                labelStyle={{ color: '#fff' }}
                itemStyle={{ color: '#a1a1aa' }}
              />
              <Bar dataKey="score" fill={chartColors.primary} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  };

  const renderLifeWheel = () => {
    if (!selectedAssessment?.life_wheel) return null;

    const wheelData = Object.entries(selectedAssessment.life_wheel)
      .filter(([key]) => key !== 'overall_satisfaction')
      .map(([key, value]) => ({
        subject: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        value: value * 10,
      }));

    return (
      <div className="space-y-6">
        <div className="glass-panel rounded-2xl p-8">
          <h3 className="text-lg font-light text-white mb-2">Life Balance Wheel</h3>
          <p className="text-xs text-gray-500 mb-8">Your satisfaction across key life dimensions</p>
          <ResponsiveContainer width="100%" height={400}>
            <RadarChart data={wheelData}>
              <PolarGrid stroke={chartColors.grid} />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#a1a1aa', fontSize: 11 }} />
              <PolarRadiusAxis domain={[0, 100]} tick={{ fill: '#525252', fontSize: 10 }} />
              <Radar name="Satisfaction" dataKey="value" stroke="#fbbf24" fill="rgba(251,191,36,0.2)" strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-panel rounded-2xl p-12 text-center">
          <p className="text-xs text-gray-500 uppercase tracking-widest mb-4">Overall Life Satisfaction</p>
          <p className="text-7xl font-light gold-gradient-text">
            {selectedAssessment.life_wheel.overall_satisfaction}%
          </p>
          <p className="text-gray-500 mt-4">Integrated Life Balance Score</p>
        </div>
      </div>
    );
  };

  const renderAppreciativeInquiry = () => {
    if (!selectedAssessment?.appreciative_inquiry) return null;
    const ai = selectedAssessment.appreciative_inquiry;

    return (
      <div className="space-y-6">
        {ai.define && (
          <div className="glass-panel rounded-2xl p-8">
            <h3 className="text-lg font-light text-white mb-4">Define: Your Focus</h3>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Core Topic</p>
                <p className="text-gray-300">{ai.define.core_topic}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Focus Area</p>
                <p className="text-gray-300">{ai.define.focus_area}</p>
              </div>
            </div>
          </div>
        )}

        {ai.discover && (
          <div className="glass-panel rounded-2xl p-8">
            <h3 className="text-lg font-light text-white mb-4">Discover: Your Best</h3>
            <div className="space-y-4">
              {ai.discover.peak_experiences?.filter(e => e).length > 0 && (
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Peak Experiences</p>
                  <ul className="space-y-1">
                    {ai.discover.peak_experiences.filter(e => e).map((exp, i) => (
                      <li key={i} className="text-gray-300 text-sm">• {exp}</li>
                    ))}
                  </ul>
                </div>
              )}
              {ai.discover.core_values?.filter(v => v).length > 0 && (
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Core Values</p>
                  <div className="flex flex-wrap gap-2">
                    {ai.discover.core_values.filter(v => v).map((value, i) => (
                      <span key={i} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300">{value}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {ai.dream && (
          <div className="glass-panel rounded-2xl p-8">
            <h3 className="text-lg font-light text-white mb-4">Dream: Your Vision</h3>
            <div className="space-y-4">
              {ai.dream.aspirations?.filter(a => a).length > 0 && (
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Aspirations</p>
                  <ul className="space-y-1">
                    {ai.dream.aspirations.filter(a => a).map((asp, i) => (
                      <li key={i} className="text-gray-300 text-sm">• {asp}</li>
                    ))}
                  </ul>
                </div>
              )}
              {ai.dream.ideal_future && (
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Ideal Future</p>
                  <p className="text-gray-300 text-sm leading-relaxed">{ai.dream.ideal_future}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-10">
          <h1 className="text-3xl font-light text-white mb-2 serif">Your Assessment Results</h1>
          <p className="text-gray-500">Comprehensive insights from your integrated assessment</p>
        </div>

        {assessments.length > 1 && (
          <div className="glass-panel rounded-2xl p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Calendar className="w-5 h-5 text-gray-500" />
              <h3 className="text-sm text-white font-medium">Assessment History</h3>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {assessments.map((assessment) => (
                <Button
                  key={assessment.id}
                  variant={selectedAssessment?.id === assessment.id ? "default" : "outline"}
                  onClick={() => setSelectedAssessment(assessment)}
                  className={selectedAssessment?.id === assessment.id 
                    ? "bg-white text-black hover:bg-gray-200 text-xs" 
                    : "border-white/10 text-gray-400 hover:bg-white/5 text-xs"
                  }
                >
                  {format(new Date(assessment.completed_date), "MMM d, yyyy")}
                </Button>
              ))}
            </div>
          </div>
        )}

        {selectedAssessment?.overall_insights && (
          <div className="glass-panel rounded-2xl p-8 mb-8 border border-amber-500/20">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="w-6 h-6 text-amber-400" />
              <h2 className="text-xl font-light text-white">Integrated Insights</h2>
            </div>
            <div className="prose prose-invert prose-sm max-w-none text-gray-400">
              <ReactMarkdown>{selectedAssessment.overall_insights}</ReactMarkdown>
            </div>
          </div>
        )}

        <Tabs defaultValue="integral" className="space-y-6">
          <TabsList className="glass-panel p-1 rounded-xl">
            <TabsTrigger value="integral" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Brain className="w-4 h-4 mr-2" />
              Integral
            </TabsTrigger>
            <TabsTrigger value="mbti" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Users className="w-4 h-4 mr-2" />
              MBTI
            </TabsTrigger>
            <TabsTrigger value="strengths" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Target className="w-4 h-4 mr-2" />
              Strengths
            </TabsTrigger>
            <TabsTrigger value="wheel" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <BarChart3 className="w-4 h-4 mr-2" />
              Life Wheel
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Heart className="w-4 h-4 mr-2" />
              5 D's
            </TabsTrigger>
          </TabsList>

          <TabsContent value="integral">{renderIntegralTheory()}</TabsContent>
          <TabsContent value="mbti">{renderMyersBriggs()}</TabsContent>
          <TabsContent value="strengths">{renderStrengths()}</TabsContent>
          <TabsContent value="wheel">{renderLifeWheel()}</TabsContent>
          <TabsContent value="ai">{renderAppreciativeInquiry()}</TabsContent>
        </Tabs>
      </div>
    </div>
  );
}