import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Sparkles, Compass, Target, RefreshCw, Scale, Layers, 
  Brain, Zap, Star, Eye, Download, Clock, CheckCircle2,
  Building2, TrendingUp, Shield, AlertTriangle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import StrategicMapView from "../components/clarity/StrategicMapView";
import PriorityDashboard from "../components/clarity/PriorityDashboard";
import IdentityArcView from "../components/clarity/IdentityArcView";
import DecisionSpineView from "../components/clarity/DecisionSpineView";

export default function ExponentialClarity() {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingPhase, setGeneratingPhase] = useState("");
  const [selectedTimeframe, setSelectedTimeframe] = useState("3_year");
  const [clarityData, setClarityData] = useState(null);
  const [isInputDialogOpen, setIsInputDialogOpen] = useState(false);
  const [companyContext, setCompanyContext] = useState({
    industry: "",
    currentChallenges: "",
    aspirations: "",
    teamSize: "",
    recentChanges: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: organization } = useQuery({
    queryKey: ['organization'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: existingClarity } = useQuery({
    queryKey: ['strategicClarity'],
    queryFn: () => base44.entities.StrategicClarity.filter({ status: 'active' }, '-created_date'),
    initialData: [],
  });

  const createClarityMutation = useMutation({
    mutationFn: (data) => base44.entities.StrategicClarity.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['strategicClarity'] }),
  });

  const org = organization[0];
  const latestClarity = existingClarity[0];

  // Aggregate organizational insights
  const orgInsights = {
    totalEmployees: employees.length,
    departments: [...new Set(employees.map(e => e.department).filter(Boolean))],
    assessmentCoverage: employees.length > 0 
      ? Math.round((new Set(assessments.map(a => a.user_email)).size / employees.length) * 100) 
      : 0,
    avgSatisfaction: assessments.length > 0 
      ? Math.round(assessments.filter(a => a.life_wheel?.overall_satisfaction).reduce((s, a) => s + a.life_wheel.overall_satisfaction, 0) / assessments.filter(a => a.life_wheel?.overall_satisfaction).length) 
      : 0,
  };

  const generateClarityEngine = async () => {
    setIsGenerating(true);
    setIsInputDialogOpen(false);

    try {
      // Phase 1: Strategic Map
      setGeneratingPhase("Analyzing market positioning and strategic lines...");
      const strategicMap = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a world-class strategic clarity consultant creating a holarchic clarity system.

ORGANIZATION CONTEXT:
- Industry: ${companyContext.industry || org?.industry || 'Technology'}
- Team Size: ${companyContext.teamSize || orgInsights.totalEmployees} employees
- Departments: ${orgInsights.departments.join(', ') || 'Multiple departments'}
- Employee Engagement: ${orgInsights.avgSatisfaction}% satisfaction
- Current Challenges: ${companyContext.currentChallenges || 'Growth and scaling'}
- Aspirations: ${companyContext.aspirations || 'Market leadership'}
- Recent Changes: ${companyContext.recentChanges || 'Organizational development'}
- Timeframe: ${selectedTimeframe.replace('_', ' ')}

Create a comprehensive 12-LINE STRATEGIC MAP that provides startling clarity on the next ${selectedTimeframe.replace('_', ' ')}.

Each of the 12 strategic lines should cover a critical domain:
1. Market Position
2. Customer Experience
3. Product/Service Evolution
4. Technology & Innovation
5. Talent & Culture
6. Operations & Scale
7. Financial Architecture
8. Partnerships & Ecosystem
9. Brand & Reputation
10. Risk & Resilience
11. Leadership & Governance
12. Impact & Legacy

For each line, define the transformation from current to future state.`,
        response_json_schema: {
          type: "object",
          properties: {
            north_star: { type: "string" },
            strategic_lines: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  line_number: { type: "number" },
                  domain: { type: "string" },
                  current_state: { type: "string" },
                  future_state: { type: "string" },
                  key_moves: { type: "array", items: { type: "string" } },
                  blockers: { type: "array", items: { type: "string" } },
                  enablers: { type: "array", items: { type: "string" } }
                }
              }
            },
            market_positioning: {
              type: "object",
              properties: {
                current_position: { type: "string" },
                target_position: { type: "string" },
                differentiation: { type: "array", items: { type: "string" } },
                competitive_moats: { type: "array", items: { type: "string" } }
              }
            },
            bottlenecks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  severity: { type: "string" },
                  impact: { type: "string" },
                  resolution_path: { type: "string" }
                }
              }
            }
          }
        }
      });

      // Phase 2: Priority Dashboard
      setGeneratingPhase("Building dynamic priority dashboard...");
      const priorityDashboard = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this strategic map, create a LIVING PRIORITY DASHBOARD:

NORTH STAR: ${strategicMap.north_star}
KEY BOTTLENECKS: ${strategicMap.bottlenecks?.map(b => b.area).join(', ')}
STRATEGIC DOMAINS: ${strategicMap.strategic_lines?.map(l => l.domain).join(', ')}

Create:
1. 5-7 Tier 1 (Critical) priorities with owners, deadlines, progress tracking
2. 8-12 Tier 2 (Important) priorities linked to Tier 1
3. Resource allocation recommendations (people, budget, time)

Make priorities SMART: Specific, Measurable, Actionable, Relevant, Time-bound.`,
        response_json_schema: {
          type: "object",
          properties: {
            tier_1_priorities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  priority: { type: "string" },
                  owner: { type: "string" },
                  deadline: { type: "string" },
                  progress: { type: "number" },
                  dependencies: { type: "array", items: { type: "string" } },
                  risk_level: { type: "string" }
                }
              }
            },
            tier_2_priorities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  priority: { type: "string" },
                  linked_to_tier_1: { type: "string" },
                  status: { type: "string" }
                }
              }
            },
            resource_allocation: {
              type: "object",
              properties: {
                people: { type: "number" },
                budget: { type: "number" },
                time: { type: "string" }
              }
            }
          }
        }
      });

      // Phase 3: Identity Arc
      setGeneratingPhase("Mapping identity evolution arc...");
      const identityArc = await base44.integrations.Core.InvokeLLM({
        prompt: `Create an IDENTITY EVOLUTION ARC for this organization:

CONTEXT:
- Industry: ${companyContext.industry || org?.industry}
- North Star: ${strategicMap.north_star}
- Aspirations: ${companyContext.aspirations}
- Recent Changes: ${companyContext.recentChanges}

Map the organization's identity journey:
1. Origin story - where did this organization come from?
2. Current identity - who is the organization today?
3. Emerging identity - what is starting to emerge?
4. Future identity - who will the organization become?

Identify tensions between current and future identity, and how to navigate them.
Define cultural markers and how values will evolve.`,
        response_json_schema: {
          type: "object",
          properties: {
            origin_story: { type: "string" },
            current_identity: { type: "string" },
            emerging_identity: { type: "string" },
            future_identity: { type: "string" },
            identity_tensions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  tension: { type: "string" },
                  resolution_path: { type: "string" }
                }
              }
            },
            cultural_markers: { type: "array", items: { type: "string" } },
            values_evolution: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  value: { type: "string" },
                  past_expression: { type: "string" },
                  future_expression: { type: "string" }
                }
              }
            }
          }
        }
      });

      // Phase 4: Decision Spine
      setGeneratingPhase("Constructing decision-making spine...");
      const decisionSpine = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a DECISION-MAKING SPINE for this organization:

NORTH STAR: ${strategicMap.north_star}
IDENTITY: ${identityArc.current_identity} → ${identityArc.future_identity}
KEY PRIORITIES: ${priorityDashboard.tier_1_priorities?.map(p => p.priority).join(', ')}

Build:
1. 5-7 Core decision principles that guide all strategic choices
2. Decision hierarchy - who decides what, at what speed
3. Strategic filters - questions to ask before any major decision

The decision spine should turn chaos into clarity by providing a reliable framework for navigating uncertainty.`,
        response_json_schema: {
          type: "object",
          properties: {
            decision_principles: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  principle: { type: "string" },
                  when_to_apply: { type: "string" },
                  example: { type: "string" }
                }
              }
            },
            decision_hierarchy: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  level: { type: "string" },
                  decision_types: { type: "array", items: { type: "string" } },
                  decision_maker: { type: "string" },
                  time_to_decide: { type: "string" }
                }
              }
            },
            strategic_filters: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  pass_threshold: { type: "string" }
                }
              }
            }
          }
        }
      });

      // Combine all data
      const fullClarityData = {
        timeframe: selectedTimeframe,
        clarity_type: "strategic_map",
        strategic_map: strategicMap,
        priority_dashboard: priorityDashboard,
        identity_arc: identityArc,
        decision_spine: decisionSpine,
        ai_confidence: 85,
        generated_date: new Date().toISOString(),
        status: 'active'
      };

      setClarityData(fullClarityData);

      // Save to database
      await createClarityMutation.mutateAsync(fullClarityData);

      setGeneratingPhase("");
    } catch (error) {
      console.error("Error generating clarity engine:", error);
      setGeneratingPhase("");
    }

    setIsGenerating(false);
  };

  const displayData = clarityData || latestClarity;

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Exponential Clarity Engine</h1>
            <p className="text-gray-500">Turn chaos into nested inevitability with holarchic strategic clarity</p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-32 bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1_year">1 Year</SelectItem>
                <SelectItem value="3_year">3 Years</SelectItem>
                <SelectItem value="5_year">5 Years</SelectItem>
                <SelectItem value="10_year">10 Years</SelectItem>
              </SelectContent>
            </Select>
            <Dialog open={isInputDialogOpen} onOpenChange={setIsInputDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Clarity
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-white/10 text-white max-w-lg">
                <DialogHeader>
                  <DialogTitle className="text-white">Configure Clarity Engine</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label className="text-gray-400">Industry</Label>
                    <Input
                      value={companyContext.industry}
                      onChange={(e) => setCompanyContext({...companyContext, industry: e.target.value})}
                      placeholder="e.g., Technology, Healthcare, Finance"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Team Size</Label>
                    <Input
                      value={companyContext.teamSize}
                      onChange={(e) => setCompanyContext({...companyContext, teamSize: e.target.value})}
                      placeholder="e.g., 50, 200, 1000"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Current Challenges</Label>
                    <Textarea
                      value={companyContext.currentChallenges}
                      onChange={(e) => setCompanyContext({...companyContext, currentChallenges: e.target.value})}
                      placeholder="What are your biggest strategic challenges?"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Aspirations</Label>
                    <Textarea
                      value={companyContext.aspirations}
                      onChange={(e) => setCompanyContext({...companyContext, aspirations: e.target.value})}
                      placeholder="Where do you want to be in 3-5 years?"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-400">Recent Changes</Label>
                    <Textarea
                      value={companyContext.recentChanges}
                      onChange={(e) => setCompanyContext({...companyContext, recentChanges: e.target.value})}
                      placeholder="Any recent organizational or market changes?"
                      className="bg-white/5 border-white/10 text-white"
                    />
                  </div>
                  <Button 
                    onClick={generateClarityEngine}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-500"
                    disabled={isGenerating}
                  >
                    {isGenerating ? (
                      <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                    ) : (
                      <><Zap className="w-4 h-4 mr-2" /> Generate Strategic Clarity</>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Generation Progress */}
        <AnimatePresence>
          {isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <Card className="bg-gradient-to-r from-amber-500/20 to-orange-500/20 border-amber-500/30">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-amber-400 animate-spin" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Generating Exponential Clarity</p>
                      <p className="text-amber-400 text-sm">{generatingPhase}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Stats */}
        {displayData && (
          <div className="grid grid-cols-4 gap-4 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-white/5 rounded-xl border border-white/10"
            >
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-500 uppercase">Strategic Lines</span>
              </div>
              <p className="text-2xl font-light text-white">{displayData.strategic_map?.strategic_lines?.length || 12}</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="p-4 bg-white/5 rounded-xl border border-white/10"
            >
              <div className="flex items-center gap-2 mb-2">
                <Layers className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-gray-500 uppercase">Priorities</span>
              </div>
              <p className="text-2xl font-light text-white">
                {(displayData.priority_dashboard?.tier_1_priorities?.length || 0) + (displayData.priority_dashboard?.tier_2_priorities?.length || 0)}
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="p-4 bg-white/5 rounded-xl border border-white/10"
            >
              <div className="flex items-center gap-2 mb-2">
                <Scale className="w-4 h-4 text-amber-400" />
                <span className="text-xs text-gray-500 uppercase">Decision Filters</span>
              </div>
              <p className="text-2xl font-light text-white">{displayData.decision_spine?.strategic_filters?.length || 0}</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="p-4 bg-white/5 rounded-xl border border-white/10"
            >
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-gray-500 uppercase">AI Confidence</span>
              </div>
              <p className="text-2xl font-light text-white">{displayData.ai_confidence || 85}%</p>
            </motion.div>
          </div>
        )}

        {/* Main Content */}
        {displayData ? (
          <Tabs defaultValue="strategic" className="space-y-6">
            <TabsList className="glass-panel p-1 rounded-xl">
              <TabsTrigger value="strategic" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                <Target className="w-4 h-4 mr-2" /> Strategic Map
              </TabsTrigger>
              <TabsTrigger value="priorities" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                <Layers className="w-4 h-4 mr-2" /> Priority Dashboard
              </TabsTrigger>
              <TabsTrigger value="identity" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                <RefreshCw className="w-4 h-4 mr-2" /> Identity Arc
              </TabsTrigger>
              <TabsTrigger value="decisions" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
                <Scale className="w-4 h-4 mr-2" /> Decision Spine
              </TabsTrigger>
            </TabsList>

            <TabsContent value="strategic">
              <StrategicMapView 
                strategicMap={displayData.strategic_map} 
                timeframe={displayData.timeframe}
              />
            </TabsContent>

            <TabsContent value="priorities">
              <PriorityDashboard priorityData={displayData.priority_dashboard} />
            </TabsContent>

            <TabsContent value="identity">
              <IdentityArcView identityArc={displayData.identity_arc} />
            </TabsContent>

            <TabsContent value="decisions">
              <DecisionSpineView decisionSpine={displayData.decision_spine} />
            </TabsContent>
          </Tabs>
        ) : (
          /* Empty State */
          <div className="glass-panel rounded-3xl p-16 text-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20 flex items-center justify-center mx-auto mb-8">
              <Compass className="w-12 h-12 text-amber-400" />
            </div>
            <h2 className="text-3xl font-light text-white mb-4 serif">Exponential Clarity Awaits</h2>
            <p className="text-gray-500 max-w-xl mx-auto mb-8">
              Transform organizational chaos into nested inevitability. Generate a holarchic clarity system 
              with a 12-line strategic map, living priority dashboard, identity evolution arc, and decision-making spine.
            </p>
            <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto mb-10">
              <div className="p-4 bg-white/5 rounded-xl">
                <Target className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">12-Line Strategic Map</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Layers className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Dynamic Priorities</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <RefreshCw className="w-6 h-6 text-pink-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Identity Evolution</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Scale className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Decision Spine</p>
              </div>
            </div>
            <Button 
              onClick={() => setIsInputDialogOpen(true)}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 px-8 py-6 text-lg"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Generate Exponential Clarity
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}