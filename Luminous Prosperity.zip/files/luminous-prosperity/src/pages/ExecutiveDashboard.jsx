import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import ExecutiveSummaryDashboard from "../components/executive/ExecutiveSummaryDashboard";

export default function ExecutiveDashboard() {
  // Fetch all required data
  const { data: employees } = useQuery({
    queryKey: ['employeesForExecDash'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['assessmentsForExecDash'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['userSkillsForExecDash'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleReqsForExecDash'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: coachingSessions } = useQuery({
    queryKey: ['coachingForExecDash'],
    queryFn: () => base44.entities.CoachingSession.list(),
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['journeysForExecDash'],
    queryFn: () => base44.entities.LearningJourney.list(),
    initialData: [],
  });

  const { data: wellnessLogs } = useQuery({
    queryKey: ['wellnessForExecDash'],
    queryFn: () => base44.entities.WellnessLog.list('-created_date', 500),
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['teamsForExecDash'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  // Calculate employee profiles with metrics
  const employeeProfiles = React.useMemo(() => {
    return employees.map(emp => {
      const empAssessments = assessments.filter(a => a.created_by === emp.email);
      const latestAssessment = empAssessments[0];
      const empSkills = userSkills.filter(s => s.user_email === emp.email);
      const empCoaching = coachingSessions.filter(c => c.user_email === emp.email);
      const empJourneys = learningJourneys.filter(j => j.user_email === emp.email);
      const empWellness = wellnessLogs.filter(w => w.user_email === emp.email);

      const lifeWheel = latestAssessment?.life_wheel || {};
      const careerSatisfaction = (lifeWheel.career || 5) * 10;
      const personalGrowth = (lifeWheel.personal_growth || 5) * 10;

      const recentWellness = empWellness.slice(0, 10);
      const avgMood = recentWellness.length > 0 
        ? recentWellness.reduce((sum, w) => sum + (w.mood_score || 5), 0) / recentWellness.length * 10
        : 50;
      const avgEnergy = recentWellness.length > 0
        ? recentWellness.reduce((sum, w) => sum + (w.energy_level || 5), 0) / recentWellness.length * 10
        : 50;

      const skillScores = empSkills.map(s => {
        const profMap = { 'Beginner': 25, 'Intermediate': 50, 'Advanced': 75, 'Expert': 100 };
        return profMap[s.current_proficiency] || 0;
      });
      const avgSkillLevel = skillScores.length > 0
        ? skillScores.reduce((a, b) => a + b, 0) / skillScores.length
        : 0;

      const currentRoleReqs = roleRequirements.filter(r => r.role_title === emp.job_title);
      let roleFit = 100;
      if (currentRoleReqs.length > 0) {
        const profOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        const matchedSkills = currentRoleReqs.filter(req => {
          const userSkill = empSkills.find(s => s.skill_name === req.skill_name);
          return userSkill && profOrder.indexOf(userSkill.current_proficiency) >= profOrder.indexOf(req.required_proficiency);
        });
        roleFit = (matchedSkills.length / currentRoleReqs.length) * 100;
      }

      const fulfillmentScore = Math.round(
        (careerSatisfaction * 0.3) +
        (personalGrowth * 0.2) +
        (avgMood * 0.25) +
        (avgEnergy * 0.25)
      );

      const avgCoachingScore = empCoaching.length > 0
        ? empCoaching.reduce((sum, c) => sum + (c.overall_score || 0), 0) / empCoaching.length
        : 0;

      const operationalScore = Math.round(
        (roleFit * 0.4) +
        (avgSkillLevel * 0.3) +
        (avgCoachingScore * 0.3)
      );

      return {
        ...emp,
        skills: empSkills,
        fulfillmentScore: Math.min(100, Math.max(0, fulfillmentScore)),
        operationalScore: Math.min(100, Math.max(0, operationalScore)),
        avgSkillLevel: Math.round(avgSkillLevel),
        avgMood: Math.round(avgMood),
        avgEnergy: Math.round(avgEnergy),
        roleFit: Math.round(roleFit),
      };
    }).filter(e => e.email);
  }, [employees, assessments, userSkills, roleRequirements, coachingSessions, learningJourneys, wellnessLogs]);

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <ExecutiveSummaryDashboard
          employeeProfiles={employeeProfiles}
          teams={teams}
          assessments={assessments}
          coachingSessions={coachingSessions}
          learningJourneys={learningJourneys}
          wellnessLogs={wellnessLogs}
          roleRequirements={roleRequirements}
        />
      </div>
    </div>
  );
}