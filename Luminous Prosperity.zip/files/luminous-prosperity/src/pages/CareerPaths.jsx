import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Sparkles, TrendingUp, Target, Users, BookOpen, Award, ArrowRight,
  Briefcase, Star, CheckCircle2, Clock, Zap, Brain, Heart, ChevronRight, Route, MessageCircle
} from "lucide-react";
import { motion } from "framer-motion";
import CareerPathingCoach from "../components/career/CareerPathingCoach";
import LearningJourneyGenerator from "../components/career/LearningJourneyGenerator";
import PerformanceFeedbackEngine from "../components/career/PerformanceFeedbackEngine";
import GamificationPanel from "../components/learning/GamificationPanel";
import AdaptiveLearningEngine from "../components/learning/AdaptiveLearningEngine";
import AICoachingSimulator from "../components/career/AICoachingSimulator";

export default function CareerPaths() {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [careerAnalysis, setCareerAnalysis] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments } = useQuery({
    queryKey: ['myAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['mySkills'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.UserSkill.filter({ user_email: currentUser.email });
    },
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: allUsers } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['myLearningJourneys'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.LearningJourney.filter({ user_email: currentUser.email });
    },
    initialData: [],
  });

  const latestAssessment = assessments[0];

  const analyzeCareerPaths = async () => {
    setIsAnalyzing(true);
    try {
      // Get unique roles from requirements
      const availableRoles = [...new Set(roleRequirements.map(r => r.role_title))];
      
      // Find potential mentors (users with higher roles)
      const potentialMentors = allUsers.filter(u => 
        u.user_role === 'executive' || u.user_role === 'manager'
      ).map(m => ({
        name: m.full_name,
        role: m.job_title,
        department: m.department,
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a career development expert and organizational psychologist.

Analyze this employee's profile and suggest personalized career paths:

EMPLOYEE PROFILE:
- Name: ${user?.full_name}
- Current Role: ${user?.job_title || 'Not specified'}
- Department: ${user?.department || 'Not specified'}
- Personality Type: ${latestAssessment?.myers_briggs?.type}
- Top Strengths: ${latestAssessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ')}
- Life Satisfaction: ${latestAssessment?.life_wheel?.overall_satisfaction}%
- Career Satisfaction: ${(latestAssessment?.life_wheel?.career || 0) * 10}%
- Personal Growth Score: ${(latestAssessment?.life_wheel?.personal_growth || 0) * 10}%

CURRENT SKILLS:
${userSkills.map(s => `- ${s.skill_name}: ${s.current_proficiency}`).join('\n') || 'No skills recorded'}

AVAILABLE ROLES IN ORGANIZATION:
${availableRoles.join(', ') || 'Various roles available'}

POTENTIAL MENTORS:
${potentialMentors.slice(0, 5).map(m => `- ${m.name} (${m.role}, ${m.department})`).join('\n') || 'Mentors available'}

Based on this profile, provide:
1. 3 potential career paths (lateral moves, promotions, or role transitions)
2. For each path, provide specific transition plans
3. Identify mentorship opportunities
4. Suggest training and experience-building opportunities
5. Estimate readiness score and timeline

Consider personality fit, current strengths, and growth areas.`,
        response_json_schema: {
          type: "object",
          properties: {
            career_summary: {
              type: "object",
              properties: {
                current_trajectory: { type: "string" },
                growth_potential: { type: "string" },
                key_strengths: { type: "array", items: { type: "string" } },
                development_areas: { type: "array", items: { type: "string" } }
              }
            },
            career_paths: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  path_type: { type: "string" },
                  target_role: { type: "string" },
                  department: { type: "string" },
                  readiness_score: { type: "number" },
                  estimated_timeline: { type: "string" },
                  salary_potential: { type: "string" },
                  personality_fit: { type: "string" },
                  why_recommended: { type: "string" },
                  skill_gaps: { type: "array", items: { type: "string" } },
                  transition_plan: {
                    type: "object",
                    properties: {
                      phase_1: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          duration: { type: "string" },
                          actions: { type: "array", items: { type: "string" } }
                        }
                      },
                      phase_2: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          duration: { type: "string" },
                          actions: { type: "array", items: { type: "string" } }
                        }
                      },
                      phase_3: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          duration: { type: "string" },
                          actions: { type: "array", items: { type: "string" } }
                        }
                      }
                    }
                  },
                  training_recommendations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        type: { type: "string" },
                        provider: { type: "string" },
                        duration: { type: "string" }
                      }
                    }
                  },
                  experience_opportunities: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        opportunity: { type: "string" },
                        skill_developed: { type: "string" },
                        how_to_access: { type: "string" }
                      }
                    }
                  },
                  mentorship_suggestion: {
                    type: "object",
                    properties: {
                      mentor_profile: { type: "string" },
                      meeting_frequency: { type: "string" },
                      topics_to_discuss: { type: "array", items: { type: "string" } }
                    }
                  }
                }
              }
            },
            immediate_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  impact: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            }
          }
        }
      });

      setCareerAnalysis(result);
    } catch (error) {
      console.error("Error analyzing career paths:", error);
    }
    setIsAnalyzing(false);
  };

  if (!latestAssessment) {
    return (
      <div className="min-h-screen bg-black text-[#f5f5f5] p-6 flex items-center justify-center">
        <div className="glass-panel rounded-3xl max-w-md text-center p-12">
          <Brain className="w-16 h-16 text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-light text-white mb-4 serif">Complete an Assessment First</h2>
          <p className="text-gray-500 mb-8">Take an assessment to unlock AI-powered career path recommendations</p>
          <Button className="bg-white text-black hover:bg-gray-200">
            Start Assessment
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Career Paths</h1>
            <p className="text-gray-500">AI-powered career development and transition planning</p>
          </div>
        </div>

        {/* Main Tabs for Career Tools */}
        <Tabs defaultValue="coach" className="mb-10">
          <TabsList className="glass-panel p-1 rounded-xl mb-6">
            <TabsTrigger value="coach" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Brain className="w-4 h-4 mr-2" /> Career Coach
            </TabsTrigger>
            <TabsTrigger value="journeys" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Route className="w-4 h-4 mr-2" /> Learning Journeys
            </TabsTrigger>
            <TabsTrigger value="feedback" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <TrendingUp className="w-4 h-4 mr-2" /> Performance Feedback
            </TabsTrigger>
            <TabsTrigger value="achievements" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <Award className="w-4 h-4 mr-2" /> Achievements
            </TabsTrigger>
            <TabsTrigger value="coaching" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">
              <MessageCircle className="w-4 h-4 mr-2" /> AI Coach
            </TabsTrigger>
          </TabsList>

          <TabsContent value="coach">
            <CareerPathingCoach 
              user={user}
              assessment={latestAssessment}
              userSkills={userSkills}
              roleRequirements={roleRequirements}
              allUsers={allUsers}
            />
          </TabsContent>

          <TabsContent value="journeys">
            <LearningJourneyGenerator
              user={user}
              userSkills={userSkills}
              assessment={latestAssessment}
              roleRequirements={roleRequirements}
              existingJourneys={learningJourneys}
            />
          </TabsContent>

          <TabsContent value="feedback">
            <PerformanceFeedbackEngine
              user={user}
              assessment={latestAssessment}
              userSkills={userSkills}
              previousAssessments={assessments}
              learningJourneys={learningJourneys}
            />
          </TabsContent>

          <TabsContent value="achievements">
            <div className="space-y-6">
              <GamificationPanel user={user} />
              {learningJourneys?.length > 0 && (
                <AdaptiveLearningEngine 
                  user={user}
                  journey={learningJourneys.find(j => j.status === 'in_progress')}
                  userSkills={userSkills}
                />
              )}
            </div>
          </TabsContent>

          <TabsContent value="coaching">
            <AICoachingSimulator
              user={user}
              assessment={latestAssessment}
              careerPath={careerAnalysis?.career_paths?.[0]?.target_role}
            />
          </TabsContent>
        </Tabs>

        {/* Quick Analysis Section */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-light text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Quick Career Analysis
            </h3>
            <Button
              onClick={analyzeCareerPaths}
              disabled={isAnalyzing}
              variant="outline"
              className="border-white/20 text-gray-300 hover:bg-white/10"
            >
              {isAnalyzing ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><TrendingUp className="w-4 h-4 mr-2" /> Quick Analysis</>
              )}
            </Button>
          </div>
          <p className="text-sm text-gray-500">Get a fast overview of your career options based on your profile</p>
        </div>

        {!careerAnalysis ? (
          /* Initial State */
          <div className="glass-panel rounded-3xl p-12 text-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-500/20 to-amber-600/20 flex items-center justify-center mx-auto mb-6">
              <Briefcase className="w-10 h-10 text-amber-400" />
            </div>
            <h2 className="text-2xl font-light text-white mb-4 serif">Additional Career Insights</h2>
            <p className="text-gray-500 mb-8 max-w-lg mx-auto">
              Use the Career Pathing Coach above for personalized plans, or run a quick analysis 
              to see immediate career path suggestions.
            </p>
            
            <div className="grid md:grid-cols-4 gap-4 max-w-2xl mx-auto mb-8">
              <div className="p-4 bg-white/5 rounded-xl">
                <Target className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Career Paths</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Mentorship</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <BookOpen className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Training Plans</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Award className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Growth Roadmap</p>
              </div>
            </div>
          </div>
        ) : (
          /* Results */
          <div className="space-y-8">
            {/* Career Summary */}
            <div className="glass-panel rounded-2xl p-6 border border-amber-500/20">
              <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-400" />
                Your Career Profile
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Current Trajectory</p>
                  <p className="text-gray-300">{careerAnalysis.career_summary?.current_trajectory}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Growth Potential</p>
                  <p className="text-gray-300">{careerAnalysis.career_summary?.growth_potential}</p>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-6 mt-6">
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Key Strengths</p>
                  <div className="flex flex-wrap gap-2">
                    {careerAnalysis.career_summary?.key_strengths?.map((s, i) => (
                      <span key={i} className="text-xs px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded">{s}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Development Areas</p>
                  <div className="flex flex-wrap gap-2">
                    {careerAnalysis.career_summary?.development_areas?.map((a, i) => (
                      <span key={i} className="text-xs px-2 py-1 bg-amber-500/20 text-amber-400 rounded">{a}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Immediate Actions */}
            {careerAnalysis.immediate_actions?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-emerald-400" />
                  Quick Wins - Start Today
                </h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {careerAnalysis.immediate_actions.map((action, i) => (
                    <div key={i} className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                      <p className="text-white font-medium mb-2">{action.action}</p>
                      <p className="text-xs text-gray-500 mb-2">Impact: {action.impact}</p>
                      <span className="text-[10px] px-2 py-1 bg-white/10 rounded text-gray-400">{action.timeline}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Career Paths */}
            <Tabs defaultValue="path-0" className="space-y-6">
              <TabsList className="glass-panel p-1 rounded-xl">
                {careerAnalysis.career_paths?.map((path, i) => (
                  <TabsTrigger
                    key={i}
                    value={`path-${i}`}
                    className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4"
                  >
                    {path.path_type}: {path.target_role}
                  </TabsTrigger>
                ))}
              </TabsList>

              {careerAnalysis.career_paths?.map((path, i) => (
                <TabsContent key={i} value={`path-${i}`} className="space-y-6">
                  {/* Path Overview */}
                  <div className="glass-panel rounded-2xl p-6">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <span className="text-[10px] px-2 py-1 bg-purple-500/20 text-purple-400 rounded uppercase">{path.path_type}</span>
                        <h3 className="text-2xl font-light text-white mt-2">{path.target_role}</h3>
                        <p className="text-gray-500">{path.department}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-gray-500">Readiness:</span>
                          <span className="text-2xl font-light text-amber-400">{path.readiness_score}%</span>
                        </div>
                        <Progress value={path.readiness_score} className="w-32 h-2" />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4 mb-6">
                      <div className="p-3 bg-white/5 rounded-lg">
                        <p className="text-xs text-gray-500">Timeline</p>
                        <p className="text-white font-medium">{path.estimated_timeline}</p>
                      </div>
                      <div className="p-3 bg-white/5 rounded-lg">
                        <p className="text-xs text-gray-500">Salary Potential</p>
                        <p className="text-emerald-400 font-medium">{path.salary_potential}</p>
                      </div>
                      <div className="p-3 bg-white/5 rounded-lg">
                        <p className="text-xs text-gray-500">Personality Fit</p>
                        <p className="text-white font-medium">{path.personality_fit}</p>
                      </div>
                    </div>

                    <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl mb-6">
                      <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Why This Path?</p>
                      <p className="text-gray-300">{path.why_recommended}</p>
                    </div>

                    {path.skill_gaps?.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Skills to Develop</p>
                        <div className="flex flex-wrap gap-2">
                          {path.skill_gaps.map((gap, j) => (
                            <span key={j} className="text-xs px-3 py-1 bg-red-500/10 border border-red-500/20 text-red-400 rounded">{gap}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Transition Plan */}
                  <div className="glass-panel rounded-2xl p-6">
                    <h4 className="text-lg font-light text-white mb-6 flex items-center gap-2">
                      <Target className="w-5 h-5 text-blue-400" />
                      Transition Plan
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      {['phase_1', 'phase_2', 'phase_3'].map((phaseKey, j) => {
                        const phase = path.transition_plan?.[phaseKey];
                        if (!phase) return null;
                        return (
                          <div key={j} className="p-4 bg-white/5 rounded-xl relative">
                            {j < 2 && (
                              <ChevronRight className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600 hidden md:block" />
                            )}
                            <div className="flex items-center gap-2 mb-3">
                              <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-400 font-bold text-sm">
                                {j + 1}
                              </div>
                              <div>
                                <p className="text-white font-medium text-sm">{phase.name}</p>
                                <p className="text-xs text-gray-500">{phase.duration}</p>
                              </div>
                            </div>
                            <ul className="space-y-2">
                              {phase.actions?.map((action, k) => (
                                <li key={k} className="text-xs text-gray-400 flex items-start gap-2">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400 mt-0.5 flex-shrink-0" />
                                  {action}
                                </li>
                              ))}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Training & Mentorship */}
                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Training */}
                    <div className="glass-panel rounded-2xl p-6">
                      <h4 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                        <BookOpen className="w-5 h-5 text-purple-400" />
                        Recommended Training
                      </h4>
                      <div className="space-y-3">
                        {path.training_recommendations?.map((training, j) => (
                          <div key={j} className="p-3 bg-white/5 rounded-lg">
                            <p className="text-white font-medium text-sm">{training.title}</p>
                            <div className="flex gap-2 mt-2">
                              <span className="text-[10px] px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded">{training.type}</span>
                              <span className="text-[10px] px-2 py-0.5 bg-white/10 text-gray-400 rounded">{training.provider}</span>
                              <span className="text-[10px] px-2 py-0.5 bg-white/10 text-gray-400 rounded">{training.duration}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Mentorship */}
                    <div className="glass-panel rounded-2xl p-6">
                      <h4 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                        <Users className="w-5 h-5 text-emerald-400" />
                        Mentorship Opportunity
                      </h4>
                      {path.mentorship_suggestion && (
                        <div className="space-y-4">
                          <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                            <p className="text-xs text-emerald-400 uppercase tracking-widest mb-2">Ideal Mentor Profile</p>
                            <p className="text-gray-300 text-sm">{path.mentorship_suggestion.mentor_profile}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-2">Meeting Frequency: {path.mentorship_suggestion.meeting_frequency}</p>
                            <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Topics to Discuss:</p>
                            <ul className="space-y-1">
                              {path.mentorship_suggestion.topics_to_discuss?.map((topic, k) => (
                                <li key={k} className="text-xs text-gray-400 flex items-center gap-2">
                                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                                  {topic}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Experience Opportunities */}
                  {path.experience_opportunities?.length > 0 && (
                    <div className="glass-panel rounded-2xl p-6">
                      <h4 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-400" />
                        Experience-Building Opportunities
                      </h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        {path.experience_opportunities.map((exp, j) => (
                          <div key={j} className="p-4 bg-white/5 rounded-xl">
                            <p className="text-white font-medium mb-2">{exp.opportunity}</p>
                            <p className="text-xs text-emerald-400 mb-1">Skill: {exp.skill_developed}</p>
                            <p className="text-xs text-gray-500">How: {exp.how_to_access}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
}