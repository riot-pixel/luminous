import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  Sparkles, Target, CheckCircle2, Circle, Play, BookOpen,
  Trophy, MessageSquare, ArrowRight, Brain, Heart, Zap, Calendar, Star,
  Settings, RefreshCw, Video, FileText, Headphones, Users
} from "lucide-react";
import { format, addDays } from "date-fns";

export default function CoachingJourney() {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [motivationalMessage, setMotivationalMessage] = useState(null);
  const [showPreferencesDialog, setShowPreferencesDialog] = useState(false);
  const [preferences, setPreferences] = useState({
    primary_goal: '',
    secondary_goals: [],
    learning_style: 'visual',
    content_format: 'mixed',
    time_commitment: '30min',
    motivation_style: 'encouraging',
    focus_areas: [],
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments } = useQuery({
    queryKey: ['myAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: developmentPaths } = useQuery({
    queryKey: ['myPaths'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.SkillDevelopmentPath.filter({ user_email: currentUser.email }, '-created_date');
    },
    initialData: [],
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const latestAssessment = assessments[0];

  // Load saved preferences
  useEffect(() => {
    if (user?.coaching_preferences) {
      setPreferences(prev => ({ ...prev, ...user.coaching_preferences }));
    }
  }, [user?.coaching_preferences]);

  const savePreferences = async () => {
    await updateUserMutation.mutateAsync({
      coaching_preferences: preferences,
    });
    setShowPreferencesDialog(false);
  };

  const generateCoachingJourney = async () => {
    if (!latestAssessment) return;
    setIsGenerating(true);

    try {
      const userPrefs = user?.coaching_preferences || preferences;
      
      const journey = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert personal development coach specializing in holistic growth.

Create a personalized 12-week coaching journey based on assessment data AND user preferences:

PERSONALITY TYPE: ${latestAssessment.myers_briggs?.type}
COGNITIVE FUNCTIONS: ${latestAssessment.myers_briggs?.cognitive_functions?.join(', ')}

TOP STRENGTHS:
${latestAssessment.strengths?.top_strengths?.slice(0, 5).map(s => `- ${s.name} (${s.score})`).join('\n')}

LIFE BALANCE:
${Object.entries(latestAssessment.life_wheel || {})
  .filter(([k]) => k !== 'overall_satisfaction')
  .map(([k, v]) => `- ${k}: ${v * 10}%`)
  .join('\n')}
Overall Satisfaction: ${latestAssessment.life_wheel?.overall_satisfaction}%

INTEGRAL THEORY:
- Primary Line: ${latestAssessment.integral_theory?.primary_line}
- Quadrants: ${JSON.stringify(latestAssessment.integral_theory?.quadrants)}

ASPIRATIONS:
${latestAssessment.appreciative_inquiry?.dream?.aspirations?.join(', ')}
Ideal Future: ${latestAssessment.appreciative_inquiry?.dream?.ideal_future}

USER PREFERENCES & GOALS:
- Primary Goal: ${userPrefs.primary_goal || 'General personal growth'}
- Secondary Goals: ${userPrefs.secondary_goals?.join(', ') || 'None specified'}
- Learning Style: ${userPrefs.learning_style} (visual learners prefer diagrams/videos, auditory prefer podcasts/discussions, reading prefer articles/books, kinesthetic prefer hands-on exercises)
- Preferred Content Format: ${userPrefs.content_format} (video, reading, audio, interactive, mixed)
- Daily Time Commitment: ${userPrefs.time_commitment}
- Motivation Style: ${userPrefs.motivation_style} (encouraging, challenging, data-driven, gentle)
- Focus Areas: ${userPrefs.focus_areas?.join(', ') || 'All areas'}

IMPORTANT CUSTOMIZATION REQUIREMENTS:
1. Tailor ALL resources to match learning style (e.g., if visual, suggest videos/infographics; if auditory, suggest podcasts)
2. Ensure each task fits within the daily time commitment
3. Adapt the tone and style of descriptions to match motivation style
4. Focus modules heavily on the primary goal while incorporating secondary goals
5. Task types should match content format preference

Create a structured coaching journey with:
1. 12 weekly modules specifically targeting the user's goals
2. Each module should have 3-4 actionable tasks matching their learning style
3. Include reflection prompts that resonate with their personality type
4. Recommend specific resources in their preferred format
5. Set milestones at weeks 4, 8, and 12 tied to their goals
6. Personalize language based on motivation style`,
        response_json_schema: {
          type: "object",
          properties: {
            journey_name: { type: "string" },
            journey_description: { type: "string" },
            personality_insights: { type: "string" },
            goal_alignment: { type: "string" },
            weekly_modules: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  week: { type: "number" },
                  title: { type: "string" },
                  focus_area: { type: "string" },
                  goal_connection: { type: "string" },
                  description: { type: "string" },
                  tasks: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        description: { type: "string" },
                        duration: { type: "string" },
                        type: { type: "string" },
                        content_format: { type: "string" }
                      }
                    }
                  },
                  reflection_prompt: { type: "string" },
                  resources: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        type: { type: "string" },
                        url_or_description: { type: "string" }
                      }
                    }
                  }
                }
              }
            },
            milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  week: { type: "number" },
                  title: { type: "string" },
                  goal_progress: { type: "string" },
                  success_criteria: { type: "array", items: { type: "string" } },
                  celebration_suggestion: { type: "string" }
                }
              }
            },
            success_metrics: { type: "array", items: { type: "string" } }
          }
        }
      });

      await updateUserMutation.mutateAsync({
        coaching_journey: {
          ...journey,
          started_date: new Date().toISOString(),
          current_week: 1,
          completed_tasks: [],
          preferences_used: userPrefs,
        }
      });

    } catch (error) {
      console.error("Error generating journey:", error);
    }
    setIsGenerating(false);
  };

  const regenerateWithPreferences = async () => {
    await savePreferences();
    await generateCoachingJourney();
  };

  const generateMotivation = async () => {
    if (!user?.coaching_journey) return;

    try {
      const completedCount = user.coaching_journey.completed_tasks?.length || 0;
      const totalTasks = user.coaching_journey.weekly_modules?.reduce((sum, m) => sum + (m.tasks?.length || 0), 0) || 0;
      const progress = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;
      const userPrefs = user?.coaching_preferences || {};

      const message = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a personal coach with a ${userPrefs.motivation_style || 'encouraging'} style.

Generate a personalized motivational message for this person:
- Name: ${user.full_name || 'Friend'}
- Personality Type: ${latestAssessment?.myers_briggs?.type}
- Current Week: ${user.coaching_journey.current_week}
- Progress: ${progress}% complete (${completedCount}/${totalTasks} tasks)
- Top Strength: ${latestAssessment?.strengths?.top_strengths?.[0]?.name}
- Primary Goal: ${userPrefs.primary_goal || 'personal growth'}
- Motivation Style Preference: ${userPrefs.motivation_style || 'encouraging'}

Style Guidelines:
- encouraging: warm, supportive, celebratory
- challenging: push them, set high expectations, competitive
- data-driven: focus on metrics, progress stats, logical reasoning
- gentle: soft, understanding, patient, no pressure

Keep it:
- Personal and warm (use their name if available)
- Reference their specific goal
- Match the motivation style exactly
- Maximum 3 sentences`,
      });

      setMotivationalMessage(message);
    } catch (error) {
      console.error("Error generating motivation:", error);
    }
  };

  useEffect(() => {
    if (user?.coaching_journey) {
      generateMotivation();
    }
  }, [user?.coaching_journey?.completed_tasks?.length]);

  const completeTask = async (weekNum, taskIndex) => {
    if (!user?.coaching_journey) return;

    const taskId = `${weekNum}-${taskIndex}`;
    const completedTasks = user.coaching_journey.completed_tasks || [];
    
    if (!completedTasks.includes(taskId)) {
      await updateUserMutation.mutateAsync({
        coaching_journey: {
          ...user.coaching_journey,
          completed_tasks: [...completedTasks, taskId],
        }
      });
    }
  };

  const advanceWeek = async () => {
    if (!user?.coaching_journey) return;
    const currentWeek = user.coaching_journey.current_week || 1;
    
    if (currentWeek < 12) {
      await updateUserMutation.mutateAsync({
        coaching_journey: {
          ...user.coaching_journey,
          current_week: currentWeek + 1,
        }
      });
    }
  };

  const journey = user?.coaching_journey;
  const currentWeek = journey?.current_week || 1;
  const completedTasks = journey?.completed_tasks || [];
  const totalTasks = journey?.weekly_modules?.reduce((sum, m) => sum + (m.tasks?.length || 0), 0) || 0;
  const overallProgress = totalTasks > 0 ? Math.round((completedTasks.length / totalTasks) * 100) : 0;

  const getFormatIcon = (format) => {
    switch(format) {
      case 'video': return Video;
      case 'reading': return FileText;
      case 'audio': return Headphones;
      case 'interactive': return Users;
      default: return BookOpen;
    }
  };

  const learningStyles = [
    { value: 'visual', label: 'Visual', description: 'Diagrams, videos, infographics' },
    { value: 'auditory', label: 'Auditory', description: 'Podcasts, discussions, audio' },
    { value: 'reading', label: 'Reading/Writing', description: 'Articles, books, notes' },
    { value: 'kinesthetic', label: 'Kinesthetic', description: 'Hands-on exercises, practice' },
  ];

  const contentFormats = [
    { value: 'video', label: 'Video Content', icon: Video },
    { value: 'reading', label: 'Reading Material', icon: FileText },
    { value: 'audio', label: 'Audio/Podcasts', icon: Headphones },
    { value: 'interactive', label: 'Interactive', icon: Users },
    { value: 'mixed', label: 'Mixed Formats', icon: BookOpen },
  ];

  const motivationStyles = [
    { value: 'encouraging', label: 'Encouraging', description: 'Warm, supportive, celebratory' },
    { value: 'challenging', label: 'Challenging', description: 'Push boundaries, competitive' },
    { value: 'data-driven', label: 'Data-Driven', description: 'Focus on metrics and progress' },
    { value: 'gentle', label: 'Gentle', description: 'Patient, understanding, no pressure' },
  ];

  const focusAreaOptions = [
    'Career Growth', 'Leadership', 'Communication', 'Work-Life Balance',
    'Health & Wellness', 'Relationships', 'Creativity', 'Financial', 'Spiritual Growth'
  ];

  if (!latestAssessment) {
    return (
      <div className="min-h-screen bg-black text-[#f5f5f5] p-6 flex items-center justify-center">
        <div className="glass-panel rounded-3xl max-w-md text-center p-12">
          <Brain className="w-16 h-16 text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-light text-white mb-4 serif">Complete an Assessment First</h2>
          <p className="text-gray-500 mb-8">Take an assessment to unlock your personalized coaching journey</p>
          <Button className="bg-white text-black hover:bg-gray-200">
            Start Assessment
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Your Coaching Journey</h1>
            <p className="text-gray-500">Personalized development path based on your goals and preferences</p>
          </div>
          <Button
            onClick={() => setShowPreferencesDialog(true)}
            variant="outline"
            className="border-white/10 text-gray-400 hover:bg-white/5 hover:text-white"
          >
            <Settings className="w-4 h-4 mr-2" />
            Preferences
          </Button>
        </div>

        {!journey ? (
          /* Setup Journey */
          <div className="space-y-8">
            {/* Goals & Preferences Setup */}
            <div className="glass-panel rounded-3xl p-8">
              <div className="text-center mb-8">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-500/20 to-amber-600/20 flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-10 h-10 text-amber-400" />
                </div>
                <h2 className="text-2xl font-light text-white mb-4 serif">Customize Your Journey</h2>
                <p className="text-gray-500 max-w-lg mx-auto">
                  Set your development goals and preferences so AI can create a truly personalized coaching experience.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {/* Primary Goal */}
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Primary Goal *</label>
                    <Input
                      value={preferences.primary_goal}
                      onChange={(e) => setPreferences({ ...preferences, primary_goal: e.target.value })}
                      placeholder="e.g., Become a better leader, Improve work-life balance"
                      className="bg-black border-white/10 text-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Secondary Goals</label>
                    <Textarea
                      value={preferences.secondary_goals?.join('\n') || ''}
                      onChange={(e) => setPreferences({ ...preferences, secondary_goals: e.target.value.split('\n').filter(g => g.trim()) })}
                      placeholder="One goal per line..."
                      className="bg-black border-white/10 text-white h-24"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Focus Areas</label>
                    <div className="flex flex-wrap gap-2">
                      {focusAreaOptions.map(area => (
                        <button
                          key={area}
                          onClick={() => {
                            const current = preferences.focus_areas || [];
                            setPreferences({
                              ...preferences,
                              focus_areas: current.includes(area)
                                ? current.filter(a => a !== area)
                                : [...current, area]
                            });
                          }}
                          className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                            preferences.focus_areas?.includes(area)
                              ? 'bg-amber-500/20 border-amber-500/30 text-amber-400'
                              : 'bg-white/5 border-white/10 text-gray-400 hover:border-white/20'
                          }`}
                        >
                          {area}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Learning Preferences */}
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Learning Style</label>
                    <Select value={preferences.learning_style} onValueChange={(v) => setPreferences({ ...preferences, learning_style: v })}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        {learningStyles.map(style => (
                          <SelectItem key={style.value} value={style.value} className="text-white hover:bg-white/5">
                            <div>
                              <span>{style.label}</span>
                              <span className="text-xs text-gray-500 ml-2">- {style.description}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Preferred Content Format</label>
                    <div className="grid grid-cols-2 gap-2">
                      {contentFormats.map(format => (
                        <button
                          key={format.value}
                          onClick={() => setPreferences({ ...preferences, content_format: format.value })}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            preferences.content_format === format.value
                              ? 'bg-amber-500/20 border-amber-500/30'
                              : 'bg-white/5 border-white/10 hover:border-white/20'
                          }`}
                        >
                          <format.icon className={`w-4 h-4 mb-1 ${preferences.content_format === format.value ? 'text-amber-400' : 'text-gray-500'}`} />
                          <p className={`text-xs ${preferences.content_format === format.value ? 'text-amber-400' : 'text-gray-400'}`}>
                            {format.label}
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Daily Time Commitment</label>
                    <Select value={preferences.time_commitment} onValueChange={(v) => setPreferences({ ...preferences, time_commitment: v })}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        <SelectItem value="15min" className="text-white hover:bg-white/5">15 minutes</SelectItem>
                        <SelectItem value="30min" className="text-white hover:bg-white/5">30 minutes</SelectItem>
                        <SelectItem value="45min" className="text-white hover:bg-white/5">45 minutes</SelectItem>
                        <SelectItem value="60min" className="text-white hover:bg-white/5">1 hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Motivation Style</label>
                    <Select value={preferences.motivation_style} onValueChange={(v) => setPreferences({ ...preferences, motivation_style: v })}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        {motivationStyles.map(style => (
                          <SelectItem key={style.value} value={style.value} className="text-white hover:bg-white/5">
                            <div>
                              <span>{style.label}</span>
                              <span className="text-xs text-gray-500 ml-2">- {style.description}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="text-center mt-8">
                <Button
                  onClick={generateCoachingJourney}
                  disabled={isGenerating || !preferences.primary_goal}
                  className="bg-white text-black px-10 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm"
                >
                  {isGenerating ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Creating Your Journey...</>
                  ) : (
                    <><Play className="w-4 h-4 mr-2" /> Generate My Journey</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        ) : (
          /* Journey Active */
          <div className="space-y-8">
            {/* Progress Overview */}
            <div className="glass-panel rounded-2xl p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex-1">
                  <h2 className="text-xl text-white mb-2">{journey.journey_name}</h2>
                  <p className="text-sm text-gray-500 mb-2">{journey.journey_description}</p>
                  {journey.goal_alignment && (
                    <p className="text-xs text-amber-400 mb-4">🎯 {journey.goal_alignment}</p>
                  )}
                  <div className="flex items-center gap-6">
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">Current Week</p>
                      <p className="text-3xl font-light text-white">{currentWeek}<span className="text-gray-500">/12</span></p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">Tasks Done</p>
                      <p className="text-3xl font-light text-white">{completedTasks.length}<span className="text-gray-500">/{totalTasks}</span></p>
                    </div>
                    <div className="flex-1 max-w-xs">
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Overall Progress</p>
                      <Progress value={overallProgress} className="h-2 bg-white/10" />
                      <p className="text-xs text-gray-500 mt-1">{overallProgress}% complete</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => setShowPreferencesDialog(true)}
                    variant="outline"
                    size="sm"
                    className="border-white/10 text-gray-400 hover:bg-white/5 hover:text-white"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                  {currentWeek < 12 && (
                    <Button
                      onClick={advanceWeek}
                      variant="outline"
                      className="border-white/10 text-gray-400 hover:bg-white/5 hover:text-white"
                    >
                      Week {currentWeek + 1} →
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Motivational Message */}
            {motivationalMessage && (
              <div className="glass-panel rounded-2xl p-6 border border-amber-500/20 bg-gradient-to-r from-amber-500/5 to-transparent">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <Star className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Your AI Coach</p>
                    <p className="text-gray-300">{motivationalMessage}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Weekly Modules */}
            <Tabs value={`week-${currentWeek}`} className="space-y-6">
              <TabsList className="glass-panel p-1 rounded-xl flex-wrap h-auto gap-1">
                {journey.weekly_modules?.map((module) => {
                  const weekTasks = module.tasks?.length || 0;
                  const weekCompleted = module.tasks?.filter((_, i) => completedTasks.includes(`${module.week}-${i}`)).length || 0;
                  const isComplete = weekTasks > 0 && weekCompleted === weekTasks;
                  
                  return (
                    <TabsTrigger
                      key={module.week}
                      value={`week-${module.week}`}
                      className={`data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-3 py-2 ${
                        isComplete ? 'text-emerald-400' : module.week === currentWeek ? 'text-white' : 'text-gray-500'
                      }`}
                    >
                      {isComplete && <CheckCircle2 className="w-3 h-3 mr-1" />}
                      W{module.week}
                    </TabsTrigger>
                  );
                })}
              </TabsList>

              {journey.weekly_modules?.map((module) => (
                <TabsContent key={module.week} value={`week-${module.week}`} className="space-y-6">
                  <div className="glass-panel rounded-2xl p-6">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Week {module.week}</p>
                        <h3 className="text-xl text-white">{module.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{module.focus_area}</p>
                        {module.goal_connection && (
                          <p className="text-xs text-amber-400 mt-2">🎯 {module.goal_connection}</p>
                        )}
                      </div>
                      {module.week === currentWeek && (
                        <span className="text-[10px] px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-full">
                          Current Week
                        </span>
                      )}
                    </div>

                    <p className="text-gray-400 mb-6">{module.description}</p>

                    {/* Tasks */}
                    <div className="space-y-3 mb-6">
                      <p className="text-xs text-gray-500 uppercase tracking-widest">Tasks</p>
                      {module.tasks?.map((task, i) => {
                        const taskId = `${module.week}-${i}`;
                        const isCompleted = completedTasks.includes(taskId);
                        const FormatIcon = getFormatIcon(task.content_format);
                        
                        return (
                          <div
                            key={i}
                            className={`flex items-start gap-4 p-4 rounded-xl border transition-all cursor-pointer ${
                              isCompleted 
                                ? 'bg-emerald-500/10 border-emerald-500/20' 
                                : 'bg-white/5 border-white/5 hover:border-white/10'
                            }`}
                            onClick={() => !isCompleted && completeTask(module.week, i)}
                          >
                            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                              isCompleted ? 'bg-emerald-500 border-emerald-500' : 'border-gray-500'
                            }`}>
                              {isCompleted && <CheckCircle2 className="w-4 h-4 text-black" />}
                            </div>
                            <div className="flex-1">
                              <p className={`font-medium ${isCompleted ? 'text-emerald-400' : 'text-white'}`}>
                                {task.title}
                              </p>
                              <p className="text-sm text-gray-500 mt-1">{task.description}</p>
                              <div className="flex gap-2 mt-2">
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400 flex items-center gap-1">
                                  <FormatIcon className="w-3 h-3" />
                                  {task.content_format || task.type}
                                </span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{task.duration}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Reflection */}
                    {module.reflection_prompt && (
                      <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl mb-6">
                        <p className="text-xs text-amber-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <Heart className="w-4 h-4" /> Reflection Prompt
                        </p>
                        <p className="text-gray-300 italic">"{module.reflection_prompt}"</p>
                      </div>
                    )}

                    {/* Resources */}
                    {module.resources?.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Recommended Resources</p>
                        <div className="grid md:grid-cols-2 gap-2">
                          {module.resources.map((r, i) => {
                            const resource = typeof r === 'string' ? { title: r, type: 'general' } : r;
                            const ResIcon = getFormatIcon(resource.type);
                            return (
                              <div key={i} className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-lg">
                                <ResIcon className="w-4 h-4 text-gray-500" />
                                <div>
                                  <p className="text-xs text-gray-300">{resource.title}</p>
                                  {resource.url_or_description && (
                                    <p className="text-[10px] text-gray-500">{resource.url_or_description}</p>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
              ))}
            </Tabs>

            {/* Milestones */}
            {journey.milestones?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg text-white mb-6 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  Journey Milestones
                </h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {journey.milestones.map((milestone, i) => {
                    const isReached = currentWeek >= milestone.week;
                    
                    return (
                      <div key={i} className={`p-5 rounded-xl border ${
                        isReached ? 'bg-amber-500/10 border-amber-500/20' : 'bg-white/5 border-white/5'
                      }`}>
                        <div className="flex items-center gap-2 mb-3">
                          {isReached ? (
                            <CheckCircle2 className="w-5 h-5 text-amber-400" />
                          ) : (
                            <Circle className="w-5 h-5 text-gray-500" />
                          )}
                          <span className="text-xs text-gray-500">Week {milestone.week}</span>
                        </div>
                        <h4 className={`font-medium mb-2 ${isReached ? 'text-amber-400' : 'text-white'}`}>
                          {milestone.title}
                        </h4>
                        {milestone.goal_progress && (
                          <p className="text-xs text-gray-400 mb-2">🎯 {milestone.goal_progress}</p>
                        )}
                        <ul className="space-y-1 mb-3">
                          {milestone.success_criteria?.slice(0, 2).map((c, j) => (
                            <li key={j} className="text-xs text-gray-500">• {c}</li>
                          ))}
                        </ul>
                        {isReached && milestone.celebration_suggestion && (
                          <p className="text-xs text-amber-400 mt-2">
                            🎉 {milestone.celebration_suggestion}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Preferences Dialog */}
        <Dialog open={showPreferencesDialog} onOpenChange={setShowPreferencesDialog}>
          <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Journey Preferences</DialogTitle>
              <DialogDescription className="text-gray-500">
                Customize your goals and learning preferences
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6 py-4">
              <div>
                <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Primary Goal</label>
                <Input
                  value={preferences.primary_goal}
                  onChange={(e) => setPreferences({ ...preferences, primary_goal: e.target.value })}
                  placeholder="What do you want to achieve?"
                  className="bg-black border-white/10 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Learning Style</label>
                  <Select value={preferences.learning_style} onValueChange={(v) => setPreferences({ ...preferences, learning_style: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {learningStyles.map(style => (
                        <SelectItem key={style.value} value={style.value} className="text-white hover:bg-white/5">{style.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Motivation Style</label>
                  <Select value={preferences.motivation_style} onValueChange={(v) => setPreferences({ ...preferences, motivation_style: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {motivationStyles.map(style => (
                        <SelectItem key={style.value} value={style.value} className="text-white hover:bg-white/5">{style.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Content Format</label>
                  <Select value={preferences.content_format} onValueChange={(v) => setPreferences({ ...preferences, content_format: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      {contentFormats.map(format => (
                        <SelectItem key={format.value} value={format.value} className="text-white hover:bg-white/5">{format.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Time Commitment</label>
                  <Select value={preferences.time_commitment} onValueChange={(v) => setPreferences({ ...preferences, time_commitment: v })}>
                    <SelectTrigger className="bg-black border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="15min" className="text-white hover:bg-white/5">15 minutes/day</SelectItem>
                      <SelectItem value="30min" className="text-white hover:bg-white/5">30 minutes/day</SelectItem>
                      <SelectItem value="45min" className="text-white hover:bg-white/5">45 minutes/day</SelectItem>
                      <SelectItem value="60min" className="text-white hover:bg-white/5">1 hour/day</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setShowPreferencesDialog(false)} className="flex-1 border-white/10 text-gray-400">
                Cancel
              </Button>
              {journey ? (
                <Button onClick={regenerateWithPreferences} disabled={isGenerating} className="flex-1 bg-white text-black hover:bg-gray-200">
                  {isGenerating ? <Sparkles className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                  Regenerate Journey
                </Button>
              ) : (
                <Button onClick={savePreferences} className="flex-1 bg-white text-black hover:bg-gray-200">
                  Save Preferences
                </Button>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}