import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, DollarSign, Users, Target, Sparkles, Play, 
  Save, CheckCircle2, AlertTriangle, ArrowLeft, Plus, Trash2, BarChart3
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

export default function ResourceAllocationSimulator() {
  const queryClient = useQueryClient();
  const [strategy, setStrategy] = useState({
    strategy_name: '',
    description: '',
    allocations: [],
  });
  const [simulationResults, setSimulationResults] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [newAllocation, setNewAllocation] = useState({
    department: '',
    resource_type: 'headcount',
    allocated_amount: 0,
    current_amount: 0,
    justification: '',
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: predictions } = useQuery({
    queryKey: ['activePredictions'],
    queryFn: async () => {
      const all = await base44.entities.PredictiveInsight.list('-created_date');
      return all.filter(p => p.status === 'active');
    },
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: savedStrategies } = useQuery({
    queryKey: ['allocationStrategies'],
    queryFn: () => base44.entities.ResourceAllocationStrategy.list('-created_date'),
    initialData: [],
  });

  const createStrategyMutation = useMutation({
    mutationFn: (data) => base44.entities.ResourceAllocationStrategy.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allocationStrategies'] });
    },
  });

  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
  
  const departmentStats = departments.map(dept => {
    const deptEmployees = employees.filter(e => e.department === dept);
    const deptPredictions = predictions.filter(p => p.department === dept);
    return {
      department: dept,
      currentHeadcount: deptEmployees.length,
      activePredictions: deptPredictions.length,
      criticalRisks: deptPredictions.filter(p => p.severity === 'critical' || p.severity === 'high').length,
    };
  });

  const addAllocation = () => {
    if (!newAllocation.department || newAllocation.allocated_amount === 0) {
      alert("Please fill in all allocation details");
      return;
    }
    
    setStrategy({
      ...strategy,
      allocations: [...strategy.allocations, { ...newAllocation }],
    });
    
    setNewAllocation({
      department: '',
      resource_type: 'headcount',
      allocated_amount: 0,
      current_amount: 0,
      justification: '',
    });
  };

  const removeAllocation = (index) => {
    setStrategy({
      ...strategy,
      allocations: strategy.allocations.filter((_, i) => i !== index),
    });
  };

  const runSimulation = async () => {
    if (strategy.allocations.length === 0) {
      alert("Please add at least one resource allocation");
      return;
    }

    setIsSimulating(true);
    try {
      // Prepare data for AI simulation
      const simulationPrompt = `You are an expert organizational resource allocation analyst with expertise in predictive modeling.

Simulate the impact of this resource allocation strategy:

STRATEGY:
${JSON.stringify(strategy, null, 2)}

CURRENT ORGANIZATIONAL STATE:
- Departments: ${departments.length}
- Total Employees: ${employees.length}
- Active Predictions: ${predictions.length}
- Critical Risks: ${predictions.filter(p => p.severity === 'critical' || p.severity === 'high').length}

DEPARTMENT-SPECIFIC DATA:
${JSON.stringify(departmentStats, null, 2)}

ACTIVE PREDICTIONS TO ADDRESS:
${JSON.stringify(predictions.map(p => ({
  type: p.insight_type,
  severity: p.severity,
  department: p.department,
  prediction: p.prediction,
  confidence: p.confidence_score
})), null, 2)}

Calculate the predicted impact of these allocations over 6-12 months:

1. Satisfaction Change: Predicted change in average life satisfaction (%)
2. Performance Improvement: Expected performance increase (%)
3. Turnover Reduction: Predicted decrease in attrition risk (%)
4. Skill Gap Closure: Expected skill gap reduction (%)
5. ROI Estimate: Return on investment multiplier
6. Implementation Cost: Estimated cost (relative scale 1-10)
7. Time to Impact: When results will be visible
8. Risk Mitigation Score: How well this addresses active predictions (0-100)
9. Confidence Level: Your confidence in these predictions (0-100)

Also provide:
- Key success factors (3-5)
- Potential risks (3-5)
- Timeline breakdown

Be realistic and data-driven. Consider:
- Current team sizes and workloads
- Severity of existing predictions
- Resource allocation efficiency
- Implementation complexity
- Market conditions`;

      const simulation = await base44.integrations.Core.InvokeLLM({
        prompt: simulationPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            predicted_satisfaction_change: { type: "number" },
            predicted_performance_improvement: { type: "number" },
            predicted_turnover_reduction: { type: "number" },
            predicted_skill_gap_closure: { type: "number" },
            roi_estimate: { type: "number" },
            implementation_cost: { type: "number" },
            time_to_impact: { type: "string" },
            risk_mitigation_score: { type: "number" },
            confidence_level: { type: "number" },
            key_success_factors: { type: "array", items: { type: "string" } },
            potential_risks: { type: "array", items: { type: "string" } },
            timeline_breakdown: {
              type: "object",
              properties: {
                month_1_3: { type: "string" },
                month_4_6: { type: "string" },
                month_7_12: { type: "string" }
              }
            }
          }
        }
      });

      setSimulationResults(simulation);
    } catch (error) {
      console.error("Error running simulation:", error);
      alert("Error running simulation. Please try again.");
    }
    setIsSimulating(false);
  };

  const saveStrategy = async () => {
    if (!strategy.strategy_name) {
      alert("Please provide a strategy name");
      return;
    }

    try {
      await createStrategyMutation.mutateAsync({
        ...strategy,
        created_by: user.email,
        simulation_results: simulationResults,
        status: simulationResults ? 'simulated' : 'draft',
        target_risks: predictions.map(p => p.id),
      });

      alert("Strategy saved successfully!");
      
      // Reset form
      setStrategy({
        strategy_name: '',
        description: '',
        allocations: [],
      });
      setSimulationResults(null);
    } catch (error) {
      console.error("Error saving strategy:", error);
      alert("Error saving strategy. Please try again.");
    }
  };

  const radarData = simulationResults ? [
    { metric: 'Satisfaction', value: Math.abs(simulationResults.predicted_satisfaction_change) },
    { metric: 'Performance', value: simulationResults.predicted_performance_improvement },
    { metric: 'Retention', value: simulationResults.predicted_turnover_reduction },
    { metric: 'Skills', value: simulationResults.predicted_skill_gap_closure },
    { metric: 'Risk Mitigation', value: simulationResults.risk_mitigation_score },
  ] : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to={createPageUrl("ExecutiveAnalytics")} className="text-sm text-indigo-600 hover:text-indigo-700 mb-2 inline-flex items-center gap-1">
              <ArrowLeft className="w-4 h-4" />
              Back to Analytics
            </Link>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Resource Allocation Simulator</h1>
            <p className="text-gray-600">Model the impact of different allocation strategies</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Panel - Strategy Builder */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Strategy Details</CardTitle>
                <CardDescription>Define your resource allocation strategy</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Strategy Name *</label>
                  <Input
                    value={strategy.strategy_name}
                    onChange={(e) => setStrategy({ ...strategy, strategy_name: e.target.value })}
                    placeholder="e.g., Q2 Engineering Scale-up"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea
                    value={strategy.description}
                    onChange={(e) => setStrategy({ ...strategy, description: e.target.value })}
                    placeholder="Describe the goals and context of this strategy..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Resource Allocations</CardTitle>
                <CardDescription>Add resources to departments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add Allocation Form */}
                <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                  <div className="grid md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium mb-1">Department</label>
                      <Select value={newAllocation.department} onValueChange={(v) => setNewAllocation({ ...newAllocation, department: v })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map(dept => (
                            <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium mb-1">Resource Type</label>
                      <Select value={newAllocation.resource_type} onValueChange={(v) => setNewAllocation({ ...newAllocation, resource_type: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="headcount">Headcount</SelectItem>
                          <SelectItem value="budget">Budget (USD)</SelectItem>
                          <SelectItem value="training_hours">Training Hours</SelectItem>
                          <SelectItem value="coaching_sessions">Coaching Sessions</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium mb-1">Current Amount</label>
                      <Input
                        type="number"
                        value={newAllocation.current_amount}
                        onChange={(e) => setNewAllocation({ ...newAllocation, current_amount: parseFloat(e.target.value) })}
                        placeholder="0"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium mb-1">Allocated Amount</label>
                      <Input
                        type="number"
                        value={newAllocation.allocated_amount}
                        onChange={(e) => setNewAllocation({ ...newAllocation, allocated_amount: parseFloat(e.target.value) })}
                        placeholder="0"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium mb-1">Justification</label>
                    <Textarea
                      value={newAllocation.justification}
                      onChange={(e) => setNewAllocation({ ...newAllocation, justification: e.target.value })}
                      placeholder="Why this allocation?"
                      rows={2}
                    />
                  </div>

                  <Button onClick={addAllocation} size="sm" className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Allocation
                  </Button>
                </div>

                {/* Allocations List */}
                {strategy.allocations.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold">Current Allocations ({strategy.allocations.length})</h4>
                    {strategy.allocations.map((alloc, idx) => (
                      <div key={idx} className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge>{alloc.department}</Badge>
                              <Badge variant="outline">{alloc.resource_type}</Badge>
                            </div>
                            <p className="text-sm font-semibold text-gray-900">
                              {alloc.current_amount} → {alloc.allocated_amount} 
                              <span className="text-green-600 ml-2">
                                (+{alloc.allocated_amount - alloc.current_amount})
                              </span>
                            </p>
                            <p className="text-xs text-gray-600 mt-1">{alloc.justification}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeAllocation(idx)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={runSimulation}
                    disabled={isSimulating || strategy.allocations.length === 0}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600"
                  >
                    {isSimulating ? (
                      <>
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        Simulating...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Run Simulation
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={saveStrategy}
                    disabled={!strategy.strategy_name}
                    variant="outline"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Simulation Results */}
            {simulationResults && (
              <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                    Simulation Results
                  </CardTitle>
                  <CardDescription>Predicted impact of this strategy</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="overview">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="overview">Overview</TabsTrigger>
                      <TabsTrigger value="details">Details</TabsTrigger>
                      <TabsTrigger value="risks">Risks</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-4 bg-white rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-gray-600">Satisfaction Impact</span>
                            <TrendingUp className="w-5 h-5 text-green-600" />
                          </div>
                          <p className="text-3xl font-bold text-green-600">
                            {simulationResults.predicted_satisfaction_change > 0 ? '+' : ''}
                            {simulationResults.predicted_satisfaction_change}%
                          </p>
                        </div>

                        <div className="p-4 bg-white rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-gray-600">Performance Gain</span>
                            <Target className="w-5 h-5 text-blue-600" />
                          </div>
                          <p className="text-3xl font-bold text-blue-600">
                            +{simulationResults.predicted_performance_improvement}%
                          </p>
                        </div>

                        <div className="p-4 bg-white rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-gray-600">Turnover Reduction</span>
                            <Users className="w-5 h-5 text-purple-600" />
                          </div>
                          <p className="text-3xl font-bold text-purple-600">
                            -{simulationResults.predicted_turnover_reduction}%
                          </p>
                        </div>

                        <div className="p-4 bg-white rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-gray-600">ROI Estimate</span>
                            <DollarSign className="w-5 h-5 text-amber-600" />
                          </div>
                          <p className="text-3xl font-bold text-amber-600">
                            {simulationResults.roi_estimate}x
                          </p>
                        </div>
                      </div>

                      <div className="p-4 bg-white rounded-lg">
                        <h4 className="font-semibold mb-2">Impact Radar</h4>
                        <ResponsiveContainer width="100%" height={250}>
                          <RadarChart data={radarData}>
                            <PolarGrid />
                            <PolarAngleAxis dataKey="metric" />
                            <PolarRadiusAxis domain={[0, 100]} />
                            <Radar name="Impact" dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
                          </RadarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="grid md:grid-cols-3 gap-3">
                        <div className="p-3 bg-white rounded-lg text-center">
                          <p className="text-xs text-gray-600 mb-1">Time to Impact</p>
                          <p className="text-lg font-bold text-gray-900">{simulationResults.time_to_impact}</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg text-center">
                          <p className="text-xs text-gray-600 mb-1">Implementation Cost</p>
                          <p className="text-lg font-bold text-gray-900">{simulationResults.implementation_cost}/10</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg text-center">
                          <p className="text-xs text-gray-600 mb-1">Confidence Level</p>
                          <p className="text-lg font-bold text-gray-900">{simulationResults.confidence_level}%</p>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="details" className="space-y-4">
                      <div className="p-4 bg-white rounded-lg">
                        <h4 className="font-semibold mb-3">Key Success Factors</h4>
                        <ul className="space-y-2">
                          {simulationResults.key_success_factors?.map((factor, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-700">{factor}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-4 bg-white rounded-lg">
                        <h4 className="font-semibold mb-3">Timeline Breakdown</h4>
                        <div className="space-y-3">
                          <div>
                            <p className="text-sm font-medium text-gray-700">Months 1-3:</p>
                            <p className="text-sm text-gray-600">{simulationResults.timeline_breakdown?.month_1_3}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700">Months 4-6:</p>
                            <p className="text-sm text-gray-600">{simulationResults.timeline_breakdown?.month_4_6}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700">Months 7-12:</p>
                            <p className="text-sm text-gray-600">{simulationResults.timeline_breakdown?.month_7_12}</p>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="risks" className="space-y-4">
                      <div className="p-4 bg-white rounded-lg">
                        <h4 className="font-semibold mb-3">Potential Risks</h4>
                        <ul className="space-y-2">
                          {simulationResults.potential_risks?.map((risk, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <AlertTriangle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-700">{risk}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-4 bg-white rounded-lg">
                        <h4 className="font-semibold mb-2">Risk Mitigation Score</h4>
                        <div className="flex items-center gap-3">
                          <div className="flex-1 bg-gray-200 rounded-full h-4">
                            <div
                              className="bg-green-600 h-4 rounded-full"
                              style={{ width: `${simulationResults.risk_mitigation_score}%` }}
                            />
                          </div>
                          <span className="text-lg font-bold">{simulationResults.risk_mitigation_score}%</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-2">
                          How effectively this strategy addresses active organizational predictions
                        </p>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Panel - Context */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Active Predictions</CardTitle>
                <CardDescription>Risks to address with allocation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {predictions.slice(0, 5).map((pred) => (
                    <div key={pred.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className={
                          pred.severity === 'critical' ? 'bg-red-600' :
                          pred.severity === 'high' ? 'bg-orange-600' :
                          pred.severity === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'
                        }>
                          {pred.severity}
                        </Badge>
                        {pred.department && <Badge variant="outline">{pred.department}</Badge>}
                      </div>
                      <p className="text-sm font-medium text-gray-900">{pred.prediction}</p>
                    </div>
                  ))}
                  {predictions.length === 0 && (
                    <p className="text-sm text-gray-500 text-center py-4">No active predictions</p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Department Overview</CardTitle>
                <CardDescription>Current state by department</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {departmentStats.map((dept) => (
                    <div key={dept.department} className="p-3 bg-gray-50 rounded-lg">
                      <p className="font-semibold text-sm text-gray-900">{dept.department}</p>
                      <div className="grid grid-cols-3 gap-2 mt-2 text-xs">
                        <div>
                          <p className="text-gray-500">Headcount</p>
                          <p className="font-bold">{dept.currentHeadcount}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Predictions</p>
                          <p className="font-bold">{dept.activePredictions}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Critical</p>
                          <p className="font-bold text-red-600">{dept.criticalRisks}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Saved Strategies</CardTitle>
                <CardDescription>Previous simulations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {savedStrategies.slice(0, 5).map((strat) => (
                    <div key={strat.id} className="p-2 bg-gray-50 rounded-lg">
                      <p className="font-medium text-sm">{strat.strategy_name}</p>
                      <p className="text-xs text-gray-500">{strat.allocations?.length || 0} allocations</p>
                    </div>
                  ))}
                  {savedStrategies.length === 0 && (
                    <p className="text-sm text-gray-500 text-center py-4">No saved strategies</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}