import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users, TrendingUp, Target, Brain, Sparkles, AlertCircle, 
  CheckCircle2, Award, Activity, Zap, Shield
} from "lucide-react";
import {
  BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";
import ReactMarkdown from "react-markdown";

export default function TeamPerformanceDashboard() {
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [isGeneratingRecommendations, setIsGeneratingRecommendations] = useState(false);
  const [teamRecommendations, setTeamRecommendations] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: teams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const logAccessMutation = useMutation({
    mutationFn: (data) => base44.entities.DataAccessLog.create(data),
  });

  useEffect(() => {
    if (user && selectedTeam) {
      logAccessMutation.mutate({
        accessor_email: user.email,
        accessor_role: user.user_role || 'employee',
        data_type: 'team_insights',
        access_level: 'aggregated',
        purpose: 'Team Performance Dashboard view',
        target_department: selectedTeam.department,
      });
    }
  }, [user, selectedTeam]);

  const accessibleTeams = teams.filter(team => {
    if (user?.role === 'admin') return true;
    if (user?.user_role === 'org_admin') return true;
    if (user?.user_role === 'c_suite' || user?.user_role === 'executive') return true;
    if (team.leader_email === user?.email) return true;
    return false;
  });

  useEffect(() => {
    if (accessibleTeams.length > 0 && !selectedTeam) {
      setSelectedTeam(accessibleTeams[0]);
    }
  }, [accessibleTeams, selectedTeam]);

  if (!selectedTeam) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="glass-panel rounded-3xl max-w-md text-center p-12">
          <Users className="w-16 h-16 text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-light text-white mb-4 serif">No Teams Available</h2>
          <p className="text-gray-500">Create a team to view performance metrics</p>
        </div>
      </div>
    );
  }

  const calculateTeamMetrics = (team) => {
    const teamMembers = employees.filter(emp => team.member_emails?.includes(emp.email));
    const privacyCompliantMembers = teamMembers.filter(member => 
      !member.privacy_settings || member.privacy_settings.allow_manager_view_assessment !== false
    );
    const teamAssessments = assessments.filter(a => team.member_emails?.includes(a.user_email));
    const completionRate = teamMembers.length > 0 
      ? Math.round((teamAssessments.length / teamMembers.length) * 100) : 0;
    const teamSkills = userSkills.filter(us => team.member_emails?.includes(us.user_email));
    const requiredSkills = roleRequirements.filter(rr => 
      teamMembers.some(m => m.job_title === rr.role_title)
    );
    const uniqueSkillsHeld = new Set(teamSkills.map(s => s.skill_id)).size;
    const uniqueSkillsRequired = new Set(requiredSkills.map(r => r.skill_id)).size;
    const skillCoverageRate = uniqueSkillsRequired > 0 
      ? Math.round((uniqueSkillsHeld / uniqueSkillsRequired) * 100) : 100;

    const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
    let criticalGaps = 0;
    requiredSkills.forEach(req => {
      if (req.priority === 'must_have') {
        const hasCompetentMember = teamSkills.some(us => 
          us.skill_id === req.skill_id && 
          proficiencyOrder.indexOf(us.current_proficiency) >= proficiencyOrder.indexOf(req.required_proficiency)
        );
        if (!hasCompetentMember) criticalGaps++;
      }
    });

    const recentAssessments = teamAssessments.filter(a => {
      const date = new Date(a.completed_date);
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      return date > sixMonthsAgo;
    });
    const engagementScore = teamMembers.length > 0
      ? Math.round((recentAssessments.length / teamMembers.length) * 100) : 0;

    const satisfactionScores = teamAssessments
      .filter(a => a.life_wheel?.overall_satisfaction)
      .map(a => a.life_wheel.overall_satisfaction);
    const avgSatisfaction = satisfactionScores.length > 0
      ? Math.round(satisfactionScores.reduce((a, b) => a + b, 0) / satisfactionScores.length) : 0;

    const personalityTypes = {};
    teamAssessments.forEach(a => {
      if (a.myers_briggs?.type) {
        personalityTypes[a.myers_briggs.type] = (personalityTypes[a.myers_briggs.type] || 0) + 1;
      }
    });

    const strengthCounts = {};
    teamAssessments.forEach(a => {
      if (a.strengths?.top_strengths) {
        a.strengths.top_strengths.slice(0, 3).forEach(s => {
          strengthCounts[s.name] = (strengthCounts[s.name] || 0) + 1;
        });
      }
    });
    const topStrengths = Object.entries(strengthCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, count]) => ({ name, count }));

    return {
      totalMembers: teamMembers.length,
      privacyCompliantCount: privacyCompliantMembers.length,
      assessmentCompletion: completionRate,
      skillCoverage: skillCoverageRate,
      criticalSkillGaps: criticalGaps,
      engagementScore,
      avgSatisfaction,
      personalityTypes,
      topStrengths,
      recentActivity: recentAssessments.length,
    };
  };

  const metrics = calculateTeamMetrics(selectedTeam);

  const generateRecommendations = async () => {
    setIsGeneratingRecommendations(true);
    try {
      const recommendations = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert team performance coach.

TEAM: ${selectedTeam.name} | ${selectedTeam.department}
SIZE: ${metrics.totalMembers} members

METRICS:
- Assessment Completion: ${metrics.assessmentCompletion}%
- Skill Coverage: ${metrics.skillCoverage}%
- Critical Skill Gaps: ${metrics.criticalSkillGaps}
- Engagement Score: ${metrics.engagementScore}%
- Average Satisfaction: ${metrics.avgSatisfaction}%

COMPOSITION:
- Personality Types: ${JSON.stringify(metrics.personalityTypes)}
- Top Strengths: ${metrics.topStrengths.map(s => s.name).join(', ')}

Provide 6-8 specific, actionable recommendations for:
1. Skill Development (2-3 recommendations)
2. Team Cohesion (2 recommendations)
3. Engagement & Well-being (1-2 recommendations)
4. Performance Optimization (1-2 recommendations)

For each: title, issue, action_steps, impact (High/Medium/Low), timeline.`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_assessment: { type: "string" },
            team_strengths: { type: "array", items: { type: "string" } },
            areas_for_improvement: { type: "array", items: { type: "string" } },
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  title: { type: "string" },
                  issue: { type: "string" },
                  action_steps: { type: "array", items: { type: "string" } },
                  impact: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            quick_wins: { type: "array", items: { type: "string" } }
          }
        }
      });
      setTeamRecommendations(recommendations);
    } catch (error) {
      console.error("Error generating recommendations:", error);
    }
    setIsGeneratingRecommendations(false);
  };

  const personalityData = Object.entries(metrics.personalityTypes).map(([name, value]) => ({ name, value }));
  const COLORS = ['#ffffff', '#a1a1aa', '#525252', '#fbbf24', '#34d399', '#f87171', '#a78bfa', '#38bdf8'];

  const radarData = [
    { metric: 'Assessments', value: metrics.assessmentCompletion },
    { metric: 'Skills', value: metrics.skillCoverage },
    { metric: 'Engagement', value: metrics.engagementScore },
    { metric: 'Satisfaction', value: metrics.avgSatisfaction },
    { metric: 'Activity', value: Math.min(metrics.recentActivity * 10, 100) },
  ];

  const chartColors = {
    grid: 'rgba(255,255,255,0.05)',
    text: '#525252',
  };

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Team Performance</h1>
            <p className="text-gray-500 flex items-center gap-2 text-sm">
              Comprehensive metrics and AI recommendations
              <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-[10px] uppercase tracking-widest">
                <Shield className="w-3 h-3" /> Privacy Protected
              </span>
            </p>
          </div>
          <div className="flex gap-3">
            <Select value={selectedTeam?.id} onValueChange={(teamId) => {
              const team = accessibleTeams.find(t => t.id === teamId);
              setSelectedTeam(team);
              setTeamRecommendations(null);
            }}>
              <SelectTrigger className="w-64 bg-black border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-black border-white/10">
                {accessibleTeams.map(team => (
                  <SelectItem key={team.id} value={team.id} className="text-white hover:bg-white/5">
                    {team.name} ({team.member_emails?.length || 0})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={generateRecommendations}
              disabled={isGeneratingRecommendations}
              className="bg-white text-black px-6 text-xs font-bold tracking-[0.15em] uppercase hover:bg-gray-200 rounded-sm"
            >
              {isGeneratingRecommendations ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> AI Insights</>
              )}
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          {[
            { label: 'Assessment Completion', value: `${metrics.assessmentCompletion}%`, icon: CheckCircle2, color: metrics.assessmentCompletion >= 80 ? 'emerald' : metrics.assessmentCompletion >= 60 ? 'amber' : 'red' },
            { label: 'Skill Coverage', value: `${metrics.skillCoverage}%`, icon: Target, color: metrics.skillCoverage >= 80 ? 'emerald' : metrics.skillCoverage >= 60 ? 'amber' : 'red' },
            { label: 'Critical Gaps', value: metrics.criticalSkillGaps, icon: AlertCircle, color: metrics.criticalSkillGaps === 0 ? 'emerald' : metrics.criticalSkillGaps <= 2 ? 'amber' : 'red' },
            { label: 'Engagement', value: `${metrics.engagementScore}%`, icon: Activity, color: metrics.engagementScore >= 80 ? 'emerald' : metrics.engagementScore >= 60 ? 'amber' : 'red' },
            { label: 'Satisfaction', value: `${metrics.avgSatisfaction}%`, icon: Award, color: metrics.avgSatisfaction >= 80 ? 'emerald' : metrics.avgSatisfaction >= 60 ? 'amber' : 'red' },
          ].map((metric, i) => (
            <div key={i} className="glass-panel rounded-2xl p-6 relative overflow-hidden">
              <div className={`absolute top-0 left-0 w-full h-0.5 ${
                metric.color === 'emerald' ? 'bg-emerald-500' :
                metric.color === 'amber' ? 'bg-amber-500' : 'bg-red-500'
              }`}></div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-3">{metric.label}</p>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-light text-white">{metric.value}</span>
                <metric.icon className={`w-6 h-6 ${
                  metric.color === 'emerald' ? 'text-emerald-400' :
                  metric.color === 'amber' ? 'text-amber-400' : 'text-red-400'
                }`} />
              </div>
            </div>
          ))}
        </div>

        {/* AI Recommendations */}
        {teamRecommendations && (
          <div className="glass-panel rounded-3xl p-8 mb-10 border border-amber-500/20">
            <div className="flex items-center gap-3 mb-8">
              <Sparkles className="w-6 h-6 text-amber-400" />
              <h2 className="text-xl font-light text-white">AI Performance Recommendations</h2>
            </div>

            <div className="glass-panel rounded-2xl p-6 mb-6 border border-white/5">
              <p className="text-gray-400 leading-relaxed">{teamRecommendations.overall_assessment}</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                <h3 className="text-sm font-medium text-emerald-400 mb-4 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Team Strengths
                </h3>
                <ul className="space-y-2">
                  {teamRecommendations.team_strengths?.map((s, i) => (
                    <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
                      <span className="text-emerald-400 mt-1">✓</span> {s}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="p-6 bg-amber-500/5 border border-amber-500/10 rounded-2xl">
                <h3 className="text-sm font-medium text-amber-400 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" /> Areas for Improvement
                </h3>
                <ul className="space-y-2">
                  {teamRecommendations.areas_for_improvement?.map((a, i) => (
                    <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
                      <span className="text-amber-400 mt-1">→</span> {a}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {teamRecommendations.quick_wins?.length > 0 && (
              <div className="p-6 bg-white/5 border border-white/10 rounded-2xl mb-8">
                <h3 className="text-sm font-medium text-white mb-4 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" /> Quick Wins
                </h3>
                <ul className="space-y-2">
                  {teamRecommendations.quick_wins.map((w, i) => (
                    <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
                      <span className="text-amber-400">⚡</span> {w}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <h3 className="text-sm font-medium text-white mb-4">Detailed Action Plan</h3>
            <div className="space-y-4">
              {teamRecommendations.recommendations?.map((rec, i) => (
                <div key={i} className="glass-panel rounded-2xl p-6 border border-white/5">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <span className="text-[10px] tracking-widest uppercase text-gray-500 mb-2 block">{rec.category}</span>
                      <h4 className="text-white font-medium">{rec.title}</h4>
                    </div>
                    <div className="text-right">
                      <span className={`text-[10px] tracking-widest uppercase px-2 py-1 rounded ${
                        rec.impact === 'High' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-gray-400'
                      }`}>{rec.impact} Impact</span>
                      <p className="text-xs text-gray-600 mt-1">{rec.timeline}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mb-4">{rec.issue}</p>
                  <ol className="space-y-2">
                    {rec.action_steps?.map((step, j) => (
                      <li key={j} className="text-sm text-gray-400 flex items-start gap-2">
                        <span className="text-white font-medium">{j + 1}.</span> {step}
                      </li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Analytics Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="glass-panel p-1 rounded-xl">
            <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Overview</TabsTrigger>
            <TabsTrigger value="skills" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Skills</TabsTrigger>
            <TabsTrigger value="engagement" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Engagement</TabsTrigger>
            <TabsTrigger value="composition" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Composition</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="glass-panel rounded-2xl p-8">
                <h3 className="text-lg font-light text-white mb-6">Performance Radar</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke={chartColors.grid} />
                    <PolarAngleAxis dataKey="metric" tick={{ fill: '#a1a1aa', fontSize: 11 }} />
                    <PolarRadiusAxis domain={[0, 100]} tick={{ fill: chartColors.text, fontSize: 10 }} />
                    <Radar name="Performance" dataKey="value" stroke="#fff" fill="rgba(255,255,255,0.1)" strokeWidth={2} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div className="glass-panel rounded-2xl p-8">
                <h3 className="text-lg font-light text-white mb-6">Team Information</h3>
                <div className="space-y-4">
                  <div><p className="text-xs text-gray-500 uppercase tracking-widest">Team Name</p><p className="text-white">{selectedTeam.name}</p></div>
                  <div><p className="text-xs text-gray-500 uppercase tracking-widest">Department</p><p className="text-white">{selectedTeam.department}</p></div>
                  <div><p className="text-xs text-gray-500 uppercase tracking-widest">Leader</p><p className="text-white">{selectedTeam.leader_email || 'Not assigned'}</p></div>
                  <div><p className="text-xs text-gray-500 uppercase tracking-widest">Status</p><span className={`text-xs px-2 py-1 rounded ${selectedTeam.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-gray-400'}`}>{selectedTeam.status}</span></div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <div className="glass-panel rounded-2xl p-8">
              <h3 className="text-lg font-light text-white mb-6">Top Team Strengths</h3>
              {metrics.topStrengths.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={metrics.topStrengths}>
                    <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fill: chartColors.text, fontSize: 10 }} />
                    <YAxis tick={{ fill: chartColors.text, fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: 'rgba(20,20,20,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                    <Bar dataKey="count" fill="#fff" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-12 text-gray-500">No strength data available</div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="glass-panel rounded-2xl p-6">
                <Activity className="w-8 h-8 text-emerald-400 mb-4" />
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Recent Activity</p>
                <p className="text-3xl font-light text-white">{metrics.recentActivity}</p>
                <p className="text-xs text-gray-500 mt-1">Assessments in 6 months</p>
              </div>
              <div className="glass-panel rounded-2xl p-6">
                <TrendingUp className="w-8 h-8 text-amber-400 mb-4" />
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Engagement Rate</p>
                <p className="text-3xl font-light text-white">{metrics.engagementScore}%</p>
                <p className="text-xs text-gray-500 mt-1">Active participation</p>
              </div>
              <div className="glass-panel rounded-2xl p-6">
                <Award className="w-8 h-8 text-white mb-4" />
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Satisfaction</p>
                <p className="text-3xl font-light text-white">{metrics.avgSatisfaction}%</p>
                <p className="text-xs text-gray-500 mt-1">Team wellbeing</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="composition" className="space-y-6">
            <div className="glass-panel rounded-2xl p-8">
              <h3 className="text-lg font-light text-white mb-6">Personality Distribution</h3>
              {personalityData.length > 0 ? (
                <div className="grid md:grid-cols-2 gap-6">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie data={personalityData} cx="50%" cy="50%" labelLine={false} outerRadius={100} dataKey="value"
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                        {personalityData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: 'rgba(20,20,20,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2">
                    <h4 className="text-sm text-gray-500 mb-4">Type Breakdown</h4>
                    {personalityData.map((type, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 rounded" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></div>
                          <span className="text-white">{type.name}</span>
                        </div>
                        <span className="text-gray-500">{type.value} members</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">No personality data available</div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}