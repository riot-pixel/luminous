import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Users, MessageSquare, Sparkles, Target, Brain, Heart, Zap,
  CheckCircle2, ArrowRight, Lightbulb, Calendar, Trophy
} from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function TeamCollaborationHub() {
  const queryClient = useQueryClient();
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeFeature, setActiveFeature] = useState(null);
  
  // Discussion state
  const [discussionTopic, setDiscussionTopic] = useState('');
  const [discussionResult, setDiscussionResult] = useState(null);
  
  // Team structure state
  const [projectDescription, setProjectDescription] = useState('');
  const [structureResult, setStructureResult] = useState(null);
  
  // Team building state
  const [teamBuildingResult, setTeamBuildingResult] = useState(null);
  const [activityPreferences, setActivityPreferences] = useState({
    focus_area: 'all',
    format: 'all',
    duration: 'all',
    energy_level: 'mixed',
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: teams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const accessibleTeams = teams.filter(team => {
    if (user?.role === 'admin') return true;
    if (team.leader_email === user?.email) return true;
    if (team.member_emails?.includes(user?.email)) return true;
    return false;
  });

  const getTeamData = (team) => {
    if (!team) return null;
    const members = employees.filter(e => team.member_emails?.includes(e.email));
    const memberAssessments = assessments.filter(a => team.member_emails?.includes(a.user_email));
    const latestAssessments = memberAssessments.reduce((acc, a) => {
      if (!acc[a.user_email] || new Date(a.completed_date) > new Date(acc[a.user_email].completed_date)) {
        acc[a.user_email] = a;
      }
      return acc;
    }, {});
    const teamSkills = userSkills.filter(us => team.member_emails?.includes(us.user_email));
    
    return { members, latestAssessments, teamSkills };
  };

  const generateDiscussion = async () => {
    if (!selectedTeam || !discussionTopic) return;
    setIsGenerating(true);
    setActiveFeature('discussion');
    
    try {
      const teamData = getTeamData(selectedTeam);
      const memberProfiles = Object.entries(teamData.latestAssessments).map(([email, assessment]) => ({
        email,
        personality: assessment.myers_briggs?.type,
        strengths: assessment.strengths?.top_strengths?.slice(0, 3).map(s => s.name),
        communication_style: assessment.integral_theory?.primary_line,
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert AI facilitator specializing in team dynamics and productive discussions.

TEAM: ${selectedTeam.name}
TOPIC: ${discussionTopic}

TEAM MEMBER PROFILES:
${JSON.stringify(memberProfiles, null, 2)}

Create an AI-moderated discussion framework that:
1. Opens with an inclusive prompt that draws on each personality type's strengths
2. Provides discussion guidelines tailored to the team's composition
3. Suggests specific questions for different personality types to ensure balanced participation
4. Identifies potential communication challenges and mitigation strategies
5. Proposes a structured agenda with time allocations
6. Includes prompts to leverage each member's unique strengths
7. Concludes with action item suggestions

Make it practical, specific to this team's dynamics, and ready to use.`,
        response_json_schema: {
          type: "object",
          properties: {
            opening_prompt: { type: "string" },
            discussion_guidelines: { type: "array", items: { type: "string" } },
            personality_specific_prompts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  personality_type: { type: "string" },
                  suggested_prompts: { type: "array", items: { type: "string" } },
                  engagement_tips: { type: "string" }
                }
              }
            },
            potential_challenges: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  challenge: { type: "string" },
                  mitigation: { type: "string" }
                }
              }
            },
            agenda: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  phase: { type: "string" },
                  duration: { type: "string" },
                  activities: { type: "array", items: { type: "string" } }
                }
              }
            },
            closing_actions: { type: "array", items: { type: "string" } }
          }
        }
      });
      
      setDiscussionResult(result);
    } catch (error) {
      console.error("Error generating discussion:", error);
    }
    setIsGenerating(false);
  };

  const generateOptimalStructure = async () => {
    if (!projectDescription) return;
    setIsGenerating(true);
    setActiveFeature('structure');
    
    try {
      const allMemberData = employees.map(emp => {
        const assessment = assessments.find(a => a.user_email === emp.email);
        const skills = userSkills.filter(us => us.user_email === emp.email);
        return {
          email: emp.email,
          name: emp.full_name,
          department: emp.department,
          role: emp.job_title,
          personality: assessment?.myers_briggs?.type,
          strengths: assessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name),
          skills: skills.map(s => ({ name: s.skill_name, level: s.current_proficiency })),
        };
      }).filter(m => m.personality || m.skills.length > 0);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational designer specializing in high-performance team composition.

PROJECT DESCRIPTION:
${projectDescription}

AVAILABLE TALENT POOL:
${JSON.stringify(allMemberData, null, 2)}

Design an optimal team structure that:
1. Identifies the ideal team size and composition
2. Recommends specific individuals based on skills and personality fit
3. Suggests role assignments that leverage each person's strengths
4. Identifies skill gaps that need to be addressed
5. Analyzes personality balance for team harmony
6. Provides a team structure diagram description
7. Suggests collaboration patterns based on personality types

Be specific about WHY each person is recommended.`,
        response_json_schema: {
          type: "object",
          properties: {
            recommended_team_size: { type: "number" },
            team_name_suggestion: { type: "string" },
            recommended_members: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  email: { type: "string" },
                  name: { type: "string" },
                  recommended_role: { type: "string" },
                  justification: { type: "string" },
                  key_contributions: { type: "array", items: { type: "string" } }
                }
              }
            },
            skill_gaps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  importance: { type: "string" },
                  recommendation: { type: "string" }
                }
              }
            },
            personality_analysis: {
              type: "object",
              properties: {
                balance_score: { type: "number" },
                strengths: { type: "array", items: { type: "string" } },
                potential_conflicts: { type: "array", items: { type: "string" } },
                collaboration_recommendations: { type: "array", items: { type: "string" } }
              }
            },
            team_structure: { type: "string" },
            success_factors: { type: "array", items: { type: "string" } }
          }
        }
      });
      
      setStructureResult(result);
    } catch (error) {
      console.error("Error generating structure:", error);
    }
    setIsGenerating(false);
  };

  const generateTeamBuilding = async () => {
    if (!selectedTeam) return;
    setIsGenerating(true);
    setActiveFeature('teambuilding');
    
    try {
      const teamData = getTeamData(selectedTeam);
      const memberProfiles = Object.entries(teamData.latestAssessments).map(([email, assessment]) => ({
        email,
        personality: assessment.myers_briggs?.type,
        cognitive_functions: assessment.myers_briggs?.cognitive_functions,
        strengths: assessment.strengths?.top_strengths?.slice(0, 5).map(s => ({ name: s.name, score: s.score, category: s.category })),
        life_balance: assessment.life_wheel,
        values: assessment.appreciative_inquiry?.discover?.core_values,
        aspirations: assessment.appreciative_inquiry?.dream?.aspirations,
        integral_quadrants: assessment.integral_theory?.quadrants,
      }));

      // Calculate team diversity metrics
      const personalities = memberProfiles.map(m => m.personality).filter(Boolean);
      const uniquePersonalities = [...new Set(personalities)];
      const introvertCount = personalities.filter(p => p?.includes('I')).length;
      const extrovertCount = personalities.filter(p => p?.includes('E')).length;
      const thinkingCount = personalities.filter(p => p?.includes('T')).length;
      const feelingCount = personalities.filter(p => p?.includes('F')).length;

      // Calculate average life balance scores
      const avgLifeBalance = {};
      const lifeWheelKeys = ['career', 'family', 'social', 'health', 'fun_recreation', 'personal_growth', 'physical_environment', 'money'];
      lifeWheelKeys.forEach(key => {
        const scores = memberProfiles.map(m => m.life_balance?.[key]).filter(s => s !== undefined);
        avgLifeBalance[key] = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length * 10) : null;
      });

      // Identify shared values
      const allValues = memberProfiles.flatMap(m => m.values || []);
      const valueCounts = allValues.reduce((acc, v) => { acc[v] = (acc[v] || 0) + 1; return acc; }, {});
      const sharedValues = Object.entries(valueCounts).filter(([_, c]) => c > 1).map(([v]) => v);

      // Identify common strengths
      const allStrengths = memberProfiles.flatMap(m => m.strengths || []);
      const strengthCounts = allStrengths.reduce((acc, s) => { acc[s.name] = (acc[s.name] || 0) + 1; return acc; }, {});
      const commonStrengths = Object.entries(strengthCounts).filter(([_, c]) => c > 1).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([s]) => s);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert team dynamics coach and organizational psychologist specializing in team cohesion, engagement, and high-performance culture.

TEAM INFORMATION:
- Name: ${selectedTeam.name}
- Department: ${selectedTeam.department}
- Goals: ${selectedTeam.goals?.join(', ') || 'Not specified'}
- Team Size: ${memberProfiles.length} members

TEAM DIVERSITY ANALYSIS:
- Personality Types Present: ${uniquePersonalities.join(', ')}
- Introvert/Extrovert Balance: ${introvertCount} introverts / ${extrovertCount} extroverts
- Thinking/Feeling Balance: ${thinkingCount} thinking / ${feelingCount} feeling
- Personality Diversity Score: ${uniquePersonalities.length}/${memberProfiles.length} unique types

AVERAGE TEAM LIFE BALANCE SCORES (0-100):
${JSON.stringify(avgLifeBalance, null, 2)}

SHARED VALUES ACROSS TEAM:
${sharedValues.join(', ') || 'None identified'}

COMMON STRENGTHS:
${commonStrengths.join(', ') || 'None identified'}

DETAILED MEMBER PROFILES:
${JSON.stringify(memberProfiles, null, 2)}

USER PREFERENCES:
- Focus Area: ${activityPreferences.focus_area}
- Format: ${activityPreferences.format}
- Duration: ${activityPreferences.duration}
- Energy Level: ${activityPreferences.energy_level}

Based on this comprehensive analysis, create HIGHLY PERSONALIZED team-building recommendations that:

1. ADDRESS SPECIFIC COHESION NEEDS:
   - If introvert/extrovert imbalance exists, suggest activities that create safe spaces for all
   - If thinking/feeling imbalance exists, suggest activities that bridge communication styles
   - Target life balance areas with lowest scores (social, fun_recreation, etc.)

2. LEVERAGE TEAM DIVERSITY:
   - Use personality diversity as a strength
   - Create activities that let different types shine
   - Build cross-personality connections

3. ALIGN WITH TEAM GOALS:
   - Connect activities to the team's stated objectives
   - Build skills needed for team success

4. HONOR SHARED VALUES:
   - Design activities around common values
   - Reinforce team identity through value-based experiences

5. BUILD ON STRENGTHS:
   - Create activities where common strengths can be demonstrated
   - Allow members to use their signature strengths

6. ADDRESS DYNAMICS INSIGHTS:
   - Consider integral quadrant balance in activities
   - Address any gaps in team's collective development

Provide 8-10 activities across different categories with DETAILED implementation guides.`,
        response_json_schema: {
          type: "object",
          properties: {
            team_dynamics_summary: {
              type: "object",
              properties: {
                diversity_score: { type: "number" },
                cohesion_level: { type: "string" },
                communication_style_mix: { type: "string" },
                energy_balance: { type: "string" },
                key_dynamics_insights: { type: "array", items: { type: "string" } }
              }
            },
            cohesion_analysis: {
              type: "object",
              properties: {
                current_strengths: { type: "array", items: { type: "string" } },
                areas_for_improvement: { type: "array", items: { type: "string" } },
                priority_focus: { type: "string" },
                personality_dynamics: { type: "string" },
                recommended_approach: { type: "string" }
              }
            },
            activities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  category: { type: "string" },
                  type: { type: "string" },
                  format: { type: "string" },
                  duration: { type: "string" },
                  energy_level: { type: "string" },
                  group_size: { type: "string" },
                  description: { type: "string" },
                  cohesion_need_addressed: { type: "string" },
                  why_recommended: { type: "string" },
                  personality_considerations: {
                    type: "object",
                    properties: {
                      introverts: { type: "string" },
                      extroverts: { type: "string" },
                      thinkers: { type: "string" },
                      feelers: { type: "string" }
                    }
                  },
                  goal_alignment: { type: "string" },
                  values_reinforced: { type: "array", items: { type: "string" } },
                  strengths_utilized: { type: "array", items: { type: "string" } },
                  implementation_steps: { type: "array", items: { type: "string" } },
                  facilitation_tips: { type: "array", items: { type: "string" } },
                  success_metrics: { type: "array", items: { type: "string" } },
                  follow_up_actions: { type: "array", items: { type: "string" } },
                  materials_needed: { type: "array", items: { type: "string" } },
                  estimated_cost: { type: "string" }
                }
              }
            },
            quick_wins: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  activity: { type: "string" },
                  time_needed: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            quarterly_plan: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  month: { type: "string" },
                  theme: { type: "string" },
                  activity: { type: "string" },
                  focus_area: { type: "string" },
                  expected_outcome: { type: "string" }
                }
              }
            },
            ongoing_rituals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  ritual_name: { type: "string" },
                  frequency: { type: "string" },
                  description: { type: "string" },
                  purpose: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      setTeamBuildingResult(result);
    } catch (error) {
      console.error("Error generating team building:", error);
    }
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-light text-white mb-2 serif">Team Collaboration Hub</h1>
          <p className="text-gray-500">AI-powered team dynamics and collaboration tools</p>
        </div>

        {/* Team Selector */}
        <div className="glass-panel rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-1">
              <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Select Team</label>
              <Select value={selectedTeam?.id} onValueChange={(id) => setSelectedTeam(teams.find(t => t.id === id))}>
                <SelectTrigger className="bg-black border-white/10 text-white">
                  <SelectValue placeholder="Choose a team" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10">
                  {accessibleTeams.map(team => (
                    <SelectItem key={team.id} value={team.id} className="text-white hover:bg-white/5">
                      {team.name} ({team.member_emails?.length || 0} members)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedTeam && (
              <div className="flex gap-6 text-sm">
                <div><span className="text-gray-500">Department:</span> <span className="text-white">{selectedTeam.department}</span></div>
                <div><span className="text-gray-500">Status:</span> <span className="text-emerald-400">{selectedTeam.status}</span></div>
              </div>
            )}
          </div>
        </div>

        {/* Feature Tabs */}
        <Tabs defaultValue="discussions" className="space-y-6">
          <TabsList className="glass-panel p-1 rounded-xl">
            <TabsTrigger value="discussions" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <MessageSquare className="w-4 h-4 mr-2" />
              AI Discussions
            </TabsTrigger>
            <TabsTrigger value="structure" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <Users className="w-4 h-4 mr-2" />
              Team Builder
            </TabsTrigger>
            <TabsTrigger value="teambuilding" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-6">
              <Heart className="w-4 h-4 mr-2" />
              Team Building
            </TabsTrigger>
          </TabsList>

          {/* AI Discussions Tab */}
          <TabsContent value="discussions" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-amber-400" />
                  Create AI-Moderated Discussion
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Discussion Topic</label>
                    <Textarea
                      value={discussionTopic}
                      onChange={(e) => setDiscussionTopic(e.target.value)}
                      placeholder="e.g., Quarterly planning priorities, Process improvement ideas, New product brainstorming..."
                      className="bg-black border-white/10 text-white h-32"
                    />
                  </div>
                  <Button
                    onClick={generateDiscussion}
                    disabled={!selectedTeam || !discussionTopic || isGenerating}
                    className="w-full bg-white text-black hover:bg-gray-200 text-xs font-bold tracking-widest uppercase"
                  >
                    {isGenerating && activeFeature === 'discussion' ? (
                      <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating Framework...</>
                    ) : (
                      <><Brain className="w-4 h-4 mr-2" /> Generate Discussion Framework</>
                    )}
                  </Button>
                </div>
              </div>

              {discussionResult && (
                <div className="glass-panel rounded-2xl p-6 border border-amber-500/20">
                  <h3 className="text-lg font-light text-white mb-4">Discussion Framework</h3>
                  
                  <div className="space-y-6">
                    <div className="p-4 bg-amber-500/10 rounded-xl">
                      <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Opening Prompt</p>
                      <p className="text-gray-300 text-sm">{discussionResult.opening_prompt}</p>
                    </div>

                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Guidelines</p>
                      <ul className="space-y-2">
                        {discussionResult.discussion_guidelines?.map((g, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-gray-400">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                            {g}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Agenda</p>
                      <div className="space-y-3">
                        {discussionResult.agenda?.map((phase, i) => (
                          <div key={i} className="p-3 bg-white/5 rounded-lg">
                            <div className="flex justify-between mb-2">
                              <span className="text-white font-medium">{phase.phase}</span>
                              <span className="text-xs text-gray-500">{phase.duration}</span>
                            </div>
                            <ul className="space-y-1">
                              {phase.activities?.map((a, j) => (
                                <li key={j} className="text-xs text-gray-400">• {a}</li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Team Builder Tab */}
          <TabsContent value="structure" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-emerald-400" />
                  Build Optimal Team for Project
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 uppercase tracking-widest mb-2 block">Project Description</label>
                    <Textarea
                      value={projectDescription}
                      onChange={(e) => setProjectDescription(e.target.value)}
                      placeholder="Describe the project, its goals, required skills, timeline, and any specific requirements..."
                      className="bg-black border-white/10 text-white h-40"
                    />
                  </div>
                  <Button
                    onClick={generateOptimalStructure}
                    disabled={!projectDescription || isGenerating}
                    className="w-full bg-white text-black hover:bg-gray-200 text-xs font-bold tracking-widest uppercase"
                  >
                    {isGenerating && activeFeature === 'structure' ? (
                      <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Talent...</>
                    ) : (
                      <><Target className="w-4 h-4 mr-2" /> Generate Team Recommendations</>
                    )}
                  </Button>
                </div>
              </div>

              {structureResult && (
                <div className="glass-panel rounded-2xl p-6 border border-emerald-500/20 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-light text-white">{structureResult.team_name_suggestion}</h3>
                    <span className="text-xs bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full">
                      {structureResult.recommended_team_size} members
                    </span>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Recommended Members</p>
                    <div className="space-y-3">
                      {structureResult.recommended_members?.map((member, i) => (
                        <div key={i} className="p-4 bg-white/5 rounded-xl">
                          <div className="flex justify-between mb-2">
                            <span className="text-white font-medium">{member.name}</span>
                            <span className="text-xs text-emerald-400">{member.recommended_role}</span>
                          </div>
                          <p className="text-sm text-gray-400 mb-2">{member.justification}</p>
                          <div className="flex flex-wrap gap-1">
                            {member.key_contributions?.map((c, j) => (
                              <span key={j} className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{c}</span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {structureResult.skill_gaps?.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Skill Gaps to Address</p>
                      <div className="space-y-2">
                        {structureResult.skill_gaps.map((gap, i) => (
                          <div key={i} className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                            <div className="flex justify-between">
                              <span className="text-amber-400">{gap.skill}</span>
                              <span className="text-xs text-gray-500">{gap.importance}</span>
                            </div>
                            <p className="text-xs text-gray-400 mt-1">{gap.recommendation}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Success Factors</p>
                    <ul className="space-y-1">
                      {structureResult.success_factors?.map((f, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-400">
                          <Zap className="w-4 h-4 text-amber-400 mt-0.5" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Team Building Tab */}
          <TabsContent value="teambuilding" className="space-y-6">
            <div className="glass-panel rounded-2xl p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h3 className="text-lg font-light text-white flex items-center gap-2">
                    <Heart className="w-5 h-5 text-rose-400" />
                    Team Building Activities
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">AI-generated activities tailored to team dynamics and cohesion needs</p>
                </div>
                <Button
                  onClick={generateTeamBuilding}
                  disabled={!selectedTeam || isGenerating}
                  className="bg-white text-black hover:bg-gray-200 text-xs font-bold tracking-widest uppercase"
                >
                  {isGenerating && activeFeature === 'teambuilding' ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Team...</>
                  ) : (
                    <><Lightbulb className="w-4 h-4 mr-2" /> Generate Activities</>
                  )}
                </Button>
              </div>

              {/* Activity Preferences */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-white/5 rounded-xl">
                <div>
                  <label className="text-[10px] text-gray-500 uppercase tracking-widest mb-1 block">Focus Area</label>
                  <Select value={activityPreferences.focus_area} onValueChange={(v) => setActivityPreferences({...activityPreferences, focus_area: v})}>
                    <SelectTrigger className="bg-black border-white/10 text-white text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="all" className="text-white hover:bg-white/5">All Areas</SelectItem>
                      <SelectItem value="communication" className="text-white hover:bg-white/5">Communication</SelectItem>
                      <SelectItem value="trust" className="text-white hover:bg-white/5">Trust Building</SelectItem>
                      <SelectItem value="collaboration" className="text-white hover:bg-white/5">Collaboration</SelectItem>
                      <SelectItem value="creativity" className="text-white hover:bg-white/5">Creativity</SelectItem>
                      <SelectItem value="problem-solving" className="text-white hover:bg-white/5">Problem Solving</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-500 uppercase tracking-widest mb-1 block">Format</label>
                  <Select value={activityPreferences.format} onValueChange={(v) => setActivityPreferences({...activityPreferences, format: v})}>
                    <SelectTrigger className="bg-black border-white/10 text-white text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="all" className="text-white hover:bg-white/5">All Formats</SelectItem>
                      <SelectItem value="virtual" className="text-white hover:bg-white/5">Virtual</SelectItem>
                      <SelectItem value="in-person" className="text-white hover:bg-white/5">In-Person</SelectItem>
                      <SelectItem value="hybrid" className="text-white hover:bg-white/5">Hybrid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-500 uppercase tracking-widest mb-1 block">Duration</label>
                  <Select value={activityPreferences.duration} onValueChange={(v) => setActivityPreferences({...activityPreferences, duration: v})}>
                    <SelectTrigger className="bg-black border-white/10 text-white text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="all" className="text-white hover:bg-white/5">Any Duration</SelectItem>
                      <SelectItem value="quick" className="text-white hover:bg-white/5">Quick (15-30 min)</SelectItem>
                      <SelectItem value="medium" className="text-white hover:bg-white/5">Medium (1-2 hours)</SelectItem>
                      <SelectItem value="extended" className="text-white hover:bg-white/5">Extended (half day+)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-500 uppercase tracking-widest mb-1 block">Energy Level</label>
                  <Select value={activityPreferences.energy_level} onValueChange={(v) => setActivityPreferences({...activityPreferences, energy_level: v})}>
                    <SelectTrigger className="bg-black border-white/10 text-white text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-white/10">
                      <SelectItem value="mixed" className="text-white hover:bg-white/5">Mixed</SelectItem>
                      <SelectItem value="low" className="text-white hover:bg-white/5">Low Energy</SelectItem>
                      <SelectItem value="medium" className="text-white hover:bg-white/5">Medium Energy</SelectItem>
                      <SelectItem value="high" className="text-white hover:bg-white/5">High Energy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {teamBuildingResult && (
                <div className="space-y-6">
                  {/* Team Dynamics Summary */}
                  {teamBuildingResult.team_dynamics_summary && (
                    <div className="p-5 bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-xl">
                      <h4 className="text-white font-medium mb-4 flex items-center gap-2">
                        <Brain className="w-5 h-5 text-purple-400" />
                        Team Dynamics Analysis
                      </h4>
                      <div className="grid md:grid-cols-4 gap-4 mb-4">
                        <div className="text-center">
                          <p className="text-3xl font-light text-white">{teamBuildingResult.team_dynamics_summary.diversity_score || 0}</p>
                          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Diversity Score</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg text-white">{teamBuildingResult.team_dynamics_summary.cohesion_level}</p>
                          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Cohesion Level</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg text-white">{teamBuildingResult.team_dynamics_summary.communication_style_mix}</p>
                          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Communication Mix</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg text-white">{teamBuildingResult.team_dynamics_summary.energy_balance}</p>
                          <p className="text-[10px] text-gray-500 uppercase tracking-widest">Energy Balance</p>
                        </div>
                      </div>
                      {teamBuildingResult.team_dynamics_summary.key_dynamics_insights?.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {teamBuildingResult.team_dynamics_summary.key_dynamics_insights.map((insight, i) => (
                            <span key={i} className="text-xs px-3 py-1 bg-white/10 rounded-full text-gray-300">{insight}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Cohesion Analysis */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                      <p className="text-xs text-emerald-400 uppercase tracking-widest mb-2">Team Strengths</p>
                      <ul className="space-y-1">
                        {teamBuildingResult.cohesion_analysis?.current_strengths?.map((s, i) => (
                          <li key={i} className="text-sm text-gray-300 flex items-center gap-2">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> {s}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                      <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Focus Areas</p>
                      <ul className="space-y-1">
                        {teamBuildingResult.cohesion_analysis?.areas_for_improvement?.map((a, i) => (
                          <li key={i} className="text-sm text-gray-300 flex items-center gap-2">
                            <ArrowRight className="w-3 h-3 text-amber-400" /> {a}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {teamBuildingResult.cohesion_analysis?.recommended_approach && (
                    <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                      <p className="text-xs text-blue-400 uppercase tracking-widest mb-2">Recommended Approach</p>
                      <p className="text-sm text-gray-300">{teamBuildingResult.cohesion_analysis.recommended_approach}</p>
                    </div>
                  )}

                  {/* Quick Wins */}
                  {teamBuildingResult.quick_wins?.length > 0 && (
                    <div className="p-4 bg-white/5 rounded-xl">
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-400" /> Quick Wins (Start Today)
                      </p>
                      <div className="grid md:grid-cols-3 gap-3">
                        {teamBuildingResult.quick_wins.map((win, i) => (
                          <div key={i} className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                            <p className="text-sm text-white font-medium">{win.activity}</p>
                            <div className="flex justify-between mt-2">
                              <span className="text-[10px] text-gray-400">{win.time_needed}</span>
                              <span className="text-[10px] text-emerald-400">{win.impact}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Activities */}
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-4">Tailored Activities</p>
                    <div className="space-y-4">
                      {teamBuildingResult.activities?.map((activity, i) => (
                        <div key={i} className="glass-panel rounded-xl p-5 border border-white/5 hover:border-white/10 transition-colors">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h4 className="text-white font-medium text-lg">{activity.name}</h4>
                              <div className="flex flex-wrap gap-2 mt-2">
                                <span className="text-[10px] px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded">{activity.category}</span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{activity.format}</span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{activity.duration}</span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{activity.energy_level} energy</span>
                                {activity.estimated_cost && <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded">{activity.estimated_cost}</span>}
                              </div>
                            </div>
                            <Trophy className="w-6 h-6 text-amber-400" />
                          </div>
                          
                          <p className="text-sm text-gray-400 mb-4">{activity.description}</p>
                          
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg">
                              <p className="text-xs text-rose-400 uppercase tracking-widest mb-2">Cohesion Need Addressed</p>
                              <p className="text-xs text-gray-300">{activity.cohesion_need_addressed}</p>
                            </div>
                            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                              <p className="text-xs text-blue-400 uppercase tracking-widest mb-2">Goal Alignment</p>
                              <p className="text-xs text-gray-300">{activity.goal_alignment}</p>
                            </div>
                          </div>

                          {activity.personality_considerations && (
                            <div className="p-3 bg-white/5 rounded-lg mb-4">
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Personality Considerations</p>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                {activity.personality_considerations.introverts && (
                                  <div className="text-xs">
                                    <span className="text-purple-400">Introverts:</span>
                                    <p className="text-gray-400 mt-0.5">{activity.personality_considerations.introverts}</p>
                                  </div>
                                )}
                                {activity.personality_considerations.extroverts && (
                                  <div className="text-xs">
                                    <span className="text-amber-400">Extroverts:</span>
                                    <p className="text-gray-400 mt-0.5">{activity.personality_considerations.extroverts}</p>
                                  </div>
                                )}
                                {activity.personality_considerations.thinkers && (
                                  <div className="text-xs">
                                    <span className="text-blue-400">Thinkers:</span>
                                    <p className="text-gray-400 mt-0.5">{activity.personality_considerations.thinkers}</p>
                                  </div>
                                )}
                                {activity.personality_considerations.feelers && (
                                  <div className="text-xs">
                                    <span className="text-rose-400">Feelers:</span>
                                    <p className="text-gray-400 mt-0.5">{activity.personality_considerations.feelers}</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Implementation Steps</p>
                              <ol className="space-y-1">
                                {activity.implementation_steps?.slice(0, 4).map((step, j) => (
                                  <li key={j} className="text-xs text-gray-400 flex items-start gap-2">
                                    <span className="text-white bg-white/10 rounded-full w-4 h-4 flex items-center justify-center flex-shrink-0 text-[10px]">{j+1}</span>
                                    {step}
                                  </li>
                                ))}
                              </ol>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Success Metrics</p>
                              <ul className="space-y-1">
                                {activity.success_metrics?.slice(0, 3).map((metric, j) => (
                                  <li key={j} className="text-xs text-gray-400 flex items-start gap-2">
                                    <Target className="w-3 h-3 text-emerald-400 mt-0.5" />
                                    {metric}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          {(activity.values_reinforced?.length > 0 || activity.strengths_utilized?.length > 0) && (
                            <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-white/5">
                              {activity.values_reinforced?.map((v, j) => (
                                <span key={`v-${j}`} className="text-[10px] px-2 py-1 bg-rose-500/10 border border-rose-500/20 rounded text-rose-400">Value: {v}</span>
                              ))}
                              {activity.strengths_utilized?.map((s, j) => (
                                <span key={`s-${j}`} className="text-[10px] px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400">Strength: {s}</span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Ongoing Rituals */}
                  {teamBuildingResult.ongoing_rituals?.length > 0 && (
                    <div className="p-6 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 rounded-xl">
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Heart className="w-4 h-4 text-rose-400" /> Recommended Ongoing Rituals
                      </p>
                      <div className="grid md:grid-cols-2 gap-4">
                        {teamBuildingResult.ongoing_rituals.map((ritual, i) => (
                          <div key={i} className="p-4 bg-white/5 rounded-lg">
                            <div className="flex justify-between mb-2">
                              <h5 className="text-white font-medium">{ritual.ritual_name}</h5>
                              <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">{ritual.frequency}</span>
                            </div>
                            <p className="text-sm text-gray-400 mb-2">{ritual.description}</p>
                            <p className="text-xs text-emerald-400">Purpose: {ritual.purpose}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Quarterly Plan */}
                  {teamBuildingResult.quarterly_plan?.length > 0 && (
                    <div className="p-6 bg-white/5 rounded-xl">
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <Calendar className="w-4 h-4" /> Quarterly Plan
                      </p>
                      <div className="grid md:grid-cols-3 gap-4">
                        {teamBuildingResult.quarterly_plan.map((item, i) => (
                          <div key={i} className="p-4 border border-white/10 rounded-lg">
                            <div className="flex justify-between mb-2">
                              <p className="text-white font-medium">{item.month}</p>
                              {item.theme && <span className="text-[10px] px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded">{item.theme}</span>}
                            </div>
                            <p className="text-sm text-gray-300">{item.activity}</p>
                            <p className="text-xs text-gray-500 mt-2">Focus: {item.focus_area}</p>
                            {item.expected_outcome && (
                              <p className="text-xs text-emerald-400 mt-1">Outcome: {item.expected_outcome}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}