import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Sparkles, Plus, TrendingUp, Users, Target, Award, Zap, 
  Heart, Leaf, Brain, Lightbulb, HandHeart, BookOpen, Share2,
  CheckCircle2, ArrowRight, ChevronRight, Trophy, Star, Globe
} from "lucide-react";
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, Treemap,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  Sankey, Layer, Rectangle
} from "recharts";

const CATEGORY_COLORS = {
  culture: "#8b5cf6",
  innovation: "#3b82f6",
  mentorship: "#10b981",
  collaboration: "#f59e0b",
  sustainability: "#22c55e",
  client_success: "#ec4899",
  knowledge_sharing: "#06b6d4",
  leadership: "#f97316"
};

const CATEGORY_ICONS = {
  culture: Heart,
  innovation: Lightbulb,
  mentorship: Users,
  collaboration: Share2,
  sustainability: Leaf,
  client_success: Target,
  knowledge_sharing: BookOpen,
  leadership: Award
};

export default function HolisticImpactDashboard() {
  const queryClient = useQueryClient();
  const [showContributionDialog, setShowContributionDialog] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [newContribution, setNewContribution] = useState({
    title: "",
    description: "",
    qualitative_impact: "",
    impact_unit_id: "",
    beneficiaries: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: impactUnits } = useQuery({
    queryKey: ['impactUnits'],
    queryFn: () => base44.entities.ImpactUnitDefinition.filter({ is_active: true }),
    initialData: [],
  });

  const { data: contributions } = useQuery({
    queryKey: ['contributions'],
    queryFn: () => base44.entities.ContributionRecord.list('-contribution_date', 100),
    initialData: [],
  });

  const { data: myContributions } = useQuery({
    queryKey: ['myContributions', user?.email],
    queryFn: () => base44.entities.ContributionRecord.filter({ user_email: user?.email }, '-contribution_date'),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: aggregates } = useQuery({
    queryKey: ['impactAggregates'],
    queryFn: () => base44.entities.ImpactAggregate.list('-total_points', 50),
    initialData: [],
  });

  const createContributionMutation = useMutation({
    mutationFn: (data) => base44.entities.ContributionRecord.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contributions'] });
      queryClient.invalidateQueries({ queryKey: ['myContributions'] });
      setShowContributionDialog(false);
      setNewContribution({ title: "", description: "", qualitative_impact: "", impact_unit_id: "", beneficiaries: "" });
    },
  });

  const submitContribution = async () => {
    setIsAnalyzing(true);
    try {
      const selectedUnit = impactUnits.find(u => u.id === newContribution.impact_unit_id);
      
      // AI analysis of the contribution
      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this contribution for organizational impact:

CONTRIBUTION:
Title: ${newContribution.title}
Description: ${newContribution.description}
Qualitative Impact: ${newContribution.qualitative_impact}
Category: ${selectedUnit?.category || 'general'}

Analyze:
1. The sentiment and tone
2. Key themes present
3. Overall impact assessment
4. Potential ripple effects on the organization
5. Connections to organizational values`,
        response_json_schema: {
          type: "object",
          properties: {
            sentiment: { type: "string" },
            themes: { type: "array", items: { type: "string" } },
            impact_assessment: { type: "string" },
            suggested_connections: { type: "array", items: { type: "string" } },
            ripple_effects: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  affected_area: { type: "string" },
                  effect_description: { type: "string" },
                  magnitude: { type: "string" }
                }
              }
            }
          }
        }
      });

      const basePoints = selectedUnit?.base_points || 10;
      
      await createContributionMutation.mutateAsync({
        user_email: user.email,
        department: user.department,
        impact_unit_id: newContribution.impact_unit_id,
        impact_unit_name: selectedUnit?.name,
        title: newContribution.title,
        description: newContribution.description,
        qualitative_impact: newContribution.qualitative_impact,
        beneficiaries: newContribution.beneficiaries.split(',').map(b => b.trim()).filter(Boolean),
        base_points: basePoints,
        final_points: basePoints,
        ai_analysis: analysis,
        ripple_effects: analysis.ripple_effects,
        verification_status: "pending",
        contribution_date: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error submitting contribution:", error);
    }
    setIsAnalyzing(false);
  };

  // Calculate metrics
  const myTotalPoints = myContributions?.reduce((sum, c) => sum + (c.final_points || 0), 0) || 0;
  const myContributionCount = myContributions?.length || 0;
  
  const categoryBreakdown = contributions?.reduce((acc, c) => {
    const unit = impactUnits.find(u => u.id === c.impact_unit_id);
    const cat = unit?.category || 'other';
    acc[cat] = (acc[cat] || 0) + (c.final_points || 0);
    return acc;
  }, {}) || {};

  const categoryChartData = Object.entries(categoryBreakdown).map(([name, value]) => ({
    name: name.replace('_', ' '),
    value,
    fill: CATEGORY_COLORS[name] || "#666"
  }));

  const topContributors = aggregates
    ?.filter(a => a.entity_type === 'user' && a.period === 'monthly')
    ?.sort((a, b) => b.total_points - a.total_points)
    ?.slice(0, 10) || [];

  // Impact chain visualization data
  const impactChainData = myContributions?.slice(0, 5).map(c => ({
    name: c.title?.substring(0, 20) + '...',
    points: c.final_points || 0,
    ripples: c.ripple_effects?.length || 0,
    beneficiaries: c.beneficiaries?.length || 0
  })) || [];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Holistic Impact Ledger</h1>
            <p className="text-gray-400">Track and visualize your contributions to organizational success</p>
          </div>
          <Dialog open={showContributionDialog} onOpenChange={setShowContributionDialog}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" />
                Log Contribution
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
              <DialogHeader>
                <DialogTitle>Log a Contribution</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Impact Category</label>
                  <Select value={newContribution.impact_unit_id} onValueChange={(v) => setNewContribution({...newContribution, impact_unit_id: v})}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {impactUnits.map(unit => (
                        <SelectItem key={unit.id} value={unit.id}>
                          {unit.name} ({unit.base_points} pts)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Title</label>
                  <Input
                    value={newContribution.title}
                    onChange={(e) => setNewContribution({...newContribution, title: e.target.value})}
                    placeholder="Brief title of your contribution"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Description</label>
                  <Textarea
                    value={newContribution.description}
                    onChange={(e) => setNewContribution({...newContribution, description: e.target.value})}
                    placeholder="What did you do?"
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Qualitative Impact</label>
                  <Textarea
                    value={newContribution.qualitative_impact}
                    onChange={(e) => setNewContribution({...newContribution, qualitative_impact: e.target.value})}
                    placeholder="Describe the impact this had..."
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Beneficiaries (comma-separated)</label>
                  <Input
                    value={newContribution.beneficiaries}
                    onChange={(e) => setNewContribution({...newContribution, beneficiaries: e.target.value})}
                    placeholder="team@company.com, john@company.com"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <Button 
                  onClick={submitContribution} 
                  disabled={isAnalyzing || !newContribution.title}
                  className="w-full bg-white text-black hover:bg-gray-200"
                >
                  {isAnalyzing ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Impact...</>
                  ) : (
                    <><CheckCircle2 className="w-4 h-4 mr-2" /> Submit Contribution</>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-purple-900 to-purple-950 border-purple-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-300 text-sm">My Total Impact</p>
                  <p className="text-3xl font-bold text-white">{myTotalPoints}</p>
                  <p className="text-purple-400 text-xs">points earned</p>
                </div>
                <Trophy className="w-10 h-10 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900 to-blue-950 border-blue-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-sm">Contributions</p>
                  <p className="text-3xl font-bold text-white">{myContributionCount}</p>
                  <p className="text-blue-400 text-xs">logged actions</p>
                </div>
                <Star className="w-10 h-10 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900 to-green-950 border-green-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-300 text-sm">Organization Total</p>
                  <p className="text-3xl font-bold text-white">
                    {contributions?.reduce((s, c) => s + (c.final_points || 0), 0) || 0}
                  </p>
                  <p className="text-green-400 text-xs">collective impact</p>
                </div>
                <Globe className="w-10 h-10 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900 to-orange-950 border-orange-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-300 text-sm">Active Contributors</p>
                  <p className="text-3xl font-bold text-white">
                    {new Set(contributions?.map(c => c.user_email)).size || 0}
                  </p>
                  <p className="text-orange-400 text-xs">this period</p>
                </div>
                <Users className="w-10 h-10 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="my-impact" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="my-impact">My Impact</TabsTrigger>
            <TabsTrigger value="impact-chains">Impact Chains</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            <TabsTrigger value="categories">By Category</TabsTrigger>
          </TabsList>

          <TabsContent value="my-impact">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Contributions */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">My Recent Contributions</CardTitle>
                </CardHeader>
                <CardContent>
                  {myContributions?.length === 0 ? (
                    <div className="text-center py-12">
                      <Zap className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No contributions yet</p>
                      <p className="text-gray-500 text-sm">Start logging your impact!</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {myContributions?.slice(0, 5).map(c => {
                        const Icon = CATEGORY_ICONS[impactUnits.find(u => u.id === c.impact_unit_id)?.category] || Star;
                        return (
                          <div key={c.id} className="p-4 bg-gray-800 rounded-lg border border-gray-700">
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-lg bg-purple-900 flex items-center justify-center">
                                <Icon className="w-5 h-5 text-purple-400" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h4 className="text-white font-medium">{c.title}</h4>
                                  <Badge className="bg-purple-600">{c.final_points} pts</Badge>
                                </div>
                                <p className="text-gray-400 text-sm mt-1 line-clamp-2">{c.description}</p>
                                {c.ai_analysis?.themes?.length > 0 && (
                                  <div className="flex gap-1 mt-2 flex-wrap">
                                    {c.ai_analysis.themes.slice(0, 3).map((t, i) => (
                                      <span key={i} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{t}</span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Impact Distribution */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">My Impact Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  {categoryChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryChartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {categoryChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', color: '#fff' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      No data yet
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="impact-chains">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Impact Chain Visualization</CardTitle>
                <CardDescription className="text-gray-400">
                  See how your contributions create ripple effects across the organization
                </CardDescription>
              </CardHeader>
              <CardContent>
                {impactChainData.length > 0 ? (
                  <div className="space-y-4">
                    {myContributions?.slice(0, 5).map((c, idx) => (
                      <div key={c.id} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-center gap-4">
                          {/* Source */}
                          <div className="w-32 text-center">
                            <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center mx-auto mb-2">
                              <Star className="w-6 h-6 text-white" />
                            </div>
                            <p className="text-white text-sm font-medium truncate">{c.title}</p>
                            <p className="text-purple-400 text-xs">{c.final_points} pts</p>
                          </div>
                          
                          {/* Arrow */}
                          <div className="flex-1 flex items-center">
                            <div className="h-0.5 bg-gradient-to-r from-purple-600 to-blue-600 flex-1" />
                            <ChevronRight className="w-5 h-5 text-blue-400" />
                          </div>
                          
                          {/* Beneficiaries */}
                          <div className="w-32 text-center">
                            <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mx-auto mb-2">
                              <Users className="w-6 h-6 text-white" />
                            </div>
                            <p className="text-white text-sm">{c.beneficiaries?.length || 0}</p>
                            <p className="text-blue-400 text-xs">beneficiaries</p>
                          </div>
                          
                          {/* Arrow */}
                          <div className="flex-1 flex items-center">
                            <div className="h-0.5 bg-gradient-to-r from-blue-600 to-green-600 flex-1" />
                            <ChevronRight className="w-5 h-5 text-green-400" />
                          </div>
                          
                          {/* Ripples */}
                          <div className="w-32 text-center">
                            <div className="w-12 h-12 rounded-full bg-green-600 flex items-center justify-center mx-auto mb-2">
                              <Share2 className="w-6 h-6 text-white" />
                            </div>
                            <p className="text-white text-sm">{c.ripple_effects?.length || 0}</p>
                            <p className="text-green-400 text-xs">ripple effects</p>
                          </div>
                        </div>
                        
                        {c.ripple_effects?.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-gray-700">
                            <p className="text-gray-400 text-xs mb-2">Ripple Effects:</p>
                            <div className="grid md:grid-cols-3 gap-2">
                              {c.ripple_effects.map((r, i) => (
                                <div key={i} className="p-2 bg-gray-700 rounded text-xs">
                                  <p className="text-white font-medium">{r.affected_area}</p>
                                  <p className="text-gray-400">{r.effect_description}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Share2 className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">Log contributions to see impact chains</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="leaderboard">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Impact Leaderboard</CardTitle>
                <CardDescription className="text-gray-400">Top contributors this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topContributors.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      No leaderboard data yet
                    </div>
                  ) : (
                    topContributors.map((contributor, idx) => (
                      <div key={contributor.id} className={`flex items-center gap-4 p-4 rounded-lg ${idx < 3 ? 'bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700' : 'bg-gray-800'}`}>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                          idx === 0 ? 'bg-yellow-500 text-black' :
                          idx === 1 ? 'bg-gray-400 text-black' :
                          idx === 2 ? 'bg-amber-700 text-white' :
                          'bg-gray-700 text-gray-400'
                        }`}>
                          {idx + 1}
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">{contributor.entity_name || contributor.entity_id}</p>
                          <p className="text-gray-400 text-sm">{contributor.contribution_count} contributions</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-white">{contributor.total_points}</p>
                          <p className="text-gray-500 text-xs">points</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Impact by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  {Object.entries(CATEGORY_COLORS).map(([category, color]) => {
                    const Icon = CATEGORY_ICONS[category];
                    const points = categoryBreakdown[category] || 0;
                    return (
                      <div key={category} className="p-4 bg-gray-800 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: color + '30' }}>
                            <Icon className="w-5 h-5" style={{ color }} />
                          </div>
                          <div>
                            <p className="text-white font-medium capitalize">{category.replace('_', ' ')}</p>
                            <p className="text-2xl font-bold text-white">{points}</p>
                          </div>
                        </div>
                        <Progress value={Math.min((points / (Math.max(...Object.values(categoryBreakdown)) || 1)) * 100, 100)} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}