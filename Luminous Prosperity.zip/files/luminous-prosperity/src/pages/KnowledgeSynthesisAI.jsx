import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Brain, Sparkles, Link2, Lightbulb, TrendingUp, Target,
  BookOpen, Globe, Building2, RefreshCw, Layers, Zap,
  ArrowRight, CheckCircle2, Network, Microscope
} from "lucide-react";

const DOMAIN_COLORS = {
  organizational: "bg-blue-600",
  ecosystem: "bg-green-600",
  market: "bg-purple-600",
  wellness: "bg-cyan-600",
  leadership: "bg-orange-600",
  skills: "bg-pink-600",
  innovation: "bg-yellow-600",
  strategy: "bg-red-600"
};

export default function KnowledgeSynthesisAI() {
  const queryClient = useQueryClient();
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [synthesisProgress, setSynthesisProgress] = useState(0);
  const [synthesisStep, setSynthesisStep] = useState("");

  const { data: articles } = useQuery({
    queryKey: ['knowledgeArticles'],
    queryFn: () => base44.entities.KnowledgeBaseArticle.list('-created_date', 100),
    initialData: [],
  });

  const { data: aiInsights } = useQuery({
    queryKey: ['aiInsightsForSynthesis'],
    queryFn: () => base44.entities.AIInsightAggregate.list('-aggregation_date', 20),
    initialData: [],
  });

  const { data: ecosystemReports } = useQuery({
    queryKey: ['ecosystemReportsForSynthesis'],
    queryFn: () => base44.entities.EcosystemOpportunityReport.list('-generation_date', 20),
    initialData: [],
  });

  const { data: syntheses } = useQuery({
    queryKey: ['synthesizedKnowledge'],
    queryFn: () => base44.entities.SynthesizedKnowledge.list('-synthesis_date', 10),
    initialData: [],
  });

  const createSynthesisMutation = useMutation({
    mutationFn: (data) => base44.entities.SynthesizedKnowledge.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['synthesizedKnowledge'] });
    },
  });

  const runKnowledgeSynthesis = async () => {
    setIsSynthesizing(true);
    setSynthesisProgress(0);

    try {
      // Step 1: Extract key concepts from all sources
      setSynthesisStep("Extracting key concepts from knowledge sources...");
      setSynthesisProgress(15);

      const articlesConcepts = articles.slice(0, 30).map(a => ({
        id: a.id,
        title: a.title,
        domain: a.domain,
        concepts: a.key_concepts || [],
        tags: a.tags || [],
        summary: a.summary
      }));

      const insightThemes = aiInsights.slice(0, 10).flatMap(i => 
        i.recurring_themes?.map(t => ({ theme: t.theme, source: 'ai_insight', id: i.id })) || []
      );

      const ecosystemOpportunities = ecosystemReports.slice(0, 10).flatMap(r => 
        r.non_zero_sum_opportunities?.map(o => ({ opportunity: o.opportunity, source: 'ecosystem', id: r.id })) || []
      );

      setSynthesisProgress(30);

      // Step 2: Identify cross-entity overlaps
      setSynthesisStep("Identifying knowledge overlaps across domains...");

      const overlapAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze these knowledge sources to identify overlaps and connections:

KNOWLEDGE ARTICLES (${articlesConcepts.length}):
${articlesConcepts.slice(0, 15).map(a => `- [${a.domain}] "${a.title}": ${a.summary?.substring(0, 100)}... Tags: ${a.tags?.join(', ')}`).join('\n')}

AI INSIGHT THEMES (${insightThemes.length}):
${insightThemes.slice(0, 15).map(t => `- ${t.theme}`).join('\n')}

ECOSYSTEM OPPORTUNITIES (${ecosystemOpportunities.length}):
${ecosystemOpportunities.slice(0, 10).map(o => `- ${o.opportunity}`).join('\n')}

Identify:
1. 5-8 knowledge overlaps where multiple sources converge on similar topics
2. For each overlap, explain the insight and which entities are involved`,
        response_json_schema: {
          type: "object",
          properties: {
            overlaps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  overlap_area: { type: "string" },
                  entities_involved: { type: "array", items: { type: "string" } },
                  insight: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSynthesisProgress(50);

      // Step 3: Identify emergent themes
      setSynthesisStep("Discovering emergent themes across domains...");

      const themesAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on the knowledge overlaps and source data, identify emergent themes:

IDENTIFIED OVERLAPS:
${overlapAnalysis.overlaps?.map(o => `- ${o.overlap_area}: ${o.insight}`).join('\n')}

DOMAINS PRESENT: organizational, ecosystem, market, wellness, leadership, skills, innovation, strategy

Identify 5-7 emergent themes that span multiple domains. For each theme:
1. Name the theme
2. List which domains are involved
3. Rate strength (weak/moderate/strong)
4. Provide 2-3 pieces of evidence`,
        response_json_schema: {
          type: "object",
          properties: {
            themes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  theme: { type: "string" },
                  domains_involved: { type: "array", items: { type: "string" } },
                  strength: { type: "string" },
                  evidence: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setSynthesisProgress(70);

      // Step 4: Generate research paths and innovation opportunities
      setSynthesisStep("Generating research paths and innovation opportunities...");

      const innovationAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on synthesized knowledge, generate research paths and innovation opportunities:

EMERGENT THEMES:
${themesAnalysis.themes?.map(t => `- ${t.theme} (${t.strength}): Domains - ${t.domains_involved?.join(', ')}`).join('\n')}

KNOWLEDGE OVERLAPS:
${overlapAnalysis.overlaps?.map(o => `- ${o.overlap_area}`).join('\n')}

Generate:
1. 4-6 suggested research paths with title, description, potential impact, required resources, and priority
2. 4-6 innovation opportunities with opportunity name, basis (what knowledge it builds on), feasibility (experimental/viable/ready), and domains combined`,
        response_json_schema: {
          type: "object",
          properties: {
            research_paths: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  path_title: { type: "string" },
                  description: { type: "string" },
                  potential_impact: { type: "string" },
                  required_resources: { type: "array", items: { type: "string" } },
                  priority: { type: "string" }
                }
              }
            },
            innovation_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  opportunity: { type: "string" },
                  basis: { type: "string" },
                  feasibility: { type: "string" },
                  domains_combined: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setSynthesisProgress(85);

      // Step 5: Generate synthesis summary
      setSynthesisStep("Generating synthesis summary...");

      const summaryAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Create an executive summary of the knowledge synthesis:

THEMES DISCOVERED: ${themesAnalysis.themes?.length || 0}
OVERLAPS IDENTIFIED: ${overlapAnalysis.overlaps?.length || 0}
RESEARCH PATHS: ${innovationAnalysis.research_paths?.length || 0}
INNOVATION OPPORTUNITIES: ${innovationAnalysis.innovation_opportunities?.length || 0}

Key themes: ${themesAnalysis.themes?.map(t => t.theme).join(', ')}

Write a 3-4 sentence executive summary and provide a confidence score (0-100).`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            confidence_score: { type: "number" }
          }
        }
      });

      setSynthesisProgress(95);

      // Step 6: Save synthesis
      setSynthesisStep("Saving synthesized knowledge...");

      const synthesis = {
        title: `Knowledge Synthesis - ${new Date().toLocaleDateString()}`,
        synthesis_date: new Date().toISOString(),
        linked_articles: articlesConcepts.slice(0, 10).map(a => ({
          article_id: a.id,
          article_title: a.title,
          relevance_score: 80
        })),
        linked_insights: aiInsights.slice(0, 5).map(i => ({
          insight_id: i.id,
          insight_type: i.period,
          connection_reason: "Contains relevant organizational themes"
        })),
        linked_ecosystem_reports: ecosystemReports.slice(0, 5).map(r => ({
          report_id: r.id,
          report_title: r.title,
          synergy_points: r.non_zero_sum_opportunities?.slice(0, 2).map(o => o.opportunity) || []
        })),
        emergent_themes: themesAnalysis.themes || [],
        knowledge_overlaps: overlapAnalysis.overlaps || [],
        research_paths: innovationAnalysis.research_paths || [],
        innovation_opportunities: innovationAnalysis.innovation_opportunities || [],
        synthesis_summary: summaryAnalysis.summary,
        confidence_score: summaryAnalysis.confidence_score || 75
      };

      await createSynthesisMutation.mutateAsync(synthesis);

      setSynthesisProgress(100);
      setSynthesisStep("Synthesis complete!");

    } catch (error) {
      console.error("Error during synthesis:", error);
      setSynthesisStep("Error occurred. Please try again.");
    }

    setTimeout(() => {
      setIsSynthesizing(false);
      setSynthesisProgress(0);
      setSynthesisStep("");
    }, 2000);
  };

  const latestSynthesis = syntheses[0];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">Knowledge Synthesis AI</h1>
            <p className="text-gray-400">Cross-domain knowledge analysis and innovation discovery</p>
          </div>
          <Button
            onClick={runKnowledgeSynthesis}
            disabled={isSynthesizing}
            className="bg-white text-black hover:bg-gray-200"
          >
            {isSynthesizing ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Synthesizing...</>
            ) : (
              <><Brain className="w-4 h-4 mr-2" /> Run Synthesis</>
            )}
          </Button>
        </div>

        {/* Progress */}
        {isSynthesizing && (
          <Card className="bg-gray-900 border-gray-800 mb-6">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white">{synthesisStep}</span>
                <span className="text-purple-400">{synthesisProgress}%</span>
              </div>
              <Progress value={synthesisProgress} className="h-2" />
            </CardContent>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{articles.length}</p>
              <p className="text-gray-400 text-sm">Articles</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <Sparkles className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{aiInsights.length}</p>
              <p className="text-gray-400 text-sm">AI Insights</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <Globe className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{ecosystemReports.length}</p>
              <p className="text-gray-400 text-sm">Ecosystem Reports</p>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <Layers className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{syntheses.length}</p>
              <p className="text-gray-400 text-sm">Syntheses</p>
            </CardContent>
          </Card>
        </div>

        {/* Latest Synthesis */}
        {latestSynthesis ? (
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="themes">Emergent Themes</TabsTrigger>
              <TabsTrigger value="overlaps">Knowledge Overlaps</TabsTrigger>
              <TabsTrigger value="research">Research Paths</TabsTrigger>
              <TabsTrigger value="innovation">Innovations</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800 mb-4">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Brain className="w-5 h-5 text-purple-400" />
                    <span className="text-purple-300 font-medium">Synthesis Summary</span>
                    <Badge className="bg-purple-600 ml-auto">{latestSynthesis.confidence_score}% Confidence</Badge>
                  </div>
                  <p className="text-gray-300">{latestSynthesis.synthesis_summary}</p>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-3 gap-4">
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Linked Articles</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px]">
                      {latestSynthesis.linked_articles?.map((a, i) => (
                        <div key={i} className="p-2 bg-gray-800 rounded mb-2">
                          <p className="text-white text-sm">{a.article_title}</p>
                          <Badge variant="outline" className="text-xs border-blue-600 text-blue-400 mt-1">
                            {a.relevance_score}% relevant
                          </Badge>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Linked Insights</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px]">
                      {latestSynthesis.linked_insights?.map((i, idx) => (
                        <div key={idx} className="p-2 bg-gray-800 rounded mb-2">
                          <p className="text-white text-sm">{i.insight_type} Insight</p>
                          <p className="text-gray-400 text-xs">{i.connection_reason}</p>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>

                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Ecosystem Reports</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px]">
                      {latestSynthesis.linked_ecosystem_reports?.map((r, i) => (
                        <div key={i} className="p-2 bg-gray-800 rounded mb-2">
                          <p className="text-white text-sm">{r.report_title}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {r.synergy_points?.slice(0, 2).map((p, j) => (
                              <span key={j} className="text-xs text-green-400">• {p.substring(0, 30)}...</span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="themes">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Network className="w-5 h-5 text-purple-400" />
                    Emergent Themes Across Domains
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestSynthesis.emergent_themes?.map((theme, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{theme.theme}</h4>
                          <Badge className={
                            theme.strength === 'strong' ? 'bg-green-600' :
                            theme.strength === 'moderate' ? 'bg-yellow-600' : 'bg-gray-600'
                          }>{theme.strength}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {theme.domains_involved?.map((d, j) => (
                            <Badge key={j} className={DOMAIN_COLORS[d] || 'bg-gray-600'}>{d}</Badge>
                          ))}
                        </div>
                        <div className="space-y-1">
                          {theme.evidence?.map((e, j) => (
                            <p key={j} className="text-gray-400 text-sm flex items-start gap-2">
                              <CheckCircle2 className="w-3 h-3 mt-1 text-green-500 flex-shrink-0" />
                              {e}
                            </p>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="overlaps">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Link2 className="w-5 h-5 text-blue-400" />
                    Knowledge Overlaps
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestSynthesis.knowledge_overlaps?.map((overlap, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-blue-600">
                        <h4 className="text-white font-medium mb-2">{overlap.overlap_area}</h4>
                        <p className="text-gray-300 text-sm mb-2">{overlap.insight}</p>
                        <div className="flex flex-wrap gap-1">
                          {overlap.entities_involved?.map((e, j) => (
                            <Badge key={j} variant="outline" className="text-xs border-gray-600 text-gray-400">{e}</Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="research">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Microscope className="w-5 h-5 text-cyan-400" />
                    Suggested Research Paths
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestSynthesis.research_paths?.map((path, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{path.path_title}</h4>
                          <Badge className={
                            path.priority === 'high' ? 'bg-red-600' :
                            path.priority === 'medium' ? 'bg-yellow-600' : 'bg-green-600'
                          }>{path.priority}</Badge>
                        </div>
                        <p className="text-gray-300 text-sm mb-2">{path.description}</p>
                        <p className="text-green-400 text-xs mb-2">Impact: {path.potential_impact}</p>
                        <div className="flex flex-wrap gap-1">
                          {path.required_resources?.map((r, j) => (
                            <span key={j} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{r}</span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="innovation">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-yellow-400" />
                    Innovation Opportunities
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestSynthesis.innovation_opportunities?.map((opp, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-yellow-600">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{opp.opportunity}</h4>
                          <Badge className={
                            opp.feasibility === 'ready' ? 'bg-green-600' :
                            opp.feasibility === 'viable' ? 'bg-blue-600' : 'bg-purple-600'
                          }>{opp.feasibility}</Badge>
                        </div>
                        <p className="text-gray-300 text-sm mb-2">Based on: {opp.basis}</p>
                        <div className="flex flex-wrap gap-1">
                          {opp.domains_combined?.map((d, j) => (
                            <Badge key={j} className={DOMAIN_COLORS[d] || 'bg-gray-600'}>{d}</Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <Card className="bg-gray-900 border-gray-800 text-center py-16">
            <CardContent>
              <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl text-white mb-2">No Synthesis Generated Yet</h3>
              <p className="text-gray-400 mb-4">Run the Knowledge Synthesis AI to discover cross-domain insights and innovations</p>
              <Button onClick={runKnowledgeSynthesis} className="bg-purple-600 hover:bg-purple-700">
                <Sparkles className="w-4 h-4 mr-2" />
                Start Synthesis
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}