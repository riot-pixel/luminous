
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, CreditCard, Settings, UserPlus, Mail, Upload, Image } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function OrganizationSettings() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const { data: subscription } = useQuery({
    queryKey: ['orgSubscription'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      if (orgs.length === 0) return null;
      const subs = await base44.entities.Subscription.filter({ organization_id: orgs[0].id });
      return subs[0];
    },
  });

  const { data: invites } = useQuery({
    queryKey: ['orgInvites'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      if (orgs.length === 0) return [];
      return base44.entities.OrganizationInvite.filter({ organization_id: orgs[0].id }, '-created_date');
    },
    initialData: [],
  });

  const { data: orgUsers } = useQuery({
    queryKey: ['orgUsers'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      if (orgs.length === 0) return [];
      return base44.entities.User.list();
    },
    initialData: [],
  });

  const organization = organizations[0];

  const isAdmin = user?.role === 'admin' || organization?.admin_emails?.includes(user?.email);

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>Only organization administrators can access these settings.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-stone-800 mb-2">Organization Settings</h1>
          <p className="text-stone-600">Manage your organization, team, and subscription</p>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="general">
              <Building2 className="w-4 h-4 mr-2" />
              General
            </TabsTrigger>
            <TabsTrigger value="branding">
              <Image className="w-4 h-4 mr-2" />
              Branding
            </TabsTrigger>
            <TabsTrigger value="team">
              <Users className="w-4 h-4 mr-2" />
              Team
            </TabsTrigger>
            <TabsTrigger value="billing">
              <CreditCard className="w-4 h-4 mr-2" />
              Billing
            </TabsTrigger>
            <TabsTrigger value="advanced">
              <Settings className="w-4 h-4 mr-2" />
              Advanced
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <GeneralSettings organization={organization} />
          </TabsContent>

          <TabsContent value="branding">
            <BrandingSettings organization={organization} />
          </TabsContent>

          <TabsContent value="team">
            <TeamManagement 
              organization={organization} 
              invites={invites}
              users={orgUsers}
            />
          </TabsContent>

          <TabsContent value="billing">
            <BillingSettings subscription={subscription} organization={organization} />
          </TabsContent>

          <TabsContent value="advanced">
            <AdvancedSettings organization={organization} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function GeneralSettings({ organization }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: organization?.name || '',
    location: organization?.location || '',
    industry: organization?.industry || '',
    mission: organization?.mission || '',
    vision: organization?.vision || '',
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Organization.update(organization.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
      alert('Organization updated successfully!');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>General Information</CardTitle>
        <CardDescription>Update your organization's basic information</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Organization Name</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Location</label>
            <Input
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Industry</label>
            <Input
              value={formData.industry}
              onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Mission Statement</label>
            <Textarea
              value={formData.mission}
              onChange={(e) => setFormData({ ...formData, mission: e.target.value })}
              rows={3}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Vision</label>
            <Textarea
              value={formData.vision}
              onChange={(e) => setFormData({ ...formData, vision: e.target.value })}
              rows={3}
            />
          </div>
          <Button type="submit" className="bg-gradient-to-r from-[#B8967D] to-[#A68364]">
            Save Changes
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function BrandingSettings({ organization }) {
  const queryClient = useQueryClient();
  const [logoUrl, setLogoUrl] = useState(organization?.logo_url || '');
  const [primaryColor, setPrimaryColor] = useState(organization?.primary_color || '#B8967D');
  const [uploading, setUploading] = useState(false);

  const updateBrandingMutation = useMutation({
    mutationFn: (data) => base44.entities.Organization.update(organization.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
      alert('Branding updated successfully!');
    },
  });

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setLogoUrl(result.file_url);
      alert('Logo uploaded! Click "Save Branding" to apply changes.');
    } catch (error) {
      alert('Error uploading logo. Please try again.');
      console.error(error);
    }
    setUploading(false);
  };

  const handleSave = () => {
    updateBrandingMutation.mutate({
      logo_url: logoUrl,
      primary_color: primaryColor,
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Report Branding</CardTitle>
        <CardDescription>Customize how your organization appears on reports</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Logo Upload */}
        <div>
          <label className="block text-sm font-medium mb-2">Organization Logo</label>
          <div className="space-y-4">
            {logoUrl && (
              <div className="p-4 border-2 border-dashed rounded-lg bg-stone-50">
                <img 
                  src={logoUrl} 
                  alt="Organization Logo Preview" 
                  className="h-24 object-contain mx-auto"
                />
              </div>
            )}
            <div className="flex items-center gap-3">
              <label className="flex-1">
                <div className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-stone-300 rounded-lg hover:border-[#B8967D] cursor-pointer transition-colors">
                  <Upload className="w-5 h-5 text-stone-600" />
                  <span className="text-sm text-stone-600">
                    {uploading ? 'Uploading...' : 'Upload Logo'}
                  </span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  disabled={uploading}
                  className="hidden"
                />
              </label>
            </div>
            <p className="text-xs text-stone-500">
              Recommended: PNG or SVG format, transparent background, max 2MB
            </p>
          </div>
        </div>

        {/* Logo URL Input (alternative) */}
        <div>
          <label className="block text-sm font-medium mb-2">Or enter Logo URL</label>
          <Input
            value={logoUrl}
            onChange={(e) => setLogoUrl(e.target.value)}
            placeholder="https://example.com/logo.png"
          />
        </div>

        {/* Primary Color */}
        <div>
          <label className="block text-sm font-medium mb-2">Primary Brand Color</label>
          <div className="flex items-center gap-4">
            <input
              type="color"
              value={primaryColor}
              onChange={(e) => setPrimaryColor(e.target.value)}
              className="h-12 w-24 rounded border cursor-pointer"
            />
            <Input
              value={primaryColor}
              onChange={(e) => setPrimaryColor(e.target.value)}
              placeholder="#B8967D"
              className="flex-1"
            />
          </div>
          <p className="text-xs text-stone-500 mt-2">
            This color will be used for accents in your reports
          </p>
        </div>

        {/* Preview */}
        <div className="p-6 border-2 rounded-lg bg-white">
          <h3 className="text-sm font-medium mb-3">Report Header Preview</h3>
          <div className="border-b-4 pb-4 flex items-start justify-between" style={{ borderColor: primaryColor }}>
            <div>
              {logoUrl && (
                <img src={logoUrl} alt="Logo" className="h-12 mb-2 object-contain" />
              )}
              <p className="font-bold text-lg">{organization?.name || 'Your Organization'}</p>
              <p className="text-sm text-stone-600">Assessment Report</p>
            </div>
          </div>
        </div>

        <Button 
          onClick={handleSave} 
          disabled={updateBrandingMutation.isPending}
          className="bg-gradient-to-r from-[#B8967D] to-[#A68364]"
        >
          {updateBrandingMutation.isPending ? 'Saving...' : 'Save Branding'}
        </Button>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-900">
            <strong>Note:</strong> Your logo and brand colors will appear on all assessment reports 
            generated by your employees through the Report Generator.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function TeamManagement({ organization, invites, users }) {
  const queryClient = useQueryClient();
  const [inviteData, setInviteData] = useState({
    email: '',
    role: 'employee',
    department: '',
    job_title: '',
  });

  const sendInviteMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();
      const inviteCode = Math.random().toString(36).substring(2, 15);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      return base44.entities.OrganizationInvite.create({
        organization_id: organization.id,
        email: data.email,
        role: data.role,
        department: data.department,
        job_title: data.job_title,
        invited_by: user.email,
        invite_code: inviteCode,
        status: 'pending',
        expires_at: expiresAt.toISOString(),
      });
    },
    onSuccess: async (invite) => {
      // Send email via Core.SendEmail
      await base44.integrations.Core.SendEmail({
        from_name: organization.name,
        to: invite.email,
        subject: `You're invited to join ${organization.name} on Luminous Prosperity`,
        body: `You've been invited to join ${organization.name} on the Luminous Prosperity platform.

Your invite code: ${invite.invite_code}

Click here to accept: ${window.location.origin}/accept-invite?code=${invite.invite_code}

This invite expires in 7 days.

Role: ${invite.role}
Department: ${invite.department || 'Not specified'}

Welcome to the team!`
      });

      queryClient.invalidateQueries({ queryKey: ['orgInvites'] });
      setInviteData({ email: '', role: 'employee', department: '', job_title: '' });
      alert('Invitation sent!');
    },
  });

  const handleInvite = (e) => {
    e.preventDefault();
    sendInviteMutation.mutate(inviteData);
  };

  const pendingInvites = invites.filter(i => i.status === 'pending');

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Invite Team Members</CardTitle>
          <CardDescription>Send invitations to new employees</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleInvite} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <Input
                  type="email"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                  placeholder="employee@company.com"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Role</label>
                <Select value={inviteData.role} onValueChange={(value) => setInviteData({ ...inviteData, role: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employee">Employee</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="executive">Executive</SelectItem>
                    <SelectItem value="c_suite">C-Suite</SelectItem>
                    <SelectItem value="org_admin">Organization Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Department</label>
                <Input
                  value={inviteData.department}
                  onChange={(e) => setInviteData({ ...inviteData, department: e.target.value })}
                  placeholder="Engineering"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Job Title</label>
                <Input
                  value={inviteData.job_title}
                  onChange={(e) => setInviteData({ ...inviteData, job_title: e.target.value })}
                  placeholder="Software Engineer"
                />
              </div>
            </div>
            <Button type="submit" className="bg-gradient-to-r from-[#B8967D] to-[#A68364]">
              <UserPlus className="w-4 h-4 mr-2" />
              Send Invitation
            </Button>
          </form>
        </CardContent>
      </Card>

      {pendingInvites.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Pending Invitations ({pendingInvites.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingInvites.map((invite) => (
                <div key={invite.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{invite.email}</p>
                    <p className="text-sm text-stone-600">
                      {invite.role} • {invite.department || 'No department'}
                    </p>
                  </div>
                  <Badge>Pending</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Team Members ({users.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {users.slice(0, 10).map((member) => (
              <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">{member.full_name || member.email}</p>
                  <p className="text-sm text-stone-600">
                    {member.job_title} • {member.department}
                  </p>
                </div>
                <Badge>{member.user_role || 'employee'}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function BillingSettings({ subscription, organization }) {
  if (!subscription) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Subscription</CardTitle>
          <CardDescription>Contact support to set up billing</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const daysUntilTrial = subscription.trial_end_date 
    ? Math.ceil((new Date(subscription.trial_end_date) - new Date()) / (1000 * 60 * 60 * 24))
    : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Current Plan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-stone-50 rounded-lg">
            <div>
              <p className="text-2xl font-bold text-stone-800">
                {subscription.plan_name.replace('_', ' ').toUpperCase()}
              </p>
              <p className="text-sm text-stone-600">
                ${subscription.monthly_price.toLocaleString()}/month
              </p>
            </div>
            <Badge className={
              subscription.status === 'active' ? 'bg-green-100 text-green-700' :
              subscription.status === 'trial' ? 'bg-blue-100 text-blue-700' :
              'bg-red-100 text-red-700'
            }>
              {subscription.status}
            </Badge>
          </div>

          {subscription.status === 'trial' && daysUntilTrial > 0 && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-900">
                <strong>Trial Period:</strong> {daysUntilTrial} days remaining
              </p>
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-stone-600 mb-1">Included Seats</p>
              <p className="text-2xl font-bold">{subscription.seats_included}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600 mb-1">Seats Used</p>
              <p className="text-2xl font-bold">{subscription.seats_used}</p>
            </div>
          </div>

          {subscription.features && (
            <div>
              <p className="text-sm font-medium text-stone-700 mb-2">Included Features:</p>
              <div className="flex flex-wrap gap-2">
                {subscription.features.map((feature, idx) => (
                  <Badge key={idx} variant="outline">
                    {feature.replace(/_/g, ' ')}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {subscription.next_billing_date && (
            <div className="pt-4 border-t">
              <p className="text-sm text-stone-600">
                Next billing date: {new Date(subscription.next_billing_date).toLocaleDateString()}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Billing Contact</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm text-stone-600">
              Email: {subscription.billing_email || 'Not set'}
            </p>
            <p className="text-sm text-stone-600">
              Contact: {subscription.billing_contact_name || 'Not set'}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdvancedSettings({ organization }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Advanced Settings</CardTitle>
        <CardDescription>Organization configuration options</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="font-medium mb-2">Organization ID</h3>
            <code className="text-xs bg-stone-100 px-3 py-2 rounded block">
              {organization?.id}
            </code>
          </div>
          <div>
            <h3 className="font-medium mb-2">Email Domain</h3>
            <p className="text-sm text-stone-600">{organization?.domain || 'Not set'}</p>
          </div>
          <div>
            <h3 className="font-medium mb-2">Status</h3>
            <Badge>{organization?.status || 'active'}</Badge>
          </div>
          <div className="pt-4 border-t">
            <p className="text-xs text-stone-500">
              For additional configuration options, please contact support.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
