import React, { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Brain, Target, TrendingUp, Sparkles, RefreshCw, CheckCircle2, ArrowLeft } from "lucide-react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import ReactMarkdown from "react-markdown";

export default function TeamInsights() {
  const [searchParams] = useSearchParams();
  const campaignId = searchParams.get('campaign');
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: campaign } = useQuery({
    queryKey: ['campaign', campaignId],
    queryFn: async () => {
      if (!campaignId) return null;
      const campaigns = await base44.entities.TeamAssessmentCampaign.list();
      return campaigns.find(c => c.id === campaignId);
    },
    enabled: !!campaignId,
  });

  const { data: teamAssessments } = useQuery({
    queryKey: ['teamAssessments', campaignId],
    queryFn: async () => {
      if (!campaign) return [];
      const allAssessments = await base44.entities.Assessment.list('-completed_date');
      return allAssessments.filter(a => 
        campaign.target_emails.includes(a.user_email) &&
        new Date(a.completed_date) >= new Date(campaign.created_date)
      );
    },
    enabled: !!campaign,
    initialData: [],
  });

  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TeamAssessmentCampaign.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaign', campaignId] });
    },
  });

  const generateInsights = async () => {
    if (!campaign || teamAssessments.length === 0) {
      alert("Not enough data to generate insights");
      return;
    }

    setIsGenerating(true);
    try {
      // Analyze personality distribution
      const personalityDist = {};
      teamAssessments.forEach(a => {
        if (a.myers_briggs?.type) {
          personalityDist[a.myers_briggs.type] = (personalityDist[a.myers_briggs.type] || 0) + 1;
        }
      });

      // Analyze strength patterns
      const strengthPatterns = {};
      teamAssessments.forEach(a => {
        if (a.strengths?.top_strengths) {
          a.strengths.top_strengths.forEach(s => {
            if (!strengthPatterns[s.name]) {
              strengthPatterns[s.name] = { count: 0, totalScore: 0 };
            }
            strengthPatterns[s.name].count++;
            strengthPatterns[s.name].totalScore += s.score;
          });
        }
      });

      // Calculate average life satisfaction
      let totalSatisfaction = 0;
      let satisfactionCount = 0;
      teamAssessments.forEach(a => {
        if (a.life_wheel?.overall_satisfaction) {
          totalSatisfaction += a.life_wheel.overall_satisfaction;
          satisfactionCount++;
        }
      });
      const avgLifeSatisfaction = satisfactionCount > 0 ? Math.round(totalSatisfaction / satisfactionCount) : 0;

      // Generate AI analysis
      const teamDynamicsAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert team psychologist and organizational consultant.

Analyze this team assessment data and provide comprehensive insights (600-800 words):

TEAM: ${campaign.name}
SIZE: ${teamAssessments.length} members
DEPARTMENT: ${campaign.department || 'Various'}

PERSONALITY DISTRIBUTION:
${JSON.stringify(personalityDist, null, 2)}

TOP TEAM STRENGTHS (by frequency):
${JSON.stringify(
  Object.entries(strengthPatterns)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 10)
    .map(([name, data]) => ({ name, count: data.count, avgScore: Math.round(data.totalScore / data.count) })),
  null, 2
)}

AVERAGE LIFE SATISFACTION: ${avgLifeSatisfaction}%

INDIVIDUAL INSIGHTS SUMMARY:
${teamAssessments.map((a, idx) => `
Member ${idx + 1}:
- Personality: ${a.myers_briggs?.type || 'N/A'}
- Top Strength: ${a.strengths?.top_strengths?.[0]?.name || 'N/A'}
- Life Satisfaction: ${a.life_wheel?.overall_satisfaction || 'N/A'}%
- Primary Intelligence: ${a.integral_theory?.primary_line?.replace(/_/g, ' ') || 'N/A'}
`).join('\n')}

Provide:
1. Team composition analysis (personality diversity, balance, potential blind spots)
2. Collective strengths and how to leverage them
3. Team dynamics insights (complementary skills, potential conflicts)
4. Collaboration opportunities based on individual profiles
5. Well-being assessment and recommendations
6. Optimal team structure and role assignments
7. Development priorities for the team
8. Specific strategies to maximize team effectiveness
9. How to integrate individual aspirations with team goals

Be specific, actionable, and data-driven. Write for a manager seeking to optimize team performance.`,
      });

      const recommendations = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on the team analysis above, provide 8-10 specific, actionable recommendations for the team manager.

Focus on:
- Team composition optimization
- Role assignments
- Collaboration strategies
- Development initiatives
- Well-being improvements
- Performance enhancement`,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      const collaborationOpportunities = await base44.integrations.Core.InvokeLLM({
        prompt: `Identify 5-7 specific collaboration opportunities based on complementary strengths and skills in the team.

For each opportunity, describe:
- Who should collaborate
- What skills/strengths complement each other
- What type of projects or initiatives would benefit`,
        response_json_schema: {
          type: "object",
          properties: {
            opportunities: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      // Update campaign with insights
      await updateCampaignMutation.mutateAsync({
        id: campaign.id,
        data: {
          insights_generated: true,
          completed_count: teamAssessments.length,
          team_insights: {
            personality_distribution: personalityDist,
            strength_patterns: strengthPatterns,
            avg_life_satisfaction: avgLifeSatisfaction,
            team_dynamics_analysis: teamDynamicsAnalysis,
            recommendations: recommendations.recommendations,
            collaboration_opportunities: collaborationOpportunities.opportunities,
          },
        },
      });

    } catch (error) {
      console.error("Error generating insights:", error);
      alert("Error generating insights. Please try again.");
    }
    setIsGenerating(false);
  };

  if (!campaign) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md text-center p-8">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">Campaign Not Found</h2>
          <p className="text-gray-600 mb-6">The requested campaign could not be found</p>
          <Link to={createPageUrl("TeamAssessments")}>
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Campaigns
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const COLORS = ['#8b5cf6', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#6366f1'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to={createPageUrl("TeamAssessments")} className="text-sm text-indigo-600 hover:text-indigo-700 mb-2 inline-flex items-center gap-1">
              <ArrowLeft className="w-4 h-4" />
              Back to Campaigns
            </Link>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{campaign.name}</h1>
            <p className="text-gray-600">{campaign.description}</p>
          </div>
          {!campaign.insights_generated && teamAssessments.length > 0 && (
            <Button
              onClick={generateInsights}
              disabled={isGenerating}
              className="bg-gradient-to-r from-indigo-600 to-purple-600"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                  Generating Insights...
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Generate Team Insights
                </>
              )}
            </Button>
          )}
          {campaign.insights_generated && (
            <Button
              onClick={generateInsights}
              disabled={isGenerating}
              variant="outline"
            >
              <RefreshCw className="w-5 h-5 mr-2" />
              Regenerate Insights
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-indigo-100">Team Size</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{campaign.target_emails.length}</div>
              <p className="text-xs text-indigo-100 mt-1">invited members</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-purple-100">Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{teamAssessments.length}</div>
              <p className="text-xs text-purple-100 mt-1">assessments submitted</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-blue-100">Completion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {Math.round((teamAssessments.length / campaign.target_emails.length) * 100)}%
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-100">Avg Life Satisfaction</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">
                {campaign.team_insights?.avg_life_satisfaction || 'N/A'}
                {campaign.team_insights?.avg_life_satisfaction && '%'}
              </div>
            </CardContent>
          </Card>
        </div>

        {teamAssessments.length === 0 ? (
          <Card className="text-center py-20">
            <CardContent>
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Waiting for Responses</h3>
              <p className="text-gray-500 mb-4">
                No team members have completed their assessments yet
              </p>
              <p className="text-sm text-gray-500">
                {campaign.target_emails.length} invitations sent
              </p>
            </CardContent>
          </Card>
        ) : !campaign.insights_generated ? (
          <Card className="text-center py-20 border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
            <CardContent>
              <Sparkles className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Ready to Generate Insights</h3>
              <p className="text-gray-600 mb-6">
                {teamAssessments.length} team member{teamAssessments.length !== 1 && 's'} completed their assessment{teamAssessments.length !== 1 && 's'}
              </p>
              <Button
                onClick={generateInsights}
                disabled={isGenerating}
                className="bg-gradient-to-r from-indigo-600 to-purple-600"
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing Team Data...
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Generate Team Insights
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* AI Analysis */}
            <Card className="border-2 border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-2xl">
                  <Sparkles className="w-6 h-6 text-indigo-600" />
                  Team Dynamics Analysis
                </CardTitle>
                <CardDescription>AI-generated comprehensive team insights</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="prose prose-indigo max-w-none">
                  <ReactMarkdown>{campaign.team_insights.team_dynamics_analysis}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="personality" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="personality">Personality</TabsTrigger>
                <TabsTrigger value="strengths">Strengths</TabsTrigger>
                <TabsTrigger value="recommendations">Actions</TabsTrigger>
                <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
              </TabsList>

              <TabsContent value="personality">
                <Card>
                  <CardHeader>
                    <CardTitle>Personality Type Distribution</CardTitle>
                    <CardDescription>Myers-Briggs types across the team</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <PieChart>
                        <Pie
                          data={Object.entries(campaign.team_insights.personality_distribution).map(([name, value]) => ({
                            name,
                            value
                          }))}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                          outerRadius={120}
                          dataKey="value"
                        >
                          {Object.keys(campaign.team_insights.personality_distribution).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="strengths">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Team Strengths</CardTitle>
                    <CardDescription>Most common character strengths in your team</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart
                        data={Object.entries(campaign.team_insights.strength_patterns)
                          .sort((a, b) => b[1].count - a[1].count)
                          .slice(0, 10)
                          .map(([name, data]) => ({
                            name,
                            count: data.count,
                          }))}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#8b5cf6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recommendations">
                <Card>
                  <CardHeader>
                    <CardTitle>Action Recommendations</CardTitle>
                    <CardDescription>Data-driven suggestions for team development</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {campaign.team_insights.recommendations?.map((rec, idx) => (
                        <div key={idx} className="flex items-start gap-3 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                          <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold flex-shrink-0">
                            {idx + 1}
                          </div>
                          <p className="text-gray-800 leading-relaxed">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="collaboration">
                <Card>
                  <CardHeader>
                    <CardTitle>Collaboration Opportunities</CardTitle>
                    <CardDescription>Strategic pairing and team synergies</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {campaign.team_insights.collaboration_opportunities?.map((opp, idx) => (
                        <div key={idx} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                          <div className="flex items-start gap-3">
                            <Target className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                            <p className="text-gray-800 leading-relaxed">{opp}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
}