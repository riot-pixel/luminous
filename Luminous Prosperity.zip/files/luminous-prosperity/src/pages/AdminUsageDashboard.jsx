import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, TrendingUp, TrendingDown, Eye, Sparkles, 
  Users, Star, AlertCircle, Lightbulb, Zap, ArrowUpRight 
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import PlatformUsageAdvisor from "../components/analytics/PlatformUsageAdvisor";

const COLORS = ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

export default function AdminUsageDashboard() {
  const { data: users } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: reports } = useQuery({
    queryKey: ['customReports'],
    queryFn: () => base44.entities.CustomReport.list(),
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['allLearningJourneys'],
    queryFn: () => base44.entities.LearningJourney.list(),
    initialData: [],
  });

  const { data: usageAnalyses } = useQuery({
    queryKey: ['platformUsageAnalytics'],
    queryFn: () => base44.entities.PlatformUsageAnalytics.list('-analysis_date', 10),
    initialData: [],
  });

  const latestAnalysis = usageAnalyses?.[0];

  // Category distribution
  const categoryData = latestAnalysis?.feature_usage?.reduce((acc, f) => {
    const existing = acc.find(a => a.category === f.category);
    if (existing) {
      existing.count += f.usage_count;
    } else {
      acc.push({ category: f.category, count: f.usage_count });
    }
    return acc;
  }, []) || [];

  // Trend data
  const trendData = latestAnalysis?.feature_usage?.slice(0, 10).map(f => ({
    name: f.feature_name,
    usage: f.usage_count,
    users: f.unique_users
  })) || [];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-light text-white mb-2">Platform Usage Dashboard</h1>
          <p className="text-gray-400">AI-powered insights into feature adoption and user engagement</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-900 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Total Users</p>
                <p className="text-2xl font-bold text-white">{users.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                <Eye className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Active Features</p>
                <p className="text-2xl font-bold text-white">{latestAnalysis?.feature_usage?.length || 14}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-900 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Avg Engagement</p>
                <p className="text-2xl font-bold text-white">
                  {latestAnalysis?.feature_usage?.length > 0 
                    ? Math.round(latestAnalysis.feature_usage.reduce((acc, f) => acc + f.unique_users, 0) / latestAnalysis.feature_usage.length)
                    : 0}
                </p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-orange-900 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-orange-400" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Underutilized</p>
                <p className="text-2xl font-bold text-white">{latestAnalysis?.underutilized_features?.length || 0}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="overview"><BarChart3 className="w-4 h-4 mr-1" />Overview</TabsTrigger>
            <TabsTrigger value="trends"><TrendingUp className="w-4 h-4 mr-1" />Trends</TabsTrigger>
            <TabsTrigger value="insights"><Sparkles className="w-4 h-4 mr-1" />AI Insights</TabsTrigger>
            <TabsTrigger value="advisor"><Brain className="w-4 h-4 mr-1" />Full Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Feature Usage Chart */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Top Features by Usage</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={trendData}>
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} stroke="#666" fontSize={10} />
                      <YAxis stroke="#666" />
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                      <Bar dataKey="usage" fill="#8b5cf6" name="Total Uses" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Category Distribution */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Usage by Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={categoryData}
                        dataKey="count"
                        nameKey="category"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        label={(entry) => entry.category}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trends">
            <div className="space-y-4">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Feature Adoption Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {latestAnalysis?.feature_usage?.sort((a, b) => Math.abs(b.growth_rate) - Math.abs(a.growth_rate)).slice(0, 10).map((feature, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                        <div className="flex-1">
                          <p className="text-white font-medium">{feature.feature_name}</p>
                          <div className="flex gap-2 text-xs text-gray-400 mt-1">
                            <span>{feature.usage_count} uses</span>
                            <span>•</span>
                            <span>{feature.unique_users} users</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="border-gray-700 text-gray-400">{feature.category}</Badge>
                          <div className="flex items-center gap-1">
                            {feature.growth_rate > 0 ? (
                              <ArrowUpRight className="w-4 h-4 text-green-400" />
                            ) : (
                              <TrendingDown className="w-4 h-4 text-red-400" />
                            )}
                            <span className={feature.growth_rate > 0 ? 'text-green-400' : 'text-red-400'}>
                              {feature.growth_rate > 0 ? '+' : ''}{feature.growth_rate}%
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="insights">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Popular Features */}
              {latestAnalysis?.popular_features?.length > 0 && (
                <Card className="bg-green-900/20 border-green-800">
                  <CardHeader>
                    <CardTitle className="text-green-400 flex items-center gap-2">
                      <Star className="w-5 h-5" />Top Performing Features
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestAnalysis.popular_features.map((feature, i) => (
                        <div key={i} className="p-3 bg-green-900/20 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-white font-medium">{feature.feature_name}</p>
                            <Badge className="bg-green-600">{feature.engagement_score}</Badge>
                          </div>
                          <p className="text-gray-400 text-sm mb-2">{feature.user_satisfaction}</p>
                          <div className="space-y-1">
                            {feature.expansion_opportunities?.slice(0, 2).map((opp, j) => (
                              <p key={j} className="text-green-400 text-xs flex items-start gap-1">
                                <ArrowUpRight className="w-3 h-3 mt-0.5" />{opp}
                              </p>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Underutilized Features */}
              {latestAnalysis?.underutilized_features?.length > 0 && (
                <Card className="bg-orange-900/20 border-orange-800">
                  <CardHeader>
                    <CardTitle className="text-orange-400 flex items-center gap-2">
                      <AlertCircle className="w-5 h-5" />Underutilized Features
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestAnalysis.underutilized_features.map((feature, i) => (
                        <div key={i} className="p-3 bg-orange-900/20 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-white font-medium">{feature.feature_name}</p>
                            <Badge variant="outline" className="border-orange-600 text-orange-400">
                              {feature.current_usage} uses
                            </Badge>
                          </div>
                          <p className="text-gray-400 text-sm mb-2">{feature.potential_value}</p>
                          <div className="p-2 bg-gray-800 rounded">
                            <p className="text-cyan-400 text-xs">{feature.promotion_strategy}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Improvement Suggestions */}
              {latestAnalysis?.ai_improvement_suggestions?.length > 0 && (
                <Card className="bg-purple-900/20 border-purple-800">
                  <CardHeader>
                    <CardTitle className="text-purple-400 flex items-center gap-2">
                      <Lightbulb className="w-5 h-5" />AI Improvement Suggestions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestAnalysis.ai_improvement_suggestions
                        .sort((a, b) => b.priority_score - a.priority_score)
                        .slice(0, 6)
                        .map((sugg, i) => (
                        <div key={i} className="p-3 bg-purple-900/20 rounded-lg">
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-white text-sm font-medium">{sugg.suggestion}</p>
                            <Badge className="bg-purple-600 text-xs">{sugg.priority_score}</Badge>
                          </div>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="outline" className="text-xs border-gray-700">{sugg.category}</Badge>
                            <Badge className={`text-xs ${sugg.impact === 'high' ? 'bg-green-600' : sugg.impact === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'}`}>
                              {sugg.impact} impact
                            </Badge>
                            <Badge className={`text-xs ${sugg.effort === 'low' ? 'bg-green-600' : sugg.effort === 'medium' ? 'bg-yellow-600' : 'bg-red-600'}`}>
                              {sugg.effort} effort
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* New Feature Ideas */}
              {latestAnalysis?.new_feature_recommendations?.length > 0 && (
                <Card className="bg-cyan-900/20 border-cyan-800">
                  <CardHeader>
                    <CardTitle className="text-cyan-400 flex items-center gap-2">
                      <Zap className="w-5 h-5" />New Feature Ideas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {latestAnalysis.new_feature_recommendations.slice(0, 4).map((rec, i) => (
                        <div key={i} className="p-3 bg-cyan-900/20 rounded-lg">
                          <p className="text-white font-medium mb-1">{rec.feature_idea}</p>
                          <p className="text-gray-400 text-xs mb-2">{rec.based_on}</p>
                          <div className="flex gap-2">
                            <Badge className="bg-green-600 text-xs">Adoption: {rec.expected_adoption}</Badge>
                            <Badge className={`text-xs ${
                              rec.development_complexity === 'low' ? 'bg-green-600' :
                              rec.development_complexity === 'medium' ? 'bg-yellow-600' : 'bg-red-600'
                            }`}>
                              {rec.development_complexity} complexity
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="advisor">
            <PlatformUsageAdvisor
              users={users}
              assessments={assessments}
              reports={reports}
              learningJourneys={learningJourneys}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}