import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Target, Mail, ChevronRight, Plus, Sparkles } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Teams() {
  const queryClient = useQueryClient();
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: teams, isLoading } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list('-created_date'),
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const createTeamMutation = useMutation({
    mutationFn: (teamData) => base44.entities.Team.create(teamData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
      setIsCreateDialogOpen(false);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Sparkles className="w-12 h-12 text-purple-600 animate-spin" />
      </div>
    );
  }

  const latestAssessments = assessments.reduce((acc, assessment) => {
    if (!acc[assessment.user_email] || new Date(assessment.completed_date) > new Date(acc[assessment.user_email].completed_date)) {
      acc[assessment.user_email] = assessment;
    }
    return acc;
  }, {});

  const getTeamMembers = (team) => {
    return employees.filter(emp => team.member_emails?.includes(emp.email));
  };

  const statusColors = {
    active: "bg-green-100 text-green-700",
    planning: "bg-blue-100 text-blue-700",
    completed: "bg-purple-100 text-purple-700",
    archived: "bg-gray-100 text-gray-700",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Teams</h1>
            <p className="text-gray-600">Manage and monitor team composition and performance</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                <Plus className="w-5 h-5 mr-2" />
                New Team
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Team</DialogTitle>
                <DialogDescription>Set up a new team with goals and members</DialogDescription>
              </DialogHeader>
              <CreateTeamForm onSubmit={(data) => createTeamMutation.mutate(data)} employees={employees} />
            </DialogContent>
          </Dialog>
        </div>

        {teams.length === 0 ? (
          <Card className="text-center py-20">
            <CardContent>
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No teams yet</h3>
              <p className="text-gray-500 mb-6">Create your first team to get started</p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="w-5 h-5 mr-2" />
                Create Team
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map(team => {
              const members = getTeamMembers(team);
              return (
                <Card key={team.id} className="hover:shadow-xl transition-all duration-300 cursor-pointer group">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2 group-hover:text-purple-600 transition-colors">
                          {team.name}
                        </CardTitle>
                        <CardDescription className="line-clamp-2">{team.description}</CardDescription>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-purple-600 group-hover:translate-x-1 transition-all" />
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Badge className={statusColors[team.status] || statusColors.active}>
                        {team.status}
                      </Badge>
                      {team.department && (
                        <Badge variant="outline">{team.department}</Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          Team Members ({members.length})
                        </p>
                        <div className="flex -space-x-2">
                          {members.slice(0, 5).map((member, idx) => (
                            <div
                              key={idx}
                              className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white text-xs font-bold border-2 border-white"
                              title={member.full_name || member.email}
                            >
                              {(member.full_name || member.email).charAt(0).toUpperCase()}
                            </div>
                          ))}
                          {members.length > 5 && (
                            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 text-xs font-bold border-2 border-white">
                              +{members.length - 5}
                            </div>
                          )}
                        </div>
                      </div>

                      {team.goals && team.goals.length > 0 && (
                        <div>
                          <p className="text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            Key Goals
                          </p>
                          <ul className="space-y-1">
                            {team.goals.slice(0, 2).map((goal, idx) => (
                              <li key={idx} className="text-sm text-gray-600 truncate">• {goal}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {members.length > 0 && (
                        <div className="pt-3 border-t border-gray-100">
                          <p className="text-xs text-gray-500 mb-2">Team Personality Mix:</p>
                          <div className="flex flex-wrap gap-1">
                            {members
                              .map(m => latestAssessments[m.email]?.myers_briggs?.type)
                              .filter(Boolean)
                              .slice(0, 4)
                              .map((type, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {type}
                                </Badge>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function CreateTeamForm({ onSubmit, employees }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    department: "",
    leader_email: "",
    member_emails: [],
    goals: "",
    required_skills: "",
    status: "planning",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      goals: formData.goals.split('\n').filter(g => g.trim()),
      required_skills: formData.required_skills.split(',').map(s => s.trim()).filter(s => s),
      member_emails: formData.member_emails,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="text-sm font-medium">Team Name</label>
        <Input
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., Product Innovation Team"
          required
        />
      </div>

      <div>
        <label className="text-sm font-medium">Description</label>
        <Textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Brief description of the team's purpose"
          rows={3}
        />
      </div>

      <div>
        <label className="text-sm font-medium">Department</label>
        <Input
          value={formData.department}
          onChange={(e) => setFormData({ ...formData, department: e.target.value })}
          placeholder="e.g., Engineering, Marketing"
          required
        />
      </div>

      <div>
        <label className="text-sm font-medium">Team Leader</label>
        <Select value={formData.leader_email} onValueChange={(value) => setFormData({ ...formData, leader_email: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select team leader" />
          </SelectTrigger>
          <SelectContent>
            {employees.map(emp => (
              <SelectItem key={emp.email} value={emp.email}>
                {emp.full_name || emp.email}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <label className="text-sm font-medium">Goals (one per line)</label>
        <Textarea
          value={formData.goals}
          onChange={(e) => setFormData({ ...formData, goals: e.target.value })}
          placeholder="Launch MVP&#10;Increase user engagement&#10;Improve performance"
          rows={4}
        />
      </div>

      <Button type="submit" className="w-full">Create Team</Button>
    </form>
  );
}