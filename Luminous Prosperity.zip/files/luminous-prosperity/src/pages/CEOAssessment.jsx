import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Building2, TrendingUp, Users, Target, Heart } from "lucide-react";
import CEOLeadershipSection from "../components/ceo/CEOLeadershipSection";
import CEOVisionSection from "../components/ceo/CEOVisionSection";
import CEOStakeholderSection from "../components/ceo/CEOStakeholderSection";
import CEOIntegralSection from "../components/ceo/CEOIntegralSection";
import CEOAppreciativeSection from "../components/ceo/CEOAppreciativeSection";

export default function CEOAssessment() {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [assessmentData, setAssessmentData] = useState({
    leadership: null,
    vision: null,
    stakeholders: null,
    integral: null,
    appreciative: null,
  });

  const { data: organizations } = useQuery({
    queryKey: ['organizations'],
    queryFn: () => base44.entities.Organization.list(),
    initialData: [],
  });

  const sections = [
    { name: "Leadership Style", key: "leadership", component: CEOLeadershipSection, icon: Users },
    { name: "Strategic Vision", key: "vision", component: CEOVisionSection, icon: Target },
    { name: "Stakeholder Orientation", key: "stakeholders", component: CEOStakeholderSection, icon: TrendingUp },
    { name: "Integral Leadership", key: "integral", component: CEOIntegralSection, icon: Building2 },
    { name: "Organizational AI", key: "appreciative", component: CEOAppreciativeSection, icon: Heart },
  ];

  const CurrentSectionComponent = sections[currentSection].component;

  const handleSectionComplete = (data) => {
    const key = sections[currentSection].key;
    setAssessmentData(prev => ({
      ...prev,
      [key]: data,
    }));

    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      completeAssessment({
        ...assessmentData,
        [key]: data,
      });
    }
  };

  const completeAssessment = async (finalData) => {
    setIsProcessing(true);
    try {
      const user = await base44.auth.me();
      
      const insights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert executive coach and organizational psychologist specializing in CEO development and leadership effectiveness.

Based on the following CEO leadership assessment, provide deeply insightful analysis (400-500 words):

CEO Assessment Data:
${JSON.stringify(finalData, null, 2)}

Provide comprehensive insights covering:
1. Leadership effectiveness and style alignment with organizational needs
2. Strategic thinking capabilities and vision clarity
3. Stakeholder management approach and relationship building
4. Integral awareness and systems thinking capacity
5. Capacity for organizational transformation and change leadership
6. Key strengths to leverage for maximum impact
7. Development opportunities for enhanced effectiveness
8. Specific recommendations for integrating leadership with organizational strategy and human capital

Write in a professional, empowering coaching tone. Be specific, actionable, and data-driven.`,
      });

      const orgId = organizations.length > 0 ? organizations[0].id : null;

      await base44.entities.CEOAssessment.create({
        user_email: user.email,
        organization_id: orgId,
        completed_date: new Date().toISOString(),
        leadership_style: finalData.leadership,
        strategic_vision: finalData.vision,
        stakeholder_orientation: finalData.stakeholders,
        integral_perspective: finalData.integral,
        appreciative_inquiry: finalData.appreciative,
        ai_insights: insights,
      });

      navigate(createPageUrl("CEODashboard"));
    } catch (error) {
      console.error("Error saving CEO assessment:", error);
    }
    setIsProcessing(false);
  };

  const handleBack = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-indigo-100 rounded-full px-5 py-2 text-indigo-700 text-sm font-medium mb-4">
            <Building2 className="w-4 h-4" />
            <span>Executive Leadership Assessment</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">CEO Assessment</h1>
          <p className="text-xl text-gray-600">Align your leadership with organizational strategy and human capital</p>
        </div>

        {/* Progress Tracker */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm font-medium text-gray-600">
              Section {currentSection + 1} of {sections.length}
            </span>
            <span className="text-sm font-medium text-indigo-600">
              {Math.round(((currentSection + 1) / sections.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-gradient-to-r from-indigo-600 to-purple-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${((currentSection + 1) / sections.length) * 100}%` }}
            />
          </div>
          <div className="flex justify-between mt-4">
            {sections.map((section, idx) => {
              const Icon = section.icon;
              return (
                <div
                  key={idx}
                  className={`flex flex-col items-center ${
                    idx <= currentSection ? 'text-indigo-600' : 'text-gray-400'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                      idx <= currentSection
                        ? 'bg-indigo-100'
                        : 'bg-gray-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs text-center hidden md:block">{section.name}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Current Section */}
        <CurrentSectionComponent
          onComplete={handleSectionComplete}
          onBack={currentSection > 0 ? handleBack : null}
          initialData={assessmentData[sections[currentSection].key]}
          isProcessing={isProcessing}
        />
      </div>
    </div>
  );
}