
import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Home, FileText, User, Sparkles, Building2, Users, LayoutGrid, Briefcase, TrendingUp, Heart, LogOut, Zap, BarChart3, UserCheck, LineChart, Brain, Target, Shield, Settings, Eye, BookOpen } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('employee');
  const [checkingOnboarding, setCheckingOnboarding] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setUserRole(currentUser.user_role || 'employee');

        // Check if user needs onboarding (unless they're on the onboarding page)
        if (!currentUser.onboarding_completed && location.pathname !== '/onboarding-wizard') {
          navigate(createPageUrl("OnboardingWizard"));
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setCheckingOnboarding(false);
      }
    };
    loadUser();
  }, [location.pathname, navigate]);

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  // Show loading while checking onboarding status
  if (checkingOnboarding) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-white/50 animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm tracking-widest uppercase">Loading...</p>
        </div>
      </div>
    );
  }

  const userNavigation = [
            { title: "Home", url: createPageUrl("Home"), icon: Home },
            { title: "My Portal", url: createPageUrl("EmployeePortal"), icon: Sparkles },
            { title: "Quick Assessment", url: createPageUrl("QuickAssessment"), icon: Zap },
            { title: "Full Assessment", url: createPageUrl("Assessment"), icon: Sparkles },
            { title: "My Results", url: createPageUrl("Results"), icon: FileText },
            { title: "My Skills", url: createPageUrl("MySkills"), icon: Target },
            { title: "Skill Tracker", url: createPageUrl("SkillTrackerPage"), icon: TrendingUp },
            { title: "Career Paths", url: createPageUrl("CareerPaths"), icon: TrendingUp },
            
            { title: "Impact Ledger", url: createPageUrl("HolisticImpactDashboard"), icon: BarChart3 },
            { title: "Ecosystem Network", url: createPageUrl("EcosystemNetwork"), icon: Users },
            { title: "Generate Reports", url: createPageUrl("ReportGenerator"), icon: FileText },
          { title: "Reports Module", url: createPageUrl("ReportingModule"), icon: BarChart3 },
          { title: "Knowledge Base", url: createPageUrl("KnowledgeBase"), icon: BookOpen },
          { title: "Performance Reviews", url: createPageUrl("PerformanceReviews"), icon: UserCheck },
            { title: "Privacy Settings", url: createPageUrl("PrivacySettings"), icon: Shield },
            { title: "Profile", url: createPageUrl("Profile"), icon: User },
          ];

  const executiveNavigation = [
        { title: "Executive Portal", url: createPageUrl("ExecutivePortal"), icon: Briefcase },
        { title: "Executive Dashboard", url: createPageUrl("ExecutiveDashboard"), icon: BarChart3 },
        { title: "Win-Win Optimizer", url: createPageUrl("WinWinOptimizer"), icon: Target },
        { title: "Exponential Clarity", url: createPageUrl("ExponentialClarity"), icon: Sparkles },
              { title: "Leadership Evolution", url: createPageUrl("LeadershipEvolution"), icon: TrendingUp },
              { title: "Executive Analytics", url: createPageUrl("ExecutiveAnalytics"), icon: LineChart },
        { title: "Predictive Insights", url: createPageUrl("PredictiveInsights"), icon: Brain },
    { title: "C-Suite Intelligence", url: createPageUrl("CSuitePortal"), icon: Building2, roles: ['c_suite'] },
    { title: "Quick Leadership", url: createPageUrl("QuickExecutiveAssessment"), icon: Zap },
    { title: "Full Leadership", url: createPageUrl("CEOAssessment"), icon: TrendingUp },
    { title: "Executive Dashboard", url: createPageUrl("CEODashboard"), icon: Briefcase },
    { title: "Strategic Analysis", url: createPageUrl("OrganizationalAnalysis"), icon: Building2 },
  ].filter(item => !item.roles || item.roles.includes(userRole));

  const adminNavigation = [
                    { title: "Organization Overview", url: createPageUrl("OrganizationDashboard"), icon: LayoutGrid },
                    { title: "AI Insights", url: createPageUrl("AIInsightsDashboard"), icon: Brain },
                    { title: "Usage Dashboard", url: createPageUrl("AdminUsageDashboard"), icon: Eye },
                    { title: "AI Content Studio", url: createPageUrl("AIContentStudio"), icon: Sparkles },
                    { title: "Custom Reports", url: createPageUrl("CustomReportBuilder"), icon: FileText },
            { title: "Collaborative Workflows", url: createPageUrl("CollaborativeWorkflows"), icon: Users },
            { title: "Team Performance", url: createPageUrl("TeamPerformanceDashboard"), icon: TrendingUp },
            { title: "Team Collaboration", url: createPageUrl("TeamCollaborationHub"), icon: Users },
            { title: "Team Assessments", url: createPageUrl("TeamAssessments"), icon: UserCheck },
            { title: "Skill Matrix", url: createPageUrl("SkillMatrix"), icon: Brain },
            { title: "Skill Management", url: createPageUrl("SkillManagement"), icon: Target },
            { title: "Security Dashboard", url: createPageUrl("SecurityDashboard"), icon: Shield },
            { title: "Team Optimization", url: createPageUrl("TeamBuilder"), icon: Users },
            { title: "Team Management", url: createPageUrl("Teams"), icon: Building2 },
            { title: "Organizational AI", url: createPageUrl("OrganizationalAI"), icon: Heart },
                  { title: "Knowledge Synthesis", url: createPageUrl("KnowledgeSynthesisAI"), icon: Brain },
            { title: "HRIS Integration", url: createPageUrl("HRISIntegration"), icon: LayoutGrid },
            { title: "Organization Settings", url: createPageUrl("OrganizationSettings"), icon: Settings },
          ];

  const platformAdminNavigation = user?.email === 'ammanuldesta@gmail.com' ? [
    { title: "Sales & Onboarding", url: createPageUrl("SalesAndOnboarding"), icon: Briefcase },
    { title: "Platform Analytics", url: createPageUrl("PlatformAnalytics"), icon: BarChart3 },
  ] : [];

  const showExecutive = userRole === 'executive' || userRole === 'c_suite' || user?.role === 'admin';
  const showAdmin = user?.role === 'admin' || userRole === 'manager' || userRole === 'executive' || userRole === 'c_suite' || userRole === 'org_admin';

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-black">
        <Sidebar className="border-r border-white/5 bg-black">
          <SidebarHeader className="border-b border-white/5 p-6">
                            <div className="flex items-center gap-3">
                              <img 
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
                                alt="Luminous Prosperity" 
                                className="w-10 h-10 object-contain"
                              />
                              <div>
                                <h2 className="font-light text-[#e8e8e8] tracking-[0.15em] uppercase text-sm drop-shadow-[0_0_4px_rgba(255,255,255,0.15)] hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.25)] transition-all duration-300">
                                  Luminous
                                </h2>
                                <p className="text-[10px] text-[#a0a0a0] tracking-widest uppercase drop-shadow-[0_0_3px_rgba(255,255,255,0.1)]">Prosperity</p>
                              </div>
                            </div>
                          </SidebarHeader>
          
          <SidebarContent className="p-3 bg-black">
            <SidebarGroup>
              <SidebarGroupLabel className="text-[10px] text-[#a0a0a0] px-3 mb-2 tracking-[0.2em] uppercase drop-shadow-[0_0_3px_rgba(255,255,255,0.08)]">Individual</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {userNavigation.map((item) => (
                            <SidebarMenuItem key={item.title}>
                              <SidebarMenuButton 
                                                                    asChild 
                                                                    className={`hover:bg-white/5 transition-all duration-300 rounded-lg mb-0.5 group/item ${
                                                                      location.pathname === item.url ? 'bg-white/5' : ''
                                                                    }`}
                                                                  >
                                                                    <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                                                                      <item.icon className={`w-4 h-4 drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`} />
                                                                      <span className={`text-xs tracking-wide drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] group-hover/item:text-[#e8e8e8] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`}>{item.title}</span>
                                                                    </Link>
                                                                  </SidebarMenuButton>
                            </SidebarMenuItem>
                          ))}
                        </SidebarMenu>
                      </SidebarGroupContent>
                    </SidebarGroup>

                    {showExecutive && (
                      <SidebarGroup>
                        <SidebarGroupLabel className="text-[10px] text-[#a0a0a0] px-3 mb-2 mt-4 tracking-[0.2em] uppercase drop-shadow-[0_0_3px_rgba(255,255,255,0.08)]">Executive</SidebarGroupLabel>
                        <SidebarGroupContent>
                          <SidebarMenu>
                            {executiveNavigation.map((item) => (
                                                                <SidebarMenuItem key={item.title}>
                                                                  <SidebarMenuButton 
                                                                    asChild 
                                                                    className={`hover:bg-white/5 transition-all duration-300 rounded-lg mb-0.5 group/item ${
                                                                      location.pathname === item.url ? 'bg-white/5' : ''
                                                                    }`}
                                                                  >
                                                                    <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                                                                      <item.icon className={`w-4 h-4 drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`} />
                                                                      <span className={`text-xs tracking-wide drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] group-hover/item:text-[#e8e8e8] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`}>{item.title}</span>
                                                                    </Link>
                                                                  </SidebarMenuButton>
                                                                </SidebarMenuItem>
                                                              ))}
                          </SidebarMenu>
                        </SidebarGroupContent>
                      </SidebarGroup>
                    )}

                    {showAdmin && (
                      <SidebarGroup>
                        <SidebarGroupLabel className="text-[10px] text-[#a0a0a0] px-3 mb-2 mt-4 tracking-[0.2em] uppercase drop-shadow-[0_0_3px_rgba(255,255,255,0.08)]">Operations</SidebarGroupLabel>
                        <SidebarGroupContent>
                          <SidebarMenu>
                            {adminNavigation.map((item) => (
                                                                <SidebarMenuItem key={item.title}>
                                                                  <SidebarMenuButton 
                                                                    asChild 
                                                                    className={`hover:bg-white/5 transition-all duration-300 rounded-lg mb-0.5 group/item ${
                                                                      location.pathname === item.url ? 'bg-white/5' : ''
                                                                    }`}
                                                                  >
                                                                    <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                                                                      <item.icon className={`w-4 h-4 drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`} />
                                                                      <span className={`text-xs tracking-wide drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] group-hover/item:text-[#e8e8e8] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`}>{item.title}</span>
                                                                    </Link>
                                                                  </SidebarMenuButton>
                                                                </SidebarMenuItem>
                                                              ))}
                          </SidebarMenu>
                        </SidebarGroupContent>
                      </SidebarGroup>
                    )}

                    {platformAdminNavigation.length > 0 && (
                      <SidebarGroup>
                        <SidebarGroupLabel className="text-[10px] text-[#a0a0a0] px-3 mb-2 mt-4 tracking-[0.2em] uppercase drop-shadow-[0_0_3px_rgba(255,255,255,0.08)]">Platform</SidebarGroupLabel>
                        <SidebarGroupContent>
                          <SidebarMenu>
                            {platformAdminNavigation.map((item) => (
                                                                <SidebarMenuItem key={item.title}>
                                                                  <SidebarMenuButton 
                                                                    asChild 
                                                                    className={`hover:bg-white/5 transition-all duration-300 rounded-lg mb-0.5 group/item ${
                                                                      location.pathname === item.url ? 'bg-white/5' : ''
                                                                    }`}
                                                                  >
                                                                    <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                                                                      <item.icon className={`w-4 h-4 drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`} />
                                                                      <span className={`text-xs tracking-wide drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/item:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] group-hover/item:text-[#e8e8e8] transition-all duration-300 ${
                                                                        location.pathname === item.url ? 'text-[#e8e8e8] drop-shadow-[0_0_6px_rgba(255,255,255,0.2)]' : 'text-[#a0a0a0]'
                                                                      }`}>{item.title}</span>
                                                                    </Link>
                                                                  </SidebarMenuButton>
                                                                </SidebarMenuItem>
                                                              ))}
                          </SidebarMenu>
                        </SidebarGroupContent>
                      </SidebarGroup>
                    )}
          </SidebarContent>

          <SidebarFooter className="border-t border-white/5 p-4 bg-black">
                            <div className="space-y-3">
                              {user && (
                                <div className="text-xs px-3">
                                  <p className="text-[#a0a0a0] truncate drop-shadow-[0_0_3px_rgba(255,255,255,0.1)]">{user.full_name || user.email}</p>
                                  <p className="capitalize text-[#808080] drop-shadow-[0_0_2px_rgba(255,255,255,0.05)]">{userRole.replace('_', ' ')}</p>
                                </div>
                              )}
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={handleLogout}
                                className="w-full justify-start text-[#a0a0a0] hover:text-[#e8e8e8] hover:bg-white/5 text-xs group/logout transition-all duration-300"
                              >
                                <LogOut className="w-4 h-4 mr-2 drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/logout:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300" />
                                <span className="drop-shadow-[0_0_3px_rgba(255,255,255,0.1)] group-hover/logout:drop-shadow-[0_0_6px_rgba(255,255,255,0.25)] transition-all duration-300">Sign Out</span>
                              </Button>
                            </div>
                          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col bg-black">
          <header className="glass-panel border-x-0 border-t-0 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-white/5 p-2 rounded-lg transition-colors duration-200 text-gray-400" />
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png" 
                alt="Luminous Prosperity" 
                className="w-8 h-8 object-contain"
              />
              <h1 className="text-sm font-light text-white tracking-[0.15em] uppercase">
                Luminous
              </h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
