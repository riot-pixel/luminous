import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Download, Calendar, Printer } from "lucide-react";
import AssessmentReport from "../components/reports/AssessmentReport";
import ExecutiveReport from "../components/reports/ExecutiveReport";
import ReportTutorial from "../components/onboarding/ReportTutorial";

export default function ReportGenerator() {
  const queryClient = useQueryClient();
  const [selectedReport, setSelectedReport] = useState(null);
  const [reportType, setReportType] = useState("assessment");
  const [showPreview, setShowPreview] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: assessments } = useQuery({
    queryKey: ['myAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Assessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: ceoAssessments } = useQuery({
    queryKey: ['myCEOAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.CEOAssessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  const { data: organization } = useQuery({
    queryKey: ['myOrganization'],
    queryFn: async () => {
      const orgs = await base44.entities.Organization.list();
      return orgs[0];
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  useEffect(() => {
    if (user && !user.tutorials_seen?.report_tutorial) {
      setShowTutorial(true);
    }
  }, [user]);

  const handlePrint = async () => {
    window.print();
    
    // Mark report as generated for onboarding
    if (!user?.onboarding_tasks?.generated_report) {
      await updateUserMutation.mutateAsync({
        onboarding_tasks: {
          ...user.onboarding_tasks,
          generated_report: true,
        },
      });
    }
  };

  const handleGenerateReport = () => {
    if (!selectedReport) {
      alert("Please select a report to generate");
      return;
    }
    setShowPreview(true);
  };

  const availableReports = reportType === "assessment" 
    ? assessments.map((a, idx) => ({
        id: a.id,
        label: `Assessment - ${new Date(a.completed_date).toLocaleDateString()}`,
        data: a
      }))
    : ceoAssessments.map((a, idx) => ({
        id: a.id,
        label: `Executive Assessment - ${new Date(a.completed_date).toLocaleDateString()}`,
        data: a
      }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-orange-50/20">
      <ReportTutorial 
        isOpen={showTutorial} 
        onClose={() => setShowTutorial(false)}
        user={user}
      />

      {!showPreview ? (
        <div className="p-6 max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Report Generator</h1>
            <p className="text-gray-600">Generate professional PDF reports of your assessments</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#B8967D]" />
                Select Report
              </CardTitle>
              <CardDescription>Choose the assessment you want to generate a report for</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Report Type</label>
                <Select value={reportType} onValueChange={(value) => {
                  setReportType(value);
                  setSelectedReport(null);
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="assessment">Individual Assessment</SelectItem>
                    <SelectItem value="executive">Executive Assessment</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Select Assessment</label>
                <Select 
                  value={selectedReport?.id} 
                  onValueChange={(value) => {
                    const report = availableReports.find(r => r.id === value);
                    setSelectedReport(report);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose an assessment" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableReports.map((report) => (
                      <SelectItem key={report.id} value={report.id}>
                        {report.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {availableReports.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p>No {reportType} reports available yet</p>
                  <p className="text-sm">Complete an assessment to generate reports</p>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-900 mb-2">Report Features:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Comprehensive assessment results and AI insights</li>
                  <li>• Professional formatting with your organization's branding</li>
                  <li>• Downloadable as PDF using your browser's print function</li>
                  <li>• Includes all visualizations and data charts</li>
                  <li>• Suitable for sharing with coaches or stakeholders</li>
                </ul>
              </div>

              <Button
                onClick={handleGenerateReport}
                disabled={!selectedReport}
                className="w-full bg-gradient-to-r from-[#B8967D] to-[#A68364] hover:from-[#A68364] hover:to-[#8F7355]"
                size="lg"
              >
                <FileText className="w-5 h-5 mr-2" />
                Generate Report Preview
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div>
          {/* Print Control Bar */}
          <div className="print:hidden bg-white border-b border-gray-200 p-4 sticky top-0 z-50 shadow-sm">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-gray-900">Report Preview</h2>
                <p className="text-sm text-gray-600">Use Print or Save as PDF to download</p>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowPreview(false)}
                >
                  Back to Selection
                </Button>
                <Button
                  onClick={handlePrint}
                  className="bg-gradient-to-r from-[#B8967D] to-[#A68364]"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Print / Save as PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Report Content */}
          <div className="bg-white">
            {reportType === "assessment" ? (
              <AssessmentReport 
                assessment={selectedReport.data} 
                user={user}
                organization={organization}
              />
            ) : (
              <ExecutiveReport 
                assessment={selectedReport.data}
                user={user}
                organization={organization}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}