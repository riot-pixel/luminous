import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Sparkles, TrendingUp, TrendingDown, AlertTriangle, Users, Brain,
  Target, Activity, Shield, Zap, Heart, Clock, CheckCircle2,
  ArrowRight, RefreshCw, User, Flame, Award, BookOpen, Gift, Calendar
} from "lucide-react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, AreaChart, Area
} from "recharts";
import { format, subMonths, differenceInMonths } from "date-fns";
import AIOnboardingAssistant from "../components/onboarding/AIOnboardingAssistant";

export default function PredictiveInsights() {
  const queryClient = useQueryClient();
  const [selectedScope, setSelectedScope] = useState('organization');
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [insights, setInsights] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: employees } = useQuery({
    queryKey: ['allEmployees'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: teams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['allUserSkills'],
    queryFn: () => base44.entities.UserSkill.list(),
    initialData: [],
  });

  const { data: roleRequirements } = useQuery({
    queryKey: ['roleRequirements'],
    queryFn: () => base44.entities.RoleSkillRequirement.list(),
    initialData: [],
  });

  const { data: predictions } = useQuery({
    queryKey: ['predictions'],
    queryFn: () => base44.entities.PredictiveInsight.list('-created_date'),
    initialData: [],
  });

  const createPredictionMutation = useMutation({
    mutationFn: (data) => base44.entities.PredictiveInsight.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['predictions'] });
    },
  });

  // Get latest assessment per employee
  const latestAssessments = assessments.reduce((acc, a) => {
    if (!acc[a.user_email] || new Date(a.completed_date) > new Date(acc[a.user_email].completed_date)) {
      acc[a.user_email] = a;
    }
    return acc;
  }, {});

  // Calculate skill gaps with detailed info
  const calculateSkillGaps = (targetEmails = null) => {
    const gaps = [];
    const relevantEmployees = targetEmails 
      ? employees.filter(e => targetEmails.includes(e.email))
      : employees;

    relevantEmployees.forEach(emp => {
      const empSkills = userSkills.filter(us => us.user_email === emp.email);
      const reqSkills = roleRequirements.filter(rr => rr.role_title === emp.job_title);
      const proficiencyOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
      
      reqSkills.forEach(req => {
        const userSkill = empSkills.find(us => us.skill_id === req.skill_id);
        const hasGap = !userSkill || 
          proficiencyOrder.indexOf(userSkill.current_proficiency) < proficiencyOrder.indexOf(req.required_proficiency);
        
        if (hasGap) {
          gaps.push({
            skill: req.skill_name,
            skill_category: req.skill_category || 'general',
            department: emp.department,
            role: emp.job_title,
            current_level: userSkill?.current_proficiency || 'None',
            required_level: req.required_proficiency,
            severity: req.priority === 'must_have' ? 'high' : 'medium',
            gap_size: proficiencyOrder.indexOf(req.required_proficiency) - 
                     (userSkill ? proficiencyOrder.indexOf(userSkill.current_proficiency) : -1),
          });
        }
      });
    });
    return gaps;
  };

  // Aggregate skill gaps for AI analysis
  const aggregateSkillGaps = (gaps) => {
    const aggregated = {};
    gaps.forEach(gap => {
      const key = gap.skill;
      if (!aggregated[key]) {
        aggregated[key] = {
          skill: gap.skill,
          category: gap.skill_category,
          count: 0,
          departments: new Set(),
          roles: new Set(),
          avgGapSize: 0,
          highSeverityCount: 0,
        };
      }
      aggregated[key].count++;
      aggregated[key].departments.add(gap.department);
      aggregated[key].roles.add(gap.role);
      aggregated[key].avgGapSize = (aggregated[key].avgGapSize * (aggregated[key].count - 1) + gap.gap_size) / aggregated[key].count;
      if (gap.severity === 'high') aggregated[key].highSeverityCount++;
    });
    
    return Object.values(aggregated).map(g => ({
      ...g,
      departments: Array.from(g.departments),
      roles: Array.from(g.roles),
      criticality: g.highSeverityCount > g.count * 0.5 ? 'critical' : g.highSeverityCount > 0 ? 'high' : 'medium',
    })).sort((a, b) => b.count - a.count);
  };

  // Calculate engagement indicators
  const calculateEngagementMetrics = (targetEmails = null) => {
    const relevantAssessments = targetEmails
      ? Object.values(latestAssessments).filter(a => targetEmails.includes(a.user_email))
      : Object.values(latestAssessments);

    if (relevantAssessments.length === 0) return { avgSatisfaction: 0, lowSatisfactionCount: 0, burnoutRisk: 0, flightRiskCount: 0 };

    const satisfactions = relevantAssessments
      .filter(a => a.life_wheel?.overall_satisfaction)
      .map(a => a.life_wheel.overall_satisfaction);

    const avgSatisfaction = satisfactions.length > 0
      ? Math.round(satisfactions.reduce((a, b) => a + b, 0) / satisfactions.length)
      : 0;

    const lowSatisfactionCount = satisfactions.filter(s => s < 50).length;

    // Burnout risk: low work-life balance + low health + low recreation
    let burnoutRiskCount = 0;
    let flightRiskCount = 0;
    
    relevantAssessments.forEach(a => {
      if (a.life_wheel) {
        const workLifeScore = (a.life_wheel.career || 0) + (a.life_wheel.family || 0) + (a.life_wheel.social || 0);
        const healthScore = a.life_wheel.health || 0;
        const funScore = a.life_wheel.fun_recreation || 0;
        const careerScore = a.life_wheel.career || 0;
        const growthScore = a.life_wheel.personal_growth || 0;
        
        if ((workLifeScore / 3) < 5 || healthScore < 4 || funScore < 4) {
          burnoutRiskCount++;
        }
        
        // Flight risk: low career satisfaction + low growth + low overall satisfaction
        if (careerScore < 5 && growthScore < 5 && (a.life_wheel.overall_satisfaction || 0) < 50) {
          flightRiskCount++;
        }
      }
    });

    return {
      avgSatisfaction,
      lowSatisfactionCount,
      burnoutRisk: relevantAssessments.length > 0 
        ? Math.round((burnoutRiskCount / relevantAssessments.length) * 100) 
        : 0,
      flightRiskCount,
      flightRiskPercent: relevantAssessments.length > 0
        ? Math.round((flightRiskCount / relevantAssessments.length) * 100)
        : 0,
      total: relevantAssessments.length,
    };
  };

  // Calculate flight risk patterns (anonymized)
  const calculateFlightRiskPatterns = (targetEmails = null) => {
    const relevantEmployees = targetEmails 
      ? employees.filter(e => targetEmails.includes(e.email))
      : employees;
    
    const patterns = {
      byTenure: { '<1yr': 0, '1-2yr': 0, '2-3yr': 0, '3+yr': 0 },
      byDepartment: {},
      riskFactors: [],
      totalAtRisk: 0,
    };

    relevantEmployees.forEach(emp => {
      const assessment = latestAssessments[emp.email];
      if (!assessment?.life_wheel) return;

      const careerScore = assessment.life_wheel.career || 0;
      const growthScore = assessment.life_wheel.personal_growth || 0;
      const overallSat = assessment.life_wheel.overall_satisfaction || 0;
      
      // Calculate tenure
      const createdDate = emp.created_date ? new Date(emp.created_date) : new Date();
      const tenureMonths = differenceInMonths(new Date(), createdDate);
      
      // Check if at risk
      const isAtRisk = careerScore < 5 && growthScore < 5 && overallSat < 50;
      
      if (isAtRisk) {
        patterns.totalAtRisk++;
        
        // By tenure
        if (tenureMonths < 12) patterns.byTenure['<1yr']++;
        else if (tenureMonths < 24) patterns.byTenure['1-2yr']++;
        else if (tenureMonths < 36) patterns.byTenure['2-3yr']++;
        else patterns.byTenure['3+yr']++;
        
        // By department
        const dept = emp.department || 'Unknown';
        patterns.byDepartment[dept] = (patterns.byDepartment[dept] || 0) + 1;
      }
    });

    // Identify common risk factors
    if (patterns.totalAtRisk > 0) {
      if (patterns.byTenure['1-2yr'] > patterns.totalAtRisk * 0.3) {
        patterns.riskFactors.push('High risk in 1-2 year tenure band');
      }
      const highestDept = Object.entries(patterns.byDepartment).sort((a, b) => b[1] - a[1])[0];
      if (highestDept && highestDept[1] > patterns.totalAtRisk * 0.3) {
        patterns.riskFactors.push(`Concentrated risk in ${highestDept[0]} department`);
      }
    }

    return patterns;
  };

  // Calculate team engagement by project phase simulation
  const calculateTeamEngagementPhases = (team) => {
    if (!team) return null;
    
    const memberAssessments = Object.values(latestAssessments)
      .filter(a => team.member_emails?.includes(a.user_email));
    
    if (memberAssessments.length === 0) return null;
    
    // Calculate team personality mix
    const personalityTypes = {};
    memberAssessments.forEach(a => {
      if (a.myers_briggs?.type) {
        personalityTypes[a.myers_briggs.type] = (personalityTypes[a.myers_briggs.type] || 0) + 1;
      }
    });
    
    // Predict engagement by phase based on team composition
    const introvertCount = Object.entries(personalityTypes)
      .filter(([type]) => type.includes('I'))
      .reduce((sum, [_, count]) => sum + count, 0);
    const extrovertCount = memberAssessments.length - introvertCount;
    
    const thinkingCount = Object.entries(personalityTypes)
      .filter(([type]) => type.includes('T'))
      .reduce((sum, [_, count]) => sum + count, 0);
    
    return {
      kickoff: Math.round(70 + (extrovertCount / memberAssessments.length) * 20),
      planning: Math.round(75 + (thinkingCount / memberAssessments.length) * 15),
      execution: Math.round(65 + (introvertCount / memberAssessments.length) * 10),
      review: Math.round(70 + (thinkingCount / memberAssessments.length) * 20),
      personalityMix: personalityTypes,
    };
  };

  // Generate comprehensive predictions
  const generatePredictions = async () => {
    setIsGenerating(true);
    
    try {
      const targetEmails = selectedScope === 'team' && selectedTeam
        ? selectedTeam.member_emails
        : null;

      const skillGaps = calculateSkillGaps(targetEmails);
      const engagementMetrics = calculateEngagementMetrics(targetEmails);

      // Calculate historical trends
      const trendData = [];
      for (let i = 5; i >= 0; i--) {
        const date = subMonths(new Date(), i);
        const monthAssessments = assessments.filter(a => {
          const aDate = new Date(a.completed_date);
          const inMonth = aDate.getMonth() === date.getMonth() && aDate.getFullYear() === date.getFullYear();
          if (targetEmails) {
            return inMonth && targetEmails.includes(a.user_email);
          }
          return inMonth;
        });

        const satisfactions = monthAssessments
          .filter(a => a.life_wheel?.overall_satisfaction)
          .map(a => a.life_wheel.overall_satisfaction);

        trendData.push({
          month: format(date, 'MMM'),
          satisfaction: satisfactions.length > 0 
            ? Math.round(satisfactions.reduce((a, b) => a + b, 0) / satisfactions.length) 
            : 0,
          assessments: monthAssessments.length,
        });
      }

      // Calculate flight risk patterns
      const flightRiskPatterns = calculateFlightRiskPatterns(targetEmails);
      
      // Calculate team engagement phases if team selected
      const teamPhaseEngagement = selectedTeam ? calculateTeamEngagementPhases(selectedTeam) : null;

      // Aggregate skill gaps for detailed analysis
      const aggregatedSkillGaps = aggregateSkillGaps(skillGaps);

      // Identify potential internal mentors (employees with high proficiency in gap skills)
      const potentialMentors = {};
      aggregatedSkillGaps.slice(0, 10).forEach(gap => {
        const expertsInSkill = userSkills.filter(us => 
          us.skill_name === gap.skill && 
          ['Advanced', 'Expert'].includes(us.current_proficiency)
        );
        if (expertsInSkill.length > 0) {
          potentialMentors[gap.skill] = {
            count: expertsInSkill.length,
            departments: [...new Set(expertsInSkill.map(e => {
              const emp = employees.find(emp => emp.email === e.user_email);
              return emp?.department;
            }).filter(Boolean))],
          };
        }
      });

      // Prepare analysis data
      const analysisData = {
        scope: selectedScope,
        teamName: selectedTeam?.name,
        teamGoals: selectedTeam?.goals,
        totalPeople: targetEmails?.length || employees.length,
        skillGaps: {
          total: skillGaps.length,
          highSeverity: skillGaps.filter(g => g.severity === 'high').length,
          byDepartment: skillGaps.reduce((acc, g) => {
            acc[g.department] = (acc[g.department] || 0) + 1;
            return acc;
          }, {}),
          detailedGaps: aggregatedSkillGaps.slice(0, 15),
          availableMentors: potentialMentors,
        },
        engagement: engagementMetrics,
        flightRisk: flightRiskPatterns,
        teamPhaseEngagement,
        trends: trendData,
        assessedCount: Object.keys(latestAssessments).length,
      };

      const aiInsights = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist and predictive analytics specialist focusing on employee well-being, retention, and performance.

Analyze this AGGREGATED, ANONYMIZED data and provide comprehensive predictive insights:

${JSON.stringify(analysisData, null, 2)}

Generate predictions in these categories:

1. SKILL GAP FORECASTING & INTERVENTIONS: 
   For each critical skill gap, provide DETAILED personalized interventions:
   
   a) LEARNING RECOMMENDATIONS:
      - Specific online courses (Coursera, LinkedIn Learning, Udemy, etc.)
      - Certifications to pursue
      - Books and resources
      - Estimated time to close the gap
   
   b) INTERNAL MENTORSHIP:
      - Suggest leveraging internal experts (based on availableMentors data)
      - Recommend mentorship program structure
      - Suggest knowledge-sharing sessions
   
   c) PROJECT-BASED LEARNING:
      - Propose specific project types to develop the skill
      - Suggest stretch assignments
      - Recommend cross-functional opportunities
      - Identify shadowing opportunities

2. ENGAGEMENT TRENDS BY PROJECT PHASE: 
   - If team data available, predict engagement fluctuations during kickoff, planning, execution, and review phases
   - Identify which project phases are highest risk for this team's composition
   - Consider personality mix effects on team dynamics during different phases

3. FLIGHT RISK IDENTIFICATION (ANONYMIZED PATTERNS):
   - Identify aggregate patterns indicating turnover risk (tenure bands, departments)
   - Flag concerning trends without identifying individuals
   - Predict which employee segments are most at risk and why
   - Consider career satisfaction + growth opportunity + overall satisfaction patterns

4. BURNOUT PREVENTION: 
   - Identify teams/departments showing burnout warning signs
   - Predict burnout trajectory over next 3 months

5. PROACTIVE INTERVENTIONS - For each risk, suggest SPECIFIC interventions:
   - Targeted learning resources (specific courses, certifications, books)
   - Recognition program recommendations (peer recognition, milestone awards, spot bonuses)
   - Well-being check-in schedules and formats
   - Career development conversations
   - Team building activities
   - Workload rebalancing suggestions
   - Mentorship pairings

For each insight provide:
- Type (skill_gap, engagement, flight_risk, burnout, performance, intervention)
- Severity (low, medium, high, critical)
- Confidence score (0-100)
- Detailed prediction
- Key indicators (based on aggregated data only)
- 4-6 specific, actionable interventions with concrete details
- Expected timeline
- Potential impact if not addressed (turnover cost, productivity loss, etc.)
- Recommended intervention owner (HR, Manager, Leadership)

IMPORTANT: All insights must be based on aggregated patterns only. Never identify or single out individuals.
Be specific, actionable, and focused on preventive measures. Prioritize employee well-being and retention.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            overall_health_score: { type: "number" },
            risk_level: { type: "string" },
            flight_risk_summary: {
              type: "object",
              properties: {
                risk_level: { type: "string" },
                estimated_at_risk_percentage: { type: "number" },
                highest_risk_segments: { type: "array", items: { type: "string" } },
                estimated_turnover_cost: { type: "string" }
              }
            },
            engagement_forecast: {
              type: "object",
              properties: {
                next_30_days: { type: "string" },
                next_90_days: { type: "string" },
                risk_phases: { type: "array", items: { type: "string" } }
              }
            },
            predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  severity: { type: "string" },
                  confidence_score: { type: "number" },
                  prediction: { type: "string" },
                  indicators: { type: "array", items: { type: "string" } },
                  interventions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        action: { type: "string" },
                        category: { type: "string" },
                        owner: { type: "string" },
                        timeline: { type: "string" },
                        resources: { type: "array", items: { type: "string" } }
                      }
                    }
                  },
                  timeline: { type: "string" },
                  impact_if_ignored: { type: "string" },
                  recommended_owner: { type: "string" }
                }
              }
            },
            proactive_programs: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  program_name: { type: "string" },
                  category: { type: "string" },
                  description: { type: "string" },
                  target_audience: { type: "string" },
                  expected_impact: { type: "string" },
                  implementation_steps: { type: "array", items: { type: "string" } }
                }
              }
            },
            skill_gap_interventions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_name: { type: "string" },
                  criticality: { type: "string" },
                  affected_count: { type: "number" },
                  gap_description: { type: "string" },
                  learning_recommendations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        type: { type: "string" },
                        title: { type: "string" },
                        provider: { type: "string" },
                        duration: { type: "string" },
                        level: { type: "string" },
                        url_hint: { type: "string" }
                      }
                    }
                  },
                  mentorship_opportunities: {
                    type: "object",
                    properties: {
                      internal_experts_available: { type: "boolean" },
                      recommended_structure: { type: "string" },
                      session_format: { type: "string" },
                      knowledge_sharing_ideas: { type: "array", items: { type: "string" } }
                    }
                  },
                  project_based_learning: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        project_type: { type: "string" },
                        description: { type: "string" },
                        skill_application: { type: "string" },
                        duration: { type: "string" },
                        complexity: { type: "string" }
                      }
                    }
                  },
                  estimated_closure_time: { type: "string" }
                }
              }
            },
            quick_wins: { type: "array", items: { type: "string" } },
            long_term_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setInsights(aiInsights);

      // Save predictions to database
      for (const pred of aiInsights.predictions) {
        await createPredictionMutation.mutateAsync({
          insight_type: pred.type === 'skill_gap' ? 'skill_gap' : 
                       pred.type === 'engagement' ? 'engagement_drop' :
                       pred.type === 'flight_risk' ? 'turnover_risk' :
                       pred.type === 'burnout' ? 'performance_risk' : 'resource_need',
          severity: pred.severity,
          department: selectedTeam?.department || 'Organization-wide',
          team_id: selectedTeam?.id,
          confidence_score: pred.confidence_score,
          prediction: pred.prediction,
          indicators: pred.indicators,
          recommendations: pred.interventions,
          timeline: pred.timeline,
          status: 'active',
          generated_by: user?.email,
        });
      }

    } catch (error) {
      console.error("Error generating predictions:", error);
    }
    setIsGenerating(false);
  };

  const getTypeIcon = (type) => {
    switch(type) {
      case 'skill_gap': return Brain;
      case 'engagement': return Activity;
      case 'flight_risk': return AlertTriangle;
      case 'burnout': return Flame;
      case 'performance': return TrendingUp;
      default: return Zap;
    }
  };

  const getSeverityStyles = (severity) => {
    switch(severity) {
      case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'high': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    }
  };

  const engagementMetrics = calculateEngagementMetrics(
    selectedScope === 'team' && selectedTeam ? selectedTeam.member_emails : null
  );

  const chartColors = {
    grid: 'rgba(255,255,255,0.05)',
    text: '#525252',
  };

  return (
    <div className="min-h-screen bg-black text-[#f5f5f5] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-light text-white mb-2 serif">Predictive Insights</h1>
            <p className="text-gray-500 flex items-center gap-2">
              AI-powered forecasting for performance, engagement, and well-being
              <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-[10px] uppercase tracking-widest">
                <Shield className="w-3 h-3" /> Privacy Protected
              </span>
            </p>
          </div>
          <div className="flex gap-3">
            <Select value={selectedScope} onValueChange={setSelectedScope}>
              <SelectTrigger className="w-40 bg-black border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-black border-white/10">
                <SelectItem value="organization" className="text-white hover:bg-white/5">Organization</SelectItem>
                <SelectItem value="team" className="text-white hover:bg-white/5">Team</SelectItem>
              </SelectContent>
            </Select>
            
            {selectedScope === 'team' && (
              <Select value={selectedTeam?.id} onValueChange={(id) => setSelectedTeam(teams.find(t => t.id === id))}>
                <SelectTrigger className="w-48 bg-black border-white/10 text-white">
                  <SelectValue placeholder="Select team" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10">
                  {teams.map(team => (
                    <SelectItem key={team.id} value={team.id} className="text-white hover:bg-white/5">
                      {team.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Button
              onClick={generatePredictions}
              disabled={isGenerating || (selectedScope === 'team' && !selectedTeam)}
              className="bg-white text-black hover:bg-gray-200 text-xs font-bold tracking-widest uppercase"
            >
              {isGenerating ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><RefreshCw className="w-4 h-4 mr-2" /> Generate Insights</>
              )}
            </Button>
          </div>
        </div>

        {/* Key Risk Indicators */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          <div className="glass-panel rounded-2xl p-6 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-0.5 ${engagementMetrics.avgSatisfaction >= 70 ? 'bg-emerald-500' : engagementMetrics.avgSatisfaction >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}></div>
            <Activity className="w-6 h-6 text-emerald-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Avg Satisfaction</p>
            <p className="text-3xl font-light text-white mt-1">{engagementMetrics.avgSatisfaction}%</p>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-0.5 ${engagementMetrics.burnoutRisk <= 10 ? 'bg-emerald-500' : engagementMetrics.burnoutRisk <= 25 ? 'bg-amber-500' : 'bg-red-500'}`}></div>
            <Flame className="w-6 h-6 text-amber-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Burnout Risk</p>
            <p className="text-3xl font-light text-white mt-1">{engagementMetrics.burnoutRisk}%</p>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-0.5 ${engagementMetrics.flightRiskPercent <= 5 ? 'bg-emerald-500' : engagementMetrics.flightRiskPercent <= 15 ? 'bg-amber-500' : 'bg-red-500'}`}></div>
            <AlertTriangle className="w-6 h-6 text-red-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Flight Risk</p>
            <p className="text-3xl font-light text-white mt-1">{engagementMetrics.flightRiskPercent}%</p>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-0.5 ${engagementMetrics.lowSatisfactionCount === 0 ? 'bg-emerald-500' : engagementMetrics.lowSatisfactionCount <= 3 ? 'bg-amber-500' : 'bg-red-500'}`}></div>
            <User className="w-6 h-6 text-purple-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Low Satisfaction</p>
            <p className="text-3xl font-light text-white mt-1">{engagementMetrics.lowSatisfactionCount}</p>
          </div>
          
          <div className="glass-panel rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-0.5 bg-blue-500"></div>
            <Brain className="w-6 h-6 text-blue-400 mb-3" />
            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Skill Gaps</p>
            <p className="text-3xl font-light text-white mt-1">
              {calculateSkillGaps(selectedScope === 'team' && selectedTeam ? selectedTeam.member_emails : null).length}
            </p>
          </div>
        </div>

        {/* AI Insights */}
        {insights ? (
          <div className="space-y-8">
            {/* Summary Card */}
            <div className="glass-panel rounded-3xl p-8 border border-amber-500/20">
              <div className="flex items-start gap-6">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/20 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-8 h-8 text-amber-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <h2 className="text-xl font-light text-white">AI Analysis Summary</h2>
                    <span className={`text-xs px-3 py-1 rounded-full border ${getSeverityStyles(insights.risk_level)}`}>
                      {insights.risk_level} Risk
                    </span>
                    <span className="text-xs px-3 py-1 bg-white/10 rounded-full text-gray-400">
                      Health Score: {insights.overall_health_score}/100
                    </span>
                  </div>
                  <p className="text-gray-400 leading-relaxed">{insights.summary}</p>
                </div>
              </div>
            </div>

            {/* Flight Risk & Engagement Forecast */}
            <div className="grid md:grid-cols-2 gap-6">
              {insights.flight_risk_summary && (
                <div className="glass-panel rounded-2xl p-6 border border-red-500/20">
                  <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    Flight Risk Analysis
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Risk Level</span>
                      <span className={`text-xs px-3 py-1 rounded-full border ${getSeverityStyles(insights.flight_risk_summary.risk_level)}`}>
                        {insights.flight_risk_summary.risk_level}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Est. At-Risk</span>
                      <span className="text-white font-medium">{insights.flight_risk_summary.estimated_at_risk_percentage}%</span>
                    </div>
                    {insights.flight_risk_summary.estimated_turnover_cost && (
                      <div className="flex items-center justify-between">
                        <span className="text-gray-500">Potential Cost</span>
                        <span className="text-amber-400">{insights.flight_risk_summary.estimated_turnover_cost}</span>
                      </div>
                    )}
                    {insights.flight_risk_summary.highest_risk_segments?.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Highest Risk Segments</p>
                        <div className="flex flex-wrap gap-2">
                          {insights.flight_risk_summary.highest_risk_segments.map((seg, i) => (
                            <span key={i} className="text-xs px-2 py-1 bg-red-500/10 border border-red-500/20 rounded text-red-400">{seg}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {insights.engagement_forecast && (
                <div className="glass-panel rounded-2xl p-6 border border-blue-500/20">
                  <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    Engagement Forecast
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Next 30 Days</p>
                      <p className="text-sm text-gray-300">{insights.engagement_forecast.next_30_days}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Next 90 Days</p>
                      <p className="text-sm text-gray-300">{insights.engagement_forecast.next_90_days}</p>
                    </div>
                    {insights.engagement_forecast.risk_phases?.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Risk Phases</p>
                        <div className="flex flex-wrap gap-2">
                          {insights.engagement_forecast.risk_phases.map((phase, i) => (
                            <span key={i} className="text-xs px-2 py-1 bg-amber-500/10 border border-amber-500/20 rounded text-amber-400">{phase}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Skill Gap Interventions */}
            {insights.skill_gap_interventions?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Brain className="w-5 h-5 text-blue-400" />
                  Skill Gap Interventions
                </h3>
                <div className="space-y-6">
                  {insights.skill_gap_interventions.map((intervention, i) => (
                    <div key={i} className="p-5 bg-white/5 border border-white/10 rounded-xl">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="text-white font-medium text-lg">{intervention.skill_name}</h4>
                          <p className="text-sm text-gray-500 mt-1">{intervention.gap_description}</p>
                        </div>
                        <div className="text-right">
                          <span className={`text-xs px-3 py-1 rounded-full border ${getSeverityStyles(intervention.criticality)}`}>
                            {intervention.criticality}
                          </span>
                          <p className="text-xs text-gray-500 mt-2">{intervention.affected_count} affected</p>
                          <p className="text-xs text-emerald-400 mt-1">~{intervention.estimated_closure_time} to close</p>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-4">
                        {/* Learning Recommendations */}
                        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                          <h5 className="text-sm font-medium text-blue-400 mb-3 flex items-center gap-2">
                            <BookOpen className="w-4 h-4" /> Learning Resources
                          </h5>
                          <div className="space-y-2">
                            {intervention.learning_recommendations?.slice(0, 4).map((rec, j) => (
                              <div key={j} className="p-2 bg-black/30 rounded">
                                <p className="text-xs text-white font-medium">{rec.title}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[10px] text-gray-500">{rec.provider}</span>
                                  <span className="text-[10px] text-gray-600">•</span>
                                  <span className="text-[10px] text-gray-500">{rec.duration}</span>
                                </div>
                                <span className="text-[10px] px-1.5 py-0.5 bg-blue-500/20 rounded text-blue-400 mt-1 inline-block">{rec.type}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Mentorship */}
                        <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                          <h5 className="text-sm font-medium text-purple-400 mb-3 flex items-center gap-2">
                            <Users className="w-4 h-4" /> Mentorship
                          </h5>
                          {intervention.mentorship_opportunities && (
                            <div className="space-y-3">
                              <div className="flex items-center gap-2">
                                {intervention.mentorship_opportunities.internal_experts_available ? (
                                  <span className="text-xs px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded">Internal experts available</span>
                                ) : (
                                  <span className="text-xs px-2 py-1 bg-amber-500/20 text-amber-400 rounded">External mentors needed</span>
                                )}
                              </div>
                              <p className="text-xs text-gray-400">{intervention.mentorship_opportunities.recommended_structure}</p>
                              <p className="text-xs text-gray-500">Format: {intervention.mentorship_opportunities.session_format}</p>
                              {intervention.mentorship_opportunities.knowledge_sharing_ideas?.length > 0 && (
                                <div>
                                  <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Ideas:</p>
                                  <ul className="space-y-1">
                                    {intervention.mentorship_opportunities.knowledge_sharing_ideas.slice(0, 2).map((idea, k) => (
                                      <li key={k} className="text-xs text-gray-400">• {idea}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Project-Based Learning */}
                        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                          <h5 className="text-sm font-medium text-emerald-400 mb-3 flex items-center gap-2">
                            <Target className="w-4 h-4" /> Project Learning
                          </h5>
                          <div className="space-y-2">
                            {intervention.project_based_learning?.slice(0, 3).map((proj, j) => (
                              <div key={j} className="p-2 bg-black/30 rounded">
                                <p className="text-xs text-white font-medium">{proj.project_type}</p>
                                <p className="text-[10px] text-gray-500 mt-1">{proj.description}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/20 rounded text-emerald-400">{proj.duration}</span>
                                  <span className="text-[10px] px-1.5 py-0.5 bg-white/10 rounded text-gray-400">{proj.complexity}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Proactive Programs */}
            {insights.proactive_programs?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Gift className="w-5 h-5 text-purple-400" />
                  Recommended Proactive Programs
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {insights.proactive_programs.map((program, i) => {
                    const categoryIcon = program.category === 'recognition' ? Award :
                                        program.category === 'learning' ? BookOpen :
                                        program.category === 'wellbeing' ? Heart : Users;
                    const CategoryIcon = categoryIcon;
                    return (
                      <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-xl">
                        <div className="flex items-start gap-3 mb-3">
                          <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                            <CategoryIcon className="w-5 h-5 text-purple-400" />
                          </div>
                          <div>
                            <h4 className="text-white font-medium">{program.program_name}</h4>
                            <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400 capitalize">{program.category}</span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-400 mb-3">{program.description}</p>
                        <div className="text-xs text-gray-500">
                          <span className="text-gray-400">Target:</span> {program.target_audience}
                        </div>
                        <div className="text-xs text-emerald-400 mt-1">
                          <span className="text-gray-400">Impact:</span> {program.expected_impact}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quick Wins */}
            {insights.quick_wins?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-emerald-400" />
                  Quick Wins - Immediate Actions
                </h3>
                <div className="grid md:grid-cols-2 gap-3">
                  {insights.quick_wins.map((win, i) => (
                    <div key={i} className="flex items-start gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-300">{win}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Predictions */}
            <Tabs defaultValue="all" className="space-y-6">
              <TabsList className="glass-panel p-1 rounded-xl">
                <TabsTrigger value="all" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">All</TabsTrigger>
                <TabsTrigger value="burnout" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Burnout</TabsTrigger>
                <TabsTrigger value="engagement" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Engagement</TabsTrigger>
                <TabsTrigger value="skill_gap" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Skills</TabsTrigger>
                <TabsTrigger value="flight_risk" className="data-[state=active]:bg-white data-[state=active]:text-black rounded-lg text-xs px-4">Flight Risk</TabsTrigger>
              </TabsList>

              {['all', 'burnout', 'engagement', 'skill_gap', 'flight_risk'].map(tab => (
                <TabsContent key={tab} value={tab} className="space-y-4">
                  {insights.predictions
                    ?.filter(p => tab === 'all' || p.type === tab)
                    .map((pred, i) => {
                      const Icon = getTypeIcon(pred.type);
                      return (
                        <div key={i} className={`glass-panel rounded-2xl p-6 border ${getSeverityStyles(pred.severity)}`}>
                          <div className="flex items-start gap-4 mb-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                              pred.severity === 'critical' ? 'bg-red-500/20' :
                              pred.severity === 'high' ? 'bg-amber-500/20' :
                              pred.severity === 'medium' ? 'bg-yellow-500/20' : 'bg-blue-500/20'
                            }`}>
                              <Icon className={`w-6 h-6 ${
                                pred.severity === 'critical' ? 'text-red-400' :
                                pred.severity === 'high' ? 'text-amber-400' :
                                pred.severity === 'medium' ? 'text-yellow-400' : 'text-blue-400'
                              }`} />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className={`text-[10px] px-2 py-0.5 rounded uppercase tracking-widest ${getSeverityStyles(pred.severity)}`}>
                                  {pred.severity}
                                </span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">
                                  {pred.confidence_score}% confidence
                                </span>
                                <span className="text-[10px] px-2 py-0.5 bg-white/10 rounded text-gray-400">
                                  {pred.timeline}
                                </span>
                              </div>
                              <h4 className="text-white font-medium mb-2">{pred.prediction}</h4>
                            </div>
                          </div>

                          <div className="grid md:grid-cols-2 gap-6">
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Key Indicators</p>
                              <ul className="space-y-2">
                                {pred.indicators?.map((ind, j) => (
                                  <li key={j} className="flex items-start gap-2 text-sm text-gray-400">
                                    <span className="text-amber-400 mt-1">•</span>
                                    {ind}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Recommended Interventions</p>
                              <ul className="space-y-2">
                                {pred.interventions?.map((int, j) => {
                                  const intervention = typeof int === 'string' ? { action: int } : int;
                                  const categoryIcon = intervention.category === 'recognition' ? Award :
                                                      intervention.category === 'learning' ? BookOpen :
                                                      intervention.category === 'wellbeing' ? Heart :
                                                      intervention.category === 'career' ? TrendingUp : CheckCircle2;
                                  const IntIcon = categoryIcon;
                                  return (
                                    <li key={j} className="p-3 bg-white/5 rounded-lg">
                                      <div className="flex items-start gap-2 text-sm text-gray-300">
                                        <IntIcon className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                                        <div>
                                          <p>{intervention.action}</p>
                                          {intervention.owner && (
                                            <p className="text-[10px] text-gray-500 mt-1">Owner: {intervention.owner}</p>
                                          )}
                                          {intervention.resources?.length > 0 && (
                                            <div className="flex flex-wrap gap-1 mt-2">
                                              {intervention.resources.map((r, k) => (
                                                <span key={k} className="text-[10px] px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 rounded text-blue-400">{r}</span>
                                              ))}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    </li>
                                  );
                                })}
                              </ul>
                            </div>
                          </div>

                          {pred.impact_if_ignored && (
                            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                              <p className="text-xs text-red-400">
                                <strong>If not addressed:</strong> {pred.impact_if_ignored}
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                </TabsContent>
              ))}
            </Tabs>

            {/* Long-term Recommendations */}
            {insights.long_term_recommendations?.length > 0 && (
              <div className="glass-panel rounded-2xl p-6">
                <h3 className="text-lg font-light text-white mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-400" />
                  Long-term Strategic Recommendations
                </h3>
                <div className="space-y-3">
                  {insights.long_term_recommendations.map((rec, i) => (
                    <div key={i} className="flex items-start gap-3 p-4 bg-white/5 border border-white/10 rounded-xl">
                      <ArrowRight className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-300">{rec}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Empty State */
          <div className="glass-panel rounded-3xl p-16 text-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-500/20 to-amber-600/20 flex items-center justify-center mx-auto mb-6">
              <Brain className="w-10 h-10 text-amber-400" />
            </div>
            <h2 className="text-2xl font-light text-white mb-4 serif">Generate Predictive Insights</h2>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              AI will analyze assessment data, skill gaps, and engagement patterns to forecast potential 
              risks and recommend proactive interventions.
            </p>
            <div className="grid md:grid-cols-4 gap-4 max-w-2xl mx-auto mb-8">
              <div className="p-4 bg-white/5 rounded-xl">
                <Brain className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Skill Gap Forecasting</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Activity className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Engagement Trends</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <AlertTriangle className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Flight Risk Detection</p>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <Flame className="w-6 h-6 text-red-400 mx-auto mb-2" />
                <p className="text-xs text-gray-400">Burnout Prevention</p>
              </div>
            </div>
            <Button
              onClick={generatePredictions}
              disabled={isGenerating || (selectedScope === 'team' && !selectedTeam)}
              className="bg-white text-black px-10 py-4 text-xs font-bold tracking-[0.2em] uppercase hover:bg-gray-200 rounded-sm"
            >
              {isGenerating ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Data...</>
              ) : (
                <><Zap className="w-4 h-4 mr-2" /> Generate Insights</>
              )}
            </Button>
          </div>
        )}

        {/* Historical Predictions */}
        {predictions.length > 0 && !insights && (
          <div className="mt-10">
            <h3 className="text-xs font-bold tracking-[0.2em] text-gray-500 uppercase mb-6">Previous Predictions</h3>
            <div className="space-y-3">
              {predictions.slice(0, 5).map((pred) => {
                const Icon = getTypeIcon(pred.insight_type);
                return (
                  <div key={pred.id} className="glass-panel rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Icon className="w-5 h-5 text-gray-500" />
                      <div>
                        <p className="text-sm text-white">{pred.prediction}</p>
                        <p className="text-xs text-gray-500">{pred.timeline} • {pred.department}</p>
                      </div>
                    </div>
                    <span className={`text-[10px] px-2 py-1 rounded ${getSeverityStyles(pred.severity)}`}>
                      {pred.severity}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* AI Onboarding Assistant */}
      <AIOnboardingAssistant user={user} />
    </div>
  );
}