import Layout from "./Layout.jsx";

import Home from "./Home";

import Assessment from "./Assessment";

import Results from "./Results";

import Profile from "./Profile";

import OrganizationDashboard from "./OrganizationDashboard";

import TeamBuilder from "./TeamBuilder";

import Teams from "./Teams";

import CEOAssessment from "./CEOAssessment";

import CEODashboard from "./CEODashboard";

import OrganizationalAnalysis from "./OrganizationalAnalysis";

import OrganizationalAI from "./OrganizationalAI";

import EmployeePortal from "./EmployeePortal";

import ExecutivePortal from "./ExecutivePortal";

import CSuitePortal from "./CSuitePortal";

import AuthSetup from "./AuthSetup";

import QuickAssessment from "./QuickAssessment";

import QuickExecutiveAssessment from "./QuickExecutiveAssessment";

import PlatformAdmin from "./PlatformAdmin";

import OrganizationSettings from "./OrganizationSettings";

import AcceptInvite from "./AcceptInvite";

import SalesAndOnboarding from "./SalesAndOnboarding";

import ReportGenerator from "./ReportGenerator";

import PlatformAnalytics from "./PlatformAnalytics";

import OnboardingWizard from "./OnboardingWizard";

import TeamAssessments from "./TeamAssessments";

import TeamInsights from "./TeamInsights";

import ExecutiveAnalytics from "./ExecutiveAnalytics";

import ResourceAllocationSimulator from "./ResourceAllocationSimulator";

import SkillMatrix from "./SkillMatrix";

import SkillManagement from "./SkillManagement";

import MySkills from "./MySkills";

import SkillDevelopmentPath from "./SkillDevelopmentPath";

import PrivacySettings from "./PrivacySettings";

import SecurityDashboard from "./SecurityDashboard";

import TeamPerformanceDashboard from "./TeamPerformanceDashboard";

import TeamCollaborationHub from "./TeamCollaborationHub";

import CoachingJourney from "./CoachingJourney";

import HRISIntegration from "./HRISIntegration";

import PredictiveInsights from "./PredictiveInsights";

import CareerPaths from "./CareerPaths";

import ExponentialClarity from "./ExponentialClarity";

import LeadershipEvolution from "./LeadershipEvolution";

import WellnessCompanion from "./WellnessCompanion";

import HolisticImpactDashboard from "./HolisticImpactDashboard";

import EcosystemNetwork from "./EcosystemNetwork";

import CollaborativeWorkflows from "./CollaborativeWorkflows";

import CustomReportBuilder from "./CustomReportBuilder";

import AIInsightsDashboard from "./AIInsightsDashboard";

import KnowledgeSynthesisAI from "./KnowledgeSynthesisAI";

import AILearningJourneys from "./AILearningJourneys";

import SkillTrackerPage from "./SkillTrackerPage";

import AdminUsageDashboard from "./AdminUsageDashboard";

import AIContentStudio from "./AIContentStudio";

import WinWinOptimizer from "./WinWinOptimizer";

import ExecutiveDashboard from "./ExecutiveDashboard";

import ReportingModule from "./ReportingModule";

import KnowledgeBase from "./KnowledgeBase";

import PerformanceReviews from "./PerformanceReviews";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Assessment: Assessment,
    
    Results: Results,
    
    Profile: Profile,
    
    OrganizationDashboard: OrganizationDashboard,
    
    TeamBuilder: TeamBuilder,
    
    Teams: Teams,
    
    CEOAssessment: CEOAssessment,
    
    CEODashboard: CEODashboard,
    
    OrganizationalAnalysis: OrganizationalAnalysis,
    
    OrganizationalAI: OrganizationalAI,
    
    EmployeePortal: EmployeePortal,
    
    ExecutivePortal: ExecutivePortal,
    
    CSuitePortal: CSuitePortal,
    
    AuthSetup: AuthSetup,
    
    QuickAssessment: QuickAssessment,
    
    QuickExecutiveAssessment: QuickExecutiveAssessment,
    
    PlatformAdmin: PlatformAdmin,
    
    OrganizationSettings: OrganizationSettings,
    
    AcceptInvite: AcceptInvite,
    
    SalesAndOnboarding: SalesAndOnboarding,
    
    ReportGenerator: ReportGenerator,
    
    PlatformAnalytics: PlatformAnalytics,
    
    OnboardingWizard: OnboardingWizard,
    
    TeamAssessments: TeamAssessments,
    
    TeamInsights: TeamInsights,
    
    ExecutiveAnalytics: ExecutiveAnalytics,
    
    ResourceAllocationSimulator: ResourceAllocationSimulator,
    
    SkillMatrix: SkillMatrix,
    
    SkillManagement: SkillManagement,
    
    MySkills: MySkills,
    
    SkillDevelopmentPath: SkillDevelopmentPath,
    
    PrivacySettings: PrivacySettings,
    
    SecurityDashboard: SecurityDashboard,
    
    TeamPerformanceDashboard: TeamPerformanceDashboard,
    
    TeamCollaborationHub: TeamCollaborationHub,
    
    CoachingJourney: CoachingJourney,
    
    HRISIntegration: HRISIntegration,
    
    PredictiveInsights: PredictiveInsights,
    
    CareerPaths: CareerPaths,
    
    ExponentialClarity: ExponentialClarity,
    
    LeadershipEvolution: LeadershipEvolution,
    
    WellnessCompanion: WellnessCompanion,
    
    HolisticImpactDashboard: HolisticImpactDashboard,
    
    EcosystemNetwork: EcosystemNetwork,
    
    CollaborativeWorkflows: CollaborativeWorkflows,
    
    CustomReportBuilder: CustomReportBuilder,
    
    AIInsightsDashboard: AIInsightsDashboard,
    
    KnowledgeSynthesisAI: KnowledgeSynthesisAI,
    
    AILearningJourneys: AILearningJourneys,
    
    SkillTrackerPage: SkillTrackerPage,
    
    AdminUsageDashboard: AdminUsageDashboard,
    
    AIContentStudio: AIContentStudio,
    
    WinWinOptimizer: WinWinOptimizer,
    
    ExecutiveDashboard: ExecutiveDashboard,
    
    ReportingModule: ReportingModule,
    
    KnowledgeBase: KnowledgeBase,
    
    PerformanceReviews: PerformanceReviews,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Assessment" element={<Assessment />} />
                
                <Route path="/Results" element={<Results />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/OrganizationDashboard" element={<OrganizationDashboard />} />
                
                <Route path="/TeamBuilder" element={<TeamBuilder />} />
                
                <Route path="/Teams" element={<Teams />} />
                
                <Route path="/CEOAssessment" element={<CEOAssessment />} />
                
                <Route path="/CEODashboard" element={<CEODashboard />} />
                
                <Route path="/OrganizationalAnalysis" element={<OrganizationalAnalysis />} />
                
                <Route path="/OrganizationalAI" element={<OrganizationalAI />} />
                
                <Route path="/EmployeePortal" element={<EmployeePortal />} />
                
                <Route path="/ExecutivePortal" element={<ExecutivePortal />} />
                
                <Route path="/CSuitePortal" element={<CSuitePortal />} />
                
                <Route path="/AuthSetup" element={<AuthSetup />} />
                
                <Route path="/QuickAssessment" element={<QuickAssessment />} />
                
                <Route path="/QuickExecutiveAssessment" element={<QuickExecutiveAssessment />} />
                
                <Route path="/PlatformAdmin" element={<PlatformAdmin />} />
                
                <Route path="/OrganizationSettings" element={<OrganizationSettings />} />
                
                <Route path="/AcceptInvite" element={<AcceptInvite />} />
                
                <Route path="/SalesAndOnboarding" element={<SalesAndOnboarding />} />
                
                <Route path="/ReportGenerator" element={<ReportGenerator />} />
                
                <Route path="/PlatformAnalytics" element={<PlatformAnalytics />} />
                
                <Route path="/OnboardingWizard" element={<OnboardingWizard />} />
                
                <Route path="/TeamAssessments" element={<TeamAssessments />} />
                
                <Route path="/TeamInsights" element={<TeamInsights />} />
                
                <Route path="/ExecutiveAnalytics" element={<ExecutiveAnalytics />} />
                
                <Route path="/ResourceAllocationSimulator" element={<ResourceAllocationSimulator />} />
                
                <Route path="/SkillMatrix" element={<SkillMatrix />} />
                
                <Route path="/SkillManagement" element={<SkillManagement />} />
                
                <Route path="/MySkills" element={<MySkills />} />
                
                <Route path="/SkillDevelopmentPath" element={<SkillDevelopmentPath />} />
                
                <Route path="/PrivacySettings" element={<PrivacySettings />} />
                
                <Route path="/SecurityDashboard" element={<SecurityDashboard />} />
                
                <Route path="/TeamPerformanceDashboard" element={<TeamPerformanceDashboard />} />
                
                <Route path="/TeamCollaborationHub" element={<TeamCollaborationHub />} />
                
                <Route path="/CoachingJourney" element={<CoachingJourney />} />
                
                <Route path="/HRISIntegration" element={<HRISIntegration />} />
                
                <Route path="/PredictiveInsights" element={<PredictiveInsights />} />
                
                <Route path="/CareerPaths" element={<CareerPaths />} />
                
                <Route path="/ExponentialClarity" element={<ExponentialClarity />} />
                
                <Route path="/LeadershipEvolution" element={<LeadershipEvolution />} />
                
                <Route path="/WellnessCompanion" element={<WellnessCompanion />} />
                
                <Route path="/HolisticImpactDashboard" element={<HolisticImpactDashboard />} />
                
                <Route path="/EcosystemNetwork" element={<EcosystemNetwork />} />
                
                <Route path="/CollaborativeWorkflows" element={<CollaborativeWorkflows />} />
                
                <Route path="/CustomReportBuilder" element={<CustomReportBuilder />} />
                
                <Route path="/AIInsightsDashboard" element={<AIInsightsDashboard />} />
                
                <Route path="/KnowledgeSynthesisAI" element={<KnowledgeSynthesisAI />} />
                
                <Route path="/AILearningJourneys" element={<AILearningJourneys />} />
                
                <Route path="/SkillTrackerPage" element={<SkillTrackerPage />} />
                
                <Route path="/AdminUsageDashboard" element={<AdminUsageDashboard />} />
                
                <Route path="/AIContentStudio" element={<AIContentStudio />} />
                
                <Route path="/WinWinOptimizer" element={<WinWinOptimizer />} />
                
                <Route path="/ExecutiveDashboard" element={<ExecutiveDashboard />} />
                
                <Route path="/ReportingModule" element={<ReportingModule />} />
                
                <Route path="/KnowledgeBase" element={<KnowledgeBase />} />
                
                <Route path="/PerformanceReviews" element={<PerformanceReviews />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}