import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sparkles, BookOpen, Target, Award, Trophy, Clock, CheckCircle2,
  Play, Lock, Star, Brain, Zap, RefreshCw, Plus, ChevronRight,
  GraduationCap, Lightbulb, FileText, HelpCircle, TrendingUp, TrendingDown, Eye
} from "lucide-react";
import JourneyModuleViewer from "../components/learning/JourneyModuleViewer";
import LearningCatalog, { COURSE_CATALOG } from "../components/learning/LearningCatalog";
import GamificationPanel from "../components/learning/GamificationPanel";
import AdaptiveLearningEngine from "../components/learning/AdaptiveLearningEngine";
import FunCourseViewer from "../components/learning/FunCourseViewer";
import PersonalizedLearningEngine from "../components/learning/PersonalizedLearningEngine";

export default function AILearningJourneys() {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedJourney, setSelectedJourney] = useState(null);
  const [activeModule, setActiveModule] = useState(null);
  const [journeyInput, setJourneyInput] = useState({
    career_goal: "",
    timeframe: "3_months",
    focus_areas: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: journeys, isLoading } = useQuery({
    queryKey: ['myLearningJourneys', user?.email],
    queryFn: () => base44.entities.LearningJourney.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: userSkills } = useQuery({
    queryKey: ['userSkillsForJourney', user?.email],
    queryFn: () => base44.entities.UserSkill.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['userAssessmentsForJourney', user?.email],
    queryFn: () => base44.entities.Assessment.filter({ created_by: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: usageInsights } = useQuery({
    queryKey: ['platformUsageForLearning'],
    queryFn: async () => {
      const analyses = await base44.entities.PlatformUsageAnalytics.list('-analysis_date', 1);
      return analyses[0] || null;
    },
  });

  const createJourneyMutation = useMutation({
    mutationFn: (data) => base44.entities.LearningJourney.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] });
      setShowCreateDialog(false);
    },
  });

  const updateJourneyMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LearningJourney.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] });
    },
  });

  const generateLearningJourney = async () => {
    setIsGenerating(true);
    setGenerationStep("Analyzing your profile and skill gaps...");

    try {
      const skillNames = userSkills?.map(s => `${s.skill_name} (${s.current_proficiency || 'Beginner'})`).join(', ') || 'No skills recorded';
      const latestAssessment = assessments?.[0];

      setGenerationStep("Designing personalized learning path...");

      const journeyDesign = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert learning designer. Create a comprehensive, personalized learning journey.

USER PROFILE:
- Career Goal: ${journeyInput.career_goal}
- Focus Areas: ${journeyInput.focus_areas || 'General development'}
- Timeframe: ${journeyInput.timeframe}
- Current Skills: ${skillNames}
- Recent Assessment Insights: ${latestAssessment?.ai_insights?.substring(0, 500) || 'No assessment data'}

Generate a detailed learning journey with 4-6 modules. Each module should have:
1. Clear learning objectives
2. Key concepts to master
3. 2-3 detailed lessons with actual educational content (not placeholders)
4. Practical exercises with clear instructions
5. Assessment questions with answers and explanations
6. Reflection prompts

The content should be REAL, SUBSTANTIVE educational material - not outlines or placeholders.
Make the content actionable and immediately applicable.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            difficulty_level: { type: "string" },
            total_duration_hours: { type: "number" },
            skill_gaps_identified: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  current_level: { type: "string" },
                  target_level: { type: "string" }
                }
              }
            },
            modules: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  module_id: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  duration_minutes: { type: "number" },
                  skill_focus: { type: "string" },
                  content: {
                    type: "object",
                    properties: {
                      learning_objectives: { type: "array", items: { type: "string" } },
                      key_concepts: { type: "array", items: { type: "string" } },
                      lessons: {
                        type: "array",
                        items: {
                          type: "object",
                          properties: {
                            lesson_id: { type: "string" },
                            title: { type: "string" },
                            content: { type: "string" },
                            exercises: { type: "array", items: { type: "string" } },
                            reflection_prompts: { type: "array", items: { type: "string" } }
                          }
                        }
                      },
                      assessment: {
                        type: "object",
                        properties: {
                          questions: {
                            type: "array",
                            items: {
                              type: "object",
                              properties: {
                                question: { type: "string" },
                                type: { type: "string" },
                                options: { type: "array", items: { type: "string" } },
                                correct_answer: { type: "string" },
                                explanation: { type: "string" }
                              }
                            }
                          },
                          passing_score: { type: "number" }
                        }
                      },
                      practical_exercises: {
                        type: "array",
                        items: {
                          type: "object",
                          properties: {
                            title: { type: "string" },
                            instructions: { type: "string" },
                            expected_outcome: { type: "string" },
                            time_estimate: { type: "string" }
                          }
                        }
                      }
                    }
                  }
                }
              }
            },
            completion_badge: {
              type: "object",
              properties: {
                badge_name: { type: "string" },
                badge_icon: { type: "string" },
                description: { type: "string" }
              }
            },
            bonus_points_available: { type: "number" },
            ai_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setGenerationStep("Creating your personalized journey...");

      // Set first module as available
      const modulesWithStatus = journeyDesign.modules?.map((m, i) => ({
        ...m,
        status: i === 0 ? 'available' : 'locked'
      })) || [];

      const targetDate = new Date();
      const monthsToAdd = journeyInput.timeframe === '1_month' ? 1 : 
                          journeyInput.timeframe === '3_months' ? 3 : 6;
      targetDate.setMonth(targetDate.getMonth() + monthsToAdd);

      await createJourneyMutation.mutateAsync({
        user_email: user.email,
        title: journeyDesign.title,
        description: journeyDesign.description,
        career_goal: journeyInput.career_goal,
        target_skills: journeyInput.focus_areas?.split(',').map(s => s.trim()) || [],
        current_skill_gaps: journeyDesign.skill_gaps_identified || [],
        modules: modulesWithStatus,
        total_duration_hours: journeyDesign.total_duration_hours || 20,
        difficulty_level: journeyDesign.difficulty_level || 'intermediate',
        progress_percentage: 0,
        status: 'not_started',
        badges_earned: [],
        bonus_points_earned: 0,
        ai_recommendations: journeyDesign.ai_recommendations || [],
        start_date: new Date().toISOString(),
        target_completion_date: targetDate.toISOString().split('T')[0]
      });

      setGenerationStep("Journey created successfully!");
      setJourneyInput({ career_goal: "", timeframe: "3_months", focus_areas: "" });

    } catch (error) {
      console.error("Error generating journey:", error);
      setGenerationStep("Error generating journey. Please try again.");
    }

    setTimeout(() => {
      setIsGenerating(false);
      setGenerationStep("");
    }, 1500);
  };

  const completeModule = async (journey, moduleIndex) => {
    const updatedModules = [...journey.modules];
    updatedModules[moduleIndex] = {
      ...updatedModules[moduleIndex],
      status: 'completed',
      completion_date: new Date().toISOString(),
      score: 100
    };

    // Unlock next module
    if (moduleIndex + 1 < updatedModules.length) {
      updatedModules[moduleIndex + 1] = {
        ...updatedModules[moduleIndex + 1],
        status: 'available'
      };
    }

    const completedCount = updatedModules.filter(m => m.status === 'completed').length;
    const progress = Math.round((completedCount / updatedModules.length) * 100);
    const isComplete = completedCount === updatedModules.length;

    let badges = [...(journey.badges_earned || [])];
    let bonusPoints = journey.bonus_points_earned || 0;

    // Award module completion badge
    badges.push({
      badge_id: `module_${moduleIndex}_${Date.now()}`,
      badge_name: `${updatedModules[moduleIndex].title} Master`,
      badge_icon: '🎯',
      earned_date: new Date().toISOString(),
      description: `Completed module: ${updatedModules[moduleIndex].title}`
    });
    bonusPoints += 50;

    // Award journey completion badge if all modules done
    if (isComplete) {
      badges.push({
        badge_id: `journey_complete_${Date.now()}`,
        badge_name: `${journey.title} Champion`,
        badge_icon: '🏆',
        earned_date: new Date().toISOString(),
        description: `Successfully completed the entire ${journey.title} learning journey!`
      });
      bonusPoints += 200;
    }

    await updateJourneyMutation.mutateAsync({
      id: journey.id,
      data: {
        modules: updatedModules,
        progress_percentage: progress,
        status: isComplete ? 'completed' : 'in_progress',
        badges_earned: badges,
        bonus_points_earned: bonusPoints,
        ...(isComplete && { actual_completion_date: new Date().toISOString() })
      }
    });

    setActiveModule(null);
  };

  const startJourney = async (journey) => {
    if (journey.status === 'not_started') {
      await updateJourneyMutation.mutateAsync({
        id: journey.id,
        data: { status: 'in_progress' }
      });
    }
    setSelectedJourney(journey);
  };

  const totalBadges = journeys?.reduce((acc, j) => acc + (j.badges_earned?.length || 0), 0) || 0;
  const totalPoints = journeys?.reduce((acc, j) => acc + (j.bonus_points_earned || 0), 0) || 0;
  const completedJourneys = journeys?.filter(j => j.status === 'completed').length || 0;
  const completedJourneysList = journeys?.filter(j => j.status === 'completed') || [];
  const inProgressJourneysList = journeys?.filter(j => j.status === 'in_progress') || [];

  const scrollToCourse = (courseTitle) => {
    // Trigger catalog tab and scroll to course
    const catalogTab = document.querySelector('[value="catalog"]');
    if (catalogTab) catalogTab.click();
  };

  if (activeModule && selectedJourney) {
    return (
      <FunCourseViewer
        journey={selectedJourney}
        module={activeModule}
        moduleIndex={selectedJourney.modules.findIndex(m => m.module_id === activeModule.module_id)}
        onComplete={() => completeModule(selectedJourney, selectedJourney.modules.findIndex(m => m.module_id === activeModule.module_id))}
        onBack={() => setActiveModule(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide mb-2">AI Learning Journeys</h1>
            <p className="text-gray-400">Personalized learning paths generated by AI based on your goals</p>
          </div>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200">
                <Plus className="w-4 h-4 mr-2" />
                Create Journey
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  Generate AI Learning Journey
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Career Goal</label>
                  <Textarea
                    value={journeyInput.career_goal}
                    onChange={(e) => setJourneyInput({...journeyInput, career_goal: e.target.value})}
                    placeholder="e.g., Become a Senior Product Manager, Transition to Data Science, Develop Leadership Skills"
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Focus Areas (comma-separated)</label>
                  <Input
                    value={journeyInput.focus_areas}
                    onChange={(e) => setJourneyInput({...journeyInput, focus_areas: e.target.value})}
                    placeholder="e.g., Strategic thinking, Data analysis, Communication"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Timeframe</label>
                  <Select value={journeyInput.timeframe} onValueChange={(v) => setJourneyInput({...journeyInput, timeframe: v})}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1_month">1 Month (Intensive)</SelectItem>
                      <SelectItem value="3_months">3 Months (Recommended)</SelectItem>
                      <SelectItem value="6_months">6 Months (Comprehensive)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {isGenerating && (
                  <div className="p-4 bg-purple-900/30 border border-purple-800 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                      <span className="text-purple-300 text-sm">{generationStep}</span>
                    </div>
                  </div>
                )}

                <Button 
                  onClick={generateLearningJourney}
                  disabled={!journeyInput.career_goal || isGenerating}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {isGenerating ? (
                    <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                  ) : (
                    <><Brain className="w-4 h-4 mr-2" /> Generate Journey with AI</>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Active Journeys</p>
                  <p className="text-2xl font-bold text-white">{journeys?.filter(j => j.status === 'in_progress').length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-green-900 flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Completed</p>
                  <p className="text-2xl font-bold text-white">{completedJourneys}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-yellow-900 flex items-center justify-center">
                  <Award className="w-6 h-6 text-yellow-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Badges Earned</p>
                  <p className="text-2xl font-bold text-white">{totalBadges}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-cyan-900 flex items-center justify-center">
                  <Star className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Bonus Points</p>
                  <p className="text-2xl font-bold text-white">{totalPoints}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="my-journeys" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="my-journeys">My Journeys</TabsTrigger>
            <TabsTrigger value="recommendations">
              <Sparkles className="w-4 h-4 mr-1" />AI Recommendations
            </TabsTrigger>
            <TabsTrigger value="catalog">Course Catalog</TabsTrigger>
            <TabsTrigger value="gamification">🏆 Achievements</TabsTrigger>
            <TabsTrigger value="create">Create Custom</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations">
            <PersonalizedLearningEngine
              user={user}
              completedJourneys={completedJourneysList}
              inProgressJourneys={inProgressJourneysList}
              userSkills={userSkills}
              assessments={assessments}
              availableCourses={COURSE_CATALOG}
              onCourseSelect={scrollToCourse}
            />
          </TabsContent>

          <TabsContent value="catalog">
            {/* AI Usage Insights Banner */}
            {usageInsights?.popular_features?.some(f => f.feature_name === "AI Learning Journeys") && (
              <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-800 mb-6">
                <CardContent className="p-4 flex items-center gap-4">
                  <TrendingUp className="w-8 h-8 text-green-400" />
                  <div className="flex-1">
                    <p className="text-green-400 font-medium">🔥 Trending Feature!</p>
                    <p className="text-gray-300 text-sm">AI Learning is one of our most popular features with high user satisfaction</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {usageInsights?.underutilized_features?.some(f => f.feature_name === "AI Learning Journeys") && (
              <Card className="bg-gradient-to-r from-orange-900/30 to-yellow-900/30 border-orange-800 mb-6">
                <CardContent className="p-4 flex items-center gap-4">
                  <Lightbulb className="w-8 h-8 text-orange-400" />
                  <div className="flex-1">
                    <p className="text-orange-400 font-medium">💡 Discovery Tip</p>
                    <p className="text-gray-300 text-sm">
                      {usageInsights.underutilized_features.find(f => f.feature_name === "AI Learning Journeys")?.promotion_strategy}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <LearningCatalog user={user} usageInsights={usageInsights} onEnroll={() => queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] })} />
          </TabsContent>

          <TabsContent value="gamification">
            <GamificationPanel user={user} />
          </TabsContent>

          <TabsContent value="create">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="max-w-lg mx-auto space-y-4">
                  <div className="text-center mb-6">
                    <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-3" />
                    <h3 className="text-white font-medium text-lg">Create Custom AI Journey</h3>
                    <p className="text-gray-400 text-sm">Generate a personalized learning path based on your goals</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Career Goal</label>
                    <Textarea
                      value={journeyInput.career_goal}
                      onChange={(e) => setJourneyInput({...journeyInput, career_goal: e.target.value})}
                      placeholder="e.g., Become a Senior Product Manager, Transition to Data Science"
                      className="bg-gray-800 border-gray-700 text-white h-20"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Focus Areas (comma-separated)</label>
                    <Input
                      value={journeyInput.focus_areas}
                      onChange={(e) => setJourneyInput({...journeyInput, focus_areas: e.target.value})}
                      placeholder="e.g., Strategic thinking, Data analysis"
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-400 mb-2 block">Timeframe</label>
                    <Select value={journeyInput.timeframe} onValueChange={(v) => setJourneyInput({...journeyInput, timeframe: v})}>
                      <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1_month">1 Month (Intensive)</SelectItem>
                        <SelectItem value="3_months">3 Months (Recommended)</SelectItem>
                        <SelectItem value="6_months">6 Months (Comprehensive)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {isGenerating && (
                    <div className="p-4 bg-purple-900/30 border border-purple-800 rounded-lg">
                      <div className="flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                        <span className="text-purple-300 text-sm">{generationStep}</span>
                      </div>
                    </div>
                  )}
                  <Button onClick={generateLearningJourney} disabled={!journeyInput.career_goal || isGenerating} className="w-full bg-purple-600 hover:bg-purple-700">
                    {isGenerating ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating...</> : <><Brain className="w-4 h-4 mr-2" /> Generate Journey with AI</>}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="my-journeys">
        {selectedJourney ? (
          /* Journey Detail View */
          <div className="space-y-6">
            <Button variant="ghost" onClick={() => setSelectedJourney(null)} className="text-gray-400">
              ← Back to Journeys
            </Button>

            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-xl">{selectedJourney.title}</CardTitle>
                    <CardDescription className="text-gray-400 mt-1">{selectedJourney.description}</CardDescription>
                  </div>
                  <Badge className={
                    selectedJourney.status === 'completed' ? 'bg-green-600' :
                    selectedJourney.status === 'in_progress' ? 'bg-blue-600' : 'bg-gray-600'
                  }>
                    {selectedJourney.status?.replace('_', ' ')}
                  </Badge>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-400">Progress</span>
                    <span className="text-white">{selectedJourney.progress_percentage}%</span>
                  </div>
                  <Progress value={selectedJourney.progress_percentage} className="h-2" />
                </div>
              </CardHeader>
              <CardContent>
                {/* Adaptive Learning Engine */}
                <div className="mb-6">
                  <AdaptiveLearningEngine 
                    user={user} 
                    journey={selectedJourney} 
                    userSkills={userSkills}
                  />
                </div>
                {/* Modules */}
                <div className="space-y-4">
                  <h3 className="text-white font-medium">Learning Modules</h3>
                  {selectedJourney.modules?.map((module, i) => (
                    <div 
                      key={module.module_id || i}
                      className={`p-4 rounded-lg border ${
                        module.status === 'completed' ? 'bg-green-900/20 border-green-800' :
                        module.status === 'available' ? 'bg-gray-800 border-gray-700 hover:border-purple-600 cursor-pointer' :
                        'bg-gray-800/50 border-gray-800 opacity-60'
                      }`}
                      onClick={() => module.status === 'available' && setActiveModule(module)}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          module.status === 'completed' ? 'bg-green-600' :
                          module.status === 'available' ? 'bg-purple-600' : 'bg-gray-700'
                        }`}>
                          {module.status === 'completed' ? (
                            <CheckCircle2 className="w-5 h-5 text-white" />
                          ) : module.status === 'available' ? (
                            <Play className="w-5 h-5 text-white" />
                          ) : (
                            <Lock className="w-5 h-5 text-gray-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-white font-medium">{module.title}</h4>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-gray-500" />
                              <span className="text-gray-400 text-sm">{module.duration_minutes} min</span>
                            </div>
                          </div>
                          <p className="text-gray-400 text-sm mt-1">{module.description}</p>
                          <Badge variant="outline" className="mt-2 border-gray-700 text-gray-400">
                            {module.skill_focus}
                          </Badge>
                        </div>
                        {module.status === 'available' && (
                          <ChevronRight className="w-5 h-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Badges */}
                {selectedJourney.badges_earned?.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-white font-medium mb-3">Badges Earned</h3>
                    <div className="flex flex-wrap gap-3">
                      {selectedJourney.badges_earned.map((badge, i) => (
                        <div key={i} className="flex items-center gap-2 px-3 py-2 bg-yellow-900/30 border border-yellow-800 rounded-lg">
                          <span className="text-2xl">{badge.badge_icon}</span>
                          <div>
                            <p className="text-yellow-300 text-sm font-medium">{badge.badge_name}</p>
                            <p className="text-gray-400 text-xs">{badge.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : (
          /* Journey List */
          <div className="space-y-6">
            {journeys?.length === 0 ? (
              <Card className="bg-gray-900 border-gray-800 text-center py-16">
                <CardContent>
                  <GraduationCap className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-white font-medium text-lg mb-2">No Learning Journeys Yet</h3>
                  <p className="text-gray-400 mb-6">Create your first AI-generated learning journey to start developing new skills</p>
                  <Button onClick={() => setShowCreateDialog(true)} className="bg-purple-600 hover:bg-purple-700">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate My First Journey
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {journeys.map(journey => (
                  <Card key={journey.id} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors cursor-pointer" onClick={() => startJourney(journey)}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-12 h-12 rounded-xl bg-purple-900 flex items-center justify-center">
                          <BookOpen className="w-6 h-6 text-purple-400" />
                        </div>
                        <Badge className={
                          journey.status === 'completed' ? 'bg-green-600' :
                          journey.status === 'in_progress' ? 'bg-blue-600' : 'bg-gray-600'
                        }>
                          {journey.status?.replace('_', ' ')}
                        </Badge>
                      </div>
                      <h3 className="text-white font-medium text-lg mb-2">{journey.title}</h3>
                      <p className="text-gray-400 text-sm line-clamp-2 mb-4">{journey.description}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {journey.total_duration_hours}h
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="w-4 h-4" />
                          {journey.modules?.length || 0} modules
                        </span>
                        <span className="flex items-center gap-1">
                          <Award className="w-4 h-4" />
                          {journey.badges_earned?.length || 0} badges
                        </span>
                      </div>

                      <Progress value={journey.progress_percentage} className="h-2 mb-2" />
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">{journey.progress_percentage}% complete</span>
                        <span className="text-purple-400">{journey.bonus_points_earned || 0} pts</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}