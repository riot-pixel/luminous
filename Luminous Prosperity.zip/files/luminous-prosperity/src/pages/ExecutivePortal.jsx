import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Briefcase, Users, TrendingUp, BarChart3, Target, Brain, Award, Building2, Heart, Sparkles, Zap, Wind } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { AnimatePresence } from "framer-motion";
import BreathingExercise from "../components/wellness/BreathingExercise";
import DailyWellnessCard from "../components/wellness/DailyWellnessCard";

export default function ExecutivePortal() {
  const [showBreathing, setShowBreathing] = useState(false);

  const { data: user, isLoading: loadingUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: directReports, isLoading: loadingReports } = useQuery({
    queryKey: ['directReports'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.User.filter({ manager_email: currentUser.email });
    },
    initialData: [],
  });

  const { data: allAssessments, isLoading: loadingAssessments } = useQuery({
    queryKey: ['allAssessments'],
    queryFn: () => base44.entities.Assessment.list('-completed_date'),
    initialData: [],
  });

  const { data: teams, isLoading: loadingTeams } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
    initialData: [],
  });

  const { data: ceoAssessments, isLoading: loadingCEO } = useQuery({
    queryKey: ['ceoAssessments'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.CEOAssessment.filter({ user_email: currentUser.email }, '-completed_date');
    },
    initialData: [],
  });

  if (loadingUser || loadingReports || loadingAssessments || loadingTeams || loadingCEO) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading executive portal...</p>
        </div>
      </div>
    );
  }

  // Calculate team assessment completion
  const reportAssessments = allAssessments.filter(a => 
    directReports.some(r => r.email === a.user_email)
  );
  const completionRate = directReports.length > 0 
    ? Math.round((reportAssessments.length / directReports.length) * 100)
    : 0;

  // Department distribution
  const deptCounts = directReports.reduce((acc, emp) => {
    const dept = emp.department || 'Unassigned';
    acc[dept] = (acc[dept] || 0) + 1;
    return acc;
  }, {});
  const deptData = Object.entries(deptCounts).map(([name, value]) => ({ name, value }));

  const executiveActions = [
    {
      title: "Quick Leadership Assessment",
      description: "10-minute executive assessment",
      icon: Zap,
      url: createPageUrl("QuickExecutiveAssessment"),
      color: "from-green-500 to-emerald-600",
      available: true,
      badge: "Fast",
    },
    {
      title: "Full Leadership Assessment",
      description: "Comprehensive CEO assessment",
      icon: Briefcase,
      url: createPageUrl("CEOAssessment"),
      color: "from-[#B8967D] to-[#A68364]",
      available: true,
    },
    {
      title: "Executive Dashboard",
      description: "View leadership insights",
      icon: TrendingUp,
      url: createPageUrl("CEODashboard"),
      color: "from-orange-400 to-orange-500",
      available: ceoAssessments.length > 0,
    },
    {
      title: "Organizational Analysis",
      description: "Deep-dive strategic analysis",
      icon: Building2,
      url: createPageUrl("OrganizationalAnalysis"),
      color: "from-amber-400 to-amber-500",
      available: true,
    },
    {
      title: "Team Optimization",
      description: "AI-powered team composition",
      icon: Users,
      url: createPageUrl("TeamBuilder"),
      color: "from-yellow-400 to-yellow-500",
      available: true,
    },
  ];

  const latestAssessment = ceoAssessments[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
      {/* Breathing Exercise Modal */}
      <AnimatePresence>
        {showBreathing && (
          <BreathingExercise onClose={() => setShowBreathing(false)} variant="light" />
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto">
        {/* Executive Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-xl flex items-center justify-center shadow-lg">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-stone-800">Executive Portal</h1>
                <p className="text-stone-600">{user?.full_name} • {user?.job_title}</p>
              </div>
            </div>
            <Button
              onClick={() => setShowBreathing(true)}
              variant="outline"
              className="border-stone-300 text-stone-600 hover:bg-stone-100"
            >
              <Wind className="w-4 h-4 mr-2" />
              Mindful Moment
            </Button>
          </div>
        </div>

        {/* Daily Wellness Card */}
        <div className="mb-8">
          <DailyWellnessCard user={user} assessment={latestAssessment} variant="light" />
        </div>

        {/* Executive Coaching Section */}
        <Card className="mb-8 border-2 border-amber-400 bg-gradient-to-r from-amber-50 to-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Users className="w-6 h-6 text-amber-600" />
              Executive Coaching
            </CardTitle>
            <CardDescription>
              One-on-one coaching sessions to discuss your leadership insights and development
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 space-y-2">
                <p className="text-sm text-gray-700">
                  <strong>What to expect:</strong> Personalized coaching focused on your assessment results, 
                  leadership challenges, and organizational strategy alignment.
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Duration:</strong> 60 minutes | <strong>Format:</strong> Video call
                </p>
              </div>
              <div className="flex flex-col gap-3 md:w-64">
                <Button 
                  className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                  onClick={() => window.open('https://ammanuel.as.me/Welcome', '_blank')}
                >
                  Schedule Coaching Call
                </Button>
                <Button 
                  variant="outline"
                  className="border-amber-600 text-amber-600 hover:bg-amber-50"
                  onClick={() => window.open('mailto:ammanuel@luminousprosperity.com?subject=Coaching Inquiry', '_blank')}
                >
                  Email Coach
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[#B8967D] to-[#A68364] text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Direct Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{directReports.length}</div>
              <p className="text-xs text-white/80 mt-1">team members</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-400 to-orange-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Assessment Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{completionRate}%</div>
              <p className="text-xs text-white/80 mt-1">{reportAssessments.length} completed</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-400 to-amber-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Active Teams</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{teams.filter(t => t.status === 'active').length}</div>
              <p className="text-xs text-white/80 mt-1">in your organization</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-400 to-yellow-500 text-white border-none">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-white/80">Leadership Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold">{ceoAssessments.length}</div>
              <p className="text-xs text-white/80 mt-1">assessments completed</p>
            </CardContent>
          </Card>
        </div>

        {/* Executive Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-stone-800 mb-4">Executive Actions</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {executiveActions.map((action, index) => (
              <Link key={index} to={action.url}>
                <Card className={`group hover:shadow-xl transition-all duration-300 border-2 hover:border-[#B8967D]/30 cursor-pointer h-full ${!action.available && 'opacity-50'}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-3">
                      <div className={`w-12 h-12 bg-gradient-to-br ${action.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-md`}>
                        <action.icon className="w-6 h-6 text-white" />
                      </div>
                      {action.badge && (
                        <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">
                          {action.badge}
                        </span>
                      )}
                    </div>
                    <CardTitle className="text-base group-hover:text-[#B8967D] transition-colors">
                      {action.title}
                    </CardTitle>
                    <CardDescription className="text-sm">{action.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Team Insights */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-[#B8967D]" />
                Team Distribution
              </CardTitle>
              <CardDescription>Direct reports by department</CardDescription>
            </CardHeader>
            <CardContent>
              {deptData.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={deptData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#B8967D" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center text-stone-400 py-8">No team data available</div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-[#B8967D]" />
                Strategic Priorities
              </CardTitle>
              <CardDescription>Key focus areas for your organization</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Link to={createPageUrl("TeamBuilder")}>
                  <div className="p-3 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer">
                    <p className="font-medium text-stone-800">Optimize Team Composition</p>
                    <p className="text-xs text-stone-600">AI-driven talent alignment</p>
                  </div>
                </Link>
                <Link to={createPageUrl("OrganizationalAI")}>
                  <div className="p-3 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer">
                    <p className="font-medium text-stone-800">Review Organizational AI</p>
                    <p className="text-xs text-stone-600">Collective insights and vision</p>
                  </div>
                </Link>
                <Link to={createPageUrl("OrganizationDashboard")}>
                  <div className="p-3 bg-stone-50 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer">
                    <p className="font-medium text-stone-800">Organizational Health</p>
                    <p className="text-xs text-stone-600">Comprehensive metrics</p>
                  </div>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Team Members Overview */}
        {directReports.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#B8967D]" />
                Your Team
              </CardTitle>
              <CardDescription>{directReports.length} direct reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
                {directReports.slice(0, 8).map((member) => {
                  const hasAssessment = reportAssessments.some(a => a.user_email === member.email);
                  return (
                    <div key={member.id} className="p-3 border border-stone-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-full flex items-center justify-center text-white text-xs font-bold">
                          {member.full_name?.charAt(0) || member.email.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-stone-800 truncate">{member.full_name || 'Not Set'}</p>
                          <p className="text-xs text-stone-500 truncate">{member.job_title || member.department}</p>
                        </div>
                      </div>
                      {hasAssessment ? (
                        <div className="flex items-center gap-1 text-xs text-green-600">
                          <Award className="w-3 h-3" />
                          <span>Assessed</span>
                        </div>
                      ) : (
                        <div className="text-xs text-stone-400">Pending assessment</div>
                      )}
                    </div>
                  );
                })}
              </div>
              {directReports.length > 8 && (
                <div className="mt-4 text-center">
                  <Link to={createPageUrl("OrganizationDashboard")}>
                    <Button variant="outline" size="sm">
                      View All Team Members
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}