import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  BookOpen, Search, Plus, Tag, FileText, HelpCircle, Lightbulb, 
  Users, Target, Brain, Edit, Trash2, Eye, Clock, Star
} from "lucide-react";

export default function KnowledgeBase() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDomain, setSelectedDomain] = useState("all");
  const [isCreating, setIsCreating] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [newArticle, setNewArticle] = useState({
    title: "",
    summary: "",
    content: "",
    domain: "organizational",
    tags: [],
    key_concepts: []
  });
  const [tagInput, setTagInput] = useState("");

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: articles } = useQuery({
    queryKey: ['knowledgeArticles'],
    queryFn: () => base44.entities.KnowledgeBaseArticle.list('-created_date'),
    initialData: [],
  });

  const createArticleMutation = useMutation({
    mutationFn: (data) => base44.entities.KnowledgeBaseArticle.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['knowledgeArticles'] });
      setIsCreating(false);
      setNewArticle({ title: "", summary: "", content: "", domain: "organizational", tags: [], key_concepts: [] });
    }
  });

  const deleteArticleMutation = useMutation({
    mutationFn: (id) => base44.entities.KnowledgeBaseArticle.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['knowledgeArticles'] });
      setSelectedArticle(null);
    }
  });

  const domains = [
    { value: "organizational", label: "Organizational", icon: Users },
    { value: "leadership", label: "Leadership", icon: Star },
    { value: "skills", label: "Skills & Development", icon: Target },
    { value: "wellness", label: "Wellness", icon: Brain },
    { value: "strategy", label: "Strategy", icon: Lightbulb },
    { value: "ecosystem", label: "Ecosystem", icon: Users },
    { value: "innovation", label: "Innovation", icon: Lightbulb },
    { value: "market", label: "Market Insights", icon: Target },
  ];

  const filteredArticles = articles.filter(article => {
    const matchesSearch = searchQuery === "" || 
      article.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      article.key_concepts?.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDomain = selectedDomain === "all" || article.domain === selectedDomain;
    return matchesSearch && matchesDomain;
  });

  const addTag = () => {
    if (tagInput && !newArticle.tags.includes(tagInput)) {
      setNewArticle({ ...newArticle, tags: [...newArticle.tags, tagInput] });
      setTagInput("");
    }
  };

  const isAdmin = user?.role === 'admin';

  const domainColors = {
    organizational: 'bg-blue-600',
    leadership: 'bg-amber-600',
    skills: 'bg-green-600',
    wellness: 'bg-pink-600',
    strategy: 'bg-purple-600',
    ecosystem: 'bg-cyan-600',
    innovation: 'bg-orange-600',
    market: 'bg-indigo-600',
  };

  // Pre-built FAQs
  const faqs = [
    { q: "What is the Integral Theory framework?", a: "Integral Theory is a comprehensive map of human development that includes four quadrants: Individual Interior (thoughts, feelings), Individual Exterior (behaviors, actions), Collective Interior (culture, shared values), and Collective Exterior (systems, structures)." },
    { q: "How are assessment scores calculated?", a: "Assessment scores are calculated using a weighted combination of self-reported data, behavioral indicators, peer feedback, and AI analysis. Each dimension is scored on a 0-100 scale." },
    { q: "What is the Win-Win Optimizer?", a: "The Win-Win Optimizer is an AI-powered tool that analyzes employee fulfillment and operational effectiveness to identify reassignment opportunities that benefit both the individual and the organization." },
    { q: "How often should assessments be taken?", a: "We recommend comprehensive assessments quarterly and quick assessments monthly to track progress and identify emerging trends." },
    { q: "What data is used in predictive analytics?", a: "Predictive analytics uses assessment history, skill progression, coaching performance, learning engagement, wellness trends, and collaboration patterns to forecast future performance." },
  ];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-light text-white tracking-wide flex items-center gap-3">
              <BookOpen className="w-8 h-8 text-cyan-400" />
              Knowledge Base
            </h1>
            <p className="text-gray-400 mt-1">Guides, frameworks, and best practices</p>
          </div>
          {isAdmin && (
            <Dialog open={isCreating} onOpenChange={setIsCreating}>
              <DialogTrigger asChild>
                <Button className="bg-white text-black hover:bg-gray-200">
                  <Plus className="w-4 h-4 mr-2" /> Add Article
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-800 max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-white">Create Knowledge Article</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <Input
                    placeholder="Article Title"
                    value={newArticle.title}
                    onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                  <Textarea
                    placeholder="Summary (brief description)"
                    value={newArticle.summary}
                    onChange={(e) => setNewArticle({ ...newArticle, summary: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white h-20"
                  />
                  <Textarea
                    placeholder="Full Content (supports markdown)"
                    value={newArticle.content}
                    onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white h-48"
                  />
                  <Select value={newArticle.domain} onValueChange={(v) => setNewArticle({ ...newArticle, domain: v })}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Domain" />
                    </SelectTrigger>
                    <SelectContent>
                      {domains.map(d => (
                        <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Tags</p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add tag"
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                        className="bg-gray-800 border-gray-700 text-white flex-1"
                      />
                      <Button type="button" onClick={addTag} variant="outline" className="border-gray-700">Add</Button>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {newArticle.tags.map((tag, i) => (
                        <Badge key={i} variant="outline" className="border-gray-700 text-gray-300">
                          {tag}
                          <button onClick={() => setNewArticle({ ...newArticle, tags: newArticle.tags.filter((_, j) => j !== i) })} className="ml-1 text-gray-500">×</button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button
                    onClick={() => createArticleMutation.mutate({ ...newArticle, status: 'published', ai_confidence: 100 })}
                    disabled={!newArticle.title || !newArticle.summary}
                    className="w-full bg-cyan-600 hover:bg-cyan-700"
                  >
                    Publish Article
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Search */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search articles, tags, concepts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-gray-900 border-gray-800 text-white"
            />
          </div>
          <Select value={selectedDomain} onValueChange={setSelectedDomain}>
            <SelectTrigger className="w-48 bg-gray-900 border-gray-800 text-white">
              <SelectValue placeholder="All Domains" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Domains</SelectItem>
              {domains.map(d => (
                <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="articles" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="articles">Articles</TabsTrigger>
            <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
            <TabsTrigger value="faqs">FAQs</TabsTrigger>
            <TabsTrigger value="guides">Quick Guides</TabsTrigger>
          </TabsList>

          <TabsContent value="articles">
            {selectedArticle ? (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <Button variant="ghost" onClick={() => setSelectedArticle(null)} className="text-gray-400 mb-2 -ml-2">← Back</Button>
                      <CardTitle className="text-white text-2xl">{selectedArticle.title}</CardTitle>
                      <CardDescription className="text-gray-400 mt-2">{selectedArticle.summary}</CardDescription>
                      <div className="flex gap-2 mt-3">
                        <Badge className={domainColors[selectedArticle.domain]}>{selectedArticle.domain}</Badge>
                        {selectedArticle.tags?.map((tag, i) => (
                          <Badge key={i} variant="outline" className="border-gray-700 text-gray-400">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                    {isAdmin && (
                      <Button size="sm" variant="ghost" onClick={() => deleteArticleMutation.mutate(selectedArticle.id)} className="text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-invert max-w-none">
                    <p className="text-gray-300 whitespace-pre-wrap">{selectedArticle.content}</p>
                  </div>
                  {selectedArticle.key_concepts?.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-gray-800">
                      <p className="text-gray-400 text-sm mb-2">Key Concepts</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedArticle.key_concepts.map((concept, i) => (
                          <Badge key={i} className="bg-purple-600">{concept}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredArticles.map(article => (
                  <Card 
                    key={article.id} 
                    className="bg-gray-900 border-gray-800 hover:border-cyan-600 cursor-pointer transition-colors"
                    onClick={() => setSelectedArticle(article)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <Badge className={domainColors[article.domain] + " text-[10px]"}>{article.domain}</Badge>
                        <Eye className="w-4 h-4 text-gray-600" />
                      </div>
                      <CardTitle className="text-white text-lg mt-2">{article.title}</CardTitle>
                      <CardDescription className="text-gray-500 line-clamp-2">{article.summary}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-1">
                        {article.tags?.slice(0, 3).map((tag, i) => (
                          <Badge key={i} variant="outline" className="text-[10px] border-gray-700 text-gray-500">{tag}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {filteredArticles.length === 0 && (
                  <Card className="bg-gray-900 border-gray-800 col-span-full">
                    <CardContent className="py-12 text-center">
                      <BookOpen className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">No articles found. {isAdmin && "Create your first article to get started."}</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="frameworks">
            <div className="grid md:grid-cols-2 gap-6">
              {[
                { title: "Integral Theory", desc: "Ken Wilber's comprehensive map of human consciousness and development across four quadrants.", icon: Brain },
                { title: "Myers-Briggs Type Indicator", desc: "Personality assessment based on psychological preferences in how people perceive and make decisions.", icon: Users },
                { title: "Strengths-Based Development", desc: "Focus on identifying and leveraging natural talents for peak performance.", icon: Star },
                { title: "Life Balance Wheel", desc: "Visual tool for assessing satisfaction across key life domains.", icon: Target },
                { title: "Appreciative Inquiry", desc: "Strengths-based approach to organizational change and development.", icon: Lightbulb },
                { title: "Spiral Dynamics", desc: "Model of human development describing evolving worldviews and value systems.", icon: FileText },
              ].map((fw, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-cyan-900 flex items-center justify-center flex-shrink-0">
                        <fw.icon className="w-6 h-6 text-cyan-400" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium">{fw.title}</h3>
                        <p className="text-gray-400 text-sm mt-1">{fw.desc}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="faqs">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-amber-400" />
                  Frequently Asked Questions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="space-y-2">
                  {faqs.map((faq, i) => (
                    <AccordionItem key={i} value={`faq-${i}`} className="border-gray-800">
                      <AccordionTrigger className="text-white hover:text-cyan-400">{faq.q}</AccordionTrigger>
                      <AccordionContent className="text-gray-400">{faq.a}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="guides">
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { title: "Getting Started", desc: "New to the platform? Start here for a complete overview.", time: "5 min" },
                { title: "Taking Your First Assessment", desc: "Step-by-step guide to completing assessments.", time: "3 min" },
                { title: "Understanding Your Results", desc: "How to interpret and act on your assessment insights.", time: "7 min" },
                { title: "Setting Development Goals", desc: "Create actionable goals based on your profile.", time: "4 min" },
                { title: "Team Collaboration", desc: "Best practices for team-based development.", time: "6 min" },
                { title: "Executive Features", desc: "Guide to advanced analytics and optimization tools.", time: "8 min" },
              ].map((guide, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800 hover:border-cyan-600 cursor-pointer transition-colors">
                  <CardContent className="p-6">
                    <FileText className="w-8 h-8 text-cyan-400 mb-3" />
                    <h3 className="text-white font-medium">{guide.title}</h3>
                    <p className="text-gray-500 text-sm mt-1">{guide.desc}</p>
                    <div className="flex items-center gap-1 mt-3 text-gray-600 text-xs">
                      <Clock className="w-3 h-3" /> {guide.time} read
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}