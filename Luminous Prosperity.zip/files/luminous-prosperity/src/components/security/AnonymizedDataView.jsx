import React from "react";
import { Badge } from "@/components/ui/badge";
import { Shield, Eye, EyeOff } from "lucide-react";

/**
 * Component to display anonymized user data based on access level
 * @param {object} user - User object to potentially anonymize
 * @param {string} accessLevel - 'identified', 'anonymized', or 'aggregated'
 * @param {object} currentUser - User viewing the data
 */
export default function AnonymizedDataView({ user, accessLevel = 'anonymized', currentUser, showBadge = true }) {
  const canSeeIdentified = () => {
    // Platform admin can see everything
    if (currentUser?.email === 'ammanuldesta@gmail.com') return true;
    
    // User can see their own data
    if (currentUser?.email === user?.email) return true;
    
    // Manager can see direct report if allowed
    if (currentUser?.email === user?.manager_email && user?.privacy_settings?.allow_manager_view_assessment) {
      return true;
    }
    
    // Org admin/HR can see if allowed
    if ((currentUser?.role === 'admin' || currentUser?.user_role === 'org_admin') && 
        user?.privacy_settings?.visible_to_hr) {
      return true;
    }
    
    return false;
  };

  const shouldAnonymize = !canSeeIdentified() || accessLevel === 'anonymized';

  if (accessLevel === 'aggregated') {
    return null; // Don't show individual data in aggregated views
  }

  const getAnonymizedName = () => {
    if (user?.data_anonymized_id) {
      return `Employee ${user.data_anonymized_id.slice(-6)}`;
    }
    return `Employee ${user?.id?.slice(-6) || 'XXXXXX'}`;
  };

  const getAnonymizedEmail = () => {
    if (user?.email) {
      const parts = user.email.split('@');
      return `${parts[0].slice(0, 2)}***@${parts[1]}`;
    }
    return '***@***.com';
  };

  return (
    <div className="flex items-center gap-2">
      <span>
        {shouldAnonymize ? getAnonymizedName() : (user?.full_name || user?.email)}
      </span>
      {showBadge && shouldAnonymize && (
        <Badge variant="outline" className="text-xs flex items-center gap-1">
          <Shield className="w-3 h-3" />
          Anonymized
        </Badge>
      )}
    </div>
  );
}

export const anonymizeUserData = (user, currentUser) => {
  const canSeeIdentified = () => {
    if (currentUser?.email === 'ammanuldesta@gmail.com') return true;
    if (currentUser?.email === user?.email) return true;
    if (currentUser?.email === user?.manager_email && user?.privacy_settings?.allow_manager_view_assessment) {
      return true;
    }
    if ((currentUser?.role === 'admin' || currentUser?.user_role === 'org_admin') && 
        user?.privacy_settings?.visible_to_hr) {
      return true;
    }
    return false;
  };

  if (canSeeIdentified()) {
    return user;
  }

  return {
    ...user,
    full_name: `Employee ${user?.data_anonymized_id?.slice(-6) || user?.id?.slice(-6)}`,
    email: `${user?.email?.split('@')[0].slice(0, 2)}***@${user?.email?.split('@')[1]}`,
    _anonymized: true,
  };
};

export const getAccessLevel = (currentUser, targetUser) => {
  if (currentUser?.email === 'ammanuldesta@gmail.com') return 'identified';
  if (currentUser?.email === targetUser?.email) return 'identified';
  if (currentUser?.email === targetUser?.manager_email && 
      targetUser?.privacy_settings?.allow_manager_view_assessment) {
    return 'identified';
  }
  if ((currentUser?.role === 'admin' || currentUser?.user_role === 'org_admin') && 
      targetUser?.privacy_settings?.visible_to_hr) {
    return 'identified';
  }
  if (targetUser?.privacy_settings?.allow_executive_view_anonymized && 
      (currentUser?.user_role === 'executive' || currentUser?.user_role === 'c_suite')) {
    return 'anonymized';
  }
  return 'aggregated';
};