import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Briefcase, ArrowLeft } from "lucide-react";

export default function QuickLeadershipSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: '', q4: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "What's your approach to leadership? How would you describe your style?",
      placeholder: "Example: I believe in empowering my team to make decisions. I set the vision and remove obstacles, but I trust people to own their work. I'm most effective when I'm coaching rather than directing...",
    },
    {
      id: 'q2',
      question: "Tell me about a difficult decision you had to make as a leader. How did you approach it?",
      placeholder: "Example: We had to restructure during a downturn. I gathered input from key stakeholders, analyzed data, but ultimately had to make a tough call. I was transparent about the reasoning and made sure affected people had support...",
    },
    {
      id: 'q3',
      question: "How do you handle resistance to change? Give me a real example.",
      placeholder: "Example: When we introduced new technology, some veteran employees pushed back. I took time to understand their concerns, involved them in implementation planning, and paired them with champions who could help them see the benefits...",
    },
    {
      id: 'q4',
      question: "What brings out the best in your team? How do you create an environment where people thrive?",
      placeholder: "Example: I create psychological safety where people can take risks without fear. I celebrate learning from failures. I also make sure everyone understands how their work connects to our bigger mission...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'leadership'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-xl flex items-center justify-center shadow-lg">
            <Briefcase className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Your Leadership Approach</CardTitle>
            <CardDescription className="text-base">How you lead and inspire others</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
          <p className="text-sm text-indigo-900">
            <strong>Share your leadership philosophy.</strong> Real examples help us understand your authentic leadership style.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-[#B8967D] to-[#A68364] text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}