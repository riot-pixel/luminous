import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Heart, ArrowLeft, Loader2 } from "lucide-react";

export default function QuickCultureSection({ onComplete, onBack, initialData, isProcessing }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "What kind of culture are you trying to build? What values are most important to you?",
      placeholder: "Example: I want a culture of trust, innovation, and accountability. People should feel safe to experiment, supported to grow, and empowered to make decisions. We value collaboration over competition...",
    },
    {
      id: 'q2',
      question: "What's the biggest cultural challenge your organization faces? How are you addressing it?",
      placeholder: "Example: We're growing fast and struggling to maintain our startup culture. I'm addressing it by being intentional about onboarding, creating cultural ambassadors, and having open forums where people can voice concerns...",
    },
    {
      id: 'q3',
      question: "How do you personally role model the culture you want? Give specific examples.",
      placeholder: "Example: I practice transparency by sharing our financials and strategy with the whole company. I admit mistakes publicly to show vulnerability. I block time for 1-on-1s to show people matter more than tasks...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'culture'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-violet-500 rounded-xl flex items-center justify-center shadow-lg">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Culture & Values</CardTitle>
            <CardDescription className="text-base">The environment you're creating</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <p className="text-sm text-purple-900">
            <strong>Almost done!</strong> Culture is your lasting legacy - share what you're building.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} disabled={isProcessing} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete}
            disabled={!allAnswered || isProcessing}
            className="flex-1 bg-gradient-to-r from-purple-400 to-violet-500 text-white"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Leadership...
              </>
            ) : (
              'Complete Assessment'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}