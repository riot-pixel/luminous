import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Target, ArrowLeft } from "lucide-react";

export default function QuickVisionSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: '', q4: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "Where do you see your organization in 3-5 years? Paint me a picture of success.",
      placeholder: "Example: I see us as the industry leader in sustainable innovation. We'll have doubled our market share while becoming carbon neutral. Our team will have grown to 500 people who are passionate about our mission...",
    },
    {
      id: 'q2',
      question: "What are your top 3 strategic priorities right now? Why these?",
      placeholder: "Example: 1) Digital transformation - we need to modernize to compete, 2) Talent development - our people are our advantage, 3) Customer experience - it's how we differentiate. These will position us for long-term growth...",
    },
    {
      id: 'q3',
      question: "How do you approach innovation? How do you balance innovation with execution?",
      placeholder: "Example: We dedicate 20% of resources to experimental projects. I encourage calculated risk-taking and fast learning. But we also have core operations that need excellence in execution. It's about portfolio balance...",
    },
    {
      id: 'q4',
      question: "What makes your organization truly different from competitors? What's your unique advantage?",
      placeholder: "Example: Our culture of collaboration and customer obsession. While competitors focus on technology, we focus on solving real problems. Our team brings diverse perspectives that lead to breakthrough solutions...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'vision'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Strategic Vision</CardTitle>
            <CardDescription className="text-base">Where you're taking the organization</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <p className="text-sm text-orange-900">
            <strong>Think strategically.</strong> Share your vision for the future and how you plan to get there.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-orange-400 to-orange-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}