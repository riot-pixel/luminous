import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Users, ArrowLeft } from "lucide-react";

export default function QuickStakeholderSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "How do you balance the needs of different stakeholders - shareholders, employees, customers, and community?",
      placeholder: "Example: I believe in stakeholder capitalism. While we need to deliver returns, sustainable success requires happy employees and loyal customers. I make decisions that optimize long-term value for all groups, not just short-term profits...",
    },
    {
      id: 'q2',
      question: "Describe your approach to corporate social responsibility and sustainability. How important is it?",
      placeholder: "Example: It's core to who we are, not an add-on. We've committed to carbon neutrality by 2030 and measure social impact alongside financial metrics. I believe companies have a responsibility to make the world better...",
    },
    {
      id: 'q3',
      question: "How do you engage with and listen to stakeholders? Give me examples of how you gather input.",
      placeholder: "Example: I do quarterly town halls with employees, monthly customer advisory board meetings, and annual community listening sessions. I also walk the floors regularly for informal conversations. Diverse input leads to better decisions...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'stakeholders'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center shadow-lg">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Stakeholder Focus</CardTitle>
            <CardDescription className="text-base">How you serve different constituencies</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm text-amber-900">
            <strong>Show how you balance interests.</strong> Great leaders navigate competing priorities with wisdom.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-amber-400 to-amber-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}