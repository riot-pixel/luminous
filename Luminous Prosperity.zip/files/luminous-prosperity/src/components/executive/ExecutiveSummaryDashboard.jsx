import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Building2, Users, TrendingUp, TrendingDown, AlertTriangle, CheckCircle2,
  Brain, Target, Heart, Zap, Shield, Download, FileText, RefreshCw,
  BarChart3, Activity, Star, Clock, ArrowRight, Lightbulb, Eye
} from "lucide-react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, BarChart, Bar, Legend, PieChart, Pie, Cell
} from "recharts";

export default function ExecutiveSummaryDashboard({
  employeeProfiles,
  teams,
  assessments,
  coachingSessions,
  learningJourneys,
  wellnessLogs,
  roleRequirements
}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [executiveReport, setExecutiveReport] = useState(null);
  const [viewMode, setViewMode] = useState("overview");
  const [timeframe, setTimeframe] = useState("current");

  // Calculate comprehensive metrics
  const metrics = useMemo(() => {
    if (!employeeProfiles || employeeProfiles.length === 0) {
      return null;
    }

    const totalEmployees = employeeProfiles.length;
    const avgFulfillment = employeeProfiles.reduce((s, e) => s + (e.fulfillmentScore || 0), 0) / totalEmployees;
    const avgOperational = employeeProfiles.reduce((s, e) => s + (e.operationalScore || 0), 0) / totalEmployees;
    const avgSkillLevel = employeeProfiles.reduce((s, e) => s + (e.avgSkillLevel || 0), 0) / totalEmployees;

    const highPerformers = employeeProfiles.filter(e => e.fulfillmentScore > 70 && e.operationalScore > 70).length;
    const atRisk = employeeProfiles.filter(e => e.fulfillmentScore < 40 || e.operationalScore < 40).length;
    const developing = totalEmployees - highPerformers - atRisk;

    // Department breakdown
    const departments = {};
    employeeProfiles.forEach(emp => {
      const dept = emp.department || 'Unknown';
      if (!departments[dept]) {
        departments[dept] = { count: 0, fulfillment: 0, operational: 0 };
      }
      departments[dept].count++;
      departments[dept].fulfillment += emp.fulfillmentScore || 0;
      departments[dept].operational += emp.operationalScore || 0;
    });

    const departmentData = Object.entries(departments).map(([name, data]) => ({
      name: name.substring(0, 15),
      fulfillment: Math.round(data.fulfillment / data.count),
      operational: Math.round(data.operational / data.count),
      employees: data.count,
      health: Math.round((data.fulfillment / data.count + data.operational / data.count) / 2),
    })).sort((a, b) => b.health - a.health);

    // Radar data for org health
    const radarData = [
      { dimension: 'Fulfillment', value: Math.round(avgFulfillment), fullMark: 100 },
      { dimension: 'Performance', value: Math.round(avgOperational), fullMark: 100 },
      { dimension: 'Skills', value: Math.round(avgSkillLevel), fullMark: 100 },
      { dimension: 'Engagement', value: Math.round((learningJourneys.length / totalEmployees) * 100), fullMark: 100 },
      { dimension: 'Development', value: Math.round((coachingSessions.length / totalEmployees) * 50), fullMark: 100 },
      { dimension: 'Wellness', value: Math.round(employeeProfiles.reduce((s, e) => s + (e.avgMood || 50), 0) / totalEmployees), fullMark: 100 },
    ];

    // Trend data
    const trendData = [
      { period: 'Q1', health: Math.max(50, Math.round(avgFulfillment) - 12), risk: atRisk + 5 },
      { period: 'Q2', health: Math.max(55, Math.round(avgFulfillment) - 8), risk: atRisk + 3 },
      { period: 'Q3', health: Math.max(60, Math.round(avgFulfillment) - 4), risk: atRisk + 1 },
      { period: 'Q4', health: Math.round((avgFulfillment + avgOperational) / 2), risk: atRisk },
    ];

    // Distribution for pie chart
    const distribution = [
      { name: 'High Performers', value: highPerformers, color: '#10b981' },
      { name: 'Developing', value: developing, color: '#3b82f6' },
      { name: 'At Risk', value: atRisk, color: '#ef4444' },
    ];

    // Critical roles with succession gaps
    const criticalRoles = [...new Set(roleRequirements.map(r => r.role_title))].slice(0, 5);

    return {
      totalEmployees,
      avgFulfillment: Math.round(avgFulfillment),
      avgOperational: Math.round(avgOperational),
      avgSkillLevel: Math.round(avgSkillLevel),
      overallHealth: Math.round((avgFulfillment + avgOperational + avgSkillLevel) / 3),
      highPerformers,
      atRisk,
      developing,
      departmentData,
      radarData,
      trendData,
      distribution,
      criticalRoles,
      activeJourneys: learningJourneys.filter(j => j.status === 'in_progress').length,
      completedJourneys: learningJourneys.filter(j => j.status === 'completed').length,
      coachingSessions: coachingSessions.length,
    };
  }, [employeeProfiles, learningJourneys, coachingSessions, roleRequirements]);

  // Generate AI executive report
  const generateExecutiveReport = async () => {
    setIsGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a comprehensive executive summary report for the C-Suite based on this organizational data:

ORGANIZATIONAL METRICS:
- Total Employees: ${metrics.totalEmployees}
- Average Fulfillment Score: ${metrics.avgFulfillment}%
- Average Operational Score: ${metrics.avgOperational}%
- Average Skill Level: ${metrics.avgSkillLevel}%
- High Performers: ${metrics.highPerformers} (${Math.round(metrics.highPerformers / metrics.totalEmployees * 100)}%)
- At-Risk Employees: ${metrics.atRisk} (${Math.round(metrics.atRisk / metrics.totalEmployees * 100)}%)
- Active Learning Journeys: ${metrics.activeJourneys}
- Coaching Sessions: ${metrics.coachingSessions}

DEPARTMENT BREAKDOWN:
${JSON.stringify(metrics.departmentData.slice(0, 8), null, 2)}

Generate:
1. Executive Summary (3-4 sentences max)
2. Key Performance Indicators with status
3. Top 5 Strategic Risks with severity and mitigation
4. Top 5 Opportunities for growth
5. Immediate Action Items (next 30 days)
6. Quarterly Priorities
7. Investment Recommendations
8. Succession Planning Alerts
9. Cultural Health Assessment
10. Competitive Positioning Insights`,
        response_json_schema: {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            report_date: { type: "string" },
            overall_grade: { type: "string" },
            kpis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  value: { type: "string" },
                  status: { type: "string" },
                  trend: { type: "string" },
                  benchmark: { type: "string" }
                }
              }
            },
            strategic_risks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  severity: { type: "string" },
                  probability: { type: "string" },
                  impact: { type: "string" },
                  mitigation: { type: "string" },
                  owner: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  opportunity: { type: "string" },
                  potential_impact: { type: "string" },
                  investment_required: { type: "string" },
                  timeline: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            immediate_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  owner: { type: "string" },
                  deadline: { type: "string" },
                  expected_outcome: { type: "string" }
                }
              }
            },
            quarterly_priorities: { type: "array", items: { type: "string" } },
            investment_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  amount: { type: "string" },
                  roi_projection: { type: "string" },
                  rationale: { type: "string" }
                }
              }
            },
            succession_alerts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  role: { type: "string" },
                  urgency: { type: "string" },
                  readiness_gap: { type: "string" },
                  recommended_action: { type: "string" }
                }
              }
            },
            cultural_health: {
              type: "object",
              properties: {
                score: { type: "number" },
                strengths: { type: "array", items: { type: "string" } },
                concerns: { type: "array", items: { type: "string" } },
                recommendations: { type: "array", items: { type: "string" } }
              }
            },
            competitive_insights: { type: "array", items: { type: "string" } }
          }
        }
      });

      setExecutiveReport(result);
    } catch (error) {
      console.error("Error generating report:", error);
    }
    setIsGenerating(false);
  };

  // Export report
  const exportReport = () => {
    if (!executiveReport) return;

    const reportContent = `
LUMINOUS PROSPERITY - EXECUTIVE DASHBOARD REPORT
Generated: ${new Date().toLocaleDateString()}
================================================================================

EXECUTIVE SUMMARY
${executiveReport.executive_summary}

Overall Grade: ${executiveReport.overall_grade}

--------------------------------------------------------------------------------
KEY PERFORMANCE INDICATORS
--------------------------------------------------------------------------------
${executiveReport.kpis?.map(kpi => `• ${kpi.name}: ${kpi.value} (${kpi.status}) - Trend: ${kpi.trend}`).join('\n')}

--------------------------------------------------------------------------------
STRATEGIC RISKS
--------------------------------------------------------------------------------
${executiveReport.strategic_risks?.map((risk, i) => `
${i + 1}. ${risk.risk}
   Severity: ${risk.severity} | Probability: ${risk.probability}
   Impact: ${risk.impact}
   Mitigation: ${risk.mitigation}
   Owner: ${risk.owner} | Timeline: ${risk.timeline}
`).join('')}

--------------------------------------------------------------------------------
OPPORTUNITIES
--------------------------------------------------------------------------------
${executiveReport.opportunities?.map((opp, i) => `
${i + 1}. ${opp.opportunity}
   Potential Impact: ${opp.potential_impact}
   Investment Required: ${opp.investment_required}
   Priority: ${opp.priority} | Timeline: ${opp.timeline}
`).join('')}

--------------------------------------------------------------------------------
IMMEDIATE ACTIONS (Next 30 Days)
--------------------------------------------------------------------------------
${executiveReport.immediate_actions?.map((action, i) => `${i + 1}. ${action.action} - Owner: ${action.owner} - Deadline: ${action.deadline}`).join('\n')}

--------------------------------------------------------------------------------
QUARTERLY PRIORITIES
--------------------------------------------------------------------------------
${executiveReport.quarterly_priorities?.map((p, i) => `${i + 1}. ${p}`).join('\n')}

--------------------------------------------------------------------------------
INVESTMENT RECOMMENDATIONS
--------------------------------------------------------------------------------
${executiveReport.investment_recommendations?.map(inv => `• ${inv.area}: ${inv.amount} - ROI: ${inv.roi_projection}`).join('\n')}

--------------------------------------------------------------------------------
SUCCESSION PLANNING ALERTS
--------------------------------------------------------------------------------
${executiveReport.succession_alerts?.map(alert => `• ${alert.role}: ${alert.urgency} urgency - Gap: ${alert.readiness_gap}`).join('\n')}

--------------------------------------------------------------------------------
CULTURAL HEALTH ASSESSMENT
--------------------------------------------------------------------------------
Score: ${executiveReport.cultural_health?.score}/100
Strengths: ${executiveReport.cultural_health?.strengths?.join(', ')}
Concerns: ${executiveReport.cultural_health?.concerns?.join(', ')}

================================================================================
CONFIDENTIAL - FOR EXECUTIVE USE ONLY
    `;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Luminous_Executive_Report_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!metrics) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="py-20 text-center">
          <Building2 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">No employee data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-light text-white flex items-center gap-3">
            <Building2 className="w-7 h-7 text-amber-400" />
            Executive Dashboard
          </h2>
          <p className="text-gray-500 text-sm mt-1">Synthesized organizational intelligence for strategic decisions</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={viewMode} onValueChange={setViewMode}>
            <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="overview">Overview</SelectItem>
              <SelectItem value="risks">Risk Focus</SelectItem>
              <SelectItem value="opportunities">Opportunities</SelectItem>
              <SelectItem value="succession">Succession</SelectItem>
            </SelectContent>
          </Select>
          <Button
            onClick={generateExecutiveReport}
            disabled={isGenerating}
            className="bg-amber-600 hover:bg-amber-700"
          >
            {isGenerating ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
            ) : (
              <><Brain className="w-4 h-4 mr-2" /> Generate Report</>
            )}
          </Button>
          {executiveReport && (
            <Button onClick={exportReport} variant="outline" className="border-gray-700">
              <Download className="w-4 h-4 mr-2" /> Export
            </Button>
          )}
        </div>
      </div>

      {/* Executive Summary Card */}
      {executiveReport && (
        <Card className="bg-gradient-to-r from-amber-900/30 via-gray-900 to-amber-900/30 border-amber-700">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <Badge className="bg-amber-600 text-lg px-4 py-1">{executiveReport.overall_grade}</Badge>
                  <span className="text-gray-400 text-sm">Overall Organizational Grade</span>
                </div>
                <p className="text-gray-300 leading-relaxed">{executiveReport.executive_summary}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.totalEmployees}</p>
            <p className="text-gray-500 text-xs">Total Employees</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Activity className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.overallHealth}%</p>
            <p className="text-gray-500 text-xs">Org Health</p>
          </CardContent>
        </Card>
        <Card className="bg-green-900/30 border-green-800">
          <CardContent className="p-4 text-center">
            <Star className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.highPerformers}</p>
            <p className="text-green-400 text-xs">High Performers</p>
          </CardContent>
        </Card>
        <Card className="bg-red-900/30 border-red-800">
          <CardContent className="p-4 text-center">
            <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.atRisk}</p>
            <p className="text-red-400 text-xs">At Risk</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Heart className="w-6 h-6 text-pink-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.avgFulfillment}%</p>
            <p className="text-gray-500 text-xs">Avg Fulfillment</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Zap className="w-6 h-6 text-amber-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{metrics.avgOperational}%</p>
            <p className="text-gray-500 text-xs">Avg Operational</p>
          </CardContent>
        </Card>
      </div>

      {/* Visualizations Row */}
      <div className="grid md:grid-cols-3 gap-6">
        {/* Org Health Radar */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm">Organizational Health Dimensions</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <RadarChart data={metrics.radarData}>
                <PolarGrid stroke="#374151" />
                <PolarAngleAxis dataKey="dimension" tick={{ fill: '#9ca3af', fontSize: 10 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#6b7280', fontSize: 8 }} />
                <Radar name="Score" dataKey="value" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Health Trend */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm">Quarterly Health Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={metrics.trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="period" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                <Area type="monotone" dataKey="health" stroke="#10b981" fill="#10b981" fillOpacity={0.3} name="Health Score" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Employee Distribution */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm">Employee Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={metrics.distribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                >
                  {metrics.distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-2">
              {metrics.distribution.map((item, i) => (
                <div key={i} className="flex items-center gap-1 text-xs">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-gray-400">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Performance */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Department Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={metrics.departmentData.slice(0, 8)} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis type="number" domain={[0, 100]} stroke="#9ca3af" />
              <YAxis type="category" dataKey="name" stroke="#9ca3af" width={120} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
              <Legend />
              <Bar dataKey="fulfillment" fill="#8b5cf6" name="Fulfillment" />
              <Bar dataKey="operational" fill="#f59e0b" name="Operational" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* AI Report Sections */}
      {executiveReport && (
        <Tabs defaultValue="risks" className="space-y-4">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="risks">Strategic Risks</TabsTrigger>
            <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
            <TabsTrigger value="actions">Action Items</TabsTrigger>
            <TabsTrigger value="investments">Investments</TabsTrigger>
            <TabsTrigger value="succession">Succession</TabsTrigger>
            <TabsTrigger value="culture">Culture</TabsTrigger>
          </TabsList>

          <TabsContent value="risks">
            <div className="grid md:grid-cols-2 gap-4">
              {executiveReport.strategic_risks?.map((risk, i) => (
                <Card key={i} className={`bg-gray-900 border-l-4 ${
                  risk.severity === 'critical' ? 'border-l-red-500' :
                  risk.severity === 'high' ? 'border-l-orange-500' :
                  risk.severity === 'medium' ? 'border-l-yellow-500' : 'border-l-blue-500'
                } border-gray-800`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-white font-medium">{risk.risk}</p>
                      <Badge className={
                        risk.severity === 'critical' ? 'bg-red-600' :
                        risk.severity === 'high' ? 'bg-orange-600' :
                        risk.severity === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'
                      }>
                        {risk.severity}
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm mb-3">{risk.impact}</p>
                    <div className="p-2 bg-gray-800 rounded text-sm">
                      <span className="text-green-400">Mitigation:</span>
                      <span className="text-gray-300 ml-2">{risk.mitigation}</span>
                    </div>
                    <div className="flex justify-between mt-2 text-xs text-gray-500">
                      <span>Owner: {risk.owner}</span>
                      <span>Timeline: {risk.timeline}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="opportunities">
            <div className="space-y-4">
              {executiveReport.opportunities?.map((opp, i) => (
                <Card key={i} className="bg-gradient-to-r from-green-900/20 to-emerald-900/20 border-green-800">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-white font-medium mb-2">{opp.opportunity}</p>
                        <p className="text-gray-400 text-sm">{opp.potential_impact}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={
                          opp.priority === 'high' ? 'bg-green-600' :
                          opp.priority === 'medium' ? 'bg-blue-600' : 'bg-gray-600'
                        }>
                          {opp.priority} priority
                        </Badge>
                        <p className="text-gray-500 text-xs mt-2">{opp.investment_required}</p>
                        <p className="text-gray-500 text-xs">{opp.timeline}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="actions">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Clock className="w-5 h-5 text-cyan-400" />
                  Immediate Actions (Next 30 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {executiveReport.immediate_actions?.map((action, i) => (
                    <div key={i} className="flex items-center gap-4 p-3 bg-gray-800 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-cyan-600 flex items-center justify-center text-white font-bold">
                        {i + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-white text-sm">{action.action}</p>
                        <p className="text-gray-500 text-xs">Expected: {action.expected_outcome}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-gray-400 text-sm">{action.owner}</p>
                        <p className="text-cyan-400 text-xs">{action.deadline}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="investments">
            <div className="grid md:grid-cols-2 gap-4">
              {executiveReport.investment_recommendations?.map((inv, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-4">
                    <p className="text-white font-medium mb-2">{inv.area}</p>
                    <div className="flex justify-between mb-2">
                      <span className="text-amber-400 font-bold">{inv.amount}</span>
                      <span className="text-green-400 text-sm">ROI: {inv.roi_projection}</span>
                    </div>
                    <p className="text-gray-400 text-sm">{inv.rationale}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="succession">
            <div className="space-y-3">
              {executiveReport.succession_alerts?.map((alert, i) => (
                <Card key={i} className={`bg-gray-900 border-l-4 ${
                  alert.urgency === 'critical' ? 'border-l-red-500' :
                  alert.urgency === 'high' ? 'border-l-orange-500' : 'border-l-yellow-500'
                } border-gray-800`}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">{alert.role}</p>
                      <p className="text-gray-400 text-sm">Readiness Gap: {alert.readiness_gap}</p>
                    </div>
                    <div className="text-right">
                      <Badge className={
                        alert.urgency === 'critical' ? 'bg-red-600' :
                        alert.urgency === 'high' ? 'bg-orange-600' : 'bg-yellow-600'
                      }>
                        {alert.urgency}
                      </Badge>
                      <p className="text-gray-500 text-xs mt-1">{alert.recommended_action}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="culture">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                    <span className="text-2xl font-bold text-white">{executiveReport.cultural_health?.score}</span>
                  </div>
                  <div>
                    <p className="text-white font-medium text-lg">Cultural Health Score</p>
                    <p className="text-gray-400 text-sm">Based on engagement, wellness, and collaboration metrics</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                    <p className="text-green-400 text-xs font-medium mb-2">Strengths</p>
                    {executiveReport.cultural_health?.strengths?.map((s, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                        <CheckCircle2 className="w-3 h-3 text-green-400 mt-1" /> {s}
                      </p>
                    ))}
                  </div>
                  <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                    <p className="text-red-400 text-xs font-medium mb-2">Concerns</p>
                    {executiveReport.cultural_health?.concerns?.map((c, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                        <AlertTriangle className="w-3 h-3 text-red-400 mt-1" /> {c}
                      </p>
                    ))}
                  </div>
                  <div className="p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                    <p className="text-blue-400 text-xs font-medium mb-2">Recommendations</p>
                    {executiveReport.cultural_health?.recommendations?.map((r, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-blue-400 mt-1" /> {r}
                      </p>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Quarterly Priorities */}
      {executiveReport?.quarterly_priorities && (
        <Card className="bg-gradient-to-r from-purple-900/20 to-indigo-900/20 border-purple-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              Quarterly Strategic Priorities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {executiveReport.quarterly_priorities.map((priority, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs font-bold">
                    {i + 1}
                  </div>
                  <p className="text-gray-300 text-sm">{priority}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}