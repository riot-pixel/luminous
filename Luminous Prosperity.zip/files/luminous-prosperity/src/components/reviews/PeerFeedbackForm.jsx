import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageSquare, Send, Star } from "lucide-react";

export default function PeerFeedbackForm({ review, currentUser, onSubmit }) {
  const [collaboration, setCollaboration] = useState([3]);
  const [communication, setCommunication] = useState([3]);
  const [strengths, setStrengths] = useState("");
  const [improvements, setImprovements] = useState("");
  const [comments, setComments] = useState("");

  const handleSubmit = () => {
    onSubmit({
      peer_email: currentUser?.email,
      peer_name: currentUser?.full_name,
      collaboration_rating: collaboration[0],
      communication_rating: communication[0],
      strengths: strengths.split('\n').filter(s => s.trim()),
      improvements: improvements.split('\n').filter(s => s.trim()),
      comments,
      submitted_date: new Date().toISOString(),
    });
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <div className="flex items-center gap-4">
          <Avatar className="w-10 h-10">
            <AvatarFallback className="bg-purple-600 text-white">
              {review.employee_name?.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-white">Peer Feedback for {review.employee_name}</CardTitle>
            <p className="text-gray-500 text-sm">{review.review_period} {review.review_year} Review</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">Collaboration</span>
            <span className="text-white">{collaboration[0]}/5</span>
          </div>
          <Slider value={collaboration} onValueChange={setCollaboration} min={1} max={5} step={1} />
        </div>
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-gray-400 text-sm">Communication</span>
            <span className="text-white">{communication[0]}/5</span>
          </div>
          <Slider value={communication} onValueChange={setCommunication} min={1} max={5} step={1} />
        </div>
        <div>
          <p className="text-gray-400 text-sm mb-2">Strengths (one per line)</p>
          <Textarea
            value={strengths}
            onChange={(e) => setStrengths(e.target.value)}
            placeholder="What does this person do well?"
            className="bg-gray-800 border-gray-700 text-white h-20"
          />
        </div>
        <div>
          <p className="text-gray-400 text-sm mb-2">Areas for Improvement (one per line)</p>
          <Textarea
            value={improvements}
            onChange={(e) => setImprovements(e.target.value)}
            placeholder="Where could they improve?"
            className="bg-gray-800 border-gray-700 text-white h-20"
          />
        </div>
        <div>
          <p className="text-gray-400 text-sm mb-2">Additional Comments</p>
          <Textarea
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            placeholder="Any other feedback..."
            className="bg-gray-800 border-gray-700 text-white"
          />
        </div>
        <Button onClick={handleSubmit} className="w-full bg-green-600 hover:bg-green-700">
          <Send className="w-4 h-4 mr-2" /> Submit Feedback
        </Button>
      </CardContent>
    </Card>
  );
}