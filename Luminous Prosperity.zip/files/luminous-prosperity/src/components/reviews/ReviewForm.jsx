import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, X } from "lucide-react";

export default function ReviewForm({ employees, userSkills, currentUser, onSubmit, onCancel }) {
  const [selectedEmployee, setSelectedEmployee] = useState("");
  const [reviewPeriod, setReviewPeriod] = useState("");
  const [reviewYear, setReviewYear] = useState(new Date().getFullYear().toString());
  const [dueDate, setDueDate] = useState("");
  const [goals, setGoals] = useState([{ goal: "", weight: 25 }]);
  const [selectedPeers, setSelectedPeers] = useState([]);

  const employee = employees.find(e => e.email === selectedEmployee);
  const empSkills = userSkills.filter(s => s.user_email === selectedEmployee);
  const availablePeers = employees.filter(e => e.email !== selectedEmployee && e.email !== currentUser?.email);

  const addGoal = () => setGoals([...goals, { goal: "", weight: 25 }]);
  const removeGoal = (index) => setGoals(goals.filter((_, i) => i !== index));
  const updateGoal = (index, field, value) => {
    const updated = [...goals];
    updated[index][field] = value;
    setGoals(updated);
  };

  const togglePeer = (email, name) => {
    if (selectedPeers.find(p => p.email === email)) {
      setSelectedPeers(selectedPeers.filter(p => p.email !== email));
    } else {
      setSelectedPeers([...selectedPeers, { peer_email: email, peer_name: name, status: 'pending' }]);
    }
  };

  const handleSubmit = () => {
    const reviewData = {
      employee_email: selectedEmployee,
      employee_name: employee?.full_name,
      reviewer_email: currentUser?.email,
      reviewer_name: currentUser?.full_name,
      review_period: reviewPeriod,
      review_year: parseInt(reviewYear),
      due_date: dueDate,
      status: 'draft',
      goals_assessment: goals.filter(g => g.goal).map(g => ({
        goal: g.goal,
        weight: g.weight,
        rating: 0,
        achievement_percentage: 0,
        comments: ""
      })),
      skills_assessment: empSkills.slice(0, 5).map(s => ({
        skill_name: s.skill_name,
        expected_level: s.target_proficiency || 'Intermediate',
        current_level: s.current_proficiency || 'Beginner',
        rating: 0,
        comments: ""
      })),
      competencies: [
        { competency: "Communication", rating: 0, examples: "" },
        { competency: "Collaboration", rating: 0, examples: "" },
        { competency: "Problem Solving", rating: 0, examples: "" },
        { competency: "Initiative", rating: 0, examples: "" },
      ],
      peer_feedback_requests: selectedPeers,
      initiated_date: new Date().toISOString(),
    };
    onSubmit(reviewData);
  };

  return (
    <div className="space-y-4 mt-4">
      <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
        <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
          <SelectValue placeholder="Select Employee" />
        </SelectTrigger>
        <SelectContent>
          {employees.filter(e => e.email !== currentUser?.email).map(e => (
            <SelectItem key={e.email} value={e.email}>{e.full_name} - {e.job_title}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="grid grid-cols-3 gap-3">
        <Select value={reviewPeriod} onValueChange={setReviewPeriod}>
          <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
            <SelectValue placeholder="Period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Q1">Q1</SelectItem>
            <SelectItem value="Q2">Q2</SelectItem>
            <SelectItem value="Q3">Q3</SelectItem>
            <SelectItem value="Q4">Q4</SelectItem>
            <SelectItem value="Mid-Year">Mid-Year</SelectItem>
            <SelectItem value="Annual">Annual</SelectItem>
          </SelectContent>
        </Select>
        <Select value={reviewYear} onValueChange={setReviewYear}>
          <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
            <SelectValue placeholder="Year" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2024">2024</SelectItem>
            <SelectItem value="2025">2025</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          className="bg-gray-800 border-gray-700 text-white"
          placeholder="Due Date"
        />
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <p className="text-gray-400 text-sm">Goals to Assess</p>
          <Button type="button" size="sm" variant="ghost" onClick={addGoal} className="text-green-400">
            <Plus className="w-3 h-3 mr-1" /> Add Goal
          </Button>
        </div>
        {goals.map((goal, i) => (
          <div key={i} className="flex gap-2 mb-2">
            <Input
              placeholder={`Goal ${i + 1}`}
              value={goal.goal}
              onChange={(e) => updateGoal(i, 'goal', e.target.value)}
              className="bg-gray-800 border-gray-700 text-white flex-1"
            />
            <Input
              type="number"
              placeholder="Weight %"
              value={goal.weight}
              onChange={(e) => updateGoal(i, 'weight', parseInt(e.target.value))}
              className="bg-gray-800 border-gray-700 text-white w-24"
            />
            {goals.length > 1 && (
              <Button type="button" size="icon" variant="ghost" onClick={() => removeGoal(i)} className="text-red-400">
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        ))}
      </div>

      <div>
        <p className="text-gray-400 text-sm mb-2">Request Peer Feedback (optional)</p>
        <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
          {availablePeers.slice(0, 20).map(peer => (
            <Badge
              key={peer.email}
              variant={selectedPeers.find(p => p.email === peer.email) ? "default" : "outline"}
              className={`cursor-pointer ${selectedPeers.find(p => p.email === peer.email) ? 'bg-green-600' : 'border-gray-700 text-gray-400'}`}
              onClick={() => togglePeer(peer.email, peer.full_name)}
            >
              {peer.full_name}
            </Badge>
          ))}
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="ghost" onClick={onCancel} className="flex-1">Cancel</Button>
        <Button
          onClick={handleSubmit}
          disabled={!selectedEmployee || !reviewPeriod}
          className="flex-1 bg-green-600 hover:bg-green-700"
        >
          Create Review
        </Button>
      </div>
    </div>
  );
}