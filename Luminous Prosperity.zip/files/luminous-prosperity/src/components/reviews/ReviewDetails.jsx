import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ArrowLeft, Target, Star, Users, TrendingUp, CheckCircle2, Save, Send
} from "lucide-react";

export default function ReviewDetails({ review, employees, userSkills, currentUser, onBack, onUpdate, isManager }) {
  const [editedReview, setEditedReview] = useState(review);
  const [isSaving, setIsSaving] = useState(false);

  const updateGoal = (index, field, value) => {
    const updated = [...editedReview.goals_assessment];
    updated[index][field] = value;
    setEditedReview({ ...editedReview, goals_assessment: updated });
  };

  const updateSkill = (index, field, value) => {
    const updated = [...editedReview.skills_assessment];
    updated[index][field] = value;
    setEditedReview({ ...editedReview, skills_assessment: updated });
  };

  const updateCompetency = (index, field, value) => {
    const updated = [...editedReview.competencies];
    updated[index][field] = value;
    setEditedReview({ ...editedReview, competencies: updated });
  };

  const calculateOverall = () => {
    let total = 0, count = 0;
    editedReview.goals_assessment?.forEach(g => { if (g.rating) { total += g.rating; count++; } });
    editedReview.skills_assessment?.forEach(s => { if (s.rating) { total += s.rating; count++; } });
    editedReview.competencies?.forEach(c => { if (c.rating) { total += c.rating; count++; } });
    return count > 0 ? (total / count).toFixed(1) : 0;
  };

  const handleSave = async (newStatus) => {
    setIsSaving(true);
    const overall = calculateOverall();
    await onUpdate({
      ...editedReview,
      overall_rating: parseFloat(overall),
      status: newStatus || editedReview.status,
      completed_date: newStatus === 'completed' ? new Date().toISOString() : editedReview.completed_date,
    });
    setIsSaving(false);
    if (newStatus) onBack();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="text-gray-400">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        {isManager && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleSave()} disabled={isSaving} className="border-gray-700">
              <Save className="w-4 h-4 mr-2" /> Save Draft
            </Button>
            {editedReview.status === 'draft' && (
              <Button onClick={() => handleSave('in_progress')} disabled={isSaving} className="bg-blue-600 hover:bg-blue-700">
                Start Review
              </Button>
            )}
            {editedReview.status === 'in_progress' && editedReview.peer_feedback_requests?.length > 0 && (
              <Button onClick={() => handleSave('pending_peer_feedback')} disabled={isSaving} className="bg-amber-600 hover:bg-amber-700">
                Request Peer Feedback
              </Button>
            )}
            {['in_progress', 'pending_peer_feedback', 'pending_employee_acknowledgment'].includes(editedReview.status) && (
              <Button onClick={() => handleSave('completed')} disabled={isSaving} className="bg-green-600 hover:bg-green-700">
                <CheckCircle2 className="w-4 h-4 mr-2" /> Complete Review
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Header */}
      <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="w-14 h-14">
                <AvatarFallback className="bg-green-600 text-white text-lg">
                  {review.employee_name?.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-2xl font-medium text-white">{review.employee_name}</h2>
                <p className="text-gray-400">{review.review_period} {review.review_year} Performance Review</p>
              </div>
            </div>
            <div className="text-center">
              <p className="text-gray-400 text-sm">Overall Rating</p>
              <div className="flex items-center gap-2">
                <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
                <span className="text-3xl font-bold text-white">{calculateOverall()}</span>
                <span className="text-gray-400">/5</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="goals" className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="skills">Skills</TabsTrigger>
          <TabsTrigger value="competencies">Competencies</TabsTrigger>
          <TabsTrigger value="feedback">Peer Feedback ({review.peer_feedback?.length || 0})</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="goals">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-green-400" /> Goals Assessment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {editedReview.goals_assessment?.map((goal, i) => (
                <div key={i} className="p-4 bg-gray-800 rounded-lg space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-white font-medium">{goal.goal}</p>
                      <p className="text-gray-500 text-sm">Weight: {goal.weight}%</p>
                    </div>
                    {isManager && (
                      <div className="text-right">
                        <p className="text-gray-400 text-xs mb-1">Rating: {goal.rating}/5</p>
                        <Slider
                          value={[goal.rating || 0]}
                          onValueChange={([v]) => updateGoal(i, 'rating', v)}
                          min={0} max={5} step={0.5}
                          className="w-32"
                        />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs mb-1">Achievement: {goal.achievement_percentage || 0}%</p>
                    <Progress value={goal.achievement_percentage || 0} className="h-2" />
                    {isManager && (
                      <Slider
                        value={[goal.achievement_percentage || 0]}
                        onValueChange={([v]) => updateGoal(i, 'achievement_percentage', v)}
                        min={0} max={100} step={5}
                        className="mt-2"
                      />
                    )}
                  </div>
                  {isManager && (
                    <Textarea
                      placeholder="Comments on goal achievement..."
                      value={goal.comments || ''}
                      onChange={(e) => updateGoal(i, 'comments', e.target.value)}
                      className="bg-gray-900 border-gray-700 text-white text-sm"
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="skills">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-400" /> Skills Assessment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {editedReview.skills_assessment?.map((skill, i) => (
                <div key={i} className="p-4 bg-gray-800 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <p className="text-white font-medium">{skill.skill_name}</p>
                      <p className="text-gray-500 text-sm">{skill.current_level} → {skill.expected_level}</p>
                    </div>
                    {isManager && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-sm">{skill.rating || 0}/5</span>
                        <Slider
                          value={[skill.rating || 0]}
                          onValueChange={([v]) => updateSkill(i, 'rating', v)}
                          min={0} max={5} step={0.5}
                          className="w-24"
                        />
                      </div>
                    )}
                  </div>
                  {isManager && (
                    <Input
                      placeholder="Comments..."
                      value={skill.comments || ''}
                      onChange={(e) => updateSkill(i, 'comments', e.target.value)}
                      className="bg-gray-900 border-gray-700 text-white text-sm"
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="competencies">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-400" /> Core Competencies
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {editedReview.competencies?.map((comp, i) => (
                <div key={i} className="p-4 bg-gray-800 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white font-medium">{comp.competency}</p>
                    {isManager && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400 text-sm">{comp.rating || 0}/5</span>
                        <Slider
                          value={[comp.rating || 0]}
                          onValueChange={([v]) => updateCompetency(i, 'rating', v)}
                          min={0} max={5} step={0.5}
                          className="w-24"
                        />
                      </div>
                    )}
                  </div>
                  {isManager && (
                    <Textarea
                      placeholder="Examples demonstrating this competency..."
                      value={comp.examples || ''}
                      onChange={(e) => updateCompetency(i, 'examples', e.target.value)}
                      className="bg-gray-900 border-gray-700 text-white text-sm"
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="feedback">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" /> Peer Feedback
              </CardTitle>
            </CardHeader>
            <CardContent>
              {review.peer_feedback?.length > 0 ? (
                <div className="space-y-4">
                  {review.peer_feedback.map((fb, i) => (
                    <div key={i} className="p-4 bg-gray-800 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-white font-medium">{fb.peer_name}</p>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="border-blue-600 text-blue-400">Collab: {fb.collaboration_rating}/5</Badge>
                          <Badge variant="outline" className="border-green-600 text-green-400">Comm: {fb.communication_rating}/5</Badge>
                        </div>
                      </div>
                      {fb.strengths?.length > 0 && (
                        <div className="mb-2">
                          <p className="text-gray-500 text-xs">Strengths:</p>
                          {fb.strengths.map((s, j) => <p key={j} className="text-gray-300 text-sm">• {s}</p>)}
                        </div>
                      )}
                      {fb.improvements?.length > 0 && (
                        <div className="mb-2">
                          <p className="text-gray-500 text-xs">Improvements:</p>
                          {fb.improvements.map((s, j) => <p key={j} className="text-gray-300 text-sm">• {s}</p>)}
                        </div>
                      )}
                      {fb.comments && <p className="text-gray-400 text-sm italic">"{fb.comments}"</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No peer feedback received yet.</p>
              )}
              {review.peer_feedback_requests?.filter(r => r.status === 'pending').length > 0 && (
                <div className="mt-4 p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                  <p className="text-amber-400 text-sm">Waiting for feedback from: {review.peer_feedback_requests.filter(r => r.status === 'pending').map(r => r.peer_name).join(', ')}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Review Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isManager && (
                <>
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Key Strengths</p>
                    <Textarea
                      placeholder="List key strengths..."
                      value={editedReview.strengths?.join('\n') || ''}
                      onChange={(e) => setEditedReview({ ...editedReview, strengths: e.target.value.split('\n').filter(s => s) })}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Areas for Improvement</p>
                    <Textarea
                      placeholder="List areas for improvement..."
                      value={editedReview.areas_for_improvement?.join('\n') || ''}
                      onChange={(e) => setEditedReview({ ...editedReview, areas_for_improvement: e.target.value.split('\n').filter(s => s) })}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Manager Comments</p>
                    <Textarea
                      placeholder="Overall feedback and comments..."
                      value={editedReview.manager_comments || ''}
                      onChange={(e) => setEditedReview({ ...editedReview, manager_comments: e.target.value })}
                      className="bg-gray-800 border-gray-700 text-white h-32"
                    />
                  </div>
                </>
              )}
              {!isManager && (
                <div className="space-y-4">
                  {review.strengths?.length > 0 && (
                    <div>
                      <p className="text-green-400 text-sm mb-2">Strengths</p>
                      {review.strengths.map((s, i) => <p key={i} className="text-gray-300">• {s}</p>)}
                    </div>
                  )}
                  {review.areas_for_improvement?.length > 0 && (
                    <div>
                      <p className="text-amber-400 text-sm mb-2">Areas for Improvement</p>
                      {review.areas_for_improvement.map((s, i) => <p key={i} className="text-gray-300">• {s}</p>)}
                    </div>
                  )}
                  {review.manager_comments && (
                    <div className="p-4 bg-gray-800 rounded-lg">
                      <p className="text-gray-400 text-sm mb-2">Manager Comments</p>
                      <p className="text-gray-300">{review.manager_comments}</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}