import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Rocket, Target, CheckCircle2, Clock, ArrowRight, Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

export default function EvolutionRoadmap({ roadmap, currentStage }) {
  if (!roadmap?.length) return null;

  const stageColors = {
    reactive: "from-red-500 to-orange-500",
    proactive: "from-orange-500 to-yellow-500",
    creative: "from-yellow-500 to-green-500",
    integral: "from-green-500 to-blue-500",
    generative: "from-blue-500 to-purple-500"
  };

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Rocket className="w-5 h-5 text-purple-400" />
          Evolution Roadmap
        </CardTitle>
        <p className="text-sm text-gray-500">Your journey from reactive to generative leadership</p>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 via-blue-500 to-emerald-500" />

          <div className="space-y-6">
            {roadmap.map((phase, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.15 }}
                className="relative pl-16"
              >
                {/* Timeline dot */}
                <div className={`absolute left-4 w-5 h-5 rounded-full ${
                  idx === 0 ? 'bg-purple-500 animate-pulse' : 'bg-white/20'
                } border-2 border-white/30 flex items-center justify-center`}>
                  {idx === 0 && <div className="w-2 h-2 bg-white rounded-full" />}
                </div>

                <div className={`p-4 rounded-xl border ${
                  idx === 0 
                    ? 'bg-gradient-to-r from-purple-500/20 to-blue-500/20 border-purple-500/30' 
                    : 'bg-white/5 border-white/10'
                }`}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-white font-medium">{phase.phase}</h4>
                        {idx === 0 && <Badge className="bg-purple-500 text-xs">Current</Badge>}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {phase.duration}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-400 mb-3">{phase.focus}</p>

                  {phase.practices?.length > 0 && (
                    <div className="mb-3">
                      <p className="text-[10px] text-gray-500 uppercase mb-2">Key Practices</p>
                      <div className="grid grid-cols-2 gap-2">
                        {phase.practices.map((practice, i) => (
                          <div key={i} className="text-xs text-gray-300 flex items-center gap-1 p-2 bg-white/5 rounded">
                            <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0" />
                            <span>{practice}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {phase.milestones?.length > 0 && (
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase mb-2">Milestones</p>
                      <div className="space-y-1">
                        {phase.milestones.map((milestone, i) => (
                          <div key={i} className="text-xs text-emerald-300 flex items-center gap-2">
                            <Target className="w-3 h-3" />
                            {milestone}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}