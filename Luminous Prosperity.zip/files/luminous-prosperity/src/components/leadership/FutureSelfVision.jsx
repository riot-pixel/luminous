import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, ArrowRight, Brain, Heart, Zap, Star
} from "lucide-react";
import { motion } from "framer-motion";

export default function FutureSelfVision({ futureProfile, currentStage }) {
  if (!futureProfile) return null;

  const stageLabels = {
    reactive: { label: "Reactive", color: "bg-red-500" },
    proactive: { label: "Proactive", color: "bg-orange-500" },
    creative: { label: "Creative", color: "bg-yellow-500" },
    integral: { label: "Integral", color: "bg-blue-500" },
    generative: { label: "Generative", color: "bg-purple-500" }
  };

  return (
    <Card className="bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-emerald-500/10 border-purple-500/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Star className="w-5 h-5 text-amber-400" />
          Your Future Self
        </CardTitle>
        <p className="text-sm text-gray-500">The leader capable of running the future company</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Evolution Journey */}
        <div className="flex items-center justify-center gap-4 p-4 bg-white/5 rounded-xl">
          <div className="text-center">
            <Badge className={stageLabels[currentStage]?.color || "bg-gray-500"}>
              {stageLabels[currentStage]?.label || "Current"}
            </Badge>
            <p className="text-xs text-gray-500 mt-1">Now</p>
          </div>
          <ArrowRight className="w-8 h-8 text-gray-600" />
          <div className="text-center">
            <Badge className="bg-gradient-to-r from-purple-500 to-amber-500">Generative</Badge>
            <p className="text-xs text-gray-500 mt-1">Future</p>
          </div>
        </div>

        {/* Vision */}
        {futureProfile.vision && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-gradient-to-r from-amber-500/20 to-orange-500/20 rounded-xl border border-amber-500/30"
          >
            <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Vision of Your Future Self</p>
            <p className="text-gray-200 leading-relaxed">{futureProfile.vision}</p>
          </motion.div>
        )}

        {/* Key Shifts */}
        {futureProfile.key_shifts?.length > 0 && (
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Key Shifts Required</p>
            <div className="space-y-2">
              {futureProfile.key_shifts.map((shift, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-center gap-3 p-3 bg-white/5 rounded-lg"
                >
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <Zap className="w-4 h-4 text-blue-400" />
                  </div>
                  <p className="text-sm text-gray-300">{shift}</p>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Capabilities to Develop */}
        {futureProfile.capabilities_to_develop?.length > 0 && (
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Capabilities to Develop</p>
            <div className="grid grid-cols-2 gap-2">
              {futureProfile.capabilities_to_develop.map((cap, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20"
                >
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm text-emerald-300">{cap}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Mindset Upgrades */}
        {futureProfile.mindset_upgrades?.length > 0 && (
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Mindset Upgrades</p>
            <div className="space-y-2">
              {futureProfile.mindset_upgrades.map((upgrade, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-start gap-2 p-2"
                >
                  <Sparkles className="w-4 h-4 text-purple-400 mt-0.5" />
                  <p className="text-sm text-purple-300">{upgrade}</p>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}