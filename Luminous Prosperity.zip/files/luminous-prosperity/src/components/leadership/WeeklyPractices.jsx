import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Calendar, Clock, Target, Sun, Moon, Coffee, Brain
} from "lucide-react";
import { motion } from "framer-motion";

export default function WeeklyPractices({ practices, onToggle }) {
  if (!practices?.length) return null;

  const getFrequencyIcon = (freq) => {
    switch(freq?.toLowerCase()) {
      case 'daily': return Sun;
      case 'morning': return Coffee;
      case 'evening': return Moon;
      default: return Calendar;
    }
  };

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Calendar className="w-5 h-5 text-emerald-400" />
          Weekly Leadership Practices
        </CardTitle>
        <p className="text-sm text-gray-500">Rituals that compound into transformation</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {practices.map((practice, idx) => {
            const FreqIcon = getFrequencyIcon(practice.frequency);
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-emerald-500/30 transition-all"
              >
                <div className="flex items-start gap-4">
                  <div className="pt-1">
                    <Checkbox 
                      id={`practice-${idx}`}
                      onCheckedChange={(checked) => onToggle?.(idx, checked)}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-white font-medium">{practice.practice}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs flex items-center gap-1">
                          <FreqIcon className="w-3 h-3" />
                          {practice.frequency}
                        </Badge>
                        <Badge variant="outline" className="text-xs flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {practice.duration}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-gray-400">{practice.purpose}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}