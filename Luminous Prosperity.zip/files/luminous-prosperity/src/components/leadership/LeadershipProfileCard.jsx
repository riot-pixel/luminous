import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, Anchor, Zap, Compass, TrendingUp, 
  AlertTriangle, CheckCircle2, Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

export default function LeadershipProfileCard({ profile }) {
  if (!profile) return null;

  const dimensions = [
    {
      key: "thinking_clarity",
      label: "Thinking Clarity",
      icon: Brain,
      color: "purple",
      description: "Clear, focused strategic thinking"
    },
    {
      key: "groundedness",
      label: "Groundedness",
      icon: Anchor,
      color: "blue",
      description: "Operating from calm presence"
    },
    {
      key: "leverage_mastery",
      label: "Leverage Mastery",
      icon: Zap,
      color: "amber",
      description: "Maximum impact, minimum drain"
    },
    {
      key: "vision_alignment",
      label: "Vision Alignment",
      icon: Compass,
      color: "emerald",
      description: "Actions aligned to north star"
    }
  ];

  const getColorClasses = (color) => ({
    purple: { bg: "bg-purple-500/20", text: "text-purple-400", border: "border-purple-500/30" },
    blue: { bg: "bg-blue-500/20", text: "text-blue-400", border: "border-blue-500/30" },
    amber: { bg: "bg-amber-500/20", text: "text-amber-400", border: "border-amber-500/30" },
    emerald: { bg: "bg-emerald-500/20", text: "text-emerald-400", border: "border-emerald-500/30" }
  }[color]);

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {dimensions.map((dim, idx) => {
        const data = profile[dim.key];
        const colors = getColorClasses(dim.color);
        const Icon = dim.icon;

        return (
          <motion.div
            key={dim.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <Card className={`bg-white/5 border-white/10 hover:${colors.border} transition-all`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${colors.bg} flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 ${colors.text}`} />
                    </div>
                    <div>
                      <CardTitle className="text-white text-sm">{dim.label}</CardTitle>
                      <p className="text-xs text-gray-500">{dim.description}</p>
                    </div>
                  </div>
                  <span className={`text-2xl font-light ${colors.text}`}>{data?.score || 0}%</span>
                </div>
              </CardHeader>
              <CardContent>
                <Progress value={data?.score || 0} className="h-2 mb-4" />
                
                {data?.patterns?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-[10px] text-gray-500 uppercase mb-1">Patterns</p>
                    <div className="flex flex-wrap gap-1">
                      {data.patterns.slice(0, 3).map((p, i) => (
                        <span key={i} className="text-xs px-2 py-0.5 bg-white/10 text-gray-300 rounded">{p}</span>
                      ))}
                    </div>
                  </div>
                )}

                {data?.blockers?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-[10px] text-red-400 uppercase mb-1">Blockers</p>
                    <div className="space-y-1">
                      {data.blockers.slice(0, 2).map((b, i) => (
                        <div key={i} className="text-xs text-red-300 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> {b}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {data?.unlocks?.length > 0 && (
                  <div>
                    <p className="text-[10px] text-emerald-400 uppercase mb-1">Unlocks</p>
                    <div className="space-y-1">
                      {data.unlocks.slice(0, 2).map((u, i) => (
                        <div key={i} className="text-xs text-emerald-300 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" /> {u}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {data?.stressors?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-[10px] text-orange-400 uppercase mb-1">Stressors</p>
                    <div className="flex flex-wrap gap-1">
                      {data.stressors.slice(0, 3).map((s, i) => (
                        <span key={i} className="text-xs px-2 py-0.5 bg-orange-500/20 text-orange-300 rounded">{s}</span>
                      ))}
                    </div>
                  </div>
                )}

                {data?.anchors?.length > 0 && (
                  <div>
                    <p className="text-[10px] text-blue-400 uppercase mb-1">Anchors</p>
                    <div className="flex flex-wrap gap-1">
                      {data.anchors.slice(0, 3).map((a, i) => (
                        <span key={i} className="text-xs px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded">{a}</span>
                      ))}
                    </div>
                  </div>
                )}

                {data?.high_leverage_activities?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-[10px] text-emerald-400 uppercase mb-1">High Leverage</p>
                    <div className="space-y-1">
                      {data.high_leverage_activities.slice(0, 2).map((h, i) => (
                        <div key={i} className="text-xs text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> {h}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {data?.energy_drains?.length > 0 && (
                  <div>
                    <p className="text-[10px] text-red-400 uppercase mb-1">Energy Drains</p>
                    <div className="space-y-1">
                      {data.energy_drains.slice(0, 2).map((d, i) => (
                        <div key={i} className="text-xs text-red-300 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3 rotate-180" /> {d}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}