import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sparkles, UserPlus, RefreshCw, Building2, Target, Lightbulb,
  CheckCircle2, Brain, Zap, Users
} from "lucide-react";

export default function SuggestedConnectionsAI({ 
  user, 
  organization, 
  userSkills, 
  challenges, 
  projects, 
  connections 
}) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [connectingId, setConnectingId] = useState(null);

  const createConnectionMutation = useMutation({
    mutationFn: (data) => base44.entities.EcosystemConnection.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
    },
  });

  const generateSuggestions = async () => {
    setIsGenerating(true);
    try {
      const mySkillNames = userSkills?.map(s => s.skill_name) || [];
      const activeProjects = projects?.filter(p => p.status === 'active') || [];
      const openChallenges = challenges?.filter(c => c.status === 'open') || [];
      const existingConnectionEmails = connections?.map(c => c.recipient_email) || [];

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI connection recommender for a professional ecosystem network. Generate 8-10 suggested connections for this user.

USER PROFILE:
- Email: ${user?.email}
- Name: ${user?.full_name || 'Unknown'}
- Organization: ${organization?.name || 'Unknown'}
- Industry: ${organization?.industry || 'Technology'}
- Skills: ${mySkillNames.join(', ') || 'General business skills'}

ACTIVE PROJECTS (${activeProjects.length}):
${activeProjects.slice(0, 5).map(p => `- ${p.name}: ${p.description || 'No description'}`).join('\n') || 'No active projects'}

OPEN CHALLENGES THEY COULD HELP WITH:
${openChallenges.slice(0, 5).map(c => `- "${c.title}" (${c.category}): Skills needed: ${c.skills_needed?.join(', ')}`).join('\n') || 'No open challenges'}

EXISTING CONNECTIONS TO AVOID:
${existingConnectionEmails.slice(0, 10).join(', ') || 'None'}

Generate realistic professional connection suggestions. For each suggestion, create:
1. A realistic name and email
2. Their organization and role
3. Their key skills
4. Connection type (skill_exchange, mentorship, collaboration, knowledge_sharing, challenge_solving)
5. Match score (60-98)
6. Detailed reason why this connection would be valuable (2-3 sentences)
7. Potential collaboration areas`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  email: { type: "string" },
                  organization: { type: "string" },
                  role: { type: "string" },
                  skills: { type: "array", items: { type: "string" } },
                  connection_type: { type: "string" },
                  match_score: { type: "number" },
                  match_reason: { type: "string" },
                  collaboration_areas: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setSuggestions(result.suggestions || []);
    } catch (error) {
      console.error("Error generating suggestions:", error);
    }
    setIsGenerating(false);
  };

  const connectWithUser = async (suggestion) => {
    setConnectingId(suggestion.email);
    try {
      await createConnectionMutation.mutateAsync({
        requester_email: user?.email,
        requester_org: organization?.name || user?.organization_name,
        recipient_email: suggestion.email,
        recipient_org: suggestion.organization,
        connection_type: suggestion.connection_type,
        matching_skills: suggestion.skills?.slice(0, 3),
        ai_match_score: suggestion.match_score,
        ai_match_reason: suggestion.match_reason,
        status: "pending"
      });
      
      // Remove from suggestions after connecting
      setSuggestions(prev => prev.filter(s => s.email !== suggestion.email));
    } catch (error) {
      console.error("Error creating connection:", error);
    }
    setConnectingId(null);
  };

  const connectionTypeColors = {
    skill_exchange: "bg-blue-600",
    mentorship: "bg-purple-600",
    collaboration: "bg-green-600",
    knowledge_sharing: "bg-cyan-600",
    challenge_solving: "bg-orange-600"
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-400" />
                AI Connection Suggestions
              </h3>
              <p className="text-gray-400 text-sm mt-1">
                Discover potential partners based on your skills, projects, and goals
              </p>
            </div>
            <Button
              onClick={generateSuggestions}
              disabled={isGenerating}
              className="bg-white text-black hover:bg-gray-200"
            >
              {isGenerating ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" /> Find Connections</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Suggestions Grid */}
      {suggestions.length === 0 ? (
        <Card className="bg-gray-900 border-gray-800 text-center py-12">
          <CardContent>
            <Users className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-medium mb-2">No Suggestions Yet</h3>
            <p className="text-gray-400 text-sm mb-4">
              Click "Find Connections" to get AI-powered partner recommendations
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {suggestions.map((suggestion, i) => (
            <Card key={i} className="bg-gray-900 border-gray-800 hover:border-gray-700 transition-colors">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-purple-600 text-white">
                      {suggestion.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-white font-medium">{suggestion.name}</h4>
                        <p className="text-gray-400 text-sm">{suggestion.role}</p>
                        <p className="text-gray-500 text-xs flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {suggestion.organization}
                        </p>
                      </div>
                      <Badge className="bg-purple-600 shrink-0">
                        {suggestion.match_score}% match
                      </Badge>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-2">
                      {suggestion.skills?.slice(0, 3).map((skill, j) => (
                        <span key={j} className="text-xs px-2 py-0.5 bg-gray-800 text-gray-300 rounded">
                          {skill}
                        </span>
                      ))}
                    </div>

                    <div className="mt-3 p-2 bg-gray-800 rounded">
                      <p className="text-gray-300 text-sm">{suggestion.match_reason}</p>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <Badge className={connectionTypeColors[suggestion.connection_type] || 'bg-gray-600'}>
                        {suggestion.connection_type?.replace('_', ' ')}
                      </Badge>
                      <Button
                        size="sm"
                        onClick={() => connectWithUser(suggestion)}
                        disabled={connectingId === suggestion.email}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {connectingId === suggestion.email ? (
                          <><RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Connecting...</>
                        ) : (
                          <><UserPlus className="w-3 h-3 mr-1" /> Connect</>
                        )}
                      </Button>
                    </div>

                    {suggestion.collaboration_areas?.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-gray-800">
                        <p className="text-gray-500 text-xs mb-1">Collaboration areas:</p>
                        <div className="flex flex-wrap gap-1">
                          {suggestion.collaboration_areas.map((area, j) => (
                            <span key={j} className="text-xs text-purple-400">• {area}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}