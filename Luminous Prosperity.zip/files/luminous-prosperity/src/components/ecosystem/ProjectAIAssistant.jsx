import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Brain, Users, AlertTriangle, Clock, FileText, RefreshCw,
  UserPlus, TrendingUp, Target, CheckCircle2, Sparkles, ChevronRight
} from "lucide-react";

export default function ProjectAIAssistant({ project, connections, userSkills, user }) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);

  const createProjectAIMutation = useMutation({
    mutationFn: (data) => base44.entities.CollaborativeProjectAI.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['projectAI'] }),
  });

  const analyzeProject = async () => {
    setIsAnalyzing(true);
    try {
      const acceptedConnections = connections?.filter(c => c.status === 'accepted') || [];
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this collaborative project and provide AI-driven insights.

PROJECT:
- Name: ${project.name}
- Description: ${project.description || 'No description'}
- Status: ${project.status}
- Current Members: ${project.members?.length || 0}
- Goals: ${project.goals?.map(g => g.goal).join(', ') || 'Not defined'}
- Milestones: ${project.milestones?.map(m => `${m.title} (${m.status})`).join(', ') || 'None'}

AVAILABLE CONNECTIONS FOR MEMBER SUGGESTIONS:
${acceptedConnections.slice(0, 20).map(c => `
- ${c.recipient_email} (${c.recipient_org})
  Skills: ${c.matching_skills?.join(', ') || 'Unknown'}
  Health Score: ${c.health_score || 'N/A'}
  Type: ${c.connection_type}
`).join('\n')}

Provide:
1. Top 5 suggested members with fit scores and reasons
2. Risk predictions with probability, impact, and mitigation
3. Timeline prediction with confidence level
4. Resource recommendations
5. Success probability assessment`,
        response_json_schema: {
          type: "object",
          properties: {
            suggested_members: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  email: { type: "string" },
                  organization: { type: "string" },
                  skills_match: { type: "array", items: { type: "string" } },
                  connection_health: { type: "number" },
                  fit_score: { type: "number" },
                  recommendation_reason: { type: "string" }
                }
              }
            },
            risk_predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  probability: { type: "number" },
                  impact: { type: "string" },
                  mitigation: { type: "string" },
                  early_warning_signs: { type: "array", items: { type: "string" } }
                }
              }
            },
            timeline_prediction: {
              type: "object",
              properties: {
                estimated_completion: { type: "string" },
                confidence_level: { type: "number" },
                bottlenecks: { type: "array", items: { type: "string" } },
                acceleration_opportunities: { type: "array", items: { type: "string" } }
              }
            },
            resource_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  resource_type: { type: "string" },
                  recommendation: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            success_probability: { type: "number" },
            progress_summary: {
              type: "object",
              properties: {
                overall_progress: { type: "number" },
                key_achievements: { type: "array", items: { type: "string" } },
                blockers: { type: "array", items: { type: "string" } },
                next_steps: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      setAiInsights(result);

      // Save to entity
      await createProjectAIMutation.mutateAsync({
        project_id: project.id,
        project_name: project.name,
        suggested_members: result.suggested_members,
        risk_predictions: result.risk_predictions,
        timeline_prediction: result.timeline_prediction,
        resource_recommendations: result.resource_recommendations,
        success_probability: result.success_probability,
        progress_reports: [{
          report_date: new Date().toISOString(),
          overall_progress: result.progress_summary?.overall_progress || 0,
          key_achievements: result.progress_summary?.key_achievements || [],
          blockers: result.progress_summary?.blockers || [],
          next_steps: result.progress_summary?.next_steps || [],
          health_score: result.success_probability
        }],
        last_analysis: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error analyzing project:", error);
    }
    setIsAnalyzing(false);
  };

  const riskColors = { high: 'bg-red-600', medium: 'bg-yellow-600', low: 'bg-green-600' };

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-800">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-400" />
                AI Project Assistant
              </h3>
              <p className="text-gray-400 text-sm">Get AI-driven insights for "{project.name}"</p>
            </div>
            <Button onClick={analyzeProject} disabled={isAnalyzing} className="bg-white text-black hover:bg-gray-200">
              {isAnalyzing ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</> : <><Sparkles className="w-4 h-4 mr-2" /> Analyze</>}
            </Button>
          </div>
        </CardContent>
      </Card>

      {aiInsights && (
        <Tabs defaultValue="members" className="space-y-4">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="members"><Users className="w-4 h-4 mr-1" />Members</TabsTrigger>
            <TabsTrigger value="risks"><AlertTriangle className="w-4 h-4 mr-1" />Risks</TabsTrigger>
            <TabsTrigger value="timeline"><Clock className="w-4 h-4 mr-1" />Timeline</TabsTrigger>
            <TabsTrigger value="report"><FileText className="w-4 h-4 mr-1" />Report</TabsTrigger>
          </TabsList>

          <TabsContent value="members">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm">Suggested Team Members</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {aiInsights.suggested_members?.map((member, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg">
                    <Avatar><AvatarFallback className="bg-blue-600">{member.email?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                    <div className="flex-1">
                      <p className="text-white text-sm">{member.email}</p>
                      <p className="text-gray-500 text-xs">{member.organization}</p>
                      <div className="flex gap-1 mt-1">
                        {member.skills_match?.slice(0, 3).map((s, j) => (
                          <Badge key={j} variant="outline" className="text-xs border-gray-700">{s}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-600">{member.fit_score}% fit</Badge>
                      <p className="text-gray-400 text-xs mt-1">Health: {member.connection_health}%</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="risks">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-sm">Risk Predictions</CardTitle>
                  <Badge className="bg-purple-600">{aiInsights.success_probability}% Success</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {aiInsights.risk_predictions?.map((risk, i) => (
                  <div key={i} className="p-3 bg-gray-800 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-white text-sm">{risk.risk}</p>
                      <div className="flex gap-2">
                        <Badge className={riskColors[risk.impact?.toLowerCase()] || 'bg-gray-600'}>{risk.impact}</Badge>
                        <Badge variant="outline" className="border-gray-700">{risk.probability}%</Badge>
                      </div>
                    </div>
                    <p className="text-green-400 text-xs">Mitigation: {risk.mitigation}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="timeline">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm">Timeline Prediction</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                  <span className="text-gray-400">Estimated Completion</span>
                  <span className="text-white font-medium">{aiInsights.timeline_prediction?.estimated_completion}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Confidence</span>
                  <div className="flex items-center gap-2">
                    <Progress value={aiInsights.timeline_prediction?.confidence_level} className="w-24 h-2" />
                    <span className="text-white">{aiInsights.timeline_prediction?.confidence_level}%</span>
                  </div>
                </div>
                {aiInsights.timeline_prediction?.bottlenecks?.length > 0 && (
                  <div>
                    <p className="text-red-400 text-xs font-medium mb-2">Bottlenecks</p>
                    {aiInsights.timeline_prediction.bottlenecks.map((b, i) => (
                      <p key={i} className="text-gray-300 text-sm flex items-center gap-2"><AlertTriangle className="w-3 h-3 text-red-400" />{b}</p>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="report">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm">Progress Report</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Overall Progress</span>
                  <div className="flex items-center gap-2">
                    <Progress value={aiInsights.progress_summary?.overall_progress} className="w-32 h-2" />
                    <span className="text-white">{aiInsights.progress_summary?.overall_progress}%</span>
                  </div>
                </div>
                {aiInsights.progress_summary?.key_achievements?.length > 0 && (
                  <div>
                    <p className="text-green-400 text-xs font-medium mb-2">Key Achievements</p>
                    {aiInsights.progress_summary.key_achievements.map((a, i) => (
                      <p key={i} className="text-gray-300 text-sm flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-green-400" />{a}</p>
                    ))}
                  </div>
                )}
                {aiInsights.progress_summary?.next_steps?.length > 0 && (
                  <div>
                    <p className="text-blue-400 text-xs font-medium mb-2">Next Steps</p>
                    {aiInsights.progress_summary.next_steps.map((s, i) => (
                      <p key={i} className="text-gray-300 text-sm flex items-center gap-2"><ChevronRight className="w-3 h-3 text-blue-400" />{s}</p>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}