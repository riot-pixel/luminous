import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, RefreshCw, Calendar, CheckCircle2, Clock, AlertTriangle,
  Mail, Phone, Users, Sparkles, Bell, Settings
} from "lucide-react";

export default function AutomatedCRMTasks({ connections, feedback, user }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [automatedTasks, setAutomatedTasks] = useState([]);
  const [autoCreateEnabled, setAutoCreateEnabled] = useState(false);

  const createOutreachMutation = useMutation({
    mutationFn: (data) => base44.entities.PartnerOutreach.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['partnerOutreaches'] }),
  });

  const generateTasks = async () => {
    setIsGenerating(true);
    try {
      // Get at-risk or cooling connections
      const needsAttention = connections?.filter(c => 
        c.health_status === 'at_risk' || 
        c.health_status === 'dormant' || 
        c.health_status === 'cooling'
      ) || [];

      // Get recent feedback
      const recentFeedback = feedback?.filter(f => f.status === 'analyzed').slice(0, 5) || [];

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate automated CRM follow-up tasks based on connection health and feedback data.

CONNECTIONS NEEDING ATTENTION:
${needsAttention.slice(0, 10).map(c => `
- ${c.recipient_email} (${c.recipient_org})
  Status: ${c.health_status}
  Health Score: ${c.health_score || 'N/A'}
  Last Interaction: ${c.last_interaction || 'Unknown'}
  Type: ${c.connection_type}
`).join('\n') || 'No connections needing attention'}

RECENT PARTNER FEEDBACK:
${recentFeedback.map(f => `
- Partner: ${f.partner_email}
  Overall Rating: ${f.overall_rating}/5
  Improvements Suggested: ${f.ai_analysis?.improvement_areas?.join(', ') || 'None'}
`).join('\n') || 'No recent feedback'}

Generate 5-8 actionable CRM tasks with:
1. Task type (email, call, meeting, follow-up)
2. Target contact
3. Recommended action
4. Priority and deadline
5. Talking points or message draft`,
        response_json_schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  task_type: { type: "string" },
                  contact_email: { type: "string" },
                  contact_org: { type: "string" },
                  action: { type: "string" },
                  reason: { type: "string" },
                  priority: { type: "string" },
                  suggested_deadline: { type: "string" },
                  talking_points: { type: "array", items: { type: "string" } },
                  message_draft: { type: "string" }
                }
              }
            }
          }
        }
      });

      setAutomatedTasks(result.tasks || []);

      // Auto-create outreach records if enabled
      if (autoCreateEnabled && result.tasks?.length > 0) {
        for (const task of result.tasks.slice(0, 3)) {
          await createOutreachMutation.mutateAsync({
            partner_name: task.contact_email?.split('@')[0] || 'Contact',
            partner_email: task.contact_email,
            partner_industry: task.contact_org,
            outreach_status: "scheduled",
            outreach_channel: task.task_type === 'call' ? 'phone' : 'email',
            personalized_message: task.message_draft,
            key_talking_points: task.talking_points || [],
            notes: `Auto-generated: ${task.reason}`,
            assigned_to: user?.email,
            next_action_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
          });
        }
      }

    } catch (error) {
      console.error("Error generating tasks:", error);
    }
    setIsGenerating(false);
  };

  const completeTask = (index) => {
    setAutomatedTasks(prev => prev.filter((_, i) => i !== index));
  };

  const taskTypeIcons = {
    email: Mail,
    call: Phone,
    meeting: Users,
    'follow-up': Bell
  };

  const priorityColors = {
    high: 'bg-red-600',
    medium: 'bg-yellow-600',
    low: 'bg-blue-600'
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Calendar className="w-5 h-5 text-orange-400" />
            Automated CRM Tasks
          </CardTitle>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-gray-400 text-xs">Auto-create</span>
              <Switch checked={autoCreateEnabled} onCheckedChange={setAutoCreateEnabled} />
            </div>
            <Button onClick={generateTasks} disabled={isGenerating} size="sm" className="bg-orange-600 hover:bg-orange-700">
              {isGenerating ? <><RefreshCw className="w-3 h-3 mr-1 animate-spin" />...</> : <><Brain className="w-3 h-3 mr-1" />Generate</>}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {automatedTasks.length === 0 ? (
          <p className="text-gray-500 text-sm text-center py-6">
            Generate AI-powered follow-up tasks based on connection health and partner feedback
          </p>
        ) : (
          <ScrollArea className="h-[400px]">
            <div className="space-y-3 pr-4">
              {automatedTasks.map((task, i) => {
                const TaskIcon = taskTypeIcons[task.task_type] || Bell;
                return (
                  <div key={i} className="p-4 bg-gray-800 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-orange-900 flex items-center justify-center flex-shrink-0">
                        <TaskIcon className="w-5 h-5 text-orange-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <h4 className="text-white font-medium text-sm">{task.action}</h4>
                          <Badge className={priorityColors[task.priority] || 'bg-gray-600'}>
                            {task.priority}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-xs">{task.contact_email} • {task.contact_org}</p>
                        <p className="text-orange-400 text-xs mt-1">{task.reason}</p>
                        
                        {task.talking_points?.length > 0 && (
                          <div className="mt-2 p-2 bg-gray-900 rounded text-xs">
                            <p className="text-gray-500 mb-1">Talking Points:</p>
                            <ul className="space-y-1">
                              {task.talking_points.slice(0, 3).map((point, j) => (
                                <li key={j} className="text-gray-300">• {point}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        <div className="flex items-center justify-between mt-3">
                          <span className="text-gray-500 text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Due: {task.suggested_deadline}
                          </span>
                          <Button size="sm" variant="ghost" onClick={() => completeTask(i)} className="text-green-400 hover:text-green-300 h-7">
                            <CheckCircle2 className="w-3 h-3 mr-1" />Done
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}