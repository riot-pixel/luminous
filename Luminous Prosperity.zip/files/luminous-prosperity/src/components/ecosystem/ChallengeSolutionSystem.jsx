import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Lightbulb, Send, Star, ThumbsUp, MessageCircle, Trophy,
  Sparkles, RefreshCw, Users, Brain, CheckCircle2, Clock,
  ArrowRight, Award, Target
} from "lucide-react";

export default function ChallengeSolutionSystem({ challenge, user, organization, userSkills }) {
  const queryClient = useQueryClient();
  const [showSolutionDialog, setShowSolutionDialog] = useState(false);
  const [showMatchDialog, setShowMatchDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isMatching, setIsMatching] = useState(false);
  const [solutionData, setSolutionData] = useState({
    title: "",
    description: "",
    approach: "",
    expected_outcomes: "",
    resources_needed: ""
  });
  const [matchResults, setMatchResults] = useState(null);

  // Fetch solutions for this challenge
  const { data: solutions } = useQuery({
    queryKey: ['challengeSolutions', challenge?.id],
    queryFn: () => base44.entities.ChallengeSolution?.filter({ challenge_id: challenge?.id }) || [],
    enabled: !!challenge?.id,
    initialData: [],
  });

  const createSolutionMutation = useMutation({
    mutationFn: (data) => base44.entities.ChallengeSolution.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['challengeSolutions', challenge?.id] });
      queryClient.invalidateQueries({ queryKey: ['sharedChallenges'] });
    },
  });

  const updateChallengeMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SharedChallenge.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedChallenges'] });
    },
  });

  const submitSolution = async () => {
    setIsSubmitting(true);
    try {
      // Generate AI assessment of the solution
      const assessment = await base44.integrations.Core.InvokeLLM({
        prompt: `Assess this solution proposal for a challenge:

CHALLENGE: ${challenge?.title}
CHALLENGE DESCRIPTION: ${challenge?.description}
SKILLS NEEDED: ${challenge?.skills_needed?.join(', ')}

PROPOSED SOLUTION:
Title: ${solutionData.title}
Description: ${solutionData.description}
Approach: ${solutionData.approach}
Expected Outcomes: ${solutionData.expected_outcomes}

Evaluate:
1. Relevance to the challenge (0-100)
2. Feasibility (0-100)
3. Innovation level (0-100)
4. Strengths of the proposal
5. Areas for improvement
6. Overall recommendation`,
        response_json_schema: {
          type: "object",
          properties: {
            relevance_score: { type: "number" },
            feasibility_score: { type: "number" },
            innovation_score: { type: "number" },
            overall_score: { type: "number" },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            recommendation: { type: "string" }
          }
        }
      });

      await createSolutionMutation.mutateAsync({
        challenge_id: challenge.id,
        challenge_title: challenge.title,
        submitter_email: user?.email,
        submitter_org: organization?.name || user?.organization_name,
        title: solutionData.title,
        description: solutionData.description,
        approach: solutionData.approach,
        expected_outcomes: solutionData.expected_outcomes,
        resources_needed: solutionData.resources_needed,
        ai_assessment: assessment,
        status: "submitted",
        votes: 0,
        submission_date: new Date().toISOString()
      });

      // Update challenge solutions count
      await updateChallengeMutation.mutateAsync({
        id: challenge.id,
        data: { solutions_count: (challenge.solutions_count || 0) + 1 }
      });

      setShowSolutionDialog(false);
      setSolutionData({
        title: "",
        description: "",
        approach: "",
        expected_outcomes: "",
        resources_needed: ""
      });
    } catch (error) {
      console.error("Error submitting solution:", error);
    }
    setIsSubmitting(false);
  };

  const findMatchingExperts = async () => {
    setIsMatching(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Find the best matching experts/organizations for this challenge:

CHALLENGE: ${challenge?.title}
DESCRIPTION: ${challenge?.description}
CATEGORY: ${challenge?.category}
SKILLS NEEDED: ${challenge?.skills_needed?.join(', ')}

Generate 5-7 ideal expert profiles that would be perfect matches for solving this challenge. For each:
1. Create a realistic expert profile (name, organization, role)
2. Their relevant expertise
3. Why they're a good match (match score 60-98)
4. How they could contribute
5. Suggested collaboration approach`,
        response_json_schema: {
          type: "object",
          properties: {
            matches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  organization: { type: "string" },
                  role: { type: "string" },
                  expertise: { type: "array", items: { type: "string" } },
                  match_score: { type: "number" },
                  match_reason: { type: "string" },
                  contribution_areas: { type: "array", items: { type: "string" } },
                  collaboration_approach: { type: "string" }
                }
              }
            },
            search_strategy: { type: "string" }
          }
        }
      });

      setMatchResults(result);
      setShowMatchDialog(true);
    } catch (error) {
      console.error("Error finding matches:", error);
    }
    setIsMatching(false);
  };

  const voteSolution = async (solution, increment) => {
    try {
      await base44.entities.ChallengeSolution.update(solution.id, {
        votes: (solution.votes || 0) + increment
      });
      queryClient.invalidateQueries({ queryKey: ['challengeSolutions', challenge?.id] });
    } catch (error) {
      console.error("Error voting:", error);
    }
  };

  const selectWinningSolution = async (solution) => {
    try {
      await base44.entities.ChallengeSolution.update(solution.id, {
        status: "selected",
        selected_date: new Date().toISOString()
      });
      
      await updateChallengeMutation.mutateAsync({
        id: challenge.id,
        data: {
          status: "solved",
          winning_solution: {
            solver_email: solution.submitter_email,
            solver_org: solution.submitter_org,
            solution_summary: solution.title,
            awarded_date: new Date().toISOString()
          }
        }
      });
    } catch (error) {
      console.error("Error selecting winner:", error);
    }
  };

  const isOwner = challenge?.posted_by_email === user?.email;
  const sortedSolutions = [...(solutions || [])].sort((a, b) => (b.votes || 0) - (a.votes || 0));

  return (
    <div className="space-y-4">
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <Dialog open={showSolutionDialog} onOpenChange={setShowSolutionDialog}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Lightbulb className="w-4 h-4 mr-2" />
              Submit Solution
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white">
            <DialogHeader>
              <DialogTitle>Submit Your Solution</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="p-3 bg-gray-800 rounded-lg">
                <p className="text-gray-400 text-sm">Challenge:</p>
                <p className="text-white font-medium">{challenge?.title}</p>
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Solution Title</label>
                <Input
                  value={solutionData.title}
                  onChange={(e) => setSolutionData({...solutionData, title: e.target.value})}
                  placeholder="Give your solution a clear title"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Description</label>
                <Textarea
                  value={solutionData.description}
                  onChange={(e) => setSolutionData({...solutionData, description: e.target.value})}
                  placeholder="Describe your solution..."
                  className="bg-gray-800 border-gray-700 text-white h-24"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Approach</label>
                <Textarea
                  value={solutionData.approach}
                  onChange={(e) => setSolutionData({...solutionData, approach: e.target.value})}
                  placeholder="How would you implement this solution?"
                  className="bg-gray-800 border-gray-700 text-white h-20"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Expected Outcomes</label>
                <Input
                  value={solutionData.expected_outcomes}
                  onChange={(e) => setSolutionData({...solutionData, expected_outcomes: e.target.value})}
                  placeholder="What results do you expect?"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <Button
                onClick={submitSolution}
                disabled={!solutionData.title || !solutionData.description || isSubmitting}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? (
                  <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Submitting...</>
                ) : (
                  <><Send className="w-4 h-4 mr-2" /> Submit Solution</>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Button
          variant="outline"
          onClick={findMatchingExperts}
          disabled={isMatching}
          className="border-purple-600 text-purple-400 hover:bg-purple-900/30"
        >
          {isMatching ? (
            <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Finding...</>
          ) : (
            <><Brain className="w-4 h-4 mr-2" /> Find Experts</>
          )}
        </Button>
      </div>

      {/* Solutions List */}
      {sortedSolutions.length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-400" />
              Submitted Solutions ({sortedSolutions.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[400px]">
              <div className="space-y-3">
                {sortedSolutions.map((solution, i) => (
                  <div key={solution.id} className={`p-4 bg-gray-800 rounded-lg ${solution.status === 'selected' ? 'border-2 border-yellow-500' : ''}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-3">
                        {i === 0 && solution.votes > 0 && (
                          <Award className="w-5 h-5 text-yellow-400" />
                        )}
                        <div>
                          <h4 className="text-white font-medium">{solution.title}</h4>
                          <p className="text-gray-400 text-xs">
                            by {solution.submitter_email} • {solution.submitter_org}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {solution.status === 'selected' && (
                          <Badge className="bg-yellow-600">Winner</Badge>
                        )}
                        {solution.ai_assessment?.overall_score && (
                          <Badge variant="outline" className="border-purple-600 text-purple-400">
                            AI: {solution.ai_assessment.overall_score}%
                          </Badge>
                        )}
                      </div>
                    </div>

                    <p className="text-gray-300 text-sm mb-3">{solution.description}</p>

                    {solution.ai_assessment && (
                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="text-center p-2 bg-gray-700 rounded">
                          <p className="text-xs text-gray-400">Relevance</p>
                          <p className="text-green-400 font-bold">{solution.ai_assessment.relevance_score}%</p>
                        </div>
                        <div className="text-center p-2 bg-gray-700 rounded">
                          <p className="text-xs text-gray-400">Feasibility</p>
                          <p className="text-blue-400 font-bold">{solution.ai_assessment.feasibility_score}%</p>
                        </div>
                        <div className="text-center p-2 bg-gray-700 rounded">
                          <p className="text-xs text-gray-400">Innovation</p>
                          <p className="text-purple-400 font-bold">{solution.ai_assessment.innovation_score}%</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => voteSolution(solution, 1)}
                          className="text-gray-400 hover:text-green-400"
                        >
                          <ThumbsUp className="w-4 h-4 mr-1" />
                          {solution.votes || 0}
                        </Button>
                      </div>
                      {isOwner && solution.status !== 'selected' && (
                        <Button
                          size="sm"
                          onClick={() => selectWinningSolution(solution)}
                          className="bg-yellow-600 hover:bg-yellow-700"
                        >
                          <Trophy className="w-3 h-3 mr-1" />
                          Select Winner
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Expert Match Results Dialog */}
      <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
        <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              Matching Experts Found
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4">
            {matchResults?.search_strategy && (
              <p className="text-gray-400 text-sm">{matchResults.search_strategy}</p>
            )}
            {matchResults?.matches?.map((match, i) => (
              <div key={i} className="p-4 bg-gray-800 rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback className="bg-purple-600">
                        {match.name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="text-white font-medium">{match.name}</h4>
                      <p className="text-gray-400 text-xs">{match.role} • {match.organization}</p>
                    </div>
                  </div>
                  <Badge className="bg-purple-600">{match.match_score}%</Badge>
                </div>
                <p className="text-gray-300 text-sm mb-2">{match.match_reason}</p>
                <div className="flex flex-wrap gap-1">
                  {match.expertise?.slice(0, 3).map((e, j) => (
                    <span key={j} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{e}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}