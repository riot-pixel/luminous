import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Activity, Heart, AlertTriangle, MessageCircle, RefreshCw,
  TrendingUp, Users, Sparkles, Target, Clock, Zap,
  ChevronRight, Copy, Send, Building2
} from "lucide-react";
import { differenceInDays, parseISO, format } from "date-fns";

const HEALTH_CONFIG = {
  thriving: { color: "bg-green-600", textColor: "text-green-400", icon: Heart, label: "Thriving" },
  active: { color: "bg-blue-600", textColor: "text-blue-400", icon: Activity, label: "Active" },
  cooling: { color: "bg-yellow-600", textColor: "text-yellow-400", icon: Clock, label: "Cooling" },
  dormant: { color: "bg-orange-600", textColor: "text-orange-400", icon: AlertTriangle, label: "Dormant" },
  at_risk: { color: "bg-red-600", textColor: "text-red-400", icon: AlertTriangle, label: "At Risk" }
};

export default function ConnectionHealthAnalyzer({ connections, projects, user }) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzedConnections, setAnalyzedConnections] = useState([]);
  const [selectedConnection, setSelectedConnection] = useState(null);

  const updateConnectionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EcosystemConnection.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
    },
  });

  const calculateBasicHealth = (connection) => {
    let score = 50;
    const now = new Date();
    
    // Recency of interaction (up to 30 points)
    if (connection.last_interaction) {
      const daysSince = differenceInDays(now, parseISO(connection.last_interaction));
      if (daysSince < 7) score += 30;
      else if (daysSince < 30) score += 20;
      else if (daysSince < 90) score += 10;
      else score -= 10;
    }

    // Project involvement (up to 20 points)
    const projectCount = connection.collaboration_projects?.length || 0;
    score += Math.min(projectCount * 5, 20);

    // Message count indicates engagement
    const messages = connection.messages_count || 0;
    if (messages > 20) score += 10;
    else if (messages > 5) score += 5;

    return Math.max(0, Math.min(100, score));
  };

  const getHealthStatus = (score) => {
    if (score >= 80) return "thriving";
    if (score >= 60) return "active";
    if (score >= 40) return "cooling";
    if (score >= 20) return "dormant";
    return "at_risk";
  };

  const analyzeConnections = async () => {
    setIsAnalyzing(true);
    const acceptedConnections = connections?.filter(c => c.status === 'accepted') || [];
    
    try {
      // First calculate basic scores
      const connectionsWithBasicScores = acceptedConnections.map(conn => ({
        ...conn,
        basicHealthScore: calculateBasicHealth(conn)
      }));

      // Use AI for deeper analysis
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze these professional connections and provide health insights, development opportunities, and conversation starters.

CONNECTIONS TO ANALYZE:
${connectionsWithBasicScores.slice(0, 15).map(c => `
CONNECTION: ${c.recipient_email}
- Organization: ${c.recipient_org || 'Unknown'}
- Type: ${c.connection_type}
- Match Score: ${c.ai_match_score || 'N/A'}
- Original Match Reason: ${c.ai_match_reason || 'N/A'}
- Shared Skills: ${c.matching_skills?.join(', ') || 'None recorded'}
- Projects Together: ${c.collaboration_projects?.length || 0}
- Messages Exchanged: ${c.messages_count || 0}
- Last Interaction: ${c.last_interaction || 'Unknown'}
- Basic Health Score: ${c.basicHealthScore}
`).join('\n---\n')}

SHARED PROJECTS CONTEXT:
${projects?.slice(0, 5).map(p => `- ${p.name}: ${p.members?.length || 0} members`).join('\n') || 'No projects'}

For EACH connection, provide:
1. A refined health score (0-100) considering communication patterns and collaboration quality
2. Development potential score (0-100) - how much this connection could grow
3. 2-3 specific opportunities to develop this connection further
4. 2-3 personalized conversation starters that reference their shared context (projects, skills, goals)
5. Recommended next steps to strengthen the connection
6. Goal alignment assessment`,
        response_json_schema: {
          type: "object",
          properties: {
            analyzed_connections: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  email: { type: "string" },
                  health_score: { type: "number" },
                  health_status: { type: "string" },
                  development_potential: { type: "number" },
                  development_opportunities: { type: "array", items: { type: "string" } },
                  conversation_starters: { type: "array", items: { type: "string" } },
                  recommended_next_steps: { type: "array", items: { type: "string" } },
                  goal_alignment: { type: "string" },
                  goal_alignment_score: { type: "number" },
                  risk_factors: { type: "array", items: { type: "string" } },
                  strengths: { type: "array", items: { type: "string" } }
                }
              }
            },
            overall_network_health: { type: "number" },
            priority_reconnections: { type: "array", items: { type: "string" } }
          }
        }
      });

      // Merge AI analysis with connection data
      const enrichedConnections = connectionsWithBasicScores.map(conn => {
        const analysis = result.analyzed_connections?.find(a => a.email === conn.recipient_email);
        return {
          ...conn,
          health_score: analysis?.health_score || conn.basicHealthScore,
          health_status: analysis?.health_status || getHealthStatus(conn.basicHealthScore),
          development_potential: analysis?.development_potential || 50,
          development_opportunities: analysis?.development_opportunities || [],
          ai_conversation_starters: analysis?.conversation_starters || [],
          recommended_next_steps: analysis?.recommended_next_steps || [],
          goal_alignment: analysis?.goal_alignment || 'Unknown',
          goal_alignment_score: analysis?.goal_alignment_score || 50,
          risk_factors: analysis?.risk_factors || [],
          strengths: analysis?.strengths || []
        };
      });

      // Update connections in database
      for (const conn of enrichedConnections) {
        await updateConnectionMutation.mutateAsync({
          id: conn.id,
          data: {
            health_score: conn.health_score,
            health_status: conn.health_status,
            development_potential: {
              score: conn.development_potential,
              opportunities: conn.development_opportunities,
              recommended_next_steps: conn.recommended_next_steps
            },
            ai_conversation_starters: conn.ai_conversation_starters,
            goal_alignment_score: conn.goal_alignment_score,
            shared_goals: [conn.goal_alignment],
            last_health_analysis: new Date().toISOString()
          }
        });
      }

      setAnalyzedConnections(enrichedConnections.sort((a, b) => (a.health_score || 0) - (b.health_score || 0)));
    } catch (error) {
      console.error("Error analyzing connections:", error);
    }
    setIsAnalyzing(false);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const healthStats = {
    thriving: analyzedConnections.filter(c => c.health_status === 'thriving').length,
    active: analyzedConnections.filter(c => c.health_status === 'active').length,
    cooling: analyzedConnections.filter(c => c.health_status === 'cooling').length,
    dormant: analyzedConnections.filter(c => c.health_status === 'dormant').length,
    at_risk: analyzedConnections.filter(c => c.health_status === 'at_risk').length,
  };

  const needsAttention = analyzedConnections.filter(c => 
    c.health_status === 'dormant' || c.health_status === 'at_risk' || c.health_status === 'cooling'
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-green-900/30 to-blue-900/30 border-green-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium flex items-center gap-2">
                <Activity className="w-5 h-5 text-green-400" />
                Connection Health Analyzer
              </h3>
              <p className="text-gray-400 text-sm mt-1">
                AI analyzes communication patterns and suggests ways to strengthen connections
              </p>
            </div>
            <Button
              onClick={analyzeConnections}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Heart className="w-4 h-4 mr-2" /> Analyze Health</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {analyzedConnections.length > 0 && (
        <>
          {/* Health Overview */}
          <div className="grid grid-cols-5 gap-3">
            {Object.entries(HEALTH_CONFIG).map(([status, config]) => {
              const Icon = config.icon;
              return (
                <Card key={status} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-4 text-center">
                    <Icon className={`w-5 h-5 mx-auto mb-2 ${config.textColor}`} />
                    <p className="text-2xl font-bold text-white">{healthStats[status] || 0}</p>
                    <p className="text-gray-400 text-xs">{config.label}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Needs Attention Alert */}
          {needsAttention.length > 0 && (
            <Card className="bg-orange-900/20 border-orange-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-orange-400 text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  {needsAttention.length} Connections Need Attention
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {needsAttention.slice(0, 5).map((conn, i) => (
                    <Badge 
                      key={i} 
                      className={`${HEALTH_CONFIG[conn.health_status]?.color} cursor-pointer`}
                      onClick={() => setSelectedConnection(conn)}
                    >
                      {conn.recipient_email?.split('@')[0]}
                    </Badge>
                  ))}
                  {needsAttention.length > 5 && (
                    <Badge variant="outline" className="border-orange-600 text-orange-400">
                      +{needsAttention.length - 5} more
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="all" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="all">All Connections</TabsTrigger>
              <TabsTrigger value="opportunities">Development Opportunities</TabsTrigger>
              <TabsTrigger value="dormant">Re-engage Dormant</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="space-y-3">
                {analyzedConnections.map((conn, i) => {
                  const healthConfig = HEALTH_CONFIG[conn.health_status] || HEALTH_CONFIG.active;
                  const HealthIcon = healthConfig.icon;
                  return (
                    <Card 
                      key={i} 
                      className="bg-gray-900 border-gray-800 hover:border-gray-700 cursor-pointer transition-colors"
                      onClick={() => setSelectedConnection(conn)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarFallback className="bg-purple-600">
                              {conn.recipient_email?.[0]?.toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-white font-medium truncate">{conn.recipient_email}</p>
                              <Badge className={healthConfig.color}>{healthConfig.label}</Badge>
                            </div>
                            <p className="text-gray-500 text-sm">{conn.recipient_org}</p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-2 mb-1">
                              <HealthIcon className={`w-4 h-4 ${healthConfig.textColor}`} />
                              <span className="text-white font-bold">{conn.health_score}%</span>
                            </div>
                            <Progress value={conn.health_score} className="h-1 w-20" />
                          </div>
                          <ChevronRight className="w-5 h-5 text-gray-600" />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="opportunities">
              <div className="space-y-4">
                {analyzedConnections
                  .filter(c => c.development_potential >= 60)
                  .sort((a, b) => b.development_potential - a.development_potential)
                  .map((conn, i) => (
                    <Card key={i} className="bg-gray-900 border-gray-800">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback className="bg-green-600">
                                {conn.recipient_email?.[0]?.toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-white font-medium">{conn.recipient_email}</p>
                              <p className="text-gray-500 text-sm">{conn.recipient_org}</p>
                            </div>
                          </div>
                          <Badge className="bg-green-600">
                            <TrendingUp className="w-3 h-3 mr-1" />
                            {conn.development_potential}% Potential
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <p className="text-gray-400 text-xs font-medium uppercase">Growth Opportunities</p>
                          {conn.development_opportunities?.map((opp, j) => (
                            <div key={j} className="flex items-start gap-2 p-2 bg-gray-800 rounded">
                              <Zap className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                              <p className="text-gray-300 text-sm">{opp}</p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="dormant">
              <div className="space-y-4">
                {analyzedConnections
                  .filter(c => c.health_status === 'dormant' || c.health_status === 'at_risk' || c.health_status === 'cooling')
                  .map((conn, i) => (
                    <Card key={i} className="bg-gray-900 border-gray-800">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback className="bg-orange-600">
                                {conn.recipient_email?.[0]?.toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-white font-medium">{conn.recipient_email}</p>
                              <p className="text-gray-500 text-sm">
                                Last interaction: {conn.last_interaction ? format(parseISO(conn.last_interaction), 'MMM d, yyyy') : 'Unknown'}
                              </p>
                            </div>
                          </div>
                          <Badge className={HEALTH_CONFIG[conn.health_status]?.color}>
                            {HEALTH_CONFIG[conn.health_status]?.label}
                          </Badge>
                        </div>
                        
                        <div className="space-y-3">
                          <p className="text-gray-400 text-xs font-medium uppercase">AI Conversation Starters</p>
                          {conn.ai_conversation_starters?.map((starter, j) => (
                            <div key={j} className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                              <p className="text-gray-300 text-sm mb-2">{starter}</p>
                              <div className="flex gap-2">
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="text-blue-400 hover:text-blue-300 h-7"
                                  onClick={(e) => { e.stopPropagation(); copyToClipboard(starter); }}
                                >
                                  <Copy className="w-3 h-3 mr-1" /> Copy
                                </Button>
                                <Button size="sm" variant="ghost" className="text-green-400 hover:text-green-300 h-7">
                                  <Send className="w-3 h-3 mr-1" /> Send
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Selected Connection Detail Modal */}
      {selectedConnection && (
        <Card className="bg-gray-900 border-purple-800 fixed bottom-6 right-6 w-96 shadow-xl z-50">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-purple-600 text-sm">
                    {selectedConnection.recipient_email?.[0]?.toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {selectedConnection.recipient_email?.split('@')[0]}
              </CardTitle>
              <Button size="sm" variant="ghost" onClick={() => setSelectedConnection(null)} className="text-gray-400 h-6 w-6 p-0">
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Health Score</span>
              <div className="flex items-center gap-2">
                <Progress value={selectedConnection.health_score} className="h-2 w-20" />
                <span className="text-white font-bold">{selectedConnection.health_score}%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-sm">Development Potential</span>
              <span className="text-green-400 font-bold">{selectedConnection.development_potential}%</span>
            </div>
            {selectedConnection.goal_alignment && (
              <div>
                <span className="text-gray-400 text-sm">Goal Alignment</span>
                <p className="text-gray-300 text-xs mt-1">{selectedConnection.goal_alignment}</p>
              </div>
            )}
            {selectedConnection.recommended_next_steps?.length > 0 && (
              <div>
                <span className="text-gray-400 text-sm">Next Steps</span>
                <ul className="mt-1 space-y-1">
                  {selectedConnection.recommended_next_steps.slice(0, 2).map((step, i) => (
                    <li key={i} className="text-xs text-purple-400 flex items-start gap-1">
                      <ChevronRight className="w-3 h-3 mt-0.5 flex-shrink-0" />
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}