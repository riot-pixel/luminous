import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  MessageSquare, Star, Send, RefreshCw, Sparkles, CheckCircle2,
  TrendingUp, Users, AlertCircle
} from "lucide-react";

export default function PartnerFeedbackSystem({ project, user }) {
  const queryClient = useQueryClient();
  const [showFeedbackDialog, setShowFeedbackDialog] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [surveyQuestions, setSurveyQuestions] = useState([]);
  const [responses, setResponses] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: existingFeedback } = useQuery({
    queryKey: ['partnerFeedback', project?.id],
    queryFn: () => base44.entities.PartnerFeedback.filter({ project_id: project?.id }),
    enabled: !!project?.id,
    initialData: [],
  });

  const createFeedbackMutation = useMutation({
    mutationFn: (data) => base44.entities.PartnerFeedback.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partnerFeedback'] });
      setShowFeedbackDialog(false);
      setSelectedPartner(null);
      setResponses({});
    },
  });

  const updateConnectionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EcosystemConnection.update(id, data),
  });

  const generateSurvey = async (partner) => {
    setSelectedPartner(partner);
    setIsGenerating(true);
    setShowFeedbackDialog(true);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a targeted feedback survey for a project collaboration partner.

PROJECT: ${project.name}
PROJECT TYPE: ${project.status}
PARTNER: ${partner.email} from ${partner.org}
PARTNER ROLE: ${partner.role || 'Contributor'}

Create 6-8 specific questions to assess:
1. Collaboration quality
2. Communication effectiveness
3. Reliability and commitment
4. Expertise demonstration
5. Overall contribution value

Include a mix of rating questions (1-5 scale) and open-ended questions.`,
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question_id: { type: "string" },
                  question: { type: "string" },
                  question_type: { type: "string" },
                  category: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSurveyQuestions(result.questions || []);
    } catch (error) {
      console.error("Error generating survey:", error);
    }
    setIsGenerating(false);
  };

  const submitFeedback = async () => {
    setIsSubmitting(true);
    try {
      // Calculate scores
      const ratingResponses = Object.entries(responses).filter(([k]) => k.startsWith('rating_'));
      const avgRating = ratingResponses.length > 0 
        ? ratingResponses.reduce((acc, [_, v]) => acc + v, 0) / ratingResponses.length 
        : 0;

      // AI analysis of feedback
      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this partner feedback and provide insights.

FEEDBACK RESPONSES:
${surveyQuestions.map(q => `Q: ${q.question}\nA: ${responses[q.question_id] || responses[`rating_${q.question_id}`] || 'No response'}`).join('\n\n')}

Provide:
1. Overall sentiment
2. Key strengths identified
3. Areas for improvement
4. Recommended actions for future collaborations
5. Suggested updates to partner profile`,
        response_json_schema: {
          type: "object",
          properties: {
            sentiment: { type: "string" },
            strengths: { type: "array", items: { type: "string" } },
            improvement_areas: { type: "array", items: { type: "string" } },
            recommended_actions: { type: "array", items: { type: "string" } },
            partner_profile_updates: { type: "array", items: { type: "string" } }
          }
        }
      });

      await createFeedbackMutation.mutateAsync({
        project_id: project.id,
        project_name: project.name,
        partner_email: selectedPartner.email,
        partner_org: selectedPartner.org,
        feedback_from: user.email,
        feedback_type: project.status === 'completed' ? 'project_completion' : 'milestone',
        survey_questions: surveyQuestions,
        responses: Object.entries(responses).map(([qId, value]) => ({
          question_id: qId.replace('rating_', ''),
          rating: typeof value === 'number' ? value : null,
          text_response: typeof value === 'string' ? value : null
        })),
        overall_rating: avgRating,
        collaboration_score: responses.rating_collaboration || avgRating,
        communication_score: responses.rating_communication || avgRating,
        reliability_score: responses.rating_reliability || avgRating,
        expertise_score: responses.rating_expertise || avgRating,
        ai_analysis: analysis,
        status: 'analyzed',
        submitted_date: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
    setIsSubmitting(false);
  };

  const partners = project?.members?.filter(m => m.email !== user?.email) || [];
  const feedbackGiven = existingFeedback?.map(f => f.partner_email) || [];

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-purple-400" />
            Partner Feedback
          </CardTitle>
        </CardHeader>
        <CardContent>
          {partners.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-4">No partners to provide feedback for</p>
          ) : (
            <div className="space-y-2">
              {partners.map((partner, i) => {
                const hasFeedback = feedbackGiven.includes(partner.email);
                return (
                  <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                    <div>
                      <p className="text-white text-sm">{partner.email}</p>
                      <p className="text-gray-500 text-xs">{partner.org} • {partner.role || 'Member'}</p>
                    </div>
                    {hasFeedback ? (
                      <Badge className="bg-green-600"><CheckCircle2 className="w-3 h-3 mr-1" />Submitted</Badge>
                    ) : (
                      <Button size="sm" onClick={() => generateSurvey(partner)} className="bg-purple-600 hover:bg-purple-700">
                        <Star className="w-3 h-3 mr-1" /> Give Feedback
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Feedback Dialog */}
      <Dialog open={showFeedbackDialog} onOpenChange={setShowFeedbackDialog}>
        <DialogContent className="max-w-lg bg-gray-900 border-gray-800 text-white max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Feedback for {selectedPartner?.email}</DialogTitle>
          </DialogHeader>
          
          {isGenerating ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 text-purple-400 animate-spin mx-auto mb-3" />
              <p className="text-gray-400">Generating personalized survey...</p>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              {surveyQuestions.map((q, i) => (
                <div key={q.question_id} className="space-y-2">
                  <p className="text-white text-sm">{i + 1}. {q.question}</p>
                  {q.question_type === 'rating' ? (
                    <div className="flex items-center gap-3">
                      <Slider
                        value={[responses[`rating_${q.question_id}`] || 3]}
                        onValueChange={([v]) => setResponses({ ...responses, [`rating_${q.question_id}`]: v })}
                        max={5}
                        min={1}
                        step={1}
                        className="flex-1"
                      />
                      <Badge className="bg-purple-600">{responses[`rating_${q.question_id}`] || 3}/5</Badge>
                    </div>
                  ) : (
                    <Textarea
                      value={responses[q.question_id] || ''}
                      onChange={(e) => setResponses({ ...responses, [q.question_id]: e.target.value })}
                      placeholder="Your response..."
                      className="bg-gray-800 border-gray-700 text-white h-20"
                    />
                  )}
                </div>
              ))}
              
              <Button onClick={submitFeedback} disabled={isSubmitting} className="w-full bg-green-600 hover:bg-green-700">
                {isSubmitting ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Submitting...</> : <><Send className="w-4 h-4 mr-2" />Submit Feedback</>}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}