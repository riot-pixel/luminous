import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Sparkles, TrendingUp, AlertTriangle, CheckCircle2, Target,
  Handshake, Globe, Building2, Zap, ArrowRight, Shield,
  BarChart3, Users, Lightbulb, RefreshCw, LineChart, Activity,
  Clock, DollarSign, Gauge
} from "lucide-react";
import { LineChart as RechartsLine, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

const HEALTH_COLORS = {
  thriving: "bg-green-600",
  stable: "bg-blue-600",
  at_risk: "bg-yellow-600",
  critical: "bg-red-600"
};

export default function EcosystemSynergyAnalyzer({ 
  connections, 
  projects, 
  challenges, 
  organization, 
  userSkills,
  orgAI 
}) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisStep, setAnalysisStep] = useState("");
  const [latestReport, setLatestReport] = useState(null);

  const createReportMutation = useMutation({
    mutationFn: (data) => base44.entities.EcosystemOpportunityReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ecosystemReports'] });
    },
  });

  const runSynergyAnalysis = async () => {
    setIsAnalyzing(true);
    setAnalysisProgress(0);

    try {
      // Step 1: Gather organizational capabilities
      setAnalysisStep("Analyzing organizational capabilities...");
      setAnalysisProgress(10);

      const orgCapabilities = userSkills?.map(s => s.skill_name).join(', ') || 'General business';
      const existingPartners = connections?.filter(c => c.status === 'accepted') || [];
      const activeProjects = projects?.filter(p => p.status === 'active') || [];

      // Step 2: Analyze existing partnerships
      setAnalysisStep("Evaluating existing partnerships...");
      setAnalysisProgress(30);

      const partnershipAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze these existing partnerships for synergy and risks:

EXISTING CONNECTIONS (${existingPartners.length}):
${existingPartners.slice(0, 15).map(c => `- ${c.recipient_email} (${c.recipient_org || 'Unknown Org'}) - Type: ${c.connection_type}, Match Score: ${c.ai_match_score || 'N/A'}`).join('\n') || 'No active partnerships'}

ACTIVE COLLABORATIVE PROJECTS (${activeProjects.length}):
${activeProjects.slice(0, 10).map(p => `- ${p.name}: ${p.members?.length || 0} members, ${p.organizations_involved?.length || 0} orgs`).join('\n') || 'No active projects'}

For each partnership, assess:
1. Current synergy level (0-100)
2. Risk factors
3. Opportunities for deeper collaboration
4. Health status (thriving/stable/at_risk/critical)`,
        response_json_schema: {
          type: "object",
          properties: {
            partnerships: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  partner_name: { type: "string" },
                  partner_org: { type: "string" },
                  synergy_score: { type: "number" },
                  synergy_assessment: { type: "string" },
                  risk_factors: { type: "array", items: { type: "string" } },
                  opportunities_for_collaboration: { type: "array", items: { type: "string" } },
                  health_status: { type: "string" }
                }
              }
            },
            overall_ecosystem_health: { type: "number" }
          }
        }
      });

      setAnalysisProgress(50);

      // Step 3: Identify potential new partners
      setAnalysisStep("Identifying strategic partner opportunities...");

      const potentialPartnersAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on organizational capabilities and market dynamics, identify potential strategic partners:

ORGANIZATION: ${organization?.name || 'Our Organization'}
INDUSTRY: ${organization?.industry || 'Technology/Business Services'}

OUR CAPABILITIES:
${orgCapabilities}

CURRENT CHALLENGES WE'RE FACING:
${challenges?.slice(0, 5).map(c => `- ${c.title} (${c.category})`).join('\n') || 'General growth challenges'}

STRATEGIC CONTEXT FROM ORG AI:
${orgAI?.unified_vision || 'Building sustainable growth through collaboration'}

Identify 5-8 types of strategic partners that would create mutual value. For each:
1. Partner type/industry
2. Why they're a good fit
3. Alignment score (0-100)
4. Partnership type (technology, distribution, R&D, etc.)
5. Potential value created`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            potential_partners: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  partner_name: { type: "string" },
                  partner_industry: { type: "string" },
                  strategic_fit_reasoning: { type: "string" },
                  alignment_score: { type: "number" },
                  partnership_type: { type: "string" },
                  potential_value: { type: "string" }
                }
              }
            },
            market_context: { type: "string" }
          }
        }
      });

      setAnalysisProgress(70);

      // Step 4: Generate non-zero-sum opportunities
      setAnalysisStep("Generating win-win growth opportunities...");

      const nonZeroSumAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate non-zero-sum growth opportunities for ecosystem partnerships:

EXISTING PARTNERS: ${existingPartners.length}
POTENTIAL NEW PARTNERS: ${potentialPartnersAnalysis.potential_partners?.length || 0}
OUR CAPABILITIES: ${orgCapabilities}

Create 5-7 detailed win-win opportunities where BOTH parties benefit significantly. Each should include:
1. The opportunity description
2. What we gain
3. What the partner gains
4. What the broader ecosystem gains
5. Implementation steps
6. Potential impact level`,
        response_json_schema: {
          type: "object",
          properties: {
            opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  opportunity: { type: "string" },
                  our_benefit: { type: "string" },
                  partner_benefit: { type: "string" },
                  ecosystem_benefit: { type: "string" },
                  implementation_steps: { type: "array", items: { type: "string" } },
                  potential_impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      setAnalysisProgress(75);

      // Step 5: Generate predictive analytics
      setAnalysisStep("Running predictive analytics...");

      const predictiveAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate predictive analytics for ecosystem partnerships:

POTENTIAL PARTNERS: ${potentialPartnersAnalysis.potential_partners?.length || 0}
OPPORTUNITIES: ${nonZeroSumAnalysis.opportunities?.length || 0}
ECOSYSTEM HEALTH: ${partnershipAnalysis.overall_ecosystem_health || 70}/100

Generate comprehensive predictive analytics including:

1. ROI FORECASTS (for top 5 opportunities/partnerships):
- Year 1, Year 3, Year 5 ROI projections
- Confidence level (low/medium/high)
- Key assumptions
- Break-even timeline

2. LONG-TERM IMPACT PROJECTIONS (5 areas):
- Impact area name
- Current state
- Projected state at 1yr, 3yr, 5yr
- Growth trajectory (exponential/linear/logarithmic/plateau)

3. SCENARIO MODELS (4 scenarios - optimistic, baseline, pessimistic, disruptive):
- Scenario name and type
- Key assumptions
- Synergy outcome
- Financial and strategic impact
- Probability (0-100)
- Trigger events

4. RISK MITIGATION STRATEGIES (for top 6 risks):
- Risk description
- Likelihood (low/medium/high)
- Impact severity (minor/moderate/severe/critical)
- Mitigation strategy
- Contingency plan
- Early warning indicators
- Responsible party

5. SENSITIVITY ANALYSIS:
- Key variables affecting outcomes
- Most sensitive factors
- Overall stability score (0-100)`,
        response_json_schema: {
          type: "object",
          properties: {
            roi_forecasts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  partner_or_opportunity: { type: "string" },
                  year_1_roi: { type: "string" },
                  year_3_roi: { type: "string" },
                  year_5_roi: { type: "string" },
                  confidence_level: { type: "string" },
                  key_assumptions: { type: "array", items: { type: "string" } },
                  break_even_timeline: { type: "string" }
                }
              }
            },
            long_term_impact_projections: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  impact_area: { type: "string" },
                  current_state: { type: "string" },
                  projected_state_1yr: { type: "string" },
                  projected_state_3yr: { type: "string" },
                  projected_state_5yr: { type: "string" },
                  growth_trajectory: { type: "string" }
                }
              }
            },
            scenario_models: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  scenario_name: { type: "string" },
                  scenario_type: { type: "string" },
                  assumptions: { type: "array", items: { type: "string" } },
                  synergy_outcome: { type: "string" },
                  financial_impact: { type: "string" },
                  strategic_impact: { type: "string" },
                  probability: { type: "number" },
                  triggers: { type: "array", items: { type: "string" } }
                }
              }
            },
            risk_mitigation_strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  likelihood: { type: "string" },
                  impact_severity: { type: "string" },
                  mitigation_strategy: { type: "string" },
                  contingency_plan: { type: "string" },
                  early_warning_indicators: { type: "array", items: { type: "string" } },
                  responsible_party: { type: "string" }
                }
              }
            },
            sensitivity_analysis: {
              type: "object",
              properties: {
                key_variables: { type: "array", items: { type: "string" } },
                most_sensitive_factors: { type: "array", items: { type: "string" } },
                stability_score: { type: "number" }
              }
            }
          }
        }
      });

      setAnalysisProgress(88);

      // Step 6: Generate actionable recommendations
      setAnalysisStep("Generating strategic recommendations...");

      const recommendationsAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on the ecosystem analysis, provide prioritized actionable recommendations:

ECOSYSTEM HEALTH: ${partnershipAnalysis.overall_ecosystem_health || 70}/100
EXISTING PARTNERSHIPS: ${existingPartners.length}
POTENTIAL NEW PARTNERS IDENTIFIED: ${potentialPartnersAnalysis.potential_partners?.length || 0}
NON-ZERO-SUM OPPORTUNITIES: ${nonZeroSumAnalysis.opportunities?.length || 0}

Generate 6-10 specific, actionable recommendations with:
1. The recommendation
2. Target audience (internal/external/both)
3. Expected outcome
4. Priority (low/medium/high/critical)
5. Timeline`,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  recommendation: { type: "string" },
                  target_audience: { type: "string" },
                  expected_outcome: { type: "string" },
                  priority: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            key_drivers: { type: "array", items: { type: "string" } },
            monitoring_metrics: { type: "array", items: { type: "string" } },
            confidence_score: { type: "number" }
          }
        }
      });

      setAnalysisProgress(95);

      // Step 7: Compile and save report
      setAnalysisStep("Compiling ecosystem opportunity report...");

      const report = {
        title: `Ecosystem Opportunity Report - ${new Date().toLocaleDateString()}`,
        description: `Comprehensive analysis of ${existingPartners.length} existing partnerships and ${potentialPartnersAnalysis.potential_partners?.length || 0} potential new strategic partners with ${nonZeroSumAnalysis.opportunities?.length || 0} non-zero-sum growth opportunities identified.`,
        generation_date: new Date().toISOString(),
        potential_partners_identified: potentialPartnersAnalysis.potential_partners || [],
        existing_partnership_analysis: partnershipAnalysis.partnerships || [],
        non_zero_sum_opportunities: nonZeroSumAnalysis.opportunities || [],
        predictive_analytics: {
          roi_forecasts: predictiveAnalysis.roi_forecasts || [],
          long_term_impact_projections: predictiveAnalysis.long_term_impact_projections || [],
          scenario_models: predictiveAnalysis.scenario_models || [],
          risk_mitigation_strategies: predictiveAnalysis.risk_mitigation_strategies || [],
          sensitivity_analysis: predictiveAnalysis.sensitivity_analysis || {}
        },
        actionable_recommendations: recommendationsAnalysis.recommendations || [],
        ecosystem_health_score: partnershipAnalysis.overall_ecosystem_health || 70,
        confidence_score: recommendationsAnalysis.confidence_score || 80,
        key_drivers: recommendationsAnalysis.key_drivers || [],
        monitoring_metrics: recommendationsAnalysis.monitoring_metrics || [],
        market_context: potentialPartnersAnalysis.market_context || ''
      };

      await createReportMutation.mutateAsync(report);
      setLatestReport(report);
      setAnalysisProgress(100);
      setAnalysisStep("Analysis complete!");

    } catch (error) {
      console.error("Error during synergy analysis:", error);
      setAnalysisStep("Error occurred. Please try again.");
    }

    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisProgress(0);
      setAnalysisStep("");
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Analysis Trigger */}
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                AI Ecosystem Synergy Analyzer
              </h3>
              <p className="text-gray-400 text-sm mt-1">
                Identify strategic partners, analyze existing partnerships, and discover non-zero-sum growth opportunities
              </p>
            </div>
            <Button
              onClick={runSynergyAnalysis}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Zap className="w-4 h-4 mr-2" /> Run Synergy Analysis</>
              )}
            </Button>
          </div>

          {isAnalyzing && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-300">{analysisStep}</span>
                <span className="text-sm text-purple-400">{analysisProgress}%</span>
              </div>
              <Progress value={analysisProgress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Latest Report Display */}
      {latestReport && (
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="partners">New Partners</TabsTrigger>
            <TabsTrigger value="existing">Existing Analysis</TabsTrigger>
            <TabsTrigger value="opportunities">Win-Win Opportunities</TabsTrigger>
            <TabsTrigger value="predictive">
              <LineChart className="w-3 h-3 mr-1" />
              Predictive Analytics
            </TabsTrigger>
            <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
            <TabsTrigger value="risks">Risk Mitigation</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-4 text-center">
                  <BarChart3 className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{latestReport.ecosystem_health_score}%</p>
                  <p className="text-gray-400 text-sm">Ecosystem Health</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-4 text-center">
                  <Building2 className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{latestReport.potential_partners_identified?.length || 0}</p>
                  <p className="text-gray-400 text-sm">Potential Partners</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-4 text-center">
                  <Handshake className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{latestReport.non_zero_sum_opportunities?.length || 0}</p>
                  <p className="text-gray-400 text-sm">Win-Win Opportunities</p>
                </CardContent>
              </Card>
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-4 text-center">
                  <Shield className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{latestReport.confidence_score}%</p>
                  <p className="text-gray-400 text-sm">AI Confidence</p>
                </CardContent>
              </Card>
            </div>

            {latestReport.market_context && (
              <Card className="bg-gray-900 border-gray-800 mt-4">
                <CardHeader>
                  <CardTitle className="text-white text-lg flex items-center gap-2">
                    <Globe className="w-5 h-5 text-blue-400" />
                    Market Context
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">{latestReport.market_context}</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="partners">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Potential Strategic Partners</CardTitle>
                <CardDescription className="text-gray-400">AI-identified partnership opportunities based on capabilities and market dynamics</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <div className="space-y-4">
                    {latestReport.potential_partners_identified?.map((partner, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="text-white font-medium">{partner.partner_name}</h4>
                            <p className="text-gray-400 text-sm">{partner.partner_industry}</p>
                          </div>
                          <Badge className="bg-blue-600">{partner.alignment_score}% Fit</Badge>
                        </div>
                        <p className="text-gray-300 text-sm mb-2">{partner.strategic_fit_reasoning}</p>
                        <div className="flex items-center gap-4 text-xs">
                          <span className="text-purple-400">Type: {partner.partnership_type}</span>
                          <span className="text-green-400">Value: {partner.potential_value}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="existing">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Existing Partnership Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <div className="space-y-4">
                    {latestReport.existing_partnership_analysis?.map((partner, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="text-white font-medium">{partner.partner_name}</h4>
                            <p className="text-gray-400 text-sm">{partner.partner_org}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={HEALTH_COLORS[partner.health_status] || 'bg-gray-600'}>
                              {partner.health_status}
                            </Badge>
                            <Badge variant="outline" className="border-purple-600 text-purple-400">
                              {partner.synergy_score}% Synergy
                            </Badge>
                          </div>
                        </div>
                        <p className="text-gray-300 text-sm mb-3">{partner.synergy_assessment}</p>
                        
                        {partner.risk_factors?.length > 0 && (
                          <div className="mb-2">
                            <p className="text-red-400 text-xs font-medium mb-1">Risk Factors:</p>
                            <div className="flex flex-wrap gap-1">
                              {partner.risk_factors.map((risk, j) => (
                                <span key={j} className="text-xs px-2 py-0.5 bg-red-900/30 text-red-300 rounded">{risk}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {partner.opportunities_for_collaboration?.length > 0 && (
                          <div>
                            <p className="text-green-400 text-xs font-medium mb-1">Collaboration Opportunities:</p>
                            <div className="flex flex-wrap gap-1">
                              {partner.opportunities_for_collaboration.map((opp, j) => (
                                <span key={j} className="text-xs px-2 py-0.5 bg-green-900/30 text-green-300 rounded">{opp}</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="opportunities">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  Non-Zero-Sum Growth Opportunities
                </CardTitle>
                <CardDescription className="text-gray-400">Win-win scenarios where all parties benefit</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[500px]">
                  <div className="space-y-4">
                    {latestReport.non_zero_sum_opportunities?.map((opp, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-green-600">
                        <h4 className="text-white font-medium mb-3">{opp.opportunity}</h4>
                        
                        <div className="grid md:grid-cols-3 gap-3 mb-3">
                          <div className="p-2 bg-blue-900/30 rounded">
                            <p className="text-blue-300 text-xs font-medium mb-1">Our Benefit</p>
                            <p className="text-gray-300 text-sm">{opp.our_benefit}</p>
                          </div>
                          <div className="p-2 bg-purple-900/30 rounded">
                            <p className="text-purple-300 text-xs font-medium mb-1">Partner Benefit</p>
                            <p className="text-gray-300 text-sm">{opp.partner_benefit}</p>
                          </div>
                          <div className="p-2 bg-green-900/30 rounded">
                            <p className="text-green-300 text-xs font-medium mb-1">Ecosystem Benefit</p>
                            <p className="text-gray-300 text-sm">{opp.ecosystem_benefit}</p>
                          </div>
                        </div>

                        {opp.implementation_steps?.length > 0 && (
                          <div className="mb-2">
                            <p className="text-gray-400 text-xs font-medium mb-1">Implementation:</p>
                            <ol className="text-sm text-gray-300 space-y-1">
                              {opp.implementation_steps.map((step, j) => (
                                <li key={j} className="flex items-start gap-2">
                                  <ArrowRight className="w-3 h-3 mt-1 text-purple-400 flex-shrink-0" />
                                  {step}
                                </li>
                              ))}
                            </ol>
                          </div>
                        )}

                        <Badge className="bg-green-600 mt-2">{opp.potential_impact}</Badge>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Predictive Analytics Tab */}
          <TabsContent value="predictive">
            <div className="space-y-6">
              {/* ROI Forecasts */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-400" />
                    ROI Forecasts
                  </CardTitle>
                  <CardDescription className="text-gray-400">Projected return on investment for partnerships</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestReport.predictive_analytics?.roi_forecasts?.map((forecast, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="text-white font-medium">{forecast.partner_or_opportunity}</h4>
                          <Badge className={
                            forecast.confidence_level === 'high' ? 'bg-green-600' :
                            forecast.confidence_level === 'medium' ? 'bg-yellow-600' : 'bg-red-600'
                          }>{forecast.confidence_level} confidence</Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 mb-3">
                          <div className="text-center p-2 bg-gray-700 rounded">
                            <p className="text-gray-400 text-xs">Year 1</p>
                            <p className="text-green-400 font-bold">{forecast.year_1_roi}</p>
                          </div>
                          <div className="text-center p-2 bg-gray-700 rounded">
                            <p className="text-gray-400 text-xs">Year 3</p>
                            <p className="text-green-400 font-bold">{forecast.year_3_roi}</p>
                          </div>
                          <div className="text-center p-2 bg-gray-700 rounded">
                            <p className="text-gray-400 text-xs">Year 5</p>
                            <p className="text-green-400 font-bold">{forecast.year_5_roi}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
                          <Clock className="w-3 h-3" />
                          Break-even: {forecast.break_even_timeline}
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {forecast.key_assumptions?.map((a, j) => (
                            <span key={j} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{a}</span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Long-term Impact Projections */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    Long-term Impact Projections
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestReport.predictive_analytics?.long_term_impact_projections?.map((proj, i) => {
                      const chartData = [
                        { year: 'Now', value: 20 },
                        { year: '1Y', value: proj.growth_trajectory === 'exponential' ? 40 : 35 },
                        { year: '3Y', value: proj.growth_trajectory === 'exponential' ? 70 : proj.growth_trajectory === 'plateau' ? 55 : 60 },
                        { year: '5Y', value: proj.growth_trajectory === 'exponential' ? 95 : proj.growth_trajectory === 'plateau' ? 60 : 80 }
                      ];
                      return (
                        <div key={i} className="p-4 bg-gray-800 rounded-lg">
                          <div className="flex items-start justify-between mb-3">
                            <h4 className="text-white font-medium">{proj.impact_area}</h4>
                            <Badge variant="outline" className={
                              proj.growth_trajectory === 'exponential' ? 'border-green-600 text-green-400' :
                              proj.growth_trajectory === 'linear' ? 'border-blue-600 text-blue-400' :
                              proj.growth_trajectory === 'logarithmic' ? 'border-yellow-600 text-yellow-400' :
                              'border-gray-600 text-gray-400'
                            }>{proj.growth_trajectory}</Badge>
                          </div>
                          <div className="h-24 mb-3">
                            <ResponsiveContainer width="100%" height="100%">
                              <AreaChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                <XAxis dataKey="year" stroke="#666" tick={{ fontSize: 10 }} />
                                <YAxis stroke="#666" tick={{ fontSize: 10 }} />
                                <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                                <Area type="monotone" dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                              </AreaChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="grid grid-cols-4 gap-2 text-xs">
                            <div className="p-2 bg-gray-700 rounded">
                              <p className="text-gray-500">Current</p>
                              <p className="text-gray-300">{proj.current_state}</p>
                            </div>
                            <div className="p-2 bg-gray-700 rounded">
                              <p className="text-gray-500">1 Year</p>
                              <p className="text-blue-300">{proj.projected_state_1yr}</p>
                            </div>
                            <div className="p-2 bg-gray-700 rounded">
                              <p className="text-gray-500">3 Years</p>
                              <p className="text-purple-300">{proj.projected_state_3yr}</p>
                            </div>
                            <div className="p-2 bg-gray-700 rounded">
                              <p className="text-gray-500">5 Years</p>
                              <p className="text-green-300">{proj.projected_state_5yr}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Sensitivity Analysis */}
              {latestReport.predictive_analytics?.sensitivity_analysis && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Gauge className="w-5 h-5 text-cyan-400" />
                      Sensitivity Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-sm mb-2">Stability Score</p>
                        <p className="text-3xl font-bold text-cyan-400">
                          {latestReport.predictive_analytics.sensitivity_analysis.stability_score || 0}%
                        </p>
                      </div>
                      <div className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-sm mb-2">Key Variables</p>
                        <div className="flex flex-wrap gap-1">
                          {latestReport.predictive_analytics.sensitivity_analysis.key_variables?.map((v, i) => (
                            <Badge key={i} variant="outline" className="text-xs border-blue-600 text-blue-400">{v}</Badge>
                          ))}
                        </div>
                      </div>
                      <div className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-sm mb-2">Most Sensitive Factors</p>
                        <div className="flex flex-wrap gap-1">
                          {latestReport.predictive_analytics.sensitivity_analysis.most_sensitive_factors?.map((f, i) => (
                            <Badge key={i} variant="outline" className="text-xs border-orange-600 text-orange-400">{f}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Scenario Models Tab */}
          <TabsContent value="scenarios">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-purple-400" />
                  Scenario Models
                </CardTitle>
                <CardDescription className="text-gray-400">Synergy outcomes under different scenarios</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {latestReport.predictive_analytics?.scenario_models?.map((scenario, i) => {
                    const scenarioColors = {
                      optimistic: 'border-green-600 bg-green-900/20',
                      baseline: 'border-blue-600 bg-blue-900/20',
                      pessimistic: 'border-yellow-600 bg-yellow-900/20',
                      disruptive: 'border-red-600 bg-red-900/20'
                    };
                    const badgeColors = {
                      optimistic: 'bg-green-600',
                      baseline: 'bg-blue-600',
                      pessimistic: 'bg-yellow-600',
                      disruptive: 'bg-red-600'
                    };
                    return (
                      <div key={i} className={`p-4 rounded-lg border ${scenarioColors[scenario.scenario_type] || 'border-gray-700'}`}>
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <Badge className={badgeColors[scenario.scenario_type] || 'bg-gray-600'}>
                              {scenario.scenario_type}
                            </Badge>
                            <h4 className="text-white font-medium mt-2">{scenario.scenario_name}</h4>
                          </div>
                          <div className="text-right">
                            <p className="text-gray-400 text-xs">Probability</p>
                            <p className="text-white font-bold">{scenario.probability}%</p>
                          </div>
                        </div>
                        
                        <div className="space-y-2 mb-3">
                          <div>
                            <p className="text-gray-500 text-xs">Synergy Outcome</p>
                            <p className="text-gray-300 text-sm">{scenario.synergy_outcome}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <p className="text-gray-500 text-xs">Financial Impact</p>
                              <p className="text-green-400 text-sm">{scenario.financial_impact}</p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Strategic Impact</p>
                              <p className="text-blue-400 text-sm">{scenario.strategic_impact}</p>
                            </div>
                          </div>
                        </div>

                        {scenario.assumptions?.length > 0 && (
                          <div className="mb-2">
                            <p className="text-gray-500 text-xs mb-1">Assumptions:</p>
                            <ul className="text-xs text-gray-400 space-y-0.5">
                              {scenario.assumptions.slice(0, 3).map((a, j) => (
                                <li key={j}>• {a}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {scenario.triggers?.length > 0 && (
                          <div>
                            <p className="text-gray-500 text-xs mb-1">Trigger Events:</p>
                            <div className="flex flex-wrap gap-1">
                              {scenario.triggers.map((t, j) => (
                                <span key={j} className="text-xs px-2 py-0.5 bg-gray-700 text-gray-300 rounded">{t}</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Risk Mitigation Tab */}
          <TabsContent value="risks">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5 text-red-400" />
                  Risk Mitigation Strategies
                </CardTitle>
                <CardDescription className="text-gray-400">Identified risks and mitigation plans</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[500px]">
                  <div className="space-y-4">
                    {latestReport.predictive_analytics?.risk_mitigation_strategies?.map((risk, i) => {
                      const likelihoodColors = { low: 'bg-green-600', medium: 'bg-yellow-600', high: 'bg-red-600' };
                      const severityColors = { minor: 'text-green-400', moderate: 'text-yellow-400', severe: 'text-orange-400', critical: 'text-red-400' };
                      return (
                        <div key={i} className="p-4 bg-gray-800 rounded-lg border-l-4 border-red-600">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <AlertTriangle className={`w-4 h-4 ${severityColors[risk.impact_severity] || 'text-gray-400'}`} />
                                <h4 className="text-white font-medium">{risk.risk}</h4>
                              </div>
                              <div className="flex gap-2">
                                <Badge className={likelihoodColors[risk.likelihood] || 'bg-gray-600'}>
                                  {risk.likelihood} likelihood
                                </Badge>
                                <Badge variant="outline" className={`border-gray-600 ${severityColors[risk.impact_severity]}`}>
                                  {risk.impact_severity} impact
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-gray-500 text-xs">Responsible</p>
                              <p className="text-gray-300 text-sm">{risk.responsible_party}</p>
                            </div>
                          </div>

                          <div className="grid md:grid-cols-2 gap-3 mb-3">
                            <div className="p-2 bg-blue-900/30 rounded">
                              <p className="text-blue-300 text-xs font-medium mb-1">Mitigation Strategy</p>
                              <p className="text-gray-300 text-sm">{risk.mitigation_strategy}</p>
                            </div>
                            <div className="p-2 bg-orange-900/30 rounded">
                              <p className="text-orange-300 text-xs font-medium mb-1">Contingency Plan</p>
                              <p className="text-gray-300 text-sm">{risk.contingency_plan}</p>
                            </div>
                          </div>

                          {risk.early_warning_indicators?.length > 0 && (
                            <div>
                              <p className="text-gray-500 text-xs mb-1">Early Warning Indicators:</p>
                              <div className="flex flex-wrap gap-1">
                                {risk.early_warning_indicators.map((indicator, j) => (
                                  <span key={j} className="text-xs px-2 py-0.5 bg-yellow-900/30 text-yellow-300 rounded flex items-center gap-1">
                                    <AlertTriangle className="w-2 h-2" />
                                    {indicator}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Strategic Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3">
                    {latestReport.actionable_recommendations?.map((rec, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start gap-3">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            rec.priority === 'critical' ? 'bg-red-500' :
                            rec.priority === 'high' ? 'bg-orange-500' :
                            rec.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                          }`} />
                          <div className="flex-1">
                            <p className="text-white">{rec.recommendation}</p>
                            <div className="flex items-center gap-3 mt-2 text-xs">
                              <Badge variant="outline" className="border-gray-600 text-gray-400">
                                {rec.target_audience}
                              </Badge>
                              <span className="text-gray-500">{rec.timeline}</span>
                            </div>
                            <p className="text-green-400 text-xs mt-1">→ {rec.expected_outcome}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {latestReport.monitoring_metrics?.length > 0 && (
                  <div className="mt-4 p-4 bg-gray-800 rounded-lg">
                    <p className="text-gray-400 text-sm font-medium mb-2">Monitoring Metrics</p>
                    <div className="flex flex-wrap gap-2">
                      {latestReport.monitoring_metrics.map((metric, i) => (
                        <Badge key={i} variant="outline" className="border-cyan-600 text-cyan-400">{metric}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}