import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import {
  RefreshCw, Upload, Download, CheckCircle2, AlertTriangle, 
  Building2, Users, FileText, Link2, Settings, Zap, 
  ArrowLeftRight, Database, Cloud, Shield, ExternalLink, Key
} from "lucide-react";

export default function CRMSyncManager({ connections, outreaches, reports }) {
  const queryClient = useQueryClient();
  const [syncStatus, setSyncStatus] = useState({});
  const [isSyncing, setIsSyncing] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [importResults, setImportResults] = useState(null);
  const [syncProgress, setSyncProgress] = useState(0);
  const [lastSyncTime, setLastSyncTime] = useState(null);
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(false);

  // Bidirectional sync status tracking
  const [bidirectionalStatus, setBidirectionalStatus] = useState({
    salesforce: { connected: false, lastSync: null, recordsSynced: 0 },
    hubspot: { connected: false, lastSync: null, recordsSynced: 0 }
  });

  // Prepare data for CRM export
  const prepareContactsForExport = () => {
    const contacts = [];
    
    // From connections
    connections?.forEach(conn => {
      contacts.push({
        email: conn.recipient_email,
        organization: conn.recipient_org,
        connection_type: conn.connection_type,
        status: conn.status,
        match_score: conn.ai_match_score,
        created_date: conn.created_date,
        source: "EcosystemConnection",
        source_id: conn.id
      });
    });

    // From outreaches
    outreaches?.forEach(out => {
      if (!contacts.find(c => c.email === out.partner_email)) {
        contacts.push({
          email: out.partner_email,
          organization: out.partner_industry,
          full_name: out.partner_name,
          outreach_status: out.outreach_status,
          strategic_fit_score: out.strategic_fit_score,
          last_contact: out.last_contact_date,
          source: "PartnerOutreach",
          source_id: out.id
        });
      }
    });

    return contacts;
  };

  const exportToCSV = () => {
    const contacts = prepareContactsForExport();
    const headers = ["email", "full_name", "organization", "status", "match_score", "source", "created_date"];
    const csvContent = [
      headers.join(","),
      ...contacts.map(c => headers.map(h => `"${c[h] || ''}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `crm_export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setCsvFile(file);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target.result;
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        
        const records = [];
        for (let i = 1; i < lines.length; i++) {
          if (!lines[i].trim()) continue;
          const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
          const record = {};
          headers.forEach((h, idx) => {
            record[h] = values[idx];
          });
          records.push(record);
        }

        setImportResults({
          total: records.length,
          preview: records.slice(0, 5),
          headers
        });
      } catch (error) {
        console.error("Error parsing CSV:", error);
      }
    };
    reader.readAsText(file);
  };

  const importFromCRM = async () => {
    if (!importResults) return;
    setIsSyncing(true);
    
    try {
      // Process imported records
      const results = { created: 0, updated: 0, errors: 0 };
      
      for (const record of importResults.preview) {
        try {
          // Check if connection exists
          const existing = connections?.find(c => c.recipient_email === record.email);
          
          if (existing) {
            // Update existing
            if (record.crm_id) {
              await base44.entities.EcosystemConnection.update(existing.id, {
                crm_id: record.crm_id,
                crm_status: record.status,
                last_crm_sync: new Date().toISOString()
              });
              results.updated++;
            }
          } else if (record.email) {
            // Create new connection from CRM
            await base44.entities.EcosystemConnection.create({
              requester_email: "crm_import@system",
              recipient_email: record.email,
              recipient_org: record.organization || record.company,
              connection_type: "collaboration",
              status: "pending",
              crm_id: record.crm_id || record.id,
              crm_source: "import"
            });
            results.created++;
          }
        } catch (err) {
          results.errors++;
        }
      }

      setSyncStatus({ ...syncStatus, lastImport: new Date().toISOString(), results });
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
    } catch (error) {
      console.error("Import error:", error);
    }
    setIsSyncing(false);
  };

  // Bidirectional sync function
  const runBidirectionalSync = async (crm) => {
    setIsSyncing(true);
    setSyncProgress(0);
    
    try {
      // Step 1: Export local data (outbound sync)
      setSyncProgress(20);
      const exportData = prepareContactsForExport();
      
      // Step 2: Prepare connection data for sync
      setSyncProgress(40);
      const connectionUpdates = connections?.filter(c => c.status === 'accepted').map(c => ({
        email: c.recipient_email,
        organization: c.recipient_org,
        status: c.status,
        health_score: c.health_score,
        connection_type: c.connection_type,
        last_interaction: c.last_interaction,
        source_id: c.id
      })) || [];

      // Step 3: Prepare outreach data
      setSyncProgress(60);
      const outreachUpdates = outreaches?.map(o => ({
        email: o.partner_email,
        name: o.partner_name,
        status: o.outreach_status,
        deal_stage: o.crm_deal_stage || o.outreach_status,
        last_contact: o.last_contact_date,
        source_id: o.id
      })) || [];

      // Step 4: Prepare report insights
      setSyncProgress(80);
      const reportInsights = reports?.slice(0, 5).map(r => ({
        title: r.title,
        health_score: r.ecosystem_health_score,
        date: r.generation_date,
        recommendations_count: r.actionable_recommendations?.length || 0
      })) || [];

      setSyncProgress(100);
      
      // Update sync status
      setBidirectionalStatus(prev => ({
        ...prev,
        [crm]: {
          connected: true,
          lastSync: new Date().toISOString(),
          recordsSynced: connectionUpdates.length + outreachUpdates.length
        }
      }));

      setLastSyncTime(new Date().toISOString());
      setSyncStatus({
        ...syncStatus,
        [`${crm}_lastSync`]: new Date().toISOString(),
        [`${crm}_records`]: connectionUpdates.length + outreachUpdates.length
      });

    } catch (error) {
      console.error(`Error syncing with ${crm}:`, error);
    }
    
    setIsSyncing(false);
    setSyncProgress(0);
  };

  const syncStats = {
    totalContacts: prepareContactsForExport().length,
    connections: connections?.length || 0,
    outreaches: outreaches?.length || 0,
    reports: reports?.length || 0
  };

  return (
    <div className="space-y-6">
      {/* OAuth Integration Status */}
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Key className="w-4 h-4 text-blue-400" />
            CRM OAuth Integration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {/* Salesforce */}
            <div className="p-4 bg-gray-800 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Cloud className="w-5 h-5 text-blue-400" />
                  <span className="text-white font-medium">Salesforce</span>
                </div>
                <Badge className={bidirectionalStatus.salesforce.connected ? "bg-green-600" : "bg-gray-600"}>
                  {bidirectionalStatus.salesforce.connected ? "Connected" : "Not Connected"}
                </Badge>
              </div>
              <p className="text-gray-400 text-xs mb-3">
                {bidirectionalStatus.salesforce.lastSync 
                  ? `Last sync: ${new Date(bidirectionalStatus.salesforce.lastSync).toLocaleString()}`
                  : "Enable backend functions for OAuth"}
              </p>
              <Button 
                onClick={() => runBidirectionalSync('salesforce')} 
                disabled={isSyncing}
                size="sm" 
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isSyncing ? <RefreshCw className="w-3 h-3 mr-1 animate-spin" /> : <ArrowLeftRight className="w-3 h-3 mr-1" />}
                Sync Now
              </Button>
            </div>

            {/* HubSpot */}
            <div className="p-4 bg-gray-800 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-orange-400" />
                  <span className="text-white font-medium">HubSpot</span>
                </div>
                <Badge className={bidirectionalStatus.hubspot.connected ? "bg-green-600" : "bg-gray-600"}>
                  {bidirectionalStatus.hubspot.connected ? "Connected" : "Not Connected"}
                </Badge>
              </div>
              <p className="text-gray-400 text-xs mb-3">
                {bidirectionalStatus.hubspot.lastSync 
                  ? `Last sync: ${new Date(bidirectionalStatus.hubspot.lastSync).toLocaleString()}`
                  : "Enable backend functions for OAuth"}
              </p>
              <Button 
                onClick={() => runBidirectionalSync('hubspot')} 
                disabled={isSyncing}
                size="sm" 
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                {isSyncing ? <RefreshCw className="w-3 h-3 mr-1 animate-spin" /> : <ArrowLeftRight className="w-3 h-3 mr-1" />}
                Sync Now
              </Button>
            </div>
          </div>

          {isSyncing && (
            <div className="mt-4">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-400">Syncing data...</span>
                <span className="text-blue-400">{syncProgress}%</span>
              </div>
              <Progress value={syncProgress} className="h-1" />
            </div>
          )}

          <Alert className="mt-4 bg-yellow-900/20 border-yellow-800">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <AlertDescription className="text-gray-300 text-xs">
              <strong className="text-yellow-400">OAuth Required:</strong> Full bidirectional sync with real-time updates requires backend functions. 
              Enable them in Settings to connect via OAuth and sync contacts, outreach status, and partnership progress automatically.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Auto-Sync Toggle */}
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-white font-medium">Auto-Sync</h4>
              <p className="text-gray-400 text-xs">Automatically sync data every hour</p>
            </div>
            <Switch checked={autoSyncEnabled} onCheckedChange={setAutoSyncEnabled} />
          </div>
        </CardContent>
      </Card>

      {/* Sync Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{syncStats.totalContacts}</p>
            <p className="text-gray-400 text-xs">Total Contacts</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Link2 className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{syncStats.connections}</p>
            <p className="text-gray-400 text-xs">Connections</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <FileText className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{syncStats.outreaches}</p>
            <p className="text-gray-400 text-xs">Outreaches</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Database className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{syncStats.reports}</p>
            <p className="text-gray-400 text-xs">Reports</p>
          </CardContent>
        </Card>
      </div>

      {/* Sync Actions */}
      <Tabs defaultValue="export" className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="export">
            <Upload className="w-4 h-4 mr-1" />
            Export to CRM
          </TabsTrigger>
          <TabsTrigger value="import">
            <Download className="w-4 h-4 mr-1" />
            Import from CRM
          </TabsTrigger>
          <TabsTrigger value="mapping">
            <ArrowLeftRight className="w-4 h-4 mr-1" />
            Field Mapping
          </TabsTrigger>
        </TabsList>

        <TabsContent value="export">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white text-sm">Export Data to CRM</CardTitle>
              <CardDescription className="text-gray-400">
                Download your partnership data as CSV for import into Salesforce or HubSpot
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-2">Connections</h4>
                  <p className="text-gray-400 text-sm mb-3">Export all partner connections with status and scores</p>
                  <Badge className="bg-blue-600">{connections?.length || 0} records</Badge>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-2">Outreach Pipeline</h4>
                  <p className="text-gray-400 text-sm mb-3">Export outreach status and engagement metrics</p>
                  <Badge className="bg-purple-600">{outreaches?.length || 0} records</Badge>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-2">Opportunity Reports</h4>
                  <p className="text-gray-400 text-sm mb-3">Export AI-generated partnership insights</p>
                  <Badge className="bg-green-600">{reports?.length || 0} records</Badge>
                </div>
              </div>

              <Button onClick={exportToCSV} className="bg-blue-600 hover:bg-blue-700">
                <Download className="w-4 h-4 mr-2" />
                Export All to CSV
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white text-sm">Import from CRM</CardTitle>
              <CardDescription className="text-gray-400">
                Upload CSV exports from Salesforce or HubSpot to sync contacts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center">
                <Upload className="w-10 h-10 text-gray-500 mx-auto mb-3" />
                <p className="text-gray-400 mb-3">Drop CSV file here or click to upload</p>
                <Input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="max-w-xs mx-auto bg-gray-800 border-gray-700"
                />
              </div>

              {importResults && (
                <div className="p-4 bg-gray-800 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-white font-medium">Preview ({importResults.total} records)</h4>
                    <Badge className="bg-green-600">Ready to import</Badge>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-700">
                          {importResults.headers.slice(0, 5).map(h => (
                            <th key={h} className="text-left py-2 text-gray-400">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {importResults.preview.map((row, i) => (
                          <tr key={i} className="border-b border-gray-700">
                            {importResults.headers.slice(0, 5).map(h => (
                              <td key={h} className="py-2 text-gray-300">{row[h] || '-'}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Button 
                    onClick={importFromCRM} 
                    disabled={isSyncing}
                    className="mt-4 bg-green-600 hover:bg-green-700"
                  >
                    {isSyncing ? (
                      <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Importing...</>
                    ) : (
                      <><CheckCircle2 className="w-4 h-4 mr-2" /> Import Records</>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mapping">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white text-sm">Field Mapping Configuration</CardTitle>
              <CardDescription className="text-gray-400">
                Map your CRM fields to partnership entities for consistent data sync
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-400" />
                    Salesforce Mapping
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">Contact.Email</span>
                      <span className="text-white">→ recipient_email</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">Account.Name</span>
                      <span className="text-white">→ recipient_org</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">Opportunity.Stage</span>
                      <span className="text-white">→ outreach_status</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">Contact.Id</span>
                      <span className="text-white">→ crm_id</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-orange-400" />
                    HubSpot Mapping
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">contact.email</span>
                      <span className="text-white">→ recipient_email</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">company.name</span>
                      <span className="text-white">→ recipient_org</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">deal.dealstage</span>
                      <span className="text-white">→ outreach_status</span>
                    </div>
                    <div className="flex justify-between p-2 bg-gray-700 rounded">
                      <span className="text-gray-400">contact.hs_object_id</span>
                      <span className="text-white">→ crm_id</span>
                    </div>
                  </div>
                </div>

                <Alert className="bg-yellow-900/30 border-yellow-800">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <AlertDescription className="text-gray-300">
                    Enable backend functions to activate real-time OAuth sync with automatic field mapping.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}