import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import {
  TrendingUp, TrendingDown, BarChart3, PieChart as PieChartIcon, Activity,
  DollarSign, Shield, Mail, Users, Target, Settings, Plus, X, GripVertical,
  Calendar, Filter, RefreshCw, Building2, Briefcase, AlertTriangle, CheckCircle2
} from "lucide-react";
import { format, subDays, subMonths, isAfter, parseISO } from "date-fns";

const WIDGET_TYPES = {
  synergy_trend: { name: "Synergy Score Trend", icon: TrendingUp, category: "trends" },
  roi_forecast: { name: "ROI Forecasts", icon: DollarSign, category: "financial" },
  risk_exposure: { name: "Risk Exposure", icon: Shield, category: "risk" },
  outreach_conversion: { name: "Outreach Conversion", icon: Mail, category: "outreach" },
  partnership_health: { name: "Partnership Health", icon: Activity, category: "overview" },
  partner_distribution: { name: "Partner Distribution", icon: PieChartIcon, category: "overview" },
  project_status: { name: "Project Status", icon: Briefcase, category: "projects" },
  ecosystem_radar: { name: "Ecosystem Radar", icon: Target, category: "overview" }
};

const COLORS = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ef4444", "#ec4899"];

const DEFAULT_WIDGETS = ["synergy_trend", "roi_forecast", "risk_exposure", "outreach_conversion", "partnership_health", "partner_distribution"];

export default function PartnershipKPIDashboard({ connections, projects, reports, outreaches }) {
  const queryClient = useQueryClient();
  const [dateRange, setDateRange] = useState("30d");
  const [partnerType, setPartnerType] = useState("all");
  const [projectStatus, setProjectStatus] = useState("all");
  const [activeWidgets, setActiveWidgets] = useState(DEFAULT_WIDGETS);
  const [showWidgetManager, setShowWidgetManager] = useState(false);
  const [userPreferences, setUserPreferences] = useState(null);

  // Load user preferences
  useEffect(() => {
    const loadPreferences = async () => {
      try {
        const user = await base44.auth.me();
        if (user?.dashboard_preferences?.partnership_kpi_widgets) {
          setActiveWidgets(user.dashboard_preferences.partnership_kpi_widgets);
        }
        setUserPreferences(user?.dashboard_preferences || {});
      } catch (e) {
        console.error("Error loading preferences:", e);
      }
    };
    loadPreferences();
  }, []);

  // Save preferences mutation
  const savePreferencesMutation = useMutation({
    mutationFn: async (widgets) => {
      await base44.auth.updateMe({
        dashboard_preferences: {
          ...userPreferences,
          partnership_kpi_widgets: widgets
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    }
  });

  const toggleWidget = (widgetId) => {
    const newWidgets = activeWidgets.includes(widgetId)
      ? activeWidgets.filter(w => w !== widgetId)
      : [...activeWidgets, widgetId];
    setActiveWidgets(newWidgets);
    savePreferencesMutation.mutate(newWidgets);
  };

  // Filter data based on selections
  const filteredData = useMemo(() => {
    const now = new Date();
    let startDate;
    switch (dateRange) {
      case "7d": startDate = subDays(now, 7); break;
      case "30d": startDate = subDays(now, 30); break;
      case "90d": startDate = subDays(now, 90); break;
      case "6m": startDate = subMonths(now, 6); break;
      case "1y": startDate = subMonths(now, 12); break;
      default: startDate = subDays(now, 30);
    }

    const filterByDate = (items, dateField) => 
      items?.filter(item => {
        const itemDate = item[dateField] ? parseISO(item[dateField]) : null;
        return itemDate && isAfter(itemDate, startDate);
      }) || [];

    const filteredConnections = filterByDate(connections, 'created_date')
      .filter(c => partnerType === "all" || c.connection_type === partnerType);

    const filteredProjects = filterByDate(projects, 'start_date')
      .filter(p => projectStatus === "all" || p.status === projectStatus);

    const filteredReports = filterByDate(reports, 'generation_date');
    const filteredOutreaches = filterByDate(outreaches, 'created_date');

    return { 
      connections: filteredConnections, 
      projects: filteredProjects, 
      reports: filteredReports, 
      outreaches: filteredOutreaches 
    };
  }, [connections, projects, reports, outreaches, dateRange, partnerType, projectStatus]);

  // Calculate metrics
  const metrics = useMemo(() => {
    const { connections: fc, projects: fp, reports: fr, outreaches: fo } = filteredData;

    // Synergy Score Trend
    const synergyData = fr.map(r => ({
      date: format(parseISO(r.generation_date), 'MMM dd'),
      score: r.ecosystem_health_score || 0,
      confidence: r.confidence_score || 0
    })).slice(-10);

    // ROI Forecasts
    const roiData = fr.flatMap(r => 
      r.predictive_analytics?.roi_forecasts?.map(f => ({
        name: f.partner_or_opportunity?.substring(0, 20) || 'Unknown',
        year1: parseFloat(f.year_1_roi?.replace(/[^0-9.-]/g, '')) || 0,
        year3: parseFloat(f.year_3_roi?.replace(/[^0-9.-]/g, '')) || 0,
        year5: parseFloat(f.year_5_roi?.replace(/[^0-9.-]/g, '')) || 0
      })) || []
    ).slice(0, 6);

    // Risk Exposure
    const riskData = [];
    const riskCounts = { low: 0, medium: 0, high: 0 };
    fr.forEach(r => {
      r.predictive_analytics?.risk_mitigation_strategies?.forEach(risk => {
        riskCounts[risk.likelihood] = (riskCounts[risk.likelihood] || 0) + 1;
      });
    });
    Object.entries(riskCounts).forEach(([key, value]) => {
      if (value > 0) riskData.push({ name: key, value, fill: key === 'high' ? '#ef4444' : key === 'medium' ? '#f59e0b' : '#10b981' });
    });

    // Outreach Conversion
    const outreachStages = { draft: 0, sent: 0, opened: 0, replied: 0, converted: 0 };
    fo.forEach(o => {
      outreachStages[o.outreach_status] = (outreachStages[o.outreach_status] || 0) + 1;
    });
    const outreachData = Object.entries(outreachStages)
      .filter(([_, v]) => v > 0)
      .map(([key, value]) => ({ stage: key, count: value }));

    const conversionRate = fo.length > 0 
      ? ((outreachStages.converted / fo.length) * 100).toFixed(1) 
      : 0;

    // Partnership Health
    const healthData = [
      { subject: 'Synergy', A: fr[0]?.ecosystem_health_score || 70, fullMark: 100 },
      { subject: 'Engagement', A: fc.filter(c => c.status === 'accepted').length * 10 || 50, fullMark: 100 },
      { subject: 'Projects', A: fp.filter(p => p.status === 'active').length * 15 || 45, fullMark: 100 },
      { subject: 'ROI', A: roiData[0]?.year1 || 60, fullMark: 100 },
      { subject: 'Risk Mgmt', A: 100 - (riskCounts.high * 20), fullMark: 100 },
      { subject: 'Outreach', A: parseFloat(conversionRate) * 5 || 40, fullMark: 100 }
    ];

    // Partner Distribution
    const partnerTypes = {};
    fc.forEach(c => {
      partnerTypes[c.connection_type] = (partnerTypes[c.connection_type] || 0) + 1;
    });
    const partnerDistribution = Object.entries(partnerTypes).map(([name, value], i) => ({
      name: name?.replace('_', ' ') || 'unknown',
      value,
      fill: COLORS[i % COLORS.length]
    }));

    // Project Status
    const projectStatuses = {};
    fp.forEach(p => {
      projectStatuses[p.status] = (projectStatuses[p.status] || 0) + 1;
    });
    const projectData = Object.entries(projectStatuses).map(([name, value]) => ({ name, value }));

    return {
      synergyData,
      roiData,
      riskData,
      outreachData,
      conversionRate,
      healthData,
      partnerDistribution,
      projectData,
      totalPartners: fc.length,
      activeProjects: fp.filter(p => p.status === 'active').length,
      avgSynergy: fr[0]?.ecosystem_health_score || 0,
      highRisks: riskCounts.high
    };
  }, [filteredData]);

  const renderWidget = (widgetId) => {
    switch (widgetId) {
      case "synergy_trend":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                Synergy Score Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={metrics.synergyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="date" stroke="#666" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#666" tick={{ fontSize: 10 }} domain={[0, 100]} />
                    <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    <Area type="monotone" dataKey="score" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} name="Synergy" />
                    <Area type="monotone" dataKey="confidence" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} name="Confidence" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case "roi_forecast":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-green-400" />
                ROI Forecasts by Partner
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metrics.roiData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis type="number" stroke="#666" tick={{ fontSize: 10 }} />
                    <YAxis dataKey="name" type="category" stroke="#666" tick={{ fontSize: 9 }} width={80} />
                    <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    <Bar dataKey="year1" fill="#10b981" name="Year 1" />
                    <Bar dataKey="year3" fill="#06b6d4" name="Year 3" />
                    <Bar dataKey="year5" fill="#8b5cf6" name="Year 5" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case "risk_exposure":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Shield className="w-4 h-4 text-red-400" />
                Risk Exposure
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] flex items-center justify-center">
                {metrics.riskData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={metrics.riskData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        labelLine={false}
                      >
                        {metrics.riskData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-gray-500 text-sm">No risk data available</p>
                )}
              </div>
            </CardContent>
          </Card>
        );

      case "outreach_conversion":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Mail className="w-4 h-4 text-cyan-400" />
                Outreach Funnel
                <Badge className="bg-cyan-600 ml-auto">{metrics.conversionRate}% Conv.</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metrics.outreachData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="stage" stroke="#666" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#666" tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    <Bar dataKey="count" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case "partnership_health":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-purple-400" />
                Partnership Health Radar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={metrics.healthData}>
                    <PolarGrid stroke="#333" />
                    <PolarAngleAxis dataKey="subject" stroke="#666" tick={{ fontSize: 9 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#444" tick={{ fontSize: 8 }} />
                    <Radar name="Health" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.5} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case "partner_distribution":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <PieChartIcon className="w-4 h-4 text-orange-400" />
                Partner Types
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                {metrics.partnerDistribution.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={metrics.partnerDistribution}
                        cx="50%"
                        cy="50%"
                        outerRadius={70}
                        dataKey="value"
                        label={({ name }) => name}
                        labelLine={false}
                      >
                        {metrics.partnerDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-gray-500 text-sm text-center pt-16">No partner data</p>
                )}
              </div>
            </CardContent>
          </Card>
        );

      case "project_status":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-blue-400" />
                Project Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={metrics.projectData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="name" stroke="#666" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#666" tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none', fontSize: 12 }} />
                    <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        );

      case "ecosystem_radar":
        return (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-green-400" />
                Ecosystem Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-800 rounded-lg text-center">
                  <Users className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                  <p className="text-xl font-bold text-white">{metrics.totalPartners}</p>
                  <p className="text-gray-400 text-xs">Partners</p>
                </div>
                <div className="p-3 bg-gray-800 rounded-lg text-center">
                  <Briefcase className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                  <p className="text-xl font-bold text-white">{metrics.activeProjects}</p>
                  <p className="text-gray-400 text-xs">Active Projects</p>
                </div>
                <div className="p-3 bg-gray-800 rounded-lg text-center">
                  <TrendingUp className="w-5 h-5 text-green-400 mx-auto mb-1" />
                  <p className="text-xl font-bold text-white">{metrics.avgSynergy}%</p>
                  <p className="text-gray-400 text-xs">Avg Synergy</p>
                </div>
                <div className="p-3 bg-gray-800 rounded-lg text-center">
                  <AlertTriangle className="w-5 h-5 text-red-400 mx-auto mb-1" />
                  <p className="text-xl font-bold text-white">{metrics.highRisks}</p>
                  <p className="text-gray-400 text-xs">High Risks</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters & Controls */}
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-32 bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                  <SelectItem value="6m">Last 6 months</SelectItem>
                  <SelectItem value="1y">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-gray-400" />
              <Select value={partnerType} onValueChange={setPartnerType}>
                <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Partner Types</SelectItem>
                  <SelectItem value="skill_exchange">Skill Exchange</SelectItem>
                  <SelectItem value="mentorship">Mentorship</SelectItem>
                  <SelectItem value="collaboration">Collaboration</SelectItem>
                  <SelectItem value="knowledge_sharing">Knowledge Sharing</SelectItem>
                  <SelectItem value="challenge_solving">Challenge Solving</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-gray-400" />
              <Select value={projectStatus} onValueChange={setProjectStatus}>
                <SelectTrigger className="w-36 bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="forming">Forming</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="on_hold">On Hold</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="ml-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowWidgetManager(!showWidgetManager)}
                className="border-gray-700 text-gray-400 hover:text-white"
              >
                <Settings className="w-4 h-4 mr-2" />
                Customize
              </Button>
            </div>
          </div>

          {/* Widget Manager */}
          {showWidgetManager && (
            <div className="mt-4 pt-4 border-t border-gray-800">
              <p className="text-gray-400 text-sm mb-3">Toggle widgets to customize your dashboard:</p>
              <div className="flex flex-wrap gap-2">
                {Object.entries(WIDGET_TYPES).map(([id, widget]) => (
                  <button
                    key={id}
                    onClick={() => toggleWidget(id)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                      activeWidgets.includes(id)
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    <widget.icon className="w-3 h-3" />
                    {widget.name}
                    {activeWidgets.includes(id) ? (
                      <X className="w-3 h-3" />
                    ) : (
                      <Plus className="w-3 h-3" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Widgets Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activeWidgets.map(widgetId => (
          <div key={widgetId}>
            {renderWidget(widgetId)}
          </div>
        ))}
      </div>

      {activeWidgets.length === 0 && (
        <Card className="bg-gray-900 border-gray-800 text-center py-12">
          <CardContent>
            <BarChart3 className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-medium mb-2">No Widgets Selected</h3>
            <p className="text-gray-400 text-sm mb-4">Click "Customize" to add widgets to your dashboard</p>
            <Button onClick={() => setShowWidgetManager(true)} variant="outline" className="border-gray-700 text-gray-400">
              <Plus className="w-4 h-4 mr-2" />
              Add Widgets
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}