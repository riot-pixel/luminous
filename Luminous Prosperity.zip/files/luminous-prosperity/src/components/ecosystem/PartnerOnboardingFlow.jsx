import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sparkles, UserPlus, Mail, Calendar, FileText, Users, CheckCircle2,
  Building2, Briefcase, RefreshCw, ArrowRight, Clock, Send
} from "lucide-react";

const PARTNER_TYPES = [
  { value: "technology", label: "Technology Partner", templates: ["Tech Integration Guide", "API Documentation", "Security Requirements"] },
  { value: "distribution", label: "Distribution Partner", templates: ["Sales Playbook", "Pricing Guidelines", "Marketing Assets"] },
  { value: "strategic", label: "Strategic Alliance", templates: ["Partnership Framework", "Joint Business Plan", "Governance Model"] },
  { value: "research", label: "R&D Partner", templates: ["Research Protocol", "IP Guidelines", "Data Sharing Agreement"] },
  { value: "consulting", label: "Consulting Partner", templates: ["Service Catalog", "Engagement Model", "Quality Standards"] }
];

export default function PartnerOnboardingFlow({ user, organization, onComplete }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showOnboardingDialog, setShowOnboardingDialog] = useState(false);
  const [onboardingData, setOnboardingData] = useState({
    partner_name: "",
    partner_email: "",
    partner_org: "",
    partner_type: "",
    contact_person: user?.full_name || "",
    intro_meeting_date: "",
    notes: ""
  });
  const [generatedContent, setGeneratedContent] = useState(null);
  const [onboardingStep, setOnboardingStep] = useState(1);

  const createConnectionMutation = useMutation({
    mutationFn: (data) => base44.entities.EcosystemConnection.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myConnections'] });
    },
  });

  const createOutreachMutation = useMutation({
    mutationFn: (data) => base44.entities.PartnerOutreach.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partnerOutreaches'] });
    },
  });

  const generateOnboardingContent = async () => {
    setIsGenerating(true);
    try {
      const partnerTypeInfo = PARTNER_TYPES.find(p => p.value === onboardingData.partner_type);
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate personalized onboarding content for a new strategic partner:

PARTNER DETAILS:
- Name: ${onboardingData.partner_name}
- Organization: ${onboardingData.partner_org}
- Partner Type: ${partnerTypeInfo?.label || onboardingData.partner_type}
- Point of Contact: ${onboardingData.contact_person}

OUR ORGANIZATION: ${organization?.name || 'Our Company'}

Generate:
1. A warm, personalized welcome message (2-3 paragraphs)
2. 3-5 key onboarding steps specific to this partner type
3. Suggested agenda items for the intro meeting
4. 3 quick wins they can achieve in the first 30 days
5. Key resources and documentation they should review`,
        response_json_schema: {
          type: "object",
          properties: {
            welcome_message: { type: "string" },
            onboarding_steps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  step: { type: "string" },
                  description: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            meeting_agenda: { type: "array", items: { type: "string" } },
            quick_wins: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  win: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            recommended_resources: { type: "array", items: { type: "string" } }
          }
        }
      });

      setGeneratedContent(result);
      setOnboardingStep(2);
    } catch (error) {
      console.error("Error generating onboarding content:", error);
    }
    setIsGenerating(false);
  };

  const completeOnboarding = async () => {
    try {
      // Create connection
      await createConnectionMutation.mutateAsync({
        requester_email: user?.email,
        requester_org: organization?.name,
        recipient_email: onboardingData.partner_email,
        recipient_org: onboardingData.partner_org,
        connection_type: "collaboration",
        ai_match_reason: `New ${PARTNER_TYPES.find(p => p.value === onboardingData.partner_type)?.label} onboarded`,
        status: "accepted",
        mutual_consent_date: new Date().toISOString()
      });

      // Create outreach record with welcome message
      await createOutreachMutation.mutateAsync({
        partner_name: onboardingData.partner_name,
        partner_email: onboardingData.partner_email,
        partner_industry: onboardingData.partner_type,
        outreach_status: "sent",
        outreach_channel: "email",
        personalized_message: generatedContent?.welcome_message,
        message_subject: `Welcome to our Partnership, ${onboardingData.partner_name}!`,
        key_talking_points: generatedContent?.meeting_agenda || [],
        assigned_to: user?.email,
        last_contact_date: new Date().toISOString()
      });

      // Send welcome email
      await base44.integrations.Core.SendEmail({
        to: onboardingData.partner_email,
        subject: `Welcome to our Partnership, ${onboardingData.partner_name}!`,
        body: `${generatedContent?.welcome_message}\n\n---\n\nNext Steps:\n${generatedContent?.onboarding_steps?.map((s, i) => `${i + 1}. ${s.step}`).join('\n')}\n\nLooking forward to a successful partnership!\n\nBest regards,\n${onboardingData.contact_person}`
      });

      setShowOnboardingDialog(false);
      setOnboardingStep(1);
      setOnboardingData({
        partner_name: "",
        partner_email: "",
        partner_org: "",
        partner_type: "",
        contact_person: user?.full_name || "",
        intro_meeting_date: "",
        notes: ""
      });
      setGeneratedContent(null);
      onComplete?.();
    } catch (error) {
      console.error("Error completing onboarding:", error);
    }
  };

  const selectedPartnerType = PARTNER_TYPES.find(p => p.value === onboardingData.partner_type);

  return (
    <>
      <Dialog open={showOnboardingDialog} onOpenChange={setShowOnboardingDialog}>
        <DialogTrigger asChild>
          <Button className="bg-green-600 hover:bg-green-700">
            <UserPlus className="w-4 h-4 mr-2" />
            Onboard New Partner
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-green-400" />
              Partner Onboarding - Step {onboardingStep} of 3
            </DialogTitle>
          </DialogHeader>

          {onboardingStep === 1 && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Partner Name</label>
                  <Input
                    value={onboardingData.partner_name}
                    onChange={(e) => setOnboardingData({...onboardingData, partner_name: e.target.value})}
                    placeholder="Contact person name"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Partner Email</label>
                  <Input
                    value={onboardingData.partner_email}
                    onChange={(e) => setOnboardingData({...onboardingData, partner_email: e.target.value})}
                    placeholder="email@partner.com"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Partner Organization</label>
                  <Input
                    value={onboardingData.partner_org}
                    onChange={(e) => setOnboardingData({...onboardingData, partner_org: e.target.value})}
                    placeholder="Company name"
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Partner Type</label>
                  <Select value={onboardingData.partner_type} onValueChange={(v) => setOnboardingData({...onboardingData, partner_type: v})}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {PARTNER_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Point of Contact (You)</label>
                  <Input
                    value={onboardingData.contact_person}
                    onChange={(e) => setOnboardingData({...onboardingData, contact_person: e.target.value})}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-400 mb-2 block">Intro Meeting Date</label>
                  <Input
                    type="datetime-local"
                    value={onboardingData.intro_meeting_date}
                    onChange={(e) => setOnboardingData({...onboardingData, intro_meeting_date: e.target.value})}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>

              {selectedPartnerType && (
                <div className="p-3 bg-gray-800 rounded-lg">
                  <p className="text-sm text-gray-400 mb-2">Recommended templates for {selectedPartnerType.label}:</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedPartnerType.templates.map((t, i) => (
                      <Badge key={i} variant="outline" className="border-green-600 text-green-400">
                        <FileText className="w-3 h-3 mr-1" />
                        {t}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <Button
                onClick={generateOnboardingContent}
                disabled={!onboardingData.partner_name || !onboardingData.partner_email || !onboardingData.partner_type || isGenerating}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {isGenerating ? (
                  <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Generating Content...</>
                ) : (
                  <><Sparkles className="w-4 h-4 mr-2" /> Generate Onboarding Content</>
                )}
              </Button>
            </div>
          )}

          {onboardingStep === 2 && generatedContent && (
            <div className="space-y-4 py-4">
              <div className="p-4 bg-gray-800 rounded-lg">
                <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-400" />
                  Welcome Message
                </h4>
                <p className="text-gray-300 text-sm whitespace-pre-wrap">{generatedContent.welcome_message}</p>
              </div>

              <div className="p-4 bg-gray-800 rounded-lg">
                <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                  <ArrowRight className="w-4 h-4 text-green-400" />
                  Onboarding Steps
                </h4>
                <div className="space-y-2">
                  {generatedContent.onboarding_steps?.map((step, i) => (
                    <div key={i} className="flex items-start gap-3 p-2 bg-gray-700 rounded">
                      <span className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-xs font-bold">{i + 1}</span>
                      <div className="flex-1">
                        <p className="text-white text-sm">{step.step}</p>
                        <p className="text-gray-400 text-xs">{step.description}</p>
                      </div>
                      <Badge variant="outline" className="text-xs border-gray-600 text-gray-400">
                        <Clock className="w-3 h-3 mr-1" />
                        {step.timeline}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-400" />
                    Meeting Agenda
                  </h4>
                  <ul className="space-y-1">
                    {generatedContent.meeting_agenda?.map((item, i) => (
                      <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                        <CheckCircle2 className="w-3 h-3 mt-1 text-purple-400 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-gray-800 rounded-lg">
                  <h4 className="text-white font-medium mb-2 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                    30-Day Quick Wins
                  </h4>
                  <ul className="space-y-1">
                    {generatedContent.quick_wins?.map((qw, i) => (
                      <li key={i} className="text-gray-300 text-sm">
                        <span className="text-yellow-400">•</span> {qw.win}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setOnboardingStep(1)} className="border-gray-700 text-gray-400">
                  Back
                </Button>
                <Button onClick={() => setOnboardingStep(3)} className="flex-1 bg-green-600 hover:bg-green-700">
                  Review & Complete
                </Button>
              </div>
            </div>
          )}

          {onboardingStep === 3 && (
            <div className="space-y-4 py-4">
              <div className="p-4 bg-green-900/30 border border-green-800 rounded-lg">
                <h4 className="text-white font-medium mb-3">Ready to Onboard</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-400">Partner</p>
                    <p className="text-white">{onboardingData.partner_name}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Organization</p>
                    <p className="text-white">{onboardingData.partner_org}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Type</p>
                    <p className="text-white">{selectedPartnerType?.label}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Point of Contact</p>
                    <p className="text-white">{onboardingData.contact_person}</p>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-gray-800 rounded-lg">
                <h4 className="text-white font-medium mb-2">This will:</h4>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    Create a new partnership connection
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    Send personalized welcome email
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    Create outreach tracking record
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    Assign you as point of contact
                  </li>
                </ul>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setOnboardingStep(2)} className="border-gray-700 text-gray-400">
                  Back
                </Button>
                <Button onClick={completeOnboarding} className="flex-1 bg-green-600 hover:bg-green-700">
                  <Send className="w-4 h-4 mr-2" />
                  Complete Onboarding
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}