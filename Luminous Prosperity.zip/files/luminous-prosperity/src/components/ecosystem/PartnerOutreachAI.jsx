import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Send, Sparkles, Mail, Linkedin, Phone, Users, MessageSquare,
  Calendar, CheckCircle2, Clock, RefreshCw, Eye, ArrowRight,
  Target, TrendingUp, Edit, Copy, ExternalLink
} from "lucide-react";

const STATUS_COLORS = {
  draft: "bg-gray-600",
  scheduled: "bg-blue-600",
  sent: "bg-purple-600",
  opened: "bg-cyan-600",
  replied: "bg-green-600",
  meeting_scheduled: "bg-orange-600",
  converted: "bg-emerald-600",
  declined: "bg-red-600"
};

const CHANNEL_ICONS = {
  email: Mail,
  linkedin: Linkedin,
  phone: Phone,
  in_person: Users,
  referral: MessageSquare
};

export default function PartnerOutreachAI({ ecosystemReports }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [editedMessage, setEditedMessage] = useState("");

  const { data: outreaches } = useQuery({
    queryKey: ['partnerOutreaches'],
    queryFn: () => base44.entities.PartnerOutreach.list('-created_date', 50),
    initialData: [],
  });

  const createOutreachMutation = useMutation({
    mutationFn: (data) => base44.entities.PartnerOutreach.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['partnerOutreaches'] }),
  });

  const updateOutreachMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PartnerOutreach.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['partnerOutreaches'] }),
  });

  const potentialPartners = ecosystemReports?.flatMap(r => 
    r.potential_partners_identified?.map(p => ({ ...p, reportId: r.id, reportTitle: r.title })) || []
  ) || [];

  const generateOutreachForPartner = async (partner) => {
    setIsGenerating(true);
    setSelectedPartner(partner);

    try {
      const outreachContent = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a personalized outreach strategy for this potential partner:

PARTNER PROFILE:
- Name: ${partner.partner_name}
- Industry: ${partner.partner_industry}
- Strategic Fit: ${partner.strategic_fit_reasoning}
- Alignment Score: ${partner.alignment_score}%
- Partnership Type: ${partner.partnership_type}
- Potential Value: ${partner.potential_value}

Create:
1. A personalized outreach email (professional, concise, value-focused)
2. Email subject line (compelling, not salesy)
3. 5 key talking points for calls/meetings
4. Clear value proposition
5. Recommended outreach channels with effectiveness scores (0-100) and reasoning
6. 5-step follow-up schedule (days and actions)`,
        response_json_schema: {
          type: "object",
          properties: {
            personalized_message: { type: "string" },
            message_subject: { type: "string" },
            key_talking_points: { type: "array", items: { type: "string" } },
            value_proposition: { type: "string" },
            recommended_channels: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  channel: { type: "string" },
                  effectiveness_score: { type: "number" },
                  reasoning: { type: "string" }
                }
              }
            },
            follow_up_schedule: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  day: { type: "number" },
                  action: { type: "string" },
                  channel: { type: "string" }
                }
              }
            }
          }
        }
      });

      await createOutreachMutation.mutateAsync({
        partner_name: partner.partner_name,
        partner_industry: partner.partner_industry,
        source_report_id: partner.reportId,
        strategic_fit_score: partner.alignment_score,
        outreach_status: "draft",
        outreach_channel: outreachContent.recommended_channels?.[0]?.channel || "email",
        personalized_message: outreachContent.personalized_message,
        message_subject: outreachContent.message_subject,
        key_talking_points: outreachContent.key_talking_points,
        value_proposition: outreachContent.value_proposition,
        recommended_channels: outreachContent.recommended_channels,
        follow_up_schedule: outreachContent.follow_up_schedule?.map(f => ({ ...f, completed: false })),
        engagement_metrics: { emails_sent: 0, emails_opened: 0, links_clicked: 0, replies_received: 0, meetings_scheduled: 0 }
      });

    } catch (error) {
      console.error("Error generating outreach:", error);
    }
    setIsGenerating(false);
    setSelectedPartner(null);
  };

  const updateStatus = async (outreach, newStatus) => {
    await updateOutreachMutation.mutateAsync({
      id: outreach.id,
      data: { 
        outreach_status: newStatus,
        last_contact_date: new Date().toISOString()
      }
    });
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const stats = {
    total: outreaches.length,
    sent: outreaches.filter(o => ['sent', 'opened', 'replied', 'meeting_scheduled', 'converted'].includes(o.outreach_status)).length,
    replied: outreaches.filter(o => ['replied', 'meeting_scheduled', 'converted'].includes(o.outreach_status)).length,
    converted: outreaches.filter(o => o.outreach_status === 'converted').length
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-white">{stats.total}</p>
            <p className="text-gray-400 text-sm">Total Outreaches</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-purple-400">{stats.sent}</p>
            <p className="text-gray-400 text-sm">Sent</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-green-400">{stats.replied}</p>
            <p className="text-gray-400 text-sm">Replied</p>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-emerald-400">{stats.converted}</p>
            <p className="text-gray-400 text-sm">Converted</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="generate" className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="generate">Generate Outreach</TabsTrigger>
          <TabsTrigger value="pipeline">Outreach Pipeline</TabsTrigger>
          <TabsTrigger value="templates">Message Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="generate">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Generate AI Outreach
              </CardTitle>
              <CardDescription className="text-gray-400">
                Select a potential partner to generate personalized outreach content
              </CardDescription>
            </CardHeader>
            <CardContent>
              {potentialPartners.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No potential partners found. Run an Ecosystem Synergy Analysis first.
                </div>
              ) : (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3">
                    {potentialPartners.map((partner, i) => {
                      const existingOutreach = outreaches.find(o => o.partner_name === partner.partner_name);
                      return (
                        <div key={i} className="p-4 bg-gray-800 rounded-lg flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="text-white font-medium">{partner.partner_name}</h4>
                              <Badge className="bg-blue-600">{partner.alignment_score}%</Badge>
                              {existingOutreach && (
                                <Badge className={STATUS_COLORS[existingOutreach.outreach_status]}>
                                  {existingOutreach.outreach_status.replace('_', ' ')}
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-400 text-sm">{partner.partner_industry} • {partner.partnership_type}</p>
                          </div>
                          <Button
                            onClick={() => generateOutreachForPartner(partner)}
                            disabled={isGenerating && selectedPartner?.partner_name === partner.partner_name}
                            size="sm"
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            {isGenerating && selectedPartner?.partner_name === partner.partner_name ? (
                              <><RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Generating...</>
                            ) : existingOutreach ? (
                              <><RefreshCw className="w-3 h-3 mr-1" /> Regenerate</>
                            ) : (
                              <><Sparkles className="w-3 h-3 mr-1" /> Generate</>
                            )}
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pipeline">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Outreach Pipeline</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <div className="space-y-4">
                  {outreaches.map((outreach, i) => {
                    const ChannelIcon = CHANNEL_ICONS[outreach.outreach_channel] || Mail;
                    return (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-white font-medium">{outreach.partner_name}</h4>
                              <Badge className={STATUS_COLORS[outreach.outreach_status]}>
                                {outreach.outreach_status.replace('_', ' ')}
                              </Badge>
                            </div>
                            <p className="text-gray-400 text-sm">{outreach.partner_industry}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <ChannelIcon className="w-4 h-4 text-gray-400" />
                            <Select
                              value={outreach.outreach_status}
                              onValueChange={(v) => updateStatus(outreach, v)}
                            >
                              <SelectTrigger className="w-32 h-8 bg-gray-700 border-gray-600 text-white text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="scheduled">Scheduled</SelectItem>
                                <SelectItem value="sent">Sent</SelectItem>
                                <SelectItem value="opened">Opened</SelectItem>
                                <SelectItem value="replied">Replied</SelectItem>
                                <SelectItem value="meeting_scheduled">Meeting</SelectItem>
                                <SelectItem value="converted">Converted</SelectItem>
                                <SelectItem value="declined">Declined</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {outreach.message_subject && (
                          <div className="mb-2 p-2 bg-gray-700 rounded">
                            <p className="text-gray-400 text-xs">Subject:</p>
                            <p className="text-white text-sm">{outreach.message_subject}</p>
                          </div>
                        )}

                        {outreach.value_proposition && (
                          <p className="text-gray-300 text-sm mb-3">{outreach.value_proposition}</p>
                        )}

                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300"
                            onClick={() => {
                              setSelectedPartner(outreach);
                              setEditedMessage(outreach.personalized_message || "");
                              setShowMessageDialog(true);
                            }}
                          >
                            <Eye className="w-3 h-3 mr-1" /> View Message
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300"
                            onClick={() => copyToClipboard(outreach.personalized_message)}
                          >
                            <Copy className="w-3 h-3 mr-1" /> Copy
                          </Button>
                        </div>

                        {outreach.recommended_channels?.length > 0 && (
                          <div className="mt-3 pt-3 border-t border-gray-700">
                            <p className="text-gray-500 text-xs mb-2">Recommended Channels:</p>
                            <div className="flex flex-wrap gap-2">
                              {outreach.recommended_channels.map((ch, j) => (
                                <Badge key={j} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                                  {ch.channel}: {ch.effectiveness_score}%
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Message Templates</CardTitle>
              <CardDescription className="text-gray-400">View and edit generated messages</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  {outreaches.filter(o => o.personalized_message).map((outreach, i) => (
                    <div key={i} className="p-4 bg-gray-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-white font-medium">{outreach.partner_name}</h4>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(outreach.personalized_message)}>
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className="text-purple-400 text-sm mb-2">Subject: {outreach.message_subject}</p>
                      <p className="text-gray-300 text-sm whitespace-pre-wrap line-clamp-4">{outreach.personalized_message}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Message Dialog */}
      <Dialog open={showMessageDialog} onOpenChange={setShowMessageDialog}>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800 text-white">
          <DialogHeader>
            <DialogTitle>Outreach Message - {selectedPartner?.partner_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-gray-400 text-sm mb-1">Subject</p>
              <p className="text-white bg-gray-800 p-2 rounded">{selectedPartner?.message_subject}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-1">Message</p>
              <Textarea
                value={editedMessage}
                onChange={(e) => setEditedMessage(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white h-64"
              />
            </div>
            {selectedPartner?.key_talking_points?.length > 0 && (
              <div>
                <p className="text-gray-400 text-sm mb-1">Key Talking Points</p>
                <ul className="text-gray-300 text-sm space-y-1">
                  {selectedPartner.key_talking_points.map((point, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 mt-1 text-green-500" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <div className="flex gap-2">
              <Button onClick={() => copyToClipboard(editedMessage)} className="flex-1">
                <Copy className="w-4 h-4 mr-2" /> Copy Message
              </Button>
              <Button 
                onClick={async () => {
                  if (selectedPartner?.id) {
                    await updateOutreachMutation.mutateAsync({
                      id: selectedPartner.id,
                      data: { personalized_message: editedMessage }
                    });
                  }
                  setShowMessageDialog(false);
                }}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}