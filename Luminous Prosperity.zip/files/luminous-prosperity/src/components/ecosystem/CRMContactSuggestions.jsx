import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Brain, RefreshCw, UserPlus, Building2, Mail, Phone, 
  Sparkles, ExternalLink, Calendar, CheckCircle2
} from "lucide-react";

export default function CRMContactSuggestions({ connections, outreaches, reports, user }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState([]);

  const createOutreachMutation = useMutation({
    mutationFn: (data) => base44.entities.PartnerOutreach.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['partnerOutreaches'] }),
  });

  const generateCRMSuggestions = async () => {
    setIsGenerating(true);
    try {
      const existingContacts = outreaches?.map(o => o.partner_email) || [];
      const connectionEmails = connections?.map(c => c.recipient_email) || [];
      const latestReport = reports?.[0];

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on the user's ecosystem activity, suggest relevant CRM contacts or leads to engage.

USER ACTIVITY SUMMARY:
- Active Connections: ${connections?.length || 0}
- Outreach Campaigns: ${outreaches?.length || 0}
- Connection Types: ${[...new Set(connections?.map(c => c.connection_type))].join(', ') || 'None'}

RECENT ECOSYSTEM REPORT INSIGHTS:
${latestReport ? `
- Health Score: ${latestReport.ecosystem_health_score}
- Potential Partners Identified: ${latestReport.potential_partners_identified?.length || 0}
- Key Recommendations: ${latestReport.actionable_recommendations?.slice(0, 3).map(r => r.recommendation).join('; ') || 'None'}
` : 'No recent reports'}

EXISTING CONTACTS TO AVOID:
${existingContacts.slice(0, 10).join(', ') || 'None'}

Generate 6-8 realistic CRM contact suggestions with:
1. Contact details (name, email, company, title)
2. Why they're relevant to the user's ecosystem goals
3. Suggested engagement approach
4. Priority level
5. Potential synergy areas`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  email: { type: "string" },
                  company: { type: "string" },
                  title: { type: "string" },
                  relevance_reason: { type: "string" },
                  engagement_approach: { type: "string" },
                  priority: { type: "string" },
                  synergy_areas: { type: "array", items: { type: "string" } },
                  estimated_value: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSuggestions(result.suggestions || []);
    } catch (error) {
      console.error("Error generating CRM suggestions:", error);
    }
    setIsGenerating(false);
  };

  const addToOutreach = async (contact) => {
    await createOutreachMutation.mutateAsync({
      partner_name: contact.name,
      partner_email: contact.email,
      partner_industry: contact.company,
      outreach_status: "draft",
      outreach_channel: "email",
      value_proposition: contact.relevance_reason,
      key_talking_points: contact.synergy_areas || [],
      strategic_fit_score: contact.priority === 'high' ? 90 : contact.priority === 'medium' ? 70 : 50,
      assigned_to: user?.email,
      notes: `AI Suggested: ${contact.engagement_approach}`
    });

    setSuggestions(prev => prev.filter(s => s.email !== contact.email));
  };

  const priorityColors = {
    high: 'bg-red-600',
    medium: 'bg-yellow-600',
    low: 'bg-blue-600'
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Brain className="w-5 h-5 text-cyan-400" />
            AI-Suggested CRM Contacts
          </CardTitle>
          <Button onClick={generateCRMSuggestions} disabled={isGenerating} size="sm" className="bg-cyan-600 hover:bg-cyan-700">
            {isGenerating ? <><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Analyzing...</> : <><Sparkles className="w-3 h-3 mr-1" />Find Leads</>}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {suggestions.length === 0 ? (
          <p className="text-gray-500 text-sm text-center py-6">
            Click "Find Leads" to get AI-powered contact suggestions based on your ecosystem activity
          </p>
        ) : (
          <div className="space-y-3">
            {suggestions.map((contact, i) => (
              <div key={i} className="p-4 bg-gray-800 rounded-lg">
                <div className="flex items-start gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-cyan-600">{contact.name?.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-white font-medium">{contact.name}</h4>
                      <Badge className={priorityColors[contact.priority] || 'bg-gray-600'}>
                        {contact.priority} priority
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm">{contact.title}</p>
                    <p className="text-gray-500 text-xs flex items-center gap-1">
                      <Building2 className="w-3 h-3" />{contact.company}
                    </p>
                    <p className="text-cyan-400 text-xs mt-2">{contact.relevance_reason}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {contact.synergy_areas?.slice(0, 3).map((area, j) => (
                        <Badge key={j} variant="outline" className="text-xs border-gray-700 text-gray-400">{area}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-700">
                  <span className="text-green-400 text-xs">Est. Value: {contact.estimated_value}</span>
                  <Button size="sm" onClick={() => addToOutreach(contact)} className="bg-green-600 hover:bg-green-700">
                    <UserPlus className="w-3 h-3 mr-1" />Add to Outreach
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}