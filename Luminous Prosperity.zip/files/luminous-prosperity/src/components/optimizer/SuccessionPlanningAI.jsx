import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Crown, Users, Brain, RefreshCw, AlertTriangle, Star, Target,
  TrendingUp, Clock, CheckCircle2, ChevronRight, Award, Zap,
  Lightbulb, ArrowRight, Shield, Calendar, BookOpen, Play
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

export default function SuccessionPlanningAI({
  employeeProfiles,
  roleRequirements,
  assessments,
  coachingSessions,
  learningJourneys
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [successionPlan, setSuccessionPlan] = useState(null);
  const [selectedRole, setSelectedRole] = useState(null);
  const [selectedSuccessor, setSelectedSuccessor] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [readinessSimulation, setReadinessSimulation] = useState(null);

  // Get critical roles (executive, senior, management)
  const criticalRoles = [...new Set(employeeProfiles
    .filter(e => e.job_title?.toLowerCase().includes('director') || 
                 e.job_title?.toLowerCase().includes('manager') ||
                 e.job_title?.toLowerCase().includes('lead') ||
                 e.job_title?.toLowerCase().includes('head') ||
                 e.job_title?.toLowerCase().includes('vp') ||
                 e.job_title?.toLowerCase().includes('chief'))
    .map(e => e.job_title)
  )].filter(Boolean);

  const analyzeSuccession = async () => {
    setIsAnalyzing(true);
    try {
      const employeeData = employeeProfiles.map(e => ({
        name: e.full_name,
        email: e.email,
        current_role: e.job_title,
        department: e.department,
        fulfillment: e.fulfillmentScore,
        operational: e.operationalScore,
        skill_level: e.avgSkillLevel,
        role_fit: e.roleFit,
        skills: e.skills?.slice(0, 8).map(s => ({ name: s.skill_name, level: s.current_proficiency })),
        strengths: e.strengths,
        mbti: e.mbti,
        coaching_score: e.avgCoachingScore,
        learning_progress: e.avgJourneyProgress,
        career_satisfaction: e.careerSatisfaction,
      }));

      const roleData = criticalRoles.map(role => {
        const requirements = roleRequirements.filter(r => r.role_title === role);
        const currentHolder = employeeProfiles.find(e => e.job_title === role);
        return {
          role,
          current_holder: currentHolder?.full_name,
          current_holder_email: currentHolder?.email,
          requirements: requirements.map(r => ({ skill: r.skill_name, level: r.required_proficiency })),
          department: currentHolder?.department
        };
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert in succession planning and leadership development. Analyze this organization's talent and identify succession candidates for critical roles.

EMPLOYEES:
${JSON.stringify(employeeData, null, 2)}

CRITICAL ROLES:
${JSON.stringify(roleData, null, 2)}

TASK: Create a comprehensive succession plan that:

1. For each critical role, identify 2-3 potential successors ranked by readiness
2. Assess each successor's:
   - Current readiness percentage
   - Time to readiness
   - Skill gaps
   - Leadership potential
   - Cultural fit
   - Development needs

3. Create personalized development plans for each successor including:
   - Specific training recommendations
   - Mentorship assignments
   - Stretch assignments
   - Timeline milestones
   - Success metrics

4. Identify succession risks:
   - Roles with no ready successors
   - Single points of failure
   - Flight risks among successors
   - Development bottlenecks

5. Provide month-by-month readiness progression for top successors`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: {
              type: "object",
              properties: {
                total_critical_roles: { type: "number" },
                roles_with_ready_successor: { type: "number" },
                roles_at_risk: { type: "number" },
                avg_successor_readiness: { type: "number" },
                key_insight: { type: "string" }
              }
            },
            role_succession: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  role: { type: "string" },
                  current_holder: { type: "string" },
                  department: { type: "string" },
                  risk_level: { type: "string" },
                  succession_status: { type: "string" },
                  successors: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                        email: { type: "string" },
                        current_role: { type: "string" },
                        readiness_score: { type: "number" },
                        time_to_ready: { type: "string" },
                        leadership_potential: { type: "number" },
                        cultural_fit: { type: "number" },
                        skill_gaps: { type: "array", items: { type: "string" } },
                        strengths_match: { type: "array", items: { type: "string" } },
                        development_plan: {
                          type: "object",
                          properties: {
                            training: { type: "array", items: { type: "string" } },
                            mentorship: { type: "string" },
                            stretch_assignments: { type: "array", items: { type: "string" } },
                            milestones: {
                              type: "array",
                              items: {
                                type: "object",
                                properties: {
                                  month: { type: "number" },
                                  milestone: { type: "string" },
                                  readiness_target: { type: "number" }
                                }
                              }
                            }
                          }
                        },
                        risk_factors: { type: "array", items: { type: "string" } },
                        flight_risk: { type: "number" }
                      }
                    }
                  }
                }
              }
            },
            organization_risks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  severity: { type: "string" },
                  affected_roles: { type: "array", items: { type: "string" } },
                  mitigation: { type: "string" }
                }
              }
            },
            priority_actions: { type: "array", items: { type: "string" } },
            development_investments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  investment: { type: "string" },
                  impact: { type: "string" },
                  beneficiaries: { type: "number" },
                  timeline: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSuccessionPlan(result);
    } catch (error) {
      console.error("Error analyzing succession:", error);
    }
    setIsAnalyzing(false);
  };

  const simulateReadiness = async (successor, role) => {
    setIsSimulating(true);
    setSelectedSuccessor(successor);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Simulate the readiness progression for this succession candidate over 24 months:

CANDIDATE: ${successor.name}
- Current Role: ${successor.current_role}
- Target Role: ${role}
- Current Readiness: ${successor.readiness_score}%
- Leadership Potential: ${successor.leadership_potential}%
- Skill Gaps: ${successor.skill_gaps?.join(', ')}

DEVELOPMENT PLAN:
- Training: ${successor.development_plan?.training?.join(', ')}
- Mentorship: ${successor.development_plan?.mentorship}
- Stretch Assignments: ${successor.development_plan?.stretch_assignments?.join(', ')}

Generate month-by-month readiness progression with:
1. Monthly readiness scores
2. Key activities each month
3. Milestone achievements
4. Confidence levels
5. Alternative scenarios (accelerated, standard, delayed)`,
        response_json_schema: {
          type: "object",
          properties: {
            candidate_name: { type: "string" },
            target_role: { type: "string" },
            monthly_progression: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  month: { type: "number" },
                  readiness_score: { type: "number" },
                  confidence: { type: "number" },
                  key_activities: { type: "array", items: { type: "string" } },
                  milestone_achieved: { type: "string" }
                }
              }
            },
            scenarios: {
              type: "object",
              properties: {
                accelerated: {
                  type: "object",
                  properties: {
                    time_to_ready: { type: "string" },
                    requirements: { type: "array", items: { type: "string" } },
                    probability: { type: "number" }
                  }
                },
                standard: {
                  type: "object",
                  properties: {
                    time_to_ready: { type: "string" },
                    requirements: { type: "array", items: { type: "string" } },
                    probability: { type: "number" }
                  }
                },
                delayed: {
                  type: "object",
                  properties: {
                    time_to_ready: { type: "string" },
                    risk_factors: { type: "array", items: { type: "string" } },
                    probability: { type: "number" }
                  }
                }
              }
            },
            critical_success_factors: { type: "array", items: { type: "string" } },
            early_warning_signs: { type: "array", items: { type: "string" } },
            recommendation: { type: "string" }
          }
        }
      });
      setReadinessSimulation(result);
    } catch (error) {
      console.error("Error simulating readiness:", error);
    }
    setIsSimulating(false);
  };

  const getRiskColor = (risk) => {
    switch (risk?.toLowerCase()) {
      case 'high': return 'bg-red-600';
      case 'medium': return 'bg-orange-600';
      case 'low': return 'bg-green-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusColor = (status) => {
    if (status?.includes('Ready')) return 'bg-green-600';
    if (status?.includes('Development')) return 'bg-blue-600';
    if (status?.includes('Risk') || status?.includes('No')) return 'bg-red-600';
    return 'bg-gray-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-amber-900/40 via-orange-900/30 to-red-900/40 border-amber-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                <Crown className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-white">AI Succession Planning</h2>
                <p className="text-gray-400 text-sm">Identify & develop future leaders for critical roles</p>
              </div>
            </div>
            <Button 
              onClick={analyzeSuccession}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200 px-8"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Analyze Succession</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {successionPlan ? (
        <>
          {/* Summary Stats */}
          <div className="grid grid-cols-4 gap-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4 text-center">
                <Crown className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{successionPlan.summary?.total_critical_roles}</p>
                <p className="text-gray-400 text-xs">Critical Roles</p>
              </CardContent>
            </Card>
            <Card className="bg-green-900/30 border-green-800">
              <CardContent className="p-4 text-center">
                <CheckCircle2 className="w-6 h-6 text-green-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{successionPlan.summary?.roles_with_ready_successor}</p>
                <p className="text-green-400 text-xs">Roles Covered</p>
              </CardContent>
            </Card>
            <Card className="bg-red-900/30 border-red-800">
              <CardContent className="p-4 text-center">
                <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{successionPlan.summary?.roles_at_risk}</p>
                <p className="text-red-400 text-xs">Roles at Risk</p>
              </CardContent>
            </Card>
            <Card className="bg-blue-900/30 border-blue-800">
              <CardContent className="p-4 text-center">
                <Target className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{successionPlan.summary?.avg_successor_readiness}%</p>
                <p className="text-blue-400 text-xs">Avg Readiness</p>
              </CardContent>
            </Card>
          </div>

          {/* Key Insight */}
          <Card className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 border-amber-800">
            <CardContent className="p-4 flex items-start gap-4">
              <Lightbulb className="w-6 h-6 text-amber-400 flex-shrink-0" />
              <p className="text-gray-300">{successionPlan.summary?.key_insight}</p>
            </CardContent>
          </Card>

          <Tabs defaultValue="roles" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="roles">Role Succession</TabsTrigger>
              <TabsTrigger value="risks">Organization Risks</TabsTrigger>
              <TabsTrigger value="investments">Development Investments</TabsTrigger>
              {selectedSuccessor && <TabsTrigger value="simulation">Readiness Simulation</TabsTrigger>}
            </TabsList>

            <TabsContent value="roles">
              <div className="grid md:grid-cols-2 gap-4">
                {successionPlan.role_succession?.map((role, i) => (
                  <Card 
                    key={i} 
                    className={`bg-gray-900 border-gray-800 cursor-pointer transition-all ${
                      selectedRole?.role === role.role ? 'ring-2 ring-amber-500' : 'hover:border-gray-700'
                    }`}
                    onClick={() => setSelectedRole(selectedRole?.role === role.role ? null : role)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-white text-lg flex items-center gap-2">
                            <Crown className="w-4 h-4 text-amber-400" />
                            {role.role}
                          </CardTitle>
                          <CardDescription className="text-gray-400">
                            Current: {role.current_holder || 'Vacant'} • {role.department}
                          </CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getRiskColor(role.risk_level)}>{role.risk_level} Risk</Badge>
                          <Badge className={getStatusColor(role.succession_status)}>{role.succession_status}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {role.successors?.map((succ, j) => (
                          <div 
                            key={j} 
                            className={`p-3 rounded-lg border ${j === 0 ? 'bg-green-900/20 border-green-800' : 'bg-gray-800 border-gray-700'}`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-3">
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback className={j === 0 ? 'bg-green-600' : 'bg-gray-600'}>
                                    {succ.name?.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-white text-sm font-medium">{succ.name}</p>
                                  <p className="text-gray-500 text-xs">{succ.current_role}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-white font-bold">{succ.readiness_score}%</p>
                                <p className="text-gray-500 text-xs">{succ.time_to_ready}</p>
                              </div>
                            </div>
                            <Progress value={succ.readiness_score} className="h-2 mb-2" />
                            <div className="flex items-center justify-between">
                              <div className="flex gap-1">
                                <Badge variant="outline" className="text-xs border-gray-700">
                                  Leadership: {succ.leadership_potential}%
                                </Badge>
                                <Badge variant="outline" className="text-xs border-gray-700">
                                  Flight Risk: {succ.flight_risk}%
                                </Badge>
                              </div>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="text-cyan-400 h-7"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  simulateReadiness(succ, role.role);
                                }}
                              >
                                <Play className="w-3 h-3 mr-1" /> Simulate
                              </Button>
                            </div>

                            {selectedRole?.role === role.role && (
                              <div className="mt-3 pt-3 border-t border-gray-700 space-y-3">
                                {/* Skill Gaps */}
                                {succ.skill_gaps?.length > 0 && (
                                  <div>
                                    <p className="text-red-400 text-xs mb-1">Skill Gaps</p>
                                    <div className="flex flex-wrap gap-1">
                                      {succ.skill_gaps.map((gap, k) => (
                                        <Badge key={k} variant="outline" className="text-xs border-red-800 text-red-400">{gap}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {/* Strengths Match */}
                                {succ.strengths_match?.length > 0 && (
                                  <div>
                                    <p className="text-green-400 text-xs mb-1">Strengths Match</p>
                                    <div className="flex flex-wrap gap-1">
                                      {succ.strengths_match.map((str, k) => (
                                        <Badge key={k} variant="outline" className="text-xs border-green-800 text-green-400">{str}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {/* Development Plan */}
                                {succ.development_plan && (
                                  <div className="p-2 bg-gray-700 rounded-lg">
                                    <p className="text-amber-400 text-xs font-medium mb-2">Development Plan</p>
                                    {succ.development_plan.training?.length > 0 && (
                                      <div className="mb-2">
                                        <p className="text-gray-500 text-xs">Training:</p>
                                        <ul className="text-gray-300 text-xs space-y-0.5">
                                          {succ.development_plan.training.map((t, k) => (
                                            <li key={k} className="flex items-start gap-1">
                                              <BookOpen className="w-3 h-3 mt-0.5 text-blue-400" /> {t}
                                            </li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}
                                    {succ.development_plan.mentorship && (
                                      <p className="text-gray-300 text-xs mb-2">
                                        <span className="text-gray-500">Mentorship:</span> {succ.development_plan.mentorship}
                                      </p>
                                    )}
                                    {succ.development_plan.stretch_assignments?.length > 0 && (
                                      <div>
                                        <p className="text-gray-500 text-xs">Stretch Assignments:</p>
                                        <ul className="text-gray-300 text-xs space-y-0.5">
                                          {succ.development_plan.stretch_assignments.map((a, k) => (
                                            <li key={k} className="flex items-start gap-1">
                                              <Target className="w-3 h-3 mt-0.5 text-purple-400" /> {a}
                                            </li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}
                                  </div>
                                )}

                                {/* Milestones */}
                                {succ.development_plan?.milestones?.length > 0 && (
                                  <div>
                                    <p className="text-gray-400 text-xs mb-2">Milestones</p>
                                    <div className="flex gap-2 overflow-x-auto pb-2">
                                      {succ.development_plan.milestones.map((m, k) => (
                                        <div key={k} className="flex-shrink-0 p-2 bg-gray-800 rounded-lg text-center min-w-[100px]">
                                          <p className="text-cyan-400 text-xs">Month {m.month}</p>
                                          <p className="text-white font-bold">{m.readiness_target}%</p>
                                          <p className="text-gray-400 text-xs truncate">{m.milestone}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="risks">
              <div className="space-y-4">
                {successionPlan.organization_risks?.map((risk, i) => (
                  <Card key={i} className={`border ${
                    risk.severity === 'High' ? 'bg-red-900/20 border-red-800' :
                    risk.severity === 'Medium' ? 'bg-orange-900/20 border-orange-800' :
                    'bg-yellow-900/20 border-yellow-800'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-3">
                          <AlertTriangle className={`w-5 h-5 flex-shrink-0 ${
                            risk.severity === 'High' ? 'text-red-400' :
                            risk.severity === 'Medium' ? 'text-orange-400' : 'text-yellow-400'
                          }`} />
                          <div>
                            <p className="text-white font-medium">{risk.risk}</p>
                            <div className="flex gap-1 mt-1">
                              {risk.affected_roles?.map((r, j) => (
                                <Badge key={j} variant="outline" className="text-xs border-gray-700 text-gray-400">{r}</Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <Badge className={getRiskColor(risk.severity)}>{risk.severity}</Badge>
                      </div>
                      <div className="p-3 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-xs mb-1">Mitigation</p>
                        <p className="text-gray-300 text-sm">{risk.mitigation}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Priority Actions */}
                <Card className="bg-amber-900/20 border-amber-800">
                  <CardHeader>
                    <CardTitle className="text-amber-400 flex items-center gap-2">
                      <Zap className="w-5 h-5" /> Priority Actions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {successionPlan.priority_actions?.map((action, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5" /> {action}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="investments">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Recommended Development Investments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {successionPlan.development_investments?.map((inv, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <p className="text-white font-medium">{inv.investment}</p>
                          <div className="flex gap-2">
                            <Badge variant="outline" className="border-gray-700 text-gray-400">
                              <Users className="w-3 h-3 mr-1" /> {inv.beneficiaries} beneficiaries
                            </Badge>
                            <Badge variant="outline" className="border-gray-700 text-gray-400">
                              <Clock className="w-3 h-3 mr-1" /> {inv.timeline}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-gray-400 text-sm">{inv.impact}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="simulation">
              {isSimulating ? (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-20 text-center">
                    <RefreshCw className="w-12 h-12 text-amber-400 animate-spin mx-auto mb-4" />
                    <p className="text-gray-400">Simulating readiness progression...</p>
                  </CardContent>
                </Card>
              ) : readinessSimulation ? (
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white">
                      Readiness Simulation: {readinessSimulation.candidate_name}
                    </CardTitle>
                    <CardDescription className="text-gray-400">
                      24-month progression to {readinessSimulation.target_role}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Progression Chart */}
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={readinessSimulation.monthly_progression}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="month" stroke="#9ca3af" tickFormatter={(v) => `M${v}`} />
                        <YAxis domain={[0, 100]} stroke="#9ca3af" />
                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                        <Line type="monotone" dataKey="readiness_score" stroke="#f59e0b" strokeWidth={2} name="Readiness" />
                        <Line type="monotone" dataKey="confidence" stroke="#8b5cf6" strokeWidth={2} name="Confidence" />
                      </LineChart>
                    </ResponsiveContainer>

                    {/* Scenarios */}
                    <div className="grid md:grid-cols-3 gap-4">
                      <Card className="bg-green-900/20 border-green-800">
                        <CardContent className="p-4">
                          <p className="text-green-400 text-sm font-medium mb-2">Accelerated</p>
                          <p className="text-white font-bold text-lg">{readinessSimulation.scenarios?.accelerated?.time_to_ready}</p>
                          <p className="text-gray-400 text-xs mb-2">{readinessSimulation.scenarios?.accelerated?.probability}% probability</p>
                          <ul className="text-xs text-gray-300 space-y-1">
                            {readinessSimulation.scenarios?.accelerated?.requirements?.slice(0, 2).map((r, i) => (
                              <li key={i}>• {r}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                      <Card className="bg-blue-900/20 border-blue-800">
                        <CardContent className="p-4">
                          <p className="text-blue-400 text-sm font-medium mb-2">Standard</p>
                          <p className="text-white font-bold text-lg">{readinessSimulation.scenarios?.standard?.time_to_ready}</p>
                          <p className="text-gray-400 text-xs mb-2">{readinessSimulation.scenarios?.standard?.probability}% probability</p>
                          <ul className="text-xs text-gray-300 space-y-1">
                            {readinessSimulation.scenarios?.standard?.requirements?.slice(0, 2).map((r, i) => (
                              <li key={i}>• {r}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                      <Card className="bg-red-900/20 border-red-800">
                        <CardContent className="p-4">
                          <p className="text-red-400 text-sm font-medium mb-2">Delayed</p>
                          <p className="text-white font-bold text-lg">{readinessSimulation.scenarios?.delayed?.time_to_ready}</p>
                          <p className="text-gray-400 text-xs mb-2">{readinessSimulation.scenarios?.delayed?.probability}% probability</p>
                          <ul className="text-xs text-gray-300 space-y-1">
                            {readinessSimulation.scenarios?.delayed?.risk_factors?.slice(0, 2).map((r, i) => (
                              <li key={i}>• {r}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Success Factors & Warnings */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                        <p className="text-green-400 text-sm font-medium mb-2">Critical Success Factors</p>
                        <ul className="space-y-1">
                          {readinessSimulation.critical_success_factors?.map((f, i) => (
                            <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                              <CheckCircle2 className="w-3 h-3 text-green-400 mt-1" /> {f}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-4 bg-orange-900/20 border border-orange-800 rounded-lg">
                        <p className="text-orange-400 text-sm font-medium mb-2">Early Warning Signs</p>
                        <ul className="space-y-1">
                          {readinessSimulation.early_warning_signs?.map((s, i) => (
                            <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                              <AlertTriangle className="w-3 h-3 text-orange-400 mt-1" /> {s}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Recommendation */}
                    <div className="p-4 bg-amber-900/20 border border-amber-800 rounded-lg">
                      <p className="text-amber-400 text-sm font-medium mb-2">Recommendation</p>
                      <p className="text-gray-300">{readinessSimulation.recommendation}</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-20 text-center">
                    <Play className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">Click "Simulate" on a successor to view readiness progression</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="py-20 text-center">
            <Crown className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 mb-2">Identify successors for critical roles</p>
            <p className="text-gray-500 text-sm mb-6">AI analyzes skills, performance, and leadership potential</p>
            <Button onClick={analyzeSuccession} disabled={isAnalyzing} className="bg-white text-black hover:bg-gray-200">
              <Brain className="w-4 h-4 mr-2" /> Analyze Succession
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}