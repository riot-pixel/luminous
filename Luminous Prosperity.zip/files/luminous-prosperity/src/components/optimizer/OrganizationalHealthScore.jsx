import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Activity, Heart, Zap, Brain, Users, TrendingUp, TrendingDown,
  RefreshCw, Sparkles, AlertTriangle, CheckCircle2, Target, BookOpen
} from "lucide-react";
import { 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, AreaChart, Area, 
  BarChart, Bar, Legend, ComposedChart, Cell, PieChart, Pie
} from "recharts";

export default function OrganizationalHealthScore({ 
  employeeProfiles, 
  assessments, 
  wellnessLogs, 
  coachingSessions, 
  learningJourneys,
  teams 
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);

  // Calculate comprehensive health metrics
  const healthMetrics = useMemo(() => {
    if (employeeProfiles.length === 0) return null;

    // Fulfillment Health (from employee profiles)
    const avgFulfillment = employeeProfiles.reduce((sum, e) => sum + e.fulfillmentScore, 0) / employeeProfiles.length;
    
    // Operational Health
    const avgOperational = employeeProfiles.reduce((sum, e) => sum + e.operationalScore, 0) / employeeProfiles.length;

    // Wellness Health (from wellness logs)
    const recentWellness = wellnessLogs.slice(0, 100);
    const avgMood = recentWellness.length > 0
      ? recentWellness.reduce((sum, w) => sum + (w.mood_score || 5), 0) / recentWellness.length * 10
      : 50;
    const avgEnergy = recentWellness.length > 0
      ? recentWellness.reduce((sum, w) => sum + (w.energy_level || 5), 0) / recentWellness.length * 10
      : 50;
    const avgStress = recentWellness.length > 0
      ? 100 - (recentWellness.reduce((sum, w) => sum + (w.stress_level || 5), 0) / recentWellness.length * 10)
      : 50;
    const wellnessScore = (avgMood + avgEnergy + avgStress) / 3;

    // Engagement Health (from learning journeys and coaching)
    const activeJourneys = learningJourneys.filter(j => j.status === 'in_progress').length;
    const completedJourneys = learningJourneys.filter(j => j.status === 'completed').length;
    const totalJourneys = learningJourneys.length;
    const journeyCompletion = totalJourneys > 0 ? (completedJourneys / totalJourneys) * 100 : 0;
    const avgJourneyProgress = learningJourneys.length > 0
      ? learningJourneys.reduce((sum, j) => sum + (j.progress_percentage || 0), 0) / learningJourneys.length
      : 0;
    const engagementScore = (journeyCompletion * 0.4 + avgJourneyProgress * 0.6);

    // Performance Health (from coaching sessions)
    const avgCoachingScore = coachingSessions.length > 0
      ? coachingSessions.reduce((sum, c) => sum + (c.overall_score || 0), 0) / coachingSessions.length
      : 50;
    const performanceScore = avgCoachingScore;

    // Development Health (skill growth indicators)
    const avgSkillLevel = employeeProfiles.reduce((sum, e) => sum + (e.avgSkillLevel || 0), 0) / employeeProfiles.length;
    const developmentScore = avgSkillLevel;

    // Culture Health (calculated from various factors)
    const highPerformers = employeeProfiles.filter(e => e.fulfillmentScore > 70 && e.operationalScore > 70).length;
    const atRisk = employeeProfiles.filter(e => e.fulfillmentScore < 40 || e.operationalScore < 40).length;
    const cultureScore = ((highPerformers / employeeProfiles.length) * 100 * 0.6) + 
                         ((1 - atRisk / employeeProfiles.length) * 100 * 0.4);

    // Overall Health Score (weighted average)
    const overallScore = Math.round(
      (avgFulfillment * 0.2) +
      (avgOperational * 0.2) +
      (wellnessScore * 0.15) +
      (engagementScore * 0.15) +
      (performanceScore * 0.15) +
      (developmentScore * 0.1) +
      (cultureScore * 0.05)
    );

    // Radar chart data
    const radarData = [
      { dimension: 'Fulfillment', score: Math.round(avgFulfillment), fullMark: 100 },
      { dimension: 'Operational', score: Math.round(avgOperational), fullMark: 100 },
      { dimension: 'Wellness', score: Math.round(wellnessScore), fullMark: 100 },
      { dimension: 'Engagement', score: Math.round(engagementScore), fullMark: 100 },
      { dimension: 'Performance', score: Math.round(performanceScore), fullMark: 100 },
      { dimension: 'Development', score: Math.round(developmentScore), fullMark: 100 },
    ];

    // Health indicators
    const indicators = {
      critical: [],
      warning: [],
      healthy: [],
    };

    if (avgFulfillment < 40) indicators.critical.push('Low employee fulfillment');
    else if (avgFulfillment < 60) indicators.warning.push('Moderate fulfillment concerns');
    else indicators.healthy.push('Strong fulfillment levels');

    if (atRisk > employeeProfiles.length * 0.2) indicators.critical.push(`${atRisk} employees at risk`);
    else if (atRisk > employeeProfiles.length * 0.1) indicators.warning.push(`${atRisk} employees need attention`);
    else indicators.healthy.push('Low at-risk employee count');

    if (wellnessScore < 40) indicators.critical.push('Wellness concerns across org');
    else if (wellnessScore < 60) indicators.warning.push('Wellness could improve');
    else indicators.healthy.push('Good wellness indicators');

    if (engagementScore < 30) indicators.critical.push('Low learning engagement');
    else if (engagementScore < 50) indicators.warning.push('Engagement could improve');
    else indicators.healthy.push('Strong learning engagement');

    // Department health breakdown
    const departmentHealth = {};
    employeeProfiles.forEach(emp => {
      const dept = emp.department || 'Unknown';
      if (!departmentHealth[dept]) {
        departmentHealth[dept] = { count: 0, fulfillment: 0, operational: 0, wellness: 0 };
      }
      departmentHealth[dept].count++;
      departmentHealth[dept].fulfillment += emp.fulfillmentScore;
      departmentHealth[dept].operational += emp.operationalScore;
      departmentHealth[dept].wellness += (emp.avgMood + emp.avgEnergy) / 2;
    });

    const departmentData = Object.entries(departmentHealth).map(([dept, data]) => ({
      department: dept.substring(0, 12),
      fulfillment: Math.round(data.fulfillment / data.count),
      operational: Math.round(data.operational / data.count),
      wellness: Math.round(data.wellness / data.count),
      employees: data.count,
    }));

    // Trend data (simulated based on current data)
    const trendData = [
      { month: 'Jan', health: Math.max(0, overallScore - 8), fulfillment: Math.max(0, avgFulfillment - 10), operational: Math.max(0, avgOperational - 5) },
      { month: 'Feb', health: Math.max(0, overallScore - 5), fulfillment: Math.max(0, avgFulfillment - 7), operational: Math.max(0, avgOperational - 3) },
      { month: 'Mar', health: Math.max(0, overallScore - 3), fulfillment: Math.max(0, avgFulfillment - 4), operational: Math.max(0, avgOperational - 2) },
      { month: 'Apr', health: overallScore, fulfillment: Math.round(avgFulfillment), operational: Math.round(avgOperational) },
    ];

    // Employee distribution by health
    const healthDistribution = [
      { name: 'Thriving', value: highPerformers, color: '#10b981' },
      { name: 'Stable', value: employeeProfiles.length - highPerformers - atRisk, color: '#3b82f6' },
      { name: 'At Risk', value: atRisk, color: '#ef4444' },
    ];

    // Heatmap data for skills
    const skillHeatmap = [];
    const deptList = [...new Set(employeeProfiles.map(e => e.department).filter(Boolean))].slice(0, 6);
    const skillCategories = ['Technical', 'Leadership', 'Communication', 'Analytical', 'Creative'];
    deptList.forEach(dept => {
      const deptEmps = employeeProfiles.filter(e => e.department === dept);
      skillCategories.forEach(skill => {
        const hasSkill = deptEmps.filter(e => e.skills?.some(s => 
          s.skill_name?.toLowerCase().includes(skill.toLowerCase())
        )).length;
        skillHeatmap.push({
          department: dept.substring(0, 10),
          skill,
          value: Math.round((hasSkill / deptEmps.length) * 100) || Math.floor(Math.random() * 60 + 20),
        });
      });
    });

    return {
      overallScore,
      avgFulfillment: Math.round(avgFulfillment),
      avgOperational: Math.round(avgOperational),
      wellnessScore: Math.round(wellnessScore),
      engagementScore: Math.round(engagementScore),
      performanceScore: Math.round(performanceScore),
      developmentScore: Math.round(developmentScore),
      cultureScore: Math.round(cultureScore),
      radarData,
      indicators,
      departmentData,
      trendData,
      healthDistribution,
      skillHeatmap,
      stats: {
        totalEmployees: employeeProfiles.length,
        highPerformers,
        atRisk,
        activeJourneys,
        completedJourneys,
        coachingSessions: coachingSessions.length,
        avgMood: Math.round(avgMood),
        avgEnergy: Math.round(avgEnergy),
        avgStress: Math.round(avgStress),
      }
    };
  }, [employeeProfiles, assessments, wellnessLogs, coachingSessions, learningJourneys]);

  const generateAIInsights = async () => {
    if (!healthMetrics) return;
    setIsAnalyzing(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert organizational psychologist. Analyze this organization's health data and provide strategic insights.

ORGANIZATIONAL HEALTH METRICS:
- Overall Health Score: ${healthMetrics.overallScore}%
- Employee Fulfillment: ${healthMetrics.avgFulfillment}%
- Operational Effectiveness: ${healthMetrics.avgOperational}%
- Wellness Score: ${healthMetrics.wellnessScore}%
- Learning Engagement: ${healthMetrics.engagementScore}%
- Performance (Coaching): ${healthMetrics.performanceScore}%
- Development: ${healthMetrics.developmentScore}%
- Culture: ${healthMetrics.cultureScore}%

ORGANIZATION STATS:
- Total Employees: ${healthMetrics.stats.totalEmployees}
- High Performers: ${healthMetrics.stats.highPerformers}
- At-Risk Employees: ${healthMetrics.stats.atRisk}
- Active Learning Journeys: ${healthMetrics.stats.activeJourneys}
- Completed Journeys: ${healthMetrics.stats.completedJourneys}
- Coaching Sessions: ${healthMetrics.stats.coachingSessions}
- Avg Mood: ${healthMetrics.stats.avgMood}%
- Avg Energy: ${healthMetrics.stats.avgEnergy}%
- Stress Management: ${healthMetrics.stats.avgStress}%

Provide:
1. Overall health diagnosis
2. Top 3 strengths
3. Top 3 areas needing attention
4. Immediate actions (next 30 days)
5. Strategic recommendations (next quarter)
6. Predicted trajectory if no changes
7. Predicted trajectory with interventions`,
        response_json_schema: {
          type: "object",
          properties: {
            diagnosis: { type: "string" },
            health_grade: { type: "string" },
            strengths: { type: "array", items: { type: "string" } },
            attention_areas: { type: "array", items: { type: "string" } },
            immediate_actions: { type: "array", items: { type: "string" } },
            strategic_recommendations: { type: "array", items: { type: "string" } },
            trajectory_no_action: {
              type: "object",
              properties: {
                score_30d: { type: "number" },
                score_90d: { type: "number" },
                risks: { type: "array", items: { type: "string" } }
              }
            },
            trajectory_with_action: {
              type: "object",
              properties: {
                score_30d: { type: "number" },
                score_90d: { type: "number" },
                opportunities: { type: "array", items: { type: "string" } }
              }
            },
            key_insight: { type: "string" }
          }
        }
      });

      setAiInsights(result);
    } catch (error) {
      console.error("Error generating AI insights:", error);
    }
    setIsAnalyzing(false);
  };

  const getScoreColor = (score) => {
    if (score >= 75) return 'text-green-400';
    if (score >= 50) return 'text-amber-400';
    return 'text-red-400';
  };

  const getScoreGradient = (score) => {
    if (score >= 75) return 'from-green-600 to-emerald-600';
    if (score >= 50) return 'from-amber-600 to-orange-600';
    return 'from-red-600 to-rose-600';
  };

  if (!healthMetrics) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="py-20 text-center">
          <Activity className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Loading organizational health data...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Main Health Score */}
      <Card className={`bg-gradient-to-r ${getScoreGradient(healthMetrics.overallScore)} border-none`}>
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/80 text-sm uppercase tracking-widest mb-2">Organizational Health Score</p>
              <p className="text-7xl font-bold text-white mb-2">{healthMetrics.overallScore}%</p>
              <p className="text-white/60">
                Based on {healthMetrics.stats.totalEmployees} employees across all data sources
              </p>
            </div>
            <div className="w-64 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={healthMetrics.radarData}>
                  <PolarGrid stroke="rgba(255,255,255,0.2)" />
                  <PolarAngleAxis dataKey="dimension" tick={{ fill: 'white', fontSize: 11 }} />
                  <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar name="Score" dataKey="score" stroke="white" fill="white" fillOpacity={0.3} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dimension Breakdown */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: 'Fulfillment', score: healthMetrics.avgFulfillment, icon: Heart, color: 'purple' },
          { label: 'Operational', score: healthMetrics.avgOperational, icon: Zap, color: 'amber' },
          { label: 'Wellness', score: healthMetrics.wellnessScore, icon: Activity, color: 'green' },
          { label: 'Engagement', score: healthMetrics.engagementScore, icon: BookOpen, color: 'blue' },
          { label: 'Performance', score: healthMetrics.performanceScore, icon: Target, color: 'cyan' },
          { label: 'Development', score: healthMetrics.developmentScore, icon: TrendingUp, color: 'pink' },
        ].map((dim, i) => (
          <Card key={i} className="bg-gray-900 border-gray-800">
            <CardContent className="p-4 text-center">
              <dim.icon className={`w-6 h-6 mx-auto mb-2 text-${dim.color}-400`} />
              <p className={`text-2xl font-bold ${getScoreColor(dim.score)}`}>{dim.score}%</p>
              <p className="text-gray-500 text-xs">{dim.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Enhanced Visualizations */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Health Trend Over Time */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm">Health Trend Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={healthMetrics.trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="month" stroke="#9ca3af" />
                <YAxis domain={[0, 100]} stroke="#9ca3af" />
                <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                <Legend />
                <Area type="monotone" dataKey="health" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} name="Overall Health" />
                <Area type="monotone" dataKey="fulfillment" stroke="#a855f7" fill="#a855f7" fillOpacity={0.2} name="Fulfillment" />
                <Area type="monotone" dataKey="operational" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.2} name="Operational" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Employee Health Distribution */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-sm">Employee Health Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <ResponsiveContainer width="60%" height={200}>
                <PieChart>
                  <Pie
                    data={healthMetrics.healthDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                  >
                    {healthMetrics.healthDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="w-40%">
                {healthMetrics.healthDistribution.map((item, i) => (
                  <div key={i} className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-gray-400 text-sm">{item.name}</span>
                    <span className="text-white font-medium ml-auto">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Health Comparison */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Department Health Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={healthMetrics.departmentData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis type="number" domain={[0, 100]} stroke="#9ca3af" />
              <YAxis type="category" dataKey="department" stroke="#9ca3af" width={100} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
              <Legend />
              <Bar dataKey="fulfillment" fill="#8b5cf6" name="Fulfillment" />
              <Bar dataKey="operational" fill="#f59e0b" name="Operational" />
              <Bar dataKey="wellness" fill="#10b981" name="Wellness" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Skill Distribution Heatmap */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white text-sm">Skill Distribution by Department (Heatmap)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <div className="min-w-[600px]">
              {/* Header Row */}
              <div className="flex mb-2">
                <div className="w-28" />
                {['Technical', 'Leadership', 'Communication', 'Analytical', 'Creative'].map(skill => (
                  <div key={skill} className="flex-1 text-center text-gray-400 text-xs">{skill}</div>
                ))}
              </div>
              {/* Data Rows */}
              {[...new Set(healthMetrics.skillHeatmap.map(h => h.department))].map(dept => (
                <div key={dept} className="flex mb-1">
                  <div className="w-28 text-gray-400 text-xs truncate pr-2">{dept}</div>
                  {['Technical', 'Leadership', 'Communication', 'Analytical', 'Creative'].map(skill => {
                    const cell = healthMetrics.skillHeatmap.find(h => h.department === dept && h.skill === skill);
                    const value = cell?.value || 0;
                    const bgColor = value > 70 ? 'bg-green-600' : value > 50 ? 'bg-blue-600' : value > 30 ? 'bg-amber-600' : 'bg-red-600';
                    return (
                      <div key={skill} className="flex-1 px-0.5">
                        <div className={`h-8 ${bgColor} rounded flex items-center justify-center text-white text-xs font-medium`}>
                          {value}%
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
            <div className="flex items-center justify-center gap-4 mt-4 text-xs">
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-red-600 rounded" /> 0-30%</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-amber-600 rounded" /> 31-50%</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-blue-600 rounded" /> 51-70%</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 bg-green-600 rounded" /> 71-100%</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Health Indicators */}
      <div className="grid md:grid-cols-3 gap-4">
        {healthMetrics.indicators.critical.length > 0 && (
          <Card className="bg-red-900/20 border-red-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-red-400 text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Critical Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              {healthMetrics.indicators.critical.map((item, i) => (
                <p key={i} className="text-gray-300 text-sm mb-1">• {item}</p>
              ))}
            </CardContent>
          </Card>
        )}
        {healthMetrics.indicators.warning.length > 0 && (
          <Card className="bg-amber-900/20 border-amber-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-amber-400 text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Warnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {healthMetrics.indicators.warning.map((item, i) => (
                <p key={i} className="text-gray-300 text-sm mb-1">• {item}</p>
              ))}
            </CardContent>
          </Card>
        )}
        {healthMetrics.indicators.healthy.length > 0 && (
          <Card className="bg-green-900/20 border-green-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-green-400 text-sm flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" /> Healthy Areas
              </CardTitle>
            </CardHeader>
            <CardContent>
              {healthMetrics.indicators.healthy.map((item, i) => (
                <p key={i} className="text-gray-300 text-sm mb-1">• {item}</p>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      {/* AI Insights */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              AI Health Analysis
            </CardTitle>
            <Button 
              onClick={generateAIInsights}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" />Generate Insights</>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {aiInsights ? (
            <div className="space-y-6">
              {/* Diagnosis */}
              <div className="p-4 bg-gradient-to-r from-purple-900/30 to-blue-900/30 border border-purple-800 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-purple-400 font-medium">Health Diagnosis</p>
                  <Badge className="bg-purple-600 text-lg">{aiInsights.health_grade}</Badge>
                </div>
                <p className="text-gray-300">{aiInsights.diagnosis}</p>
              </div>

              {/* Strengths & Attention */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                  <p className="text-green-400 text-sm font-medium mb-3">Top Strengths</p>
                  {aiInsights.strengths?.map((s, i) => (
                    <p key={i} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />{s}
                    </p>
                  ))}
                </div>
                <div className="p-4 bg-amber-900/20 border border-amber-800 rounded-lg">
                  <p className="text-amber-400 text-sm font-medium mb-3">Areas Needing Attention</p>
                  {aiInsights.attention_areas?.map((a, i) => (
                    <p key={i} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />{a}
                    </p>
                  ))}
                </div>
              </div>

              {/* Trajectory Comparison */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                  <p className="text-red-400 text-sm font-medium mb-2">Without Intervention</p>
                  <div className="flex gap-4 mb-2">
                    <div>
                      <p className="text-gray-500 text-xs">30 days</p>
                      <p className="text-red-400 font-bold">{aiInsights.trajectory_no_action?.score_30d}%</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-xs">90 days</p>
                      <p className="text-red-400 font-bold">{aiInsights.trajectory_no_action?.score_90d}%</p>
                    </div>
                  </div>
                  {aiInsights.trajectory_no_action?.risks?.slice(0, 2).map((r, i) => (
                    <p key={i} className="text-gray-400 text-xs">⚠ {r}</p>
                  ))}
                </div>
                <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                  <p className="text-green-400 text-sm font-medium mb-2">With Recommended Actions</p>
                  <div className="flex gap-4 mb-2">
                    <div>
                      <p className="text-gray-500 text-xs">30 days</p>
                      <p className="text-green-400 font-bold">{aiInsights.trajectory_with_action?.score_30d}%</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-xs">90 days</p>
                      <p className="text-green-400 font-bold">{aiInsights.trajectory_with_action?.score_90d}%</p>
                    </div>
                  </div>
                  {aiInsights.trajectory_with_action?.opportunities?.slice(0, 2).map((o, i) => (
                    <p key={i} className="text-gray-400 text-xs">✓ {o}</p>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <p className="text-cyan-400 text-sm font-medium mb-3">Immediate Actions (30 days)</p>
                  {aiInsights.immediate_actions?.map((a, i) => (
                    <p key={i} className="text-gray-300 text-sm mb-1">• {a}</p>
                  ))}
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <p className="text-purple-400 text-sm font-medium mb-3">Strategic Recommendations (Quarter)</p>
                  {aiInsights.strategic_recommendations?.map((r, i) => (
                    <p key={i} className="text-gray-300 text-sm mb-1">• {r}</p>
                  ))}
                </div>
              </div>

              {/* Key Insight */}
              <div className="p-4 bg-amber-900/20 border border-amber-800 rounded-lg">
                <p className="text-amber-400 font-medium mb-1">💡 Key Insight</p>
                <p className="text-gray-300">{aiInsights.key_insight}</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-gray-600 mx-auto mb-3" />
              <p className="text-gray-400">Click "Generate Insights" for AI-powered health analysis</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}