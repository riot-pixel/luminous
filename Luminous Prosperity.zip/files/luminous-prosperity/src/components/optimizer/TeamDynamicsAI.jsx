import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Users, Brain, RefreshCw, TrendingUp, TrendingDown, AlertTriangle,
  Star, Target, Zap, CheckCircle2, Lightbulb, ArrowRight, Activity,
  Network, BarChart3, Heart, Shield
} from "lucide-react";
import { 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, LineChart, Line, Legend, ScatterChart, Scatter, ZAxis, Sankey
} from "recharts";
import CollaborationNetworkGraph from "./CollaborationNetworkGraph";

export default function TeamDynamicsAI({
  teams,
  employeeProfiles,
  assessments,
  coachingSessions,
  learningJourneys,
  wellnessLogs
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [selectedTeam, setSelectedTeam] = useState(null);

  // Calculate team metrics
  const teamMetrics = useMemo(() => {
    if (!teams || teams.length === 0) {
      // Create pseudo-teams from departments if no teams exist
      const departments = [...new Set(employeeProfiles.map(e => e.department).filter(Boolean))];
      return departments.map(dept => {
        const members = employeeProfiles.filter(e => e.department === dept);
        if (members.length === 0) return null;

        const avgFulfillment = members.reduce((s, m) => s + (m.fulfillmentScore || 0), 0) / members.length;
        const avgOperational = members.reduce((s, m) => s + (m.operationalScore || 0), 0) / members.length;
        const avgSkillLevel = members.reduce((s, m) => s + (m.avgSkillLevel || 0), 0) / members.length;
        const avgMood = members.reduce((s, m) => s + (m.avgMood || 50), 0) / members.length;
        const avgEnergy = members.reduce((s, m) => s + (m.avgEnergy || 50), 0) / members.length;

        // Skill diversity
        const allSkills = new Set();
        members.forEach(m => m.skills?.forEach(s => allSkills.add(s.skill_name)));
        const skillDiversity = allSkills.size;

        // MBTI diversity
        const mbtiTypes = new Set(members.map(m => m.mbti).filter(Boolean));
        const personalityDiversity = mbtiTypes.size;

        // Collaboration score (based on coaching and learning engagement)
        const teamCoaching = coachingSessions.filter(c => members.some(m => m.email === c.user_email));
        const teamJourneys = learningJourneys.filter(j => members.some(m => m.email === j.user_email));
        const collaborationScore = Math.min(100, (teamCoaching.length * 5) + (teamJourneys.length * 3));

        const overallScore = (avgFulfillment * 0.25 + avgOperational * 0.35 + avgSkillLevel * 0.2 + collaborationScore * 0.2);

        return {
          id: dept,
          name: dept,
          memberCount: members.length,
          members,
          avgFulfillment: Math.round(avgFulfillment),
          avgOperational: Math.round(avgOperational),
          avgSkillLevel: Math.round(avgSkillLevel),
          avgMood: Math.round(avgMood),
          avgEnergy: Math.round(avgEnergy),
          skillDiversity,
          personalityDiversity,
          collaborationScore: Math.round(collaborationScore),
          overallScore: Math.round(overallScore),
          atRiskMembers: members.filter(m => m.fulfillmentScore < 40 || m.operationalScore < 40).length,
          highPerformers: members.filter(m => m.fulfillmentScore > 70 && m.operationalScore > 70).length,
        };
      }).filter(Boolean);
    }

    return teams.map(team => {
      const members = employeeProfiles.filter(e => team.members?.includes(e.email));
      if (members.length === 0) return { ...team, memberCount: 0, overallScore: 0 };

      const avgFulfillment = members.reduce((s, m) => s + (m.fulfillmentScore || 0), 0) / members.length;
      const avgOperational = members.reduce((s, m) => s + (m.operationalScore || 0), 0) / members.length;
      const avgSkillLevel = members.reduce((s, m) => s + (m.avgSkillLevel || 0), 0) / members.length;

      return {
        ...team,
        memberCount: members.length,
        members,
        avgFulfillment: Math.round(avgFulfillment),
        avgOperational: Math.round(avgOperational),
        avgSkillLevel: Math.round(avgSkillLevel),
        overallScore: Math.round((avgFulfillment + avgOperational + avgSkillLevel) / 3),
      };
    });
  }, [teams, employeeProfiles, coachingSessions, learningJourneys]);

  // Sort teams by performance
  const topTeams = [...teamMetrics].sort((a, b) => b.overallScore - a.overallScore).slice(0, 5);
  const strugglingTeams = [...teamMetrics].sort((a, b) => a.overallScore - b.overallScore).slice(0, 5);

  const analyzeTeamDynamics = async () => {
    setIsAnalyzing(true);
    try {
      const teamData = teamMetrics.slice(0, 15).map(t => ({
        name: t.name,
        member_count: t.memberCount,
        avg_fulfillment: t.avgFulfillment,
        avg_operational: t.avgOperational,
        avg_skill_level: t.avgSkillLevel,
        skill_diversity: t.skillDiversity,
        personality_diversity: t.personalityDiversity,
        collaboration_score: t.collaborationScore,
        overall_score: t.overallScore,
        at_risk_members: t.atRiskMembers,
        high_performers: t.highPerformers,
        avg_mood: t.avgMood,
        avg_energy: t.avgEnergy,
        member_mbti_types: [...new Set(t.members?.map(m => m.mbti).filter(Boolean))],
        member_skills: [...new Set(t.members?.flatMap(m => m.skills?.map(s => s.skill_name) || []))].slice(0, 10),
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert in organizational psychology and team dynamics. Analyze these teams deeply.

TEAM DATA:
${JSON.stringify(teamData, null, 2)}

Provide comprehensive analysis:

1. TOP PERFORMING TEAMS ANALYSIS
   - What makes them successful?
   - Key success factors (collaboration, skill synergy, leadership, culture)
   - Patterns that can be replicated

2. STRUGGLING TEAMS ANALYSIS
   - Root causes of underperformance
   - Specific issues (engagement, skill gaps, leadership, burnout)
   - Impact on organization

3. TEAM SYNERGY PATTERNS
   - Which teams could collaborate effectively?
   - Cross-functional opportunities
   - Skill complementarity analysis

4. TEAM INTERVENTIONS
   For each struggling team, provide specific interventions:
   - Development programs needed
   - Leadership changes or coaching
   - Team restructuring suggestions
   - Quick wins vs long-term fixes

5. COLLABORATION NETWORK SUGGESTIONS
   - Potential cross-team projects
   - Knowledge sharing opportunities
   - Mentorship pairings between teams

6. PREDICTIVE INSIGHTS
   - Teams at risk of decline
   - Teams poised for growth
   - Early warning indicators`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: {
              type: "object",
              properties: {
                overall_org_team_health: { type: "number" },
                top_performing_count: { type: "number" },
                struggling_count: { type: "number" },
                key_insight: { type: "string" }
              }
            },
            top_teams_analysis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  team_name: { type: "string" },
                  success_factors: { type: "array", items: { type: "string" } },
                  replicable_patterns: { type: "array", items: { type: "string" } },
                  leadership_quality: { type: "string" },
                  collaboration_style: { type: "string" }
                }
              }
            },
            struggling_teams_analysis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  team_name: { type: "string" },
                  root_causes: { type: "array", items: { type: "string" } },
                  specific_issues: { type: "array", items: { type: "string" } },
                  urgency_level: { type: "string" },
                  impact_on_org: { type: "string" }
                }
              }
            },
            team_interventions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  team_name: { type: "string" },
                  quick_wins: { type: "array", items: { type: "string" } },
                  long_term_fixes: { type: "array", items: { type: "string" } },
                  development_programs: { type: "array", items: { type: "string" } },
                  leadership_recommendations: { type: "string" },
                  expected_improvement: { type: "number" },
                  timeline: { type: "string" }
                }
              }
            },
            cross_team_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  teams_involved: { type: "array", items: { type: "string" } },
                  opportunity_type: { type: "string" },
                  description: { type: "string" },
                  expected_benefit: { type: "string" },
                  implementation_steps: { type: "array", items: { type: "string" } }
                }
              }
            },
            synergy_matrix: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  team_a: { type: "string" },
                  team_b: { type: "string" },
                  synergy_score: { type: "number" },
                  synergy_reason: { type: "string" }
                }
              }
            },
            predictive_insights: {
              type: "object",
              properties: {
                teams_at_risk: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      team_name: { type: "string" },
                      risk_factors: { type: "array", items: { type: "string" } },
                      predicted_decline: { type: "number" },
                      prevention_actions: { type: "array", items: { type: "string" } }
                    }
                  }
                },
                teams_poised_for_growth: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      team_name: { type: "string" },
                      growth_indicators: { type: "array", items: { type: "string" } },
                      predicted_improvement: { type: "number" },
                      acceleration_actions: { type: "array", items: { type: "string" } }
                    }
                  }
                },
                early_warning_indicators: { type: "array", items: { type: "string" } }
              }
            },
            strategic_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setAnalysis(result);
    } catch (error) {
      console.error("Error analyzing team dynamics:", error);
    }
    setIsAnalyzing(false);
  };

  // Prepare chart data
  const teamComparisonData = teamMetrics.slice(0, 10).map(t => ({
    name: t.name?.substring(0, 12) || 'Unknown',
    fulfillment: t.avgFulfillment,
    operational: t.avgOperational,
    skills: t.avgSkillLevel,
    collaboration: t.collaborationScore,
  }));

  const teamScatterData = teamMetrics.map(t => ({
    x: t.avgFulfillment,
    y: t.avgOperational,
    z: t.memberCount * 20,
    name: t.name,
    score: t.overallScore,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/40 via-purple-900/30 to-pink-900/40 border-indigo-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Users className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-white">Team Dynamics AI</h2>
                <p className="text-gray-400 text-sm">Analyze team performance, synergies, and improvement opportunities</p>
              </div>
            </div>
            <Button 
              onClick={analyzeTeamDynamics}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200 px-8"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Analyze Teams</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 text-center">
            <Users className="w-6 h-6 text-indigo-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{teamMetrics.length}</p>
            <p className="text-gray-400 text-xs">Teams</p>
          </CardContent>
        </Card>
        <Card className="bg-green-900/30 border-green-800">
          <CardContent className="p-4 text-center">
            <Star className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{teamMetrics.filter(t => t.overallScore > 70).length}</p>
            <p className="text-green-400 text-xs">High Performing</p>
          </CardContent>
        </Card>
        <Card className="bg-red-900/30 border-red-800">
          <CardContent className="p-4 text-center">
            <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{teamMetrics.filter(t => t.overallScore < 50).length}</p>
            <p className="text-red-400 text-xs">Needs Attention</p>
          </CardContent>
        </Card>
        <Card className="bg-blue-900/30 border-blue-800">
          <CardContent className="p-4 text-center">
            <Activity className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">
              {teamMetrics.length > 0 ? Math.round(teamMetrics.reduce((s, t) => s + t.overallScore, 0) / teamMetrics.length) : 0}%
            </p>
            <p className="text-blue-400 text-xs">Avg Team Health</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="comparison">Team Comparison</TabsTrigger>
          <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
          <TabsTrigger value="interventions">Interventions</TabsTrigger>
          <TabsTrigger value="synergies">Synergies</TabsTrigger>
          <TabsTrigger value="network">
            <Network className="w-4 h-4 mr-1" />Network Graph
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Team Performance Scatter */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-sm">Team Fulfillment vs Operational</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis type="number" dataKey="x" name="Fulfillment" domain={[0, 100]} stroke="#9ca3af" />
                    <YAxis type="number" dataKey="y" name="Operational" domain={[0, 100]} stroke="#9ca3af" />
                    <ZAxis type="number" dataKey="z" range={[50, 400]} />
                    <Tooltip 
                      content={({ payload }) => {
                        if (payload?.[0]) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-gray-800 p-2 rounded border border-gray-700 text-xs">
                              <p className="text-white font-medium">{data.name}</p>
                              <p className="text-purple-400">Fulfillment: {data.x}%</p>
                              <p className="text-amber-400">Operational: {data.y}%</p>
                              <p className="text-cyan-400">Overall: {data.score}%</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Scatter name="Teams" data={teamScatterData} fill="#8b5cf6" />
                  </ScatterChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Team Bars */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white text-sm">Team Metrics Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={teamComparisonData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis type="number" domain={[0, 100]} stroke="#9ca3af" />
                    <YAxis type="category" dataKey="name" stroke="#9ca3af" width={80} tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                    <Bar dataKey="fulfillment" fill="#8b5cf6" name="Fulfillment" />
                    <Bar dataKey="operational" fill="#f59e0b" name="Operational" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Top & Struggling Teams */}
          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <Card className="bg-green-900/20 border-green-800">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center gap-2">
                  <Star className="w-5 h-5" /> Top Performing Teams
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topTeams.map((team, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center text-white font-bold text-sm">
                          {i + 1}
                        </div>
                        <div>
                          <p className="text-white font-medium">{team.name}</p>
                          <p className="text-gray-500 text-xs">{team.memberCount} members</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 font-bold">{team.overallScore}%</p>
                        <p className="text-gray-500 text-xs">{team.highPerformers} stars</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-red-900/20 border-red-800">
              <CardHeader>
                <CardTitle className="text-red-400 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" /> Teams Needing Attention
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {strugglingTeams.map((team, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-sm">
                          !
                        </div>
                        <div>
                          <p className="text-white font-medium">{team.name}</p>
                          <p className="text-gray-500 text-xs">{team.memberCount} members</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-red-400 font-bold">{team.overallScore}%</p>
                        <p className="text-gray-500 text-xs">{team.atRiskMembers} at-risk</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparison">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Multi-Dimensional Team Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={teamComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9ca3af" tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} stroke="#9ca3af" />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                  <Legend />
                  <Bar dataKey="fulfillment" fill="#8b5cf6" name="Fulfillment" />
                  <Bar dataKey="operational" fill="#f59e0b" name="Operational" />
                  <Bar dataKey="skills" fill="#06b6d4" name="Skills" />
                  <Bar dataKey="collaboration" fill="#10b981" name="Collaboration" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Team Cards Grid */}
          <div className="grid md:grid-cols-3 gap-4 mt-6">
            {teamMetrics.slice(0, 9).map((team, i) => (
              <Card 
                key={i} 
                className={`bg-gray-900 border-gray-800 cursor-pointer transition-all ${
                  selectedTeam?.id === team.id ? 'ring-2 ring-purple-500' : 'hover:border-gray-700'
                }`}
                onClick={() => setSelectedTeam(selectedTeam?.id === team.id ? null : team)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-white font-medium">{team.name}</p>
                      <p className="text-gray-500 text-xs">{team.memberCount} members</p>
                    </div>
                    <Badge className={
                      team.overallScore > 70 ? 'bg-green-600' :
                      team.overallScore > 50 ? 'bg-blue-600' : 'bg-red-600'
                    }>
                      {team.overallScore}%
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-500">Fulfillment</span>
                        <span className="text-purple-400">{team.avgFulfillment}%</span>
                      </div>
                      <Progress value={team.avgFulfillment} className="h-1.5" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-500">Operational</span>
                        <span className="text-amber-400">{team.avgOperational}%</span>
                      </div>
                      <Progress value={team.avgOperational} className="h-1.5" />
                    </div>
                  </div>
                  {selectedTeam?.id === team.id && team.members && (
                    <div className="mt-3 pt-3 border-t border-gray-800">
                      <p className="text-gray-400 text-xs mb-2">Team Members</p>
                      <div className="flex flex-wrap gap-1">
                        {team.members.slice(0, 6).map((m, j) => (
                          <Avatar key={j} className="w-6 h-6">
                            <AvatarFallback className="text-[10px] bg-gray-700">
                              {m.full_name?.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                        {team.members.length > 6 && (
                          <span className="text-gray-500 text-xs">+{team.members.length - 6}</span>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analysis">
          {analysis ? (
            <div className="space-y-6">
              {/* Summary */}
              <Card className="bg-gradient-to-r from-indigo-900/30 to-purple-900/30 border-indigo-800">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Lightbulb className="w-8 h-8 text-amber-400 flex-shrink-0" />
                    <div>
                      <p className="text-amber-400 font-medium mb-2">Key Insight</p>
                      <p className="text-gray-300">{analysis.summary?.key_insight}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Top Teams Analysis */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-green-400 flex items-center gap-2">
                    <Star className="w-5 h-5" /> Top Teams Success Factors
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.top_teams_analysis?.map((team, i) => (
                      <div key={i} className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                        <p className="text-white font-medium mb-2">{team.team_name}</p>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-green-400 text-xs mb-2">Success Factors</p>
                            {team.success_factors?.map((f, j) => (
                              <p key={j} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                                <CheckCircle2 className="w-3 h-3 text-green-400 mt-1" /> {f}
                              </p>
                            ))}
                          </div>
                          <div>
                            <p className="text-cyan-400 text-xs mb-2">Replicable Patterns</p>
                            {team.replicable_patterns?.map((p, j) => (
                              <p key={j} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                                <ArrowRight className="w-3 h-3 text-cyan-400 mt-1" /> {p}
                              </p>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Struggling Teams Analysis */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-red-400 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" /> Struggling Teams Root Causes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.struggling_teams_analysis?.map((team, i) => (
                      <div key={i} className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <p className="text-white font-medium">{team.team_name}</p>
                          <Badge className={
                            team.urgency_level === 'high' ? 'bg-red-600' :
                            team.urgency_level === 'medium' ? 'bg-orange-600' : 'bg-yellow-600'
                          }>
                            {team.urgency_level} urgency
                          </Badge>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-red-400 text-xs mb-2">Root Causes</p>
                            {team.root_causes?.map((c, j) => (
                              <p key={j} className="text-gray-300 text-sm mb-1">⚠ {c}</p>
                            ))}
                          </div>
                          <div>
                            <p className="text-orange-400 text-xs mb-2">Specific Issues</p>
                            {team.specific_issues?.map((issue, j) => (
                              <p key={j} className="text-gray-300 text-sm mb-1">• {issue}</p>
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-400 text-xs mt-2">Impact: {team.impact_on_org}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Predictive Insights */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-orange-900/20 border-orange-800">
                  <CardHeader>
                    <CardTitle className="text-orange-400 text-sm">Teams at Risk of Decline</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {analysis.predictive_insights?.teams_at_risk?.map((team, i) => (
                      <div key={i} className="p-3 bg-gray-800 rounded-lg mb-2">
                        <div className="flex justify-between mb-1">
                          <p className="text-white text-sm">{team.team_name}</p>
                          <Badge className="bg-red-600">-{team.predicted_decline}%</Badge>
                        </div>
                        <p className="text-gray-400 text-xs">Risk: {team.risk_factors?.join(', ')}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                <Card className="bg-green-900/20 border-green-800">
                  <CardHeader>
                    <CardTitle className="text-green-400 text-sm">Teams Poised for Growth</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {analysis.predictive_insights?.teams_poised_for_growth?.map((team, i) => (
                      <div key={i} className="p-3 bg-gray-800 rounded-lg mb-2">
                        <div className="flex justify-between mb-1">
                          <p className="text-white text-sm">{team.team_name}</p>
                          <Badge className="bg-green-600">+{team.predicted_improvement}%</Badge>
                        </div>
                        <p className="text-gray-400 text-xs">Indicators: {team.growth_indicators?.join(', ')}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="py-20 text-center">
                <Brain className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400 mb-2">Run AI analysis to get deep team insights</p>
                <Button onClick={analyzeTeamDynamics} disabled={isAnalyzing} className="bg-purple-600 hover:bg-purple-700">
                  <Brain className="w-4 h-4 mr-2" /> Analyze Teams
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="interventions">
          {analysis?.team_interventions ? (
            <div className="space-y-4">
              {analysis.team_interventions.map((intervention, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{intervention.team_name}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-green-600">+{intervention.expected_improvement}% expected</Badge>
                        <Badge variant="outline" className="border-gray-700 text-gray-400">{intervention.timeline}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <p className="text-emerald-400 text-xs font-medium mb-2 flex items-center gap-1">
                          <Zap className="w-3 h-3" /> Quick Wins
                        </p>
                        {intervention.quick_wins?.map((win, j) => (
                          <p key={j} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> {win}
                          </p>
                        ))}
                      </div>
                      <div>
                        <p className="text-purple-400 text-xs font-medium mb-2 flex items-center gap-1">
                          <Target className="w-3 h-3" /> Long-Term Fixes
                        </p>
                        {intervention.long_term_fixes?.map((fix, j) => (
                          <p key={j} className="text-gray-300 text-sm mb-1 flex items-start gap-2">
                            <ArrowRight className="w-3 h-3 text-purple-400 mt-1" /> {fix}
                          </p>
                        ))}
                      </div>
                    </div>
                    {intervention.development_programs?.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-gray-800">
                        <p className="text-cyan-400 text-xs font-medium mb-2">Development Programs</p>
                        <div className="flex flex-wrap gap-2">
                          {intervention.development_programs.map((prog, j) => (
                            <Badge key={j} variant="outline" className="border-cyan-700 text-cyan-400">{prog}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {intervention.leadership_recommendations && (
                      <div className="mt-3 p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                        <p className="text-amber-400 text-xs mb-1">Leadership Recommendation</p>
                        <p className="text-gray-300 text-sm">{intervention.leadership_recommendations}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="py-20 text-center">
                <Target className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Run AI analysis to see team interventions</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="synergies">
          {analysis?.cross_team_opportunities ? (
            <div className="space-y-6">
              {/* Synergy Matrix Visualization */}
              {analysis.synergy_matrix?.length > 0 && (
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Network className="w-5 h-5 text-cyan-400" /> Team Synergy Connections
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {analysis.synergy_matrix.map((synergy, i) => (
                        <div key={i} className="p-3 bg-gradient-to-r from-cyan-900/20 to-blue-900/20 border border-cyan-800 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-white text-sm">{synergy.team_a}</span>
                              <ArrowRight className="w-4 h-4 text-cyan-400" />
                              <span className="text-white text-sm">{synergy.team_b}</span>
                            </div>
                            <Badge className="bg-cyan-600">{synergy.synergy_score}%</Badge>
                          </div>
                          <p className="text-gray-400 text-xs">{synergy.synergy_reason}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Cross-Team Opportunities */}
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Cross-Team Collaboration Opportunities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.cross_team_opportunities.map((opp, i) => (
                      <div key={i} className="p-4 bg-gradient-to-r from-purple-900/20 to-pink-900/20 border border-purple-800 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {opp.teams_involved?.map((team, j) => (
                                <Badge key={j} variant="outline" className="border-purple-700 text-purple-400">{team}</Badge>
                              ))}
                            </div>
                            <Badge className="bg-purple-600">{opp.opportunity_type}</Badge>
                          </div>
                        </div>
                        <p className="text-gray-300 text-sm mb-3">{opp.description}</p>
                        <div className="p-3 bg-gray-800 rounded-lg mb-3">
                          <p className="text-green-400 text-xs font-medium mb-1">Expected Benefit</p>
                          <p className="text-gray-300 text-sm">{opp.expected_benefit}</p>
                        </div>
                        {opp.implementation_steps?.length > 0 && (
                          <div>
                            <p className="text-gray-400 text-xs mb-2">Implementation Steps</p>
                            <div className="flex flex-wrap gap-2">
                              {opp.implementation_steps.map((step, j) => (
                                <span key={j} className="text-xs px-2 py-1 bg-gray-800 text-gray-300 rounded">
                                  {j + 1}. {step}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Strategic Recommendations */}
              {analysis.strategic_recommendations?.length > 0 && (
                <Card className="bg-amber-900/20 border-amber-800">
                  <CardHeader>
                    <CardTitle className="text-amber-400 flex items-center gap-2">
                      <Lightbulb className="w-5 h-5" /> Strategic Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {analysis.strategic_recommendations.map((rec, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-amber-400 mt-0.5" /> {rec}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="py-20 text-center">
                <Network className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Run AI analysis to discover team synergies</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="network">
          <CollaborationNetworkGraph
            employeeProfiles={employeeProfiles}
            teams={teams}
            coachingSessions={coachingSessions}
            learningJourneys={learningJourneys}
            onNodeSelect={(node) => console.log('Selected:', node)}
          />

          {/* Network Analysis Insights */}
          {analysis && (
            <Card className="bg-gray-900 border-gray-800 mt-6">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Network className="w-5 h-5 text-cyan-400" />
                  AI Network Analysis Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-cyan-900/20 border border-cyan-800 rounded-lg">
                    <p className="text-cyan-400 text-xs font-medium mb-2">Cross-Functional Opportunities</p>
                    {analysis.cross_team_opportunities?.slice(0, 3).map((opp, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1">• {opp.description?.substring(0, 60)}...</p>
                    ))}
                  </div>
                  <div className="p-4 bg-purple-900/20 border border-purple-800 rounded-lg">
                    <p className="text-purple-400 text-xs font-medium mb-2">Team Restructuring Suggestions</p>
                    {analysis.team_interventions?.slice(0, 2).map((int, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1">• {int.team_name}: {int.quick_wins?.[0]?.substring(0, 50)}...</p>
                    ))}
                  </div>
                  <div className="p-4 bg-amber-900/20 border border-amber-800 rounded-lg">
                    <p className="text-amber-400 text-xs font-medium mb-2">Project Assignment Recommendations</p>
                    {analysis.synergy_matrix?.slice(0, 3).map((syn, i) => (
                      <p key={i} className="text-gray-300 text-sm mb-1">• {syn.team_a} + {syn.team_b}: {syn.synergy_score}% synergy</p>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}