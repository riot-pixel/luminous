import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sparkles, Users, Globe, Building2, Handshake, Lightbulb, 
  TrendingUp, Brain, RefreshCw, ArrowRight, Star, Zap,
  Target, Award, CheckCircle2, ExternalLink, UserPlus
} from "lucide-react";

export default function EmergentWinWinScenarios({ 
  employeeProfiles, 
  userSkills,
  departments 
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scenarios, setScenarios] = useState(null);

  // Fetch ecosystem data
  const { data: connections } = useQuery({
    queryKey: ['ecosystemConnectionsForWinWin'],
    queryFn: () => base44.entities.EcosystemConnection.list(),
    initialData: [],
  });

  const { data: challenges } = useQuery({
    queryKey: ['sharedChallengesForWinWin'],
    queryFn: () => base44.entities.SharedChallenge.filter({ status: 'open' }),
    initialData: [],
  });

  const { data: projects } = useQuery({
    queryKey: ['collaborativeProjectsForWinWin'],
    queryFn: () => base44.entities.CollaborativeProject.list(),
    initialData: [],
  });

  const { data: ecosystemReports } = useQuery({
    queryKey: ['ecosystemReportsForWinWin'],
    queryFn: () => base44.entities.EcosystemOpportunityReport.list('-generation_date', 5),
    initialData: [],
  });

  const { data: skillGapAudits } = useQuery({
    queryKey: ['skillGapAuditsForWinWin'],
    queryFn: () => base44.entities.SkillGapAudit.list('-audit_date', 3),
    initialData: [],
  });

  const analyzeEmergentScenarios = async () => {
    setIsAnalyzing(true);
    try {
      const employeeData = employeeProfiles.slice(0, 25).map(e => ({
        name: e.full_name,
        role: e.job_title,
        department: e.department,
        skills: e.skills?.slice(0, 5).map(s => s.skill_name),
        strengths: e.strengths,
        mbti: e.mbti,
        fulfillment: e.fulfillmentScore,
        operational: e.operationalScore,
        career_satisfaction: e.careerSatisfaction,
      }));

      const challengeData = challenges.slice(0, 10).map(c => ({
        title: c.title,
        category: c.category,
        skills_needed: c.skills_needed,
        organization: c.posted_by_org,
      }));

      const connectionData = connections.slice(0, 15).map(c => ({
        type: c.connection_type,
        partner_org: c.recipient_org,
        skills: c.matching_skills,
        status: c.status,
      }));

      const latestAudit = skillGapAudits[0];
      const criticalGaps = latestAudit?.critical_gaps?.slice(0, 5) || [];

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert in organizational strategy, ecosystem partnerships, and emergent opportunity identification. Analyze the following data to identify NOVEL WIN-WIN scenarios that create value both WITHIN and OUTSIDE the organization.

INTERNAL EMPLOYEES:
${JSON.stringify(employeeData, null, 2)}

EXTERNAL ECOSYSTEM CHALLENGES (opportunities to help partners):
${JSON.stringify(challengeData, null, 2)}

EXISTING PARTNERSHIPS:
${JSON.stringify(connectionData, null, 2)}

INTERNAL SKILL GAPS:
${JSON.stringify(criticalGaps, null, 2)}

DEPARTMENTS: ${departments.join(', ')}

TASK: Identify EMERGENT win-win scenarios in these categories:

1. INTERNAL INNOVATION OPPORTUNITIES
   - Cross-department collaborations that leverage underutilized talent
   - Internal skill-sharing programs that address gaps while engaging employees
   - New role creation opportunities that match employee aspirations with business needs

2. EXTERNAL ECOSYSTEM OPPORTUNITIES
   - Challenges from partner organizations our employees could solve (mutual benefit)
   - Skill exchange programs with external partners
   - Joint ventures or projects that combine complementary strengths

3. BOUNDARY-SPANNING OPPORTUNITIES
   - Internal employees who could become ecosystem ambassadors
   - External challenges that could be solved by internal restructuring
   - Talent loan/exchange programs with partners

4. EMERGENT PATTERNS
   - Non-obvious connections between internal talent and external needs
   - Skill clusters that could form new service offerings
   - Partnership opportunities based on complementary weaknesses

For each scenario, provide:
- Clear description of the opportunity
- Who benefits internally (employees/departments)
- Who benefits externally (partners/ecosystem)
- Quantified potential impact
- Implementation approach
- Risk factors
- Timeline
- Innovation score (1-10)`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_insight: { type: "string" },
            internal_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  internal_beneficiaries: { type: "array", items: { type: "string" } },
                  departments_involved: { type: "array", items: { type: "string" } },
                  potential_impact: { type: "string" },
                  employee_fulfillment_boost: { type: "number" },
                  operational_efficiency_boost: { type: "number" },
                  implementation: { type: "string" },
                  timeline: { type: "string" },
                  innovation_score: { type: "number" }
                }
              }
            },
            external_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  our_contribution: { type: "string" },
                  partner_contribution: { type: "string" },
                  mutual_benefits: { type: "array", items: { type: "string" } },
                  target_challenge: { type: "string" },
                  recommended_employees: { type: "array", items: { type: "string" } },
                  potential_revenue: { type: "string" },
                  relationship_value: { type: "string" },
                  timeline: { type: "string" },
                  innovation_score: { type: "number" }
                }
              }
            },
            boundary_spanning: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  internal_action: { type: "string" },
                  external_action: { type: "string" },
                  synergy_explanation: { type: "string" },
                  key_players: { type: "array", items: { type: "string" } },
                  ecosystem_impact: { type: "string" },
                  innovation_score: { type: "number" }
                }
              }
            },
            emergent_patterns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  pattern_name: { type: "string" },
                  observation: { type: "string" },
                  opportunity: { type: "string" },
                  action_required: { type: "string" },
                  novelty_score: { type: "number" }
                }
              }
            },
            quick_wins: { type: "array", items: { type: "string" } },
            strategic_bets: { type: "array", items: { type: "string" } },
            ecosystem_health_impact: { type: "string" }
          }
        }
      });

      setScenarios(result);
    } catch (error) {
      console.error("Error analyzing scenarios:", error);
    }
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/40 via-purple-900/30 to-pink-900/40 border-purple-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-white">Emergent Win-Win Scenarios</h2>
                <p className="text-gray-400 text-sm">AI-discovered opportunities within & across organizational boundaries</p>
              </div>
            </div>
            <Button 
              onClick={analyzeEmergentScenarios}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200 px-8"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Discovering...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Discover Scenarios</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-gray-500 text-xs">Employees Analyzed</p>
              <p className="text-xl font-bold text-white">{employeeProfiles.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 flex items-center gap-3">
            <Globe className="w-8 h-8 text-cyan-400" />
            <div>
              <p className="text-gray-500 text-xs">Ecosystem Challenges</p>
              <p className="text-xl font-bold text-white">{challenges.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 flex items-center gap-3">
            <Handshake className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-gray-500 text-xs">Active Partnerships</p>
              <p className="text-xl font-bold text-white">{connections.filter(c => c.status === 'accepted').length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4 flex items-center gap-3">
            <Target className="w-8 h-8 text-amber-400" />
            <div>
              <p className="text-gray-500 text-xs">Active Projects</p>
              <p className="text-xl font-bold text-white">{projects.filter(p => p.status === 'active').length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {scenarios ? (
        <Tabs defaultValue="internal" className="space-y-4">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="internal">
              <Building2 className="w-4 h-4 mr-1" /> Internal ({scenarios.internal_opportunities?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="external">
              <Globe className="w-4 h-4 mr-1" /> External ({scenarios.external_opportunities?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="boundary">
              <ArrowRight className="w-4 h-4 mr-1" /> Boundary-Spanning ({scenarios.boundary_spanning?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="patterns">
              <Lightbulb className="w-4 h-4 mr-1" /> Emergent Patterns
            </TabsTrigger>
          </TabsList>

          {/* Overall Insight */}
          <Card className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 border-amber-800">
            <CardContent className="p-4 flex items-start gap-4">
              <Lightbulb className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
              <p className="text-gray-300">{scenarios.overall_insight}</p>
            </CardContent>
          </Card>

          <TabsContent value="internal">
            <div className="space-y-4">
              {scenarios.internal_opportunities?.map((opp, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800 hover:border-purple-700 transition-colors">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-purple-900 flex items-center justify-center">
                          <Users className="w-5 h-5 text-purple-400" />
                        </div>
                        <div>
                          <h4 className="text-white font-medium">{opp.title}</h4>
                          <div className="flex gap-2 mt-1">
                            {opp.departments_involved?.map((d, j) => (
                              <Badge key={j} variant="outline" className="text-xs border-purple-700 text-purple-400">{d}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-purple-600">
                          <Star className="w-3 h-3 mr-1" /> {opp.innovation_score}/10
                        </Badge>
                      </div>
                    </div>
                    <p className="text-gray-400 text-sm mb-4">{opp.description}</p>
                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg">
                        <p className="text-green-400 text-xs mb-1">Fulfillment Boost</p>
                        <p className="text-white font-bold">+{opp.employee_fulfillment_boost}%</p>
                      </div>
                      <div className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                        <p className="text-amber-400 text-xs mb-1">Efficiency Boost</p>
                        <p className="text-white font-bold">+{opp.operational_efficiency_boost}%</p>
                      </div>
                      <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                        <p className="text-blue-400 text-xs mb-1">Timeline</p>
                        <p className="text-white font-medium text-sm">{opp.timeline}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-gray-800 rounded-lg">
                      <p className="text-gray-400 text-xs mb-1">Implementation</p>
                      <p className="text-gray-300 text-sm">{opp.implementation}</p>
                    </div>
                    {opp.internal_beneficiaries?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1">
                        <span className="text-gray-500 text-xs mr-2">Beneficiaries:</span>
                        {opp.internal_beneficiaries.map((b, j) => (
                          <Badge key={j} variant="outline" className="text-xs border-gray-700 text-gray-400">{b}</Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="external">
            <div className="space-y-4">
              {scenarios.external_opportunities?.map((opp, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800 hover:border-cyan-700 transition-colors">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-cyan-900 flex items-center justify-center">
                          <Globe className="w-5 h-5 text-cyan-400" />
                        </div>
                        <div>
                          <h4 className="text-white font-medium">{opp.title}</h4>
                          {opp.target_challenge && (
                            <p className="text-cyan-400 text-xs mt-1 flex items-center gap-1">
                              <ExternalLink className="w-3 h-3" /> {opp.target_challenge}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge className="bg-cyan-600">
                        <Star className="w-3 h-3 mr-1" /> {opp.innovation_score}/10
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm mb-4">{opp.description}</p>
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="p-3 bg-purple-900/20 border border-purple-800 rounded-lg">
                        <p className="text-purple-400 text-xs mb-1">Our Contribution</p>
                        <p className="text-gray-300 text-sm">{opp.our_contribution}</p>
                      </div>
                      <div className="p-3 bg-cyan-900/20 border border-cyan-800 rounded-lg">
                        <p className="text-cyan-400 text-xs mb-1">Partner Contribution</p>
                        <p className="text-gray-300 text-sm">{opp.partner_contribution}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg mb-4">
                      <p className="text-green-400 text-xs mb-2">Mutual Benefits</p>
                      <div className="space-y-1">
                        {opp.mutual_benefits?.map((b, j) => (
                          <p key={j} className="text-gray-300 text-sm flex items-start gap-2">
                            <CheckCircle2 className="w-3 h-3 mt-1 text-green-400 flex-shrink-0" /> {b}
                          </p>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex gap-4 text-xs">
                        <span className="text-gray-500">Revenue: <span className="text-green-400">{opp.potential_revenue}</span></span>
                        <span className="text-gray-500">Relationship: <span className="text-cyan-400">{opp.relationship_value}</span></span>
                      </div>
                      <Badge variant="outline" className="border-gray-700 text-gray-400">{opp.timeline}</Badge>
                    </div>
                    {opp.recommended_employees?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1">
                        <UserPlus className="w-4 h-4 text-gray-500 mr-1" />
                        {opp.recommended_employees.map((e, j) => (
                          <Badge key={j} className="bg-purple-600 text-xs">{e}</Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="boundary">
            <div className="space-y-4">
              {scenarios.boundary_spanning?.map((opp, i) => (
                <Card key={i} className="bg-gradient-to-r from-purple-900/20 to-cyan-900/20 border-gray-700">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-600 flex items-center justify-center">
                          <ArrowRight className="w-5 h-5 text-white" />
                        </div>
                        <h4 className="text-white font-medium">{opp.title}</h4>
                      </div>
                      <Badge className="bg-gradient-to-r from-purple-600 to-cyan-600">
                        <Star className="w-3 h-3 mr-1" /> {opp.innovation_score}/10
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm mb-4">{opp.description}</p>
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="p-3 bg-purple-900/30 rounded-lg">
                        <p className="text-purple-400 text-xs mb-1 flex items-center gap-1">
                          <Building2 className="w-3 h-3" /> Internal Action
                        </p>
                        <p className="text-gray-300 text-sm">{opp.internal_action}</p>
                      </div>
                      <div className="p-3 bg-cyan-900/30 rounded-lg">
                        <p className="text-cyan-400 text-xs mb-1 flex items-center gap-1">
                          <Globe className="w-3 h-3" /> External Action
                        </p>
                        <p className="text-gray-300 text-sm">{opp.external_action}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                      <p className="text-amber-400 text-xs mb-1">Synergy</p>
                      <p className="text-gray-300 text-sm">{opp.synergy_explanation}</p>
                    </div>
                    {opp.key_players?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1">
                        <span className="text-gray-500 text-xs mr-2">Key Players:</span>
                        {opp.key_players.map((p, j) => (
                          <Badge key={j} variant="outline" className="text-xs border-gray-700 text-gray-400">{p}</Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="patterns">
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                {scenarios.emergent_patterns?.map((pattern, i) => (
                  <Card key={i} className="bg-gray-900 border-gray-800">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <h4 className="text-white font-medium flex items-center gap-2">
                          <Lightbulb className="w-4 h-4 text-amber-400" />
                          {pattern.pattern_name}
                        </h4>
                        <Badge className="bg-amber-600">Novelty: {pattern.novelty_score}/10</Badge>
                      </div>
                      <p className="text-gray-400 text-sm mb-3">{pattern.observation}</p>
                      <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg mb-3">
                        <p className="text-green-400 text-xs mb-1">Opportunity</p>
                        <p className="text-gray-300 text-sm">{pattern.opportunity}</p>
                      </div>
                      <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                        <p className="text-blue-400 text-xs mb-1">Action Required</p>
                        <p className="text-gray-300 text-sm">{pattern.action_required}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Quick Wins & Strategic Bets */}
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-green-900/20 border-green-800">
                  <CardHeader>
                    <CardTitle className="text-green-400 flex items-center gap-2 text-lg">
                      <Zap className="w-5 h-5" /> Quick Wins
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {scenarios.quick_wins?.map((win, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                          {win}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-purple-900/20 border-purple-800">
                  <CardHeader>
                    <CardTitle className="text-purple-400 flex items-center gap-2 text-lg">
                      <Award className="w-5 h-5" /> Strategic Bets
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {scenarios.strategic_bets?.map((bet, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <TrendingUp className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                          {bet}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {scenarios.ecosystem_health_impact && (
                <Card className="bg-gradient-to-r from-cyan-900/30 to-green-900/30 border-cyan-800">
                  <CardContent className="p-4 flex items-start gap-4">
                    <Globe className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-cyan-400 text-sm font-medium mb-1">Ecosystem Health Impact</p>
                      <p className="text-gray-300">{scenarios.ecosystem_health_impact}</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="py-20 text-center">
            <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 mb-2">Discover novel win-win opportunities</p>
            <p className="text-gray-500 text-sm mb-6">AI analyzes internal talent, external challenges, and ecosystem partnerships</p>
            <Button onClick={analyzeEmergentScenarios} disabled={isAnalyzing} className="bg-white text-black hover:bg-gray-200">
              <Brain className="w-4 h-4 mr-2" /> Start Discovery
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}