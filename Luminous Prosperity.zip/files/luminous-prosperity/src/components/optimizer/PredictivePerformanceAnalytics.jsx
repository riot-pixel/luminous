import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  TrendingUp, TrendingDown, Brain, RefreshCw, AlertTriangle, 
  Star, Zap, Target, ChevronRight, Play, CheckCircle2,
  LineChart, BarChart3, Clock, Award, Lightbulb, Users
} from "lucide-react";
import { LineChart as ReLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";

export default function PredictivePerformanceAnalytics({
  employeeProfiles,
  assessments,
  coachingSessions,
  learningJourneys,
  wellnessLogs
}) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [predictions, setPredictions] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [simulationStrategy, setSimulationStrategy] = useState(null);
  const [simulationResult, setSimulationResult] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const analyzePredictions = async () => {
    setIsAnalyzing(true);
    try {
      const employeeData = employeeProfiles.slice(0, 30).map(e => {
        const empAssessments = assessments.filter(a => a.created_by === e.email);
        const empCoaching = coachingSessions.filter(c => c.user_email === e.email);
        const empJourneys = learningJourneys.filter(j => j.user_email === e.email);
        const empWellness = wellnessLogs.filter(w => w.user_email === e.email).slice(0, 20);

        return {
          name: e.full_name,
          email: e.email,
          role: e.job_title,
          department: e.department,
          tenure_months: Math.floor(Math.random() * 48) + 6,
          current_fulfillment: e.fulfillmentScore,
          current_operational: e.operationalScore,
          career_satisfaction: e.careerSatisfaction,
          role_fit: e.roleFit,
          skill_level: e.avgSkillLevel,
          mood_trend: e.avgMood,
          energy_trend: e.avgEnergy,
          stress_level: 100 - e.avgStress,
          completed_trainings: e.completedJourneys,
          coaching_score: e.avgCoachingScore,
          mbti: e.mbti,
          strengths: e.strengths,
          assessment_count: empAssessments.length,
          coaching_count: empCoaching.length,
          journey_progress: e.avgJourneyProgress,
        };
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert in predictive HR analytics and organizational psychology. Analyze these employees and forecast their performance trajectory.

EMPLOYEE DATA:
${JSON.stringify(employeeData, null, 2)}

TASK: For each employee, predict their performance over the next 3, 6, and 12 months. Identify:

1. PERFORMANCE FORECASTS
   - Trajectory (improving, stable, declining, volatile)
   - Predicted operational score changes
   - Predicted fulfillment changes
   - Confidence level

2. RISK IDENTIFICATION
   - Burnout risk
   - Disengagement risk
   - Turnover risk
   - Underperformance risk

3. HIGH-POTENTIAL IDENTIFICATION
   - Leadership potential
   - Innovation potential
   - Growth velocity
   - Development readiness

4. PROACTIVE INTERVENTIONS
   - Specific recommendations for at-risk employees
   - Development accelerators for high-potentials
   - Personalized action items

5. DEVELOPMENT STRATEGIES (for simulation)
   - Different intervention options with predicted impact
   - Cost-benefit analysis
   - Timeline to impact

Categorize employees into: At-Risk, Watch List, Stable, High-Potential, and Star Performers.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: {
              type: "object",
              properties: {
                at_risk_count: { type: "number" },
                watch_list_count: { type: "number" },
                stable_count: { type: "number" },
                high_potential_count: { type: "number" },
                star_count: { type: "number" },
                overall_trajectory: { type: "string" },
                key_insight: { type: "string" }
              }
            },
            employee_predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  email: { type: "string" },
                  category: { type: "string" },
                  trajectory: { type: "string" },
                  confidence: { type: "number" },
                  current_performance: { type: "number" },
                  forecast_3m: { type: "number" },
                  forecast_6m: { type: "number" },
                  forecast_12m: { type: "number" },
                  fulfillment_forecast: { type: "number" },
                  risks: {
                    type: "object",
                    properties: {
                      burnout: { type: "number" },
                      disengagement: { type: "number" },
                      turnover: { type: "number" },
                      underperformance: { type: "number" }
                    }
                  },
                  potentials: {
                    type: "object",
                    properties: {
                      leadership: { type: "number" },
                      innovation: { type: "number" },
                      growth_velocity: { type: "number" }
                    }
                  },
                  interventions: { type: "array", items: { type: "string" } },
                  development_strategies: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        strategy: { type: "string" },
                        predicted_impact: { type: "number" },
                        timeline: { type: "string" },
                        effort: { type: "string" },
                        description: { type: "string" }
                      }
                    }
                  },
                  key_drivers: { type: "array", items: { type: "string" } },
                  watch_indicators: { type: "array", items: { type: "string" } }
                }
              }
            },
            organization_forecast: {
              type: "object",
              properties: {
                avg_performance_3m: { type: "number" },
                avg_performance_6m: { type: "number" },
                avg_performance_12m: { type: "number" },
                turnover_risk_percent: { type: "number" },
                high_potential_pipeline: { type: "number" }
              }
            },
            priority_actions: { type: "array", items: { type: "string" } },
            strategic_recommendations: { type: "array", items: { type: "string" } }
          }
        }
      });

      setPredictions(result);
    } catch (error) {
      console.error("Error analyzing predictions:", error);
    }
    setIsAnalyzing(false);
  };

  const simulateStrategy = async (employee, strategy) => {
    setIsSimulating(true);
    setSimulationStrategy(strategy);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Simulate the impact of this development strategy on employee performance:

EMPLOYEE: ${employee.name}
- Current Performance: ${employee.current_performance}%
- Category: ${employee.category}
- Trajectory: ${employee.trajectory}
- Risks: ${JSON.stringify(employee.risks)}
- Potentials: ${JSON.stringify(employee.potentials)}

STRATEGY: ${strategy.strategy}
- Description: ${strategy.description}
- Predicted Impact: ${strategy.predicted_impact}%
- Timeline: ${strategy.timeline}
- Effort: ${strategy.effort}

Provide a detailed week-by-week simulation of how this strategy would affect the employee's performance, engagement, and risks over 12 weeks. Include milestones, potential obstacles, and success indicators.`,
        response_json_schema: {
          type: "object",
          properties: {
            strategy_name: { type: "string" },
            weekly_progression: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  week: { type: "number" },
                  performance_score: { type: "number" },
                  engagement_score: { type: "number" },
                  milestone: { type: "string" },
                  activities: { type: "array", items: { type: "string" } }
                }
              }
            },
            risk_reduction: {
              type: "object",
              properties: {
                burnout: { type: "number" },
                disengagement: { type: "number" },
                turnover: { type: "number" }
              }
            },
            potential_obstacles: { type: "array", items: { type: "string" } },
            success_indicators: { type: "array", items: { type: "string" } },
            roi_estimate: { type: "string" },
            recommendation: { type: "string" }
          }
        }
      });
      setSimulationResult(result);
    } catch (error) {
      console.error("Error simulating strategy:", error);
    }
    setIsSimulating(false);
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'Star': return 'bg-yellow-600';
      case 'High-Potential': return 'bg-green-600';
      case 'Stable': return 'bg-blue-600';
      case 'Watch List': return 'bg-orange-600';
      case 'At-Risk': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getTrajectoryIcon = (trajectory) => {
    if (trajectory?.toLowerCase().includes('improv')) return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (trajectory?.toLowerCase().includes('declin')) return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <LineChart className="w-4 h-4 text-blue-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/40 border-indigo-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                <LineChart className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-medium text-white">Predictive Performance Analytics</h2>
                <p className="text-gray-400 text-sm">AI-powered forecasting with proactive interventions</p>
              </div>
            </div>
            <Button 
              onClick={analyzePredictions}
              disabled={isAnalyzing}
              className="bg-white text-black hover:bg-gray-200 px-8"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Generate Forecasts</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {predictions ? (
        <>
          {/* Summary Stats */}
          <div className="grid grid-cols-5 gap-4">
            <Card className="bg-red-900/30 border-red-800">
              <CardContent className="p-4 text-center">
                <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{predictions.summary?.at_risk_count}</p>
                <p className="text-red-400 text-xs">At-Risk</p>
              </CardContent>
            </Card>
            <Card className="bg-orange-900/30 border-orange-800">
              <CardContent className="p-4 text-center">
                <Clock className="w-6 h-6 text-orange-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{predictions.summary?.watch_list_count}</p>
                <p className="text-orange-400 text-xs">Watch List</p>
              </CardContent>
            </Card>
            <Card className="bg-blue-900/30 border-blue-800">
              <CardContent className="p-4 text-center">
                <CheckCircle2 className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{predictions.summary?.stable_count}</p>
                <p className="text-blue-400 text-xs">Stable</p>
              </CardContent>
            </Card>
            <Card className="bg-green-900/30 border-green-800">
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{predictions.summary?.high_potential_count}</p>
                <p className="text-green-400 text-xs">High-Potential</p>
              </CardContent>
            </Card>
            <Card className="bg-yellow-900/30 border-yellow-800">
              <CardContent className="p-4 text-center">
                <Star className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{predictions.summary?.star_count}</p>
                <p className="text-yellow-400 text-xs">Stars</p>
              </CardContent>
            </Card>
          </div>

          {/* Key Insight */}
          <Card className="bg-gradient-to-r from-amber-900/30 to-orange-900/30 border-amber-800">
            <CardContent className="p-4 flex items-start gap-4">
              <Lightbulb className="w-6 h-6 text-amber-400 flex-shrink-0" />
              <p className="text-gray-300">{predictions.summary?.key_insight}</p>
            </CardContent>
          </Card>

          <Tabs defaultValue="employees" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="employees">Employee Forecasts</TabsTrigger>
              <TabsTrigger value="org">Organization Forecast</TabsTrigger>
              <TabsTrigger value="actions">Priority Actions</TabsTrigger>
              {selectedEmployee && <TabsTrigger value="simulate">Simulation</TabsTrigger>}
            </TabsList>

            <TabsContent value="employees">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Employee Performance Forecasts</CardTitle>
                  <CardDescription className="text-gray-400">Click on an employee to view strategies and run simulations</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[500px]">
                    <div className="space-y-3">
                      {predictions.employee_predictions?.map((emp, i) => (
                        <div 
                          key={i}
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            selectedEmployee?.email === emp.email 
                              ? 'bg-indigo-900/30 border-indigo-600' 
                              : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                          }`}
                          onClick={() => setSelectedEmployee(emp)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <Avatar>
                                <AvatarFallback className={getCategoryColor(emp.category)}>
                                  {emp.name?.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-white font-medium">{emp.name}</p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge className={getCategoryColor(emp.category)}>{emp.category}</Badge>
                                  <span className="text-gray-500 text-xs flex items-center gap-1">
                                    {getTrajectoryIcon(emp.trajectory)} {emp.trajectory}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-6">
                              <div className="text-center">
                                <p className="text-gray-500 text-xs">Now</p>
                                <p className="text-white font-bold">{emp.current_performance}%</p>
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-500" />
                              <div className="text-center">
                                <p className="text-gray-500 text-xs">3M</p>
                                <p className={`font-bold ${emp.forecast_3m > emp.current_performance ? 'text-green-400' : emp.forecast_3m < emp.current_performance ? 'text-red-400' : 'text-white'}`}>
                                  {emp.forecast_3m}%
                                </p>
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-500" />
                              <div className="text-center">
                                <p className="text-gray-500 text-xs">6M</p>
                                <p className={`font-bold ${emp.forecast_6m > emp.current_performance ? 'text-green-400' : emp.forecast_6m < emp.current_performance ? 'text-red-400' : 'text-white'}`}>
                                  {emp.forecast_6m}%
                                </p>
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-500" />
                              <div className="text-center">
                                <p className="text-gray-500 text-xs">12M</p>
                                <p className={`font-bold ${emp.forecast_12m > emp.current_performance ? 'text-green-400' : emp.forecast_12m < emp.current_performance ? 'text-red-400' : 'text-white'}`}>
                                  {emp.forecast_12m}%
                                </p>
                              </div>
                              <Badge variant="outline" className="border-gray-700 text-gray-400">
                                {emp.confidence}% conf
                              </Badge>
                            </div>
                          </div>

                          {selectedEmployee?.email === emp.email && (
                            <div className="mt-4 pt-4 border-t border-gray-700 space-y-4">
                              {/* Risks */}
                              <div className="grid grid-cols-4 gap-3">
                                <div className="p-2 bg-red-900/20 rounded-lg text-center">
                                  <p className="text-red-400 text-xs">Burnout</p>
                                  <p className="text-white font-bold">{emp.risks?.burnout}%</p>
                                </div>
                                <div className="p-2 bg-orange-900/20 rounded-lg text-center">
                                  <p className="text-orange-400 text-xs">Disengagement</p>
                                  <p className="text-white font-bold">{emp.risks?.disengagement}%</p>
                                </div>
                                <div className="p-2 bg-yellow-900/20 rounded-lg text-center">
                                  <p className="text-yellow-400 text-xs">Turnover</p>
                                  <p className="text-white font-bold">{emp.risks?.turnover}%</p>
                                </div>
                                <div className="p-2 bg-purple-900/20 rounded-lg text-center">
                                  <p className="text-purple-400 text-xs">Underperform</p>
                                  <p className="text-white font-bold">{emp.risks?.underperformance}%</p>
                                </div>
                              </div>

                              {/* Potentials */}
                              <div className="grid grid-cols-3 gap-3">
                                <div className="p-2 bg-green-900/20 rounded-lg text-center">
                                  <p className="text-green-400 text-xs">Leadership</p>
                                  <p className="text-white font-bold">{emp.potentials?.leadership}%</p>
                                </div>
                                <div className="p-2 bg-cyan-900/20 rounded-lg text-center">
                                  <p className="text-cyan-400 text-xs">Innovation</p>
                                  <p className="text-white font-bold">{emp.potentials?.innovation}%</p>
                                </div>
                                <div className="p-2 bg-blue-900/20 rounded-lg text-center">
                                  <p className="text-blue-400 text-xs">Growth Velocity</p>
                                  <p className="text-white font-bold">{emp.potentials?.growth_velocity}%</p>
                                </div>
                              </div>

                              {/* Interventions */}
                              {emp.interventions?.length > 0 && (
                                <div className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg">
                                  <p className="text-amber-400 text-xs font-medium mb-2">Recommended Interventions</p>
                                  <ul className="space-y-1">
                                    {emp.interventions.map((int, j) => (
                                      <li key={j} className="text-gray-300 text-sm flex items-start gap-2">
                                        <Zap className="w-3 h-3 text-amber-400 mt-1" /> {int}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              {/* Development Strategies */}
                              {emp.development_strategies?.length > 0 && (
                                <div>
                                  <p className="text-gray-400 text-xs font-medium mb-2">Development Strategies (Click to Simulate)</p>
                                  <div className="grid md:grid-cols-2 gap-2">
                                    {emp.development_strategies.map((strat, j) => (
                                      <button
                                        key={j}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          simulateStrategy(emp, strat);
                                        }}
                                        className="p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-left transition-colors"
                                      >
                                        <div className="flex items-center justify-between mb-1">
                                          <p className="text-white text-sm font-medium">{strat.strategy}</p>
                                          <Badge className="bg-green-600 text-xs">+{strat.predicted_impact}%</Badge>
                                        </div>
                                        <p className="text-gray-400 text-xs">{strat.description}</p>
                                        <div className="flex gap-2 mt-2">
                                          <Badge variant="outline" className="text-xs border-gray-600">{strat.timeline}</Badge>
                                          <Badge variant="outline" className="text-xs border-gray-600">{strat.effort} effort</Badge>
                                        </div>
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="org">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Organization Performance Forecast</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={[
                          { month: 'Now', performance: employeeProfiles.length > 0 ? Math.round(employeeProfiles.reduce((s, e) => s + e.operationalScore, 0) / employeeProfiles.length) : 50 },
                          { month: '3M', performance: predictions.organization_forecast?.avg_performance_3m },
                          { month: '6M', performance: predictions.organization_forecast?.avg_performance_6m },
                          { month: '12M', performance: predictions.organization_forecast?.avg_performance_12m },
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="month" stroke="#9ca3af" />
                          <YAxis domain={[0, 100]} stroke="#9ca3af" />
                          <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                          <Area type="monotone" dataKey="performance" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-4">
                      <div className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-sm">Turnover Risk</p>
                        <p className="text-2xl font-bold text-red-400">{predictions.organization_forecast?.turnover_risk_percent}%</p>
                        <Progress value={predictions.organization_forecast?.turnover_risk_percent} className="h-2 mt-2" />
                      </div>
                      <div className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-gray-400 text-sm">High-Potential Pipeline</p>
                        <p className="text-2xl font-bold text-green-400">{predictions.organization_forecast?.high_potential_pipeline}%</p>
                        <Progress value={predictions.organization_forecast?.high_potential_pipeline} className="h-2 mt-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="actions">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-red-900/20 border-red-800">
                  <CardHeader>
                    <CardTitle className="text-red-400 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" /> Priority Actions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {predictions.priority_actions?.map((action, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <Zap className="w-4 h-4 text-red-400 mt-0.5" /> {action}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card className="bg-blue-900/20 border-blue-800">
                  <CardHeader>
                    <CardTitle className="text-blue-400 flex items-center gap-2">
                      <Target className="w-5 h-5" /> Strategic Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {predictions.strategic_recommendations?.map((rec, i) => (
                        <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-blue-400 mt-0.5" /> {rec}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="simulate">
              {isSimulating ? (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-20 text-center">
                    <RefreshCw className="w-12 h-12 text-indigo-400 animate-spin mx-auto mb-4" />
                    <p className="text-gray-400">Simulating strategy impact...</p>
                  </CardContent>
                </Card>
              ) : simulationResult ? (
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white">Strategy Simulation: {simulationResult.strategy_name}</CardTitle>
                    <CardDescription className="text-gray-400">12-week impact forecast for {selectedEmployee?.name}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Progression Chart */}
                    <ResponsiveContainer width="100%" height={250}>
                      <ReLineChart data={simulationResult.weekly_progression}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="week" stroke="#9ca3af" tickFormatter={(v) => `W${v}`} />
                        <YAxis domain={[0, 100]} stroke="#9ca3af" />
                        <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                        <Line type="monotone" dataKey="performance_score" stroke="#8b5cf6" strokeWidth={2} name="Performance" />
                        <Line type="monotone" dataKey="engagement_score" stroke="#06b6d4" strokeWidth={2} name="Engagement" />
                      </ReLineChart>
                    </ResponsiveContainer>

                    {/* Risk Reduction */}
                    <div className="grid grid-cols-3 gap-4">
                      <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg text-center">
                        <p className="text-green-400 text-xs">Burnout Risk Reduction</p>
                        <p className="text-white font-bold text-xl">-{simulationResult.risk_reduction?.burnout}%</p>
                      </div>
                      <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg text-center">
                        <p className="text-green-400 text-xs">Disengagement Reduction</p>
                        <p className="text-white font-bold text-xl">-{simulationResult.risk_reduction?.disengagement}%</p>
                      </div>
                      <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg text-center">
                        <p className="text-green-400 text-xs">Turnover Risk Reduction</p>
                        <p className="text-white font-bold text-xl">-{simulationResult.risk_reduction?.turnover}%</p>
                      </div>
                    </div>

                    {/* ROI & Recommendation */}
                    <div className="p-4 bg-amber-900/20 border border-amber-800 rounded-lg">
                      <p className="text-amber-400 text-sm font-medium mb-2">Estimated ROI: {simulationResult.roi_estimate}</p>
                      <p className="text-gray-300">{simulationResult.recommendation}</p>
                    </div>

                    {/* Milestones */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-gray-400 text-xs mb-2">Success Indicators</p>
                        <ul className="space-y-1">
                          {simulationResult.success_indicators?.map((ind, i) => (
                            <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                              <CheckCircle2 className="w-3 h-3 text-green-400 mt-1" /> {ind}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs mb-2">Potential Obstacles</p>
                        <ul className="space-y-1">
                          {simulationResult.potential_obstacles?.map((obs, i) => (
                            <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                              <AlertTriangle className="w-3 h-3 text-orange-400 mt-1" /> {obs}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="py-20 text-center">
                    <Play className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">Select an employee and click a strategy to simulate</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </>
      ) : (
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="py-20 text-center">
            <LineChart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 mb-2">Predict future employee performance</p>
            <p className="text-gray-500 text-sm mb-6">AI analyzes historical data to forecast trajectories and suggest interventions</p>
            <Button onClick={analyzePredictions} disabled={isAnalyzing} className="bg-white text-black hover:bg-gray-200">
              <Brain className="w-4 h-4 mr-2" /> Generate Forecasts
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}