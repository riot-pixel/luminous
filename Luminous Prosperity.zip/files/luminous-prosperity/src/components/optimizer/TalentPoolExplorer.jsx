import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Search, Filter, Users, Heart, Zap, Target, Brain, Star,
  TrendingUp, ChevronRight, SortAsc, SortDesc, Eye
} from "lucide-react";

export default function TalentPoolExplorer({ employeeProfiles, departments, roles }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [sortBy, setSortBy] = useState("combined");
  const [sortDirection, setSortDirection] = useState("desc");
  const [fulfillmentRange, setFulfillmentRange] = useState([0, 100]);
  const [operationalRange, setOperationalRange] = useState([0, 100]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  const filteredEmployees = useMemo(() => {
    let filtered = employeeProfiles.filter(emp => {
      const matchesSearch = !searchQuery || 
        emp.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.job_title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.mbti?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.skills?.some(s => s.skill_name?.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesDepartment = departmentFilter === "all" || emp.department === departmentFilter;
      const matchesFulfillment = emp.fulfillmentScore >= fulfillmentRange[0] && emp.fulfillmentScore <= fulfillmentRange[1];
      const matchesOperational = emp.operationalScore >= operationalRange[0] && emp.operationalScore <= operationalRange[1];

      return matchesSearch && matchesDepartment && matchesFulfillment && matchesOperational;
    });

    // Sort
    filtered.sort((a, b) => {
      let aVal, bVal;
      switch (sortBy) {
        case "fulfillment": aVal = a.fulfillmentScore; bVal = b.fulfillmentScore; break;
        case "operational": aVal = a.operationalScore; bVal = b.operationalScore; break;
        case "combined": aVal = a.fulfillmentScore + a.operationalScore; bVal = b.fulfillmentScore + b.operationalScore; break;
        case "skills": aVal = a.skillCount; bVal = b.skillCount; break;
        case "growth": aVal = a.avgJourneyProgress; bVal = b.avgJourneyProgress; break;
        default: aVal = a.fulfillmentScore + a.operationalScore; bVal = b.fulfillmentScore + b.operationalScore;
      }
      return sortDirection === "desc" ? bVal - aVal : aVal - bVal;
    });

    return filtered;
  }, [employeeProfiles, searchQuery, departmentFilter, sortBy, sortDirection, fulfillmentRange, operationalRange]);

  const getEmployeeCategory = (emp) => {
    if (emp.fulfillmentScore > 70 && emp.operationalScore > 70) return { label: "Star", color: "bg-green-600", icon: Star };
    if (emp.fulfillmentScore > 70 && emp.operationalScore < 50) return { label: "High Potential", color: "bg-purple-600", icon: TrendingUp };
    if (emp.operationalScore > 70 && emp.fulfillmentScore < 50) return { label: "At Risk", color: "bg-amber-600", icon: Heart };
    if (emp.fulfillmentScore < 40 && emp.operationalScore < 40) return { label: "Needs Support", color: "bg-red-600", icon: Target };
    return { label: "Developing", color: "bg-blue-600", icon: Brain };
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex-1 min-w-[250px] relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, role, MBTI, or skills..."
                className="pl-10 bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map(d => (
                  <SelectItem key={d} value={d}>{d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="combined">Combined Score</SelectItem>
                <SelectItem value="fulfillment">Fulfillment</SelectItem>
                <SelectItem value="operational">Operational</SelectItem>
                <SelectItem value="skills">Skill Count</SelectItem>
                <SelectItem value="growth">Growth Progress</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSortDirection(d => d === "desc" ? "asc" : "desc")}
              className="border-gray-700"
            >
              {sortDirection === "desc" ? <SortDesc className="w-4 h-4" /> : <SortAsc className="w-4 h-4" />}
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="border-gray-700 text-gray-400"
            >
              <Filter className="w-4 h-4 mr-2" />
              Advanced Filters
            </Button>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-800 grid md:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-400 text-sm mb-3">Fulfillment Range: {fulfillmentRange[0]}% - {fulfillmentRange[1]}%</p>
                <Slider
                  value={fulfillmentRange}
                  onValueChange={setFulfillmentRange}
                  min={0}
                  max={100}
                  step={5}
                  className="mb-2"
                />
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-3">Operational Range: {operationalRange[0]}% - {operationalRange[1]}%</p>
                <Slider
                  value={operationalRange}
                  onValueChange={setOperationalRange}
                  min={0}
                  max={100}
                  step={5}
                  className="mb-2"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="flex items-center justify-between">
        <p className="text-gray-400 text-sm">
          Showing {filteredEmployees.length} of {employeeProfiles.length} employees
        </p>
        <div className="flex gap-2">
          <Badge className="bg-green-600">{filteredEmployees.filter(e => e.fulfillmentScore > 70 && e.operationalScore > 70).length} Stars</Badge>
          <Badge className="bg-purple-600">{filteredEmployees.filter(e => e.fulfillmentScore > 70 && e.operationalScore < 50).length} High Potential</Badge>
          <Badge className="bg-amber-600">{filteredEmployees.filter(e => e.operationalScore > 70 && e.fulfillmentScore < 50).length} At Risk</Badge>
        </div>
      </div>

      {/* Talent Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEmployees.map((emp, i) => {
          const category = getEmployeeCategory(emp);
          const CategoryIcon = category.icon;
          
          return (
            <Card 
              key={i} 
              className="bg-gray-900 border-gray-800 hover:border-gray-700 cursor-pointer transition-all"
              onClick={() => setSelectedEmployee(emp)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3 mb-4">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-purple-600 text-white">
                      {emp.full_name?.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium truncate">{emp.full_name}</p>
                    <p className="text-gray-500 text-xs truncate">{emp.job_title}</p>
                    <p className="text-gray-600 text-xs">{emp.department}</p>
                  </div>
                  <Badge className={`${category.color} text-xs`}>
                    <CategoryIcon className="w-3 h-3 mr-1" />
                    {category.label}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <p className="text-[10px] text-gray-500 mb-1 flex items-center gap-1">
                      <Heart className="w-3 h-3 text-purple-400" /> Fulfillment
                    </p>
                    <Progress value={emp.fulfillmentScore} className="h-2" />
                    <p className="text-purple-400 text-xs mt-0.5">{emp.fulfillmentScore}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-500 mb-1 flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-400" /> Operational
                    </p>
                    <Progress value={emp.operationalScore} className="h-2" />
                    <p className="text-amber-400 text-xs mt-0.5">{emp.operationalScore}%</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <Badge variant="outline" className="border-gray-700 text-gray-400">{emp.mbti}</Badge>
                  <span className="text-gray-500">{emp.skillCount} skills</span>
                  <Button variant="ghost" size="sm" className="h-6 text-gray-400 hover:text-white">
                    <Eye className="w-3 h-3 mr-1" /> View
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Employee Detail Dialog */}
      <Dialog open={!!selectedEmployee} onOpenChange={() => setSelectedEmployee(null)}>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800 text-white max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-purple-600">
                  {selectedEmployee?.full_name?.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <p>{selectedEmployee?.full_name}</p>
                <p className="text-sm text-gray-400 font-normal">{selectedEmployee?.job_title} • {selectedEmployee?.department}</p>
              </div>
            </DialogTitle>
          </DialogHeader>

          {selectedEmployee && (
            <div className="space-y-6 py-4">
              {/* Scores Overview */}
              <div className="grid grid-cols-4 gap-4">
                <div className="p-3 bg-purple-900/20 border border-purple-800 rounded-lg text-center">
                  <p className="text-2xl font-bold text-purple-400">{selectedEmployee.fulfillmentScore}%</p>
                  <p className="text-xs text-gray-400">Fulfillment</p>
                </div>
                <div className="p-3 bg-amber-900/20 border border-amber-800 rounded-lg text-center">
                  <p className="text-2xl font-bold text-amber-400">{selectedEmployee.operationalScore}%</p>
                  <p className="text-xs text-gray-400">Operational</p>
                </div>
                <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-400">{selectedEmployee.roleFit}%</p>
                  <p className="text-xs text-gray-400">Role Fit</p>
                </div>
                <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg text-center">
                  <p className="text-2xl font-bold text-green-400">{selectedEmployee.avgSkillLevel}%</p>
                  <p className="text-xs text-gray-400">Skill Level</p>
                </div>
              </div>

              {/* Detailed Metrics */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg">
                  <p className="text-white font-medium mb-3">Fulfillment Breakdown</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Career Satisfaction</span>
                      <span className="text-white">{selectedEmployee.careerSatisfaction}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Personal Growth</span>
                      <span className="text-white">{selectedEmployee.personalGrowth}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Work-Life Balance</span>
                      <span className="text-white">{selectedEmployee.workLifeBalance}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Mood</span>
                      <span className="text-white">{Math.round(selectedEmployee.avgMood)}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Energy</span>
                      <span className="text-white">{Math.round(selectedEmployee.avgEnergy)}%</span>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg">
                  <p className="text-white font-medium mb-3">Performance Metrics</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Role Fit</span>
                      <span className="text-white">{selectedEmployee.roleFit}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Avg Skill Level</span>
                      <span className="text-white">{Math.round(selectedEmployee.avgSkillLevel)}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Coaching Score</span>
                      <span className="text-white">{Math.round(selectedEmployee.avgCoachingScore)}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Completed Journeys</span>
                      <span className="text-white">{selectedEmployee.completedJourneys}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Learning Progress</span>
                      <span className="text-white">{Math.round(selectedEmployee.avgJourneyProgress)}%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Personality & Strengths */}
              <div className="p-4 bg-gray-800 rounded-lg">
                <p className="text-white font-medium mb-3">Personality & Strengths</p>
                <div className="flex items-center gap-4 mb-3">
                  <Badge className="bg-purple-600 text-lg px-4 py-1">{selectedEmployee.mbti}</Badge>
                  <span className="text-gray-400 text-sm">{selectedEmployee.skillCount} skills recorded</span>
                </div>
                {selectedEmployee.strengths?.length > 0 && (
                  <div>
                    <p className="text-gray-400 text-xs mb-2">Top Strengths</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedEmployee.strengths.map((s, i) => (
                        <Badge key={i} variant="outline" className="border-green-700 text-green-400">{s}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Skills */}
              {selectedEmployee.skills?.length > 0 && (
                <div className="p-4 bg-gray-800 rounded-lg">
                  <p className="text-white font-medium mb-3">Skills ({selectedEmployee.skills.length})</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedEmployee.skills.slice(0, 15).map((s, i) => (
                      <Badge key={i} variant="outline" className="border-gray-700 text-gray-400 text-xs">
                        {s.skill_name} ({s.current_proficiency || 'N/A'})
                      </Badge>
                    ))}
                    {selectedEmployee.skills.length > 15 && (
                      <Badge variant="outline" className="border-gray-700 text-gray-500 text-xs">
                        +{selectedEmployee.skills.length - 15} more
                      </Badge>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}