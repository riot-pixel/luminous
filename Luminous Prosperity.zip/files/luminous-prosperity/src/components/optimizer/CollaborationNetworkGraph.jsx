import React, { useState, useMemo, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  Network, Users, Star, AlertTriangle, Zap, ArrowRight, 
  Filter, ZoomIn, ZoomOut, Maximize2, Info
} from "lucide-react";

export default function CollaborationNetworkGraph({ 
  employeeProfiles, 
  teams, 
  coachingSessions, 
  learningJourneys,
  onNodeSelect 
}) {
  const canvasRef = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [selectedNode, setSelectedNode] = useState(null);
  const [viewMode, setViewMode] = useState("department");
  const [showLabels, setShowLabels] = useState(true);
  const [connectionStrength, setConnectionStrength] = useState([30]);

  // Generate network data based on collaboration patterns
  const networkData = useMemo(() => {
    const nodes = [];
    const links = [];
    const nodeMap = {};

    // Create nodes from employees
    employeeProfiles.forEach((emp, i) => {
      const nodeId = emp.email || `emp-${i}`;
      const dept = emp.department || 'Unknown';
      
      // Calculate influence score based on skills, coaching, and journeys
      const skillCount = emp.skills?.length || 0;
      const coachingCount = coachingSessions.filter(c => c.user_email === emp.email).length;
      const journeyCount = learningJourneys.filter(j => j.user_email === emp.email).length;
      const influenceScore = Math.min(100, skillCount * 5 + coachingCount * 10 + journeyCount * 8 + (emp.operationalScore || 0) * 0.3);

      nodeMap[nodeId] = nodes.length;
      nodes.push({
        id: nodeId,
        name: emp.full_name || emp.email?.split('@')[0] || 'Unknown',
        department: dept,
        role: emp.job_title || 'Employee',
        fulfillment: emp.fulfillmentScore || 50,
        operational: emp.operationalScore || 50,
        influenceScore: Math.round(influenceScore),
        skillCount,
        isHighPerformer: emp.fulfillmentScore > 70 && emp.operationalScore > 70,
        isAtRisk: emp.fulfillmentScore < 40 || emp.operationalScore < 40,
        skills: emp.skills?.slice(0, 5).map(s => s.skill_name) || [],
        x: 0,
        y: 0,
        radius: Math.max(8, Math.min(25, influenceScore / 4)),
      });
    });

    // Generate links based on collaboration indicators
    // 1. Same department = base connection
    // 2. Shared skills = stronger connection
    // 3. Same learning journeys = connection
    // 4. Coaching interactions = connection

    employeeProfiles.forEach((emp1, i) => {
      employeeProfiles.forEach((emp2, j) => {
        if (i >= j) return; // Avoid duplicates

        let strength = 0;
        const reasons = [];

        // Same department
        if (emp1.department && emp1.department === emp2.department) {
          strength += 30;
          reasons.push('Same department');
        }

        // Shared skills
        const skills1 = new Set(emp1.skills?.map(s => s.skill_name) || []);
        const skills2 = emp2.skills?.map(s => s.skill_name) || [];
        const sharedSkills = skills2.filter(s => skills1.has(s));
        if (sharedSkills.length > 0) {
          strength += sharedSkills.length * 15;
          reasons.push(`${sharedSkills.length} shared skills`);
        }

        // Same learning journeys
        const journeys1 = new Set(learningJourneys.filter(j => j.user_email === emp1.email).map(j => j.title));
        const journeys2 = learningJourneys.filter(j => j.user_email === emp2.email).map(j => j.title);
        const sharedJourneys = journeys2.filter(j => journeys1.has(j));
        if (sharedJourneys.length > 0) {
          strength += sharedJourneys.length * 20;
          reasons.push(`${sharedJourneys.length} shared learning paths`);
        }

        // Only add link if strength meets threshold
        if (strength >= connectionStrength[0]) {
          links.push({
            source: nodeMap[emp1.email || `emp-${i}`],
            target: nodeMap[emp2.email || `emp-${j}`],
            strength,
            reasons,
            type: emp1.department === emp2.department ? 'intra' : 'inter',
          });
        }
      });
    });

    // Calculate positions using force-directed-like placement
    const departments = [...new Set(nodes.map(n => n.department))];
    const deptAngles = {};
    departments.forEach((dept, i) => {
      deptAngles[dept] = (i / departments.length) * 2 * Math.PI;
    });

    const centerX = 300;
    const centerY = 250;
    const radius = 180;

    nodes.forEach((node, i) => {
      const deptAngle = deptAngles[node.department] || 0;
      const spread = 0.5;
      const offsetAngle = deptAngle + (Math.random() - 0.5) * spread;
      const offsetRadius = radius * (0.5 + Math.random() * 0.5);
      
      node.x = centerX + Math.cos(offsetAngle) * offsetRadius;
      node.y = centerY + Math.sin(offsetAngle) * offsetRadius;
    });

    // Identify key network metrics
    const connectionCounts = nodes.map((_, i) => 
      links.filter(l => l.source === i || l.target === i).length
    );

    const keyInfluencers = nodes
      .map((n, i) => ({ ...n, connections: connectionCounts[i], index: i }))
      .sort((a, b) => (b.influenceScore + b.connections * 5) - (a.influenceScore + a.connections * 5))
      .slice(0, 5);

    const bottlenecks = nodes
      .map((n, i) => ({ ...n, connections: connectionCounts[i], index: i }))
      .filter(n => n.connections > 5 && n.influenceScore > 60)
      .slice(0, 3);

    const isolatedNodes = nodes
      .map((n, i) => ({ ...n, connections: connectionCounts[i], index: i }))
      .filter(n => n.connections < 2);

    // Cross-department links
    const crossDeptLinks = links.filter(l => l.type === 'inter');
    const intraDeptLinks = links.filter(l => l.type === 'intra');

    return {
      nodes,
      links,
      departments,
      deptAngles,
      keyInfluencers,
      bottlenecks,
      isolatedNodes,
      crossDeptLinks,
      intraDeptLinks,
      totalConnections: links.length,
      avgConnections: links.length > 0 ? (links.length * 2 / nodes.length).toFixed(1) : 0,
    };
  }, [employeeProfiles, coachingSessions, learningJourneys, connectionStrength]);

  // Department colors
  const deptColors = useMemo(() => {
    const colors = ['#8b5cf6', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#ec4899', '#06b6d4', '#84cc16'];
    const colorMap = {};
    networkData.departments.forEach((dept, i) => {
      colorMap[dept] = colors[i % colors.length];
    });
    return colorMap;
  }, [networkData.departments]);

  // Draw network on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, width, height);

    // Apply zoom
    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-width / 2, -height / 2);

    // Draw links
    networkData.links.forEach(link => {
      const source = networkData.nodes[link.source];
      const target = networkData.nodes[link.target];
      if (!source || !target) return;

      ctx.beginPath();
      ctx.moveTo(source.x, source.y);
      ctx.lineTo(target.x, target.y);
      
      const alpha = Math.min(0.6, link.strength / 100);
      ctx.strokeStyle = link.type === 'inter' 
        ? `rgba(251, 191, 36, ${alpha})` 
        : `rgba(139, 92, 246, ${alpha * 0.5})`;
      ctx.lineWidth = Math.max(1, link.strength / 30);
      ctx.stroke();
    });

    // Draw nodes
    networkData.nodes.forEach((node, i) => {
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.radius, 0, 2 * Math.PI);
      
      // Node color based on department
      const color = deptColors[node.department] || '#6b7280';
      ctx.fillStyle = selectedNode === i ? '#ffffff' : color;
      ctx.fill();

      // Border for special nodes
      if (node.isHighPerformer) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 3;
        ctx.stroke();
      } else if (node.isAtRisk) {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Labels
      if (showLabels && node.radius > 10) {
        ctx.fillStyle = '#ffffff';
        ctx.font = '9px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(node.name.split(' ')[0], node.x, node.y + node.radius + 12);
      }
    });

    // Draw department labels
    networkData.departments.forEach(dept => {
      const angle = networkData.deptAngles[dept];
      const labelRadius = 220;
      const x = 300 + Math.cos(angle) * labelRadius;
      const y = 250 + Math.sin(angle) * labelRadius;
      
      ctx.fillStyle = deptColors[dept];
      ctx.font = 'bold 10px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(dept.substring(0, 12), x, y);
    });

    ctx.restore();
  }, [networkData, zoom, selectedNode, showLabels, deptColors]);

  // Handle canvas click
  const handleCanvasClick = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;

    // Find clicked node
    const clickedNode = networkData.nodes.findIndex(node => {
      const dx = node.x - x;
      const dy = node.y - y;
      return Math.sqrt(dx * dx + dy * dy) < node.radius;
    });

    setSelectedNode(clickedNode >= 0 ? clickedNode : null);
    if (clickedNode >= 0 && onNodeSelect) {
      onNodeSelect(networkData.nodes[clickedNode]);
    }
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-4 p-4 bg-gray-800 rounded-lg">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-purple-400" />
          <span className="text-white text-sm font-medium">Collaboration Network</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-gray-400 text-xs">Connection Threshold:</span>
          <div className="w-32">
            <Slider
              value={connectionStrength}
              onValueChange={setConnectionStrength}
              min={10}
              max={80}
              step={10}
            />
          </div>
          <span className="text-gray-500 text-xs">{connectionStrength[0]}%</span>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => setZoom(z => Math.min(2, z + 0.2))} className="h-8 w-8">
            <ZoomIn className="w-4 h-4 text-gray-400" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setZoom(z => Math.max(0.5, z - 0.2))} className="h-8 w-8">
            <ZoomOut className="w-4 h-4 text-gray-400" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setZoom(1)} className="h-8 w-8">
            <Maximize2 className="w-4 h-4 text-gray-400" />
          </Button>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowLabels(!showLabels)}
          className={showLabels ? 'bg-purple-600/20' : ''}
        >
          Labels
        </Button>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {/* Canvas */}
        <div className="md:col-span-2">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-2">
              <canvas
                ref={canvasRef}
                width={600}
                height={500}
                onClick={handleCanvasClick}
                className="w-full rounded-lg cursor-pointer"
                style={{ maxHeight: '500px' }}
              />
              {/* Legend */}
              <div className="flex flex-wrap gap-3 mt-3 px-2">
                {networkData.departments.slice(0, 6).map(dept => (
                  <div key={dept} className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: deptColors[dept] }} />
                    <span className="text-gray-400 text-xs">{dept}</span>
                  </div>
                ))}
                <div className="flex items-center gap-1 ml-4">
                  <div className="w-3 h-3 rounded-full border-2 border-green-500 bg-transparent" />
                  <span className="text-gray-400 text-xs">High Performer</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded-full border-2 border-red-500 bg-transparent" />
                  <span className="text-gray-400 text-xs">At Risk</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Network Insights */}
        <div className="space-y-4">
          {/* Stats */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">Network Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Total Nodes</span>
                <span className="text-white">{networkData.nodes.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Total Connections</span>
                <span className="text-white">{networkData.totalConnections}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Avg Connections/Person</span>
                <span className="text-white">{networkData.avgConnections}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Cross-Dept Links</span>
                <span className="text-amber-400">{networkData.crossDeptLinks.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Isolated Employees</span>
                <span className="text-red-400">{networkData.isolatedNodes.length}</span>
              </div>
            </CardContent>
          </Card>

          {/* Key Influencers */}
          <Card className="bg-green-900/20 border-green-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-green-400 text-sm flex items-center gap-2">
                <Star className="w-4 h-4" /> Key Influencers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {networkData.keyInfluencers.slice(0, 4).map((node, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <span className="text-gray-300 truncate flex-1">{node.name}</span>
                    <Badge className="bg-green-600 text-[10px]">{node.influenceScore}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Bottlenecks */}
          {networkData.bottlenecks.length > 0 && (
            <Card className="bg-orange-900/20 border-orange-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-orange-400 text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Potential Bottlenecks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {networkData.bottlenecks.map((node, i) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="text-gray-300 truncate flex-1">{node.name}</span>
                      <span className="text-orange-400">{node.connections} links</span>
                    </div>
                  ))}
                </div>
                <p className="text-gray-500 text-[10px] mt-2">High connection count may indicate single point of failure</p>
              </CardContent>
            </Card>
          )}

          {/* Selected Node Info */}
          {selectedNode !== null && networkData.nodes[selectedNode] && (
            <Card className="bg-purple-900/20 border-purple-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-purple-400 text-sm">Selected: {networkData.nodes[selectedNode].name}</CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-1">
                <p className="text-gray-400">Role: <span className="text-white">{networkData.nodes[selectedNode].role}</span></p>
                <p className="text-gray-400">Dept: <span className="text-white">{networkData.nodes[selectedNode].department}</span></p>
                <p className="text-gray-400">Influence: <span className="text-green-400">{networkData.nodes[selectedNode].influenceScore}%</span></p>
                <p className="text-gray-400">Fulfillment: <span className="text-purple-400">{networkData.nodes[selectedNode].fulfillment}%</span></p>
                <p className="text-gray-400">Operational: <span className="text-amber-400">{networkData.nodes[selectedNode].operational}%</span></p>
                {networkData.nodes[selectedNode].skills.length > 0 && (
                  <div className="mt-2">
                    <p className="text-gray-500 mb-1">Skills:</p>
                    <div className="flex flex-wrap gap-1">
                      {networkData.nodes[selectedNode].skills.map((s, i) => (
                        <Badge key={i} variant="outline" className="text-[9px] border-gray-700">{s}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}