import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Play, RefreshCw, CheckCircle2, AlertTriangle, TrendingUp, TrendingDown,
  ArrowRight, Clock, Users, Building2, Sparkles, BarChart3
} from "lucide-react";

export default function ReassignmentSimulator({ reassignment, employeeProfile, onClose }) {
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulation, setSimulation] = useState(null);

  const runSimulation = async () => {
    setIsSimulating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Simulate the detailed impact of this employee reassignment over time.

REASSIGNMENT DETAILS:
- Employee: ${reassignment.employee_name}
- Current Role: ${reassignment.current_role} in ${reassignment.current_department}
- New Role: ${reassignment.recommended_role} in ${reassignment.recommended_department}
- Expected Fulfillment Change: ${reassignment.fulfillment_change}%
- Expected Operational Change: ${reassignment.operational_change}%

EMPLOYEE PROFILE:
- MBTI: ${employeeProfile?.mbti || 'Unknown'}
- Top Strengths: ${employeeProfile?.strengths?.join(', ') || 'Various'}
- Current Fulfillment: ${employeeProfile?.fulfillmentScore || 50}%
- Current Operational: ${employeeProfile?.operationalScore || 50}%
- Skill Level: ${employeeProfile?.avgSkillLevel || 50}%

Provide a detailed simulation including:
1. Week-by-week progression for the first month
2. Month-by-month outlook for 6 months
3. Impact on team dynamics (both teams affected)
4. Training/onboarding requirements
5. Risk probability assessment
6. Best case vs worst case scenarios
7. Key success indicators to monitor
8. Recommended support interventions`,
        response_json_schema: {
          type: "object",
          properties: {
            weekly_progression: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  week: { type: "number" },
                  focus: { type: "string" },
                  expected_fulfillment: { type: "number" },
                  expected_operational: { type: "number" },
                  key_activities: { type: "array", items: { type: "string" } },
                  risks: { type: "array", items: { type: "string" } }
                }
              }
            },
            monthly_outlook: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  month: { type: "number" },
                  fulfillment_projection: { type: "number" },
                  operational_projection: { type: "number" },
                  milestones: { type: "array", items: { type: "string" } },
                  challenges: { type: "array", items: { type: "string" } }
                }
              }
            },
            team_impact: {
              type: "object",
              properties: {
                origin_team: {
                  type: "object",
                  properties: {
                    impact: { type: "string" },
                    mitigation: { type: "string" },
                    timeline_to_stabilize: { type: "string" }
                  }
                },
                destination_team: {
                  type: "object",
                  properties: {
                    impact: { type: "string" },
                    integration_timeline: { type: "string" },
                    success_factors: { type: "array", items: { type: "string" } }
                  }
                }
              }
            },
            training_requirements: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  duration: { type: "string" },
                  priority: { type: "string" },
                  resources_needed: { type: "string" }
                }
              }
            },
            risk_assessment: {
              type: "object",
              properties: {
                overall_risk_level: { type: "string" },
                success_probability: { type: "number" },
                critical_risks: { type: "array", items: { type: "string" } },
                mitigation_plan: { type: "array", items: { type: "string" } }
              }
            },
            scenarios: {
              type: "object",
              properties: {
                best_case: {
                  type: "object",
                  properties: {
                    fulfillment_at_6mo: { type: "number" },
                    operational_at_6mo: { type: "number" },
                    description: { type: "string" }
                  }
                },
                worst_case: {
                  type: "object",
                  properties: {
                    fulfillment_at_6mo: { type: "number" },
                    operational_at_6mo: { type: "number" },
                    description: { type: "string" }
                  }
                },
                most_likely: {
                  type: "object",
                  properties: {
                    fulfillment_at_6mo: { type: "number" },
                    operational_at_6mo: { type: "number" },
                    description: { type: "string" }
                  }
                }
              }
            },
            success_indicators: { type: "array", items: { type: "string" } },
            support_interventions: { type: "array", items: { type: "string" } }
          }
        }
      });

      setSimulation(result);
    } catch (error) {
      console.error("Error running simulation:", error);
    }
    setIsSimulating(false);
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Play className="w-5 h-5 text-cyan-400" />
            Reassignment Simulator
          </CardTitle>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose} className="text-gray-400">
              ✕
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {/* Reassignment Summary */}
        <div className="flex items-center gap-4 p-4 bg-gray-800 rounded-lg mb-6">
          <Avatar className="w-12 h-12">
            <AvatarFallback className="bg-purple-600 text-white">
              {reassignment.employee_name?.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="text-white font-medium">{reassignment.employee_name}</p>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-gray-400">{reassignment.current_role}</span>
              <ArrowRight className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-400">{reassignment.recommended_role}</span>
            </div>
          </div>
          <Button 
            onClick={runSimulation} 
            disabled={isSimulating}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            {isSimulating ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Simulating...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" />Run Simulation</>
            )}
          </Button>
        </div>

        {simulation && (
          <div className="space-y-6">
            {/* Scenarios Overview */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                <p className="text-green-400 text-xs font-medium mb-2">Best Case (6mo)</p>
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-2xl font-bold text-green-400">{simulation.scenarios?.best_case?.fulfillment_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Fulfillment</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-400">{simulation.scenarios?.best_case?.operational_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Operational</p>
                  </div>
                </div>
                <p className="text-gray-400 text-xs mt-2">{simulation.scenarios?.best_case?.description}</p>
              </div>
              <div className="p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                <p className="text-blue-400 text-xs font-medium mb-2">Most Likely (6mo)</p>
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-2xl font-bold text-blue-400">{simulation.scenarios?.most_likely?.fulfillment_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Fulfillment</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-blue-400">{simulation.scenarios?.most_likely?.operational_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Operational</p>
                  </div>
                </div>
                <p className="text-gray-400 text-xs mt-2">{simulation.scenarios?.most_likely?.description}</p>
              </div>
              <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                <p className="text-red-400 text-xs font-medium mb-2">Worst Case (6mo)</p>
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-2xl font-bold text-red-400">{simulation.scenarios?.worst_case?.fulfillment_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Fulfillment</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-400">{simulation.scenarios?.worst_case?.operational_at_6mo}%</p>
                    <p className="text-xs text-gray-500">Operational</p>
                  </div>
                </div>
                <p className="text-gray-400 text-xs mt-2">{simulation.scenarios?.worst_case?.description}</p>
              </div>
            </div>

            {/* Risk Assessment */}
            <div className="p-4 bg-gray-800 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <p className="text-white font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Risk Assessment
                </p>
                <div className="flex items-center gap-2">
                  <Badge className={
                    simulation.risk_assessment?.overall_risk_level === 'low' ? 'bg-green-600' :
                    simulation.risk_assessment?.overall_risk_level === 'medium' ? 'bg-amber-600' : 'bg-red-600'
                  }>
                    {simulation.risk_assessment?.overall_risk_level} risk
                  </Badge>
                  <Badge className="bg-cyan-600">
                    {simulation.risk_assessment?.success_probability}% success probability
                  </Badge>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-red-400 text-xs mb-2">Critical Risks</p>
                  {simulation.risk_assessment?.critical_risks?.map((risk, i) => (
                    <p key={i} className="text-gray-300 text-xs mb-1">⚠ {risk}</p>
                  ))}
                </div>
                <div>
                  <p className="text-green-400 text-xs mb-2">Mitigation Plan</p>
                  {simulation.risk_assessment?.mitigation_plan?.map((action, i) => (
                    <p key={i} className="text-gray-300 text-xs mb-1">✓ {action}</p>
                  ))}
                </div>
              </div>
            </div>

            {/* Weekly Progression */}
            <div>
              <p className="text-white font-medium mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-400" />
                First Month Progression
              </p>
              <div className="grid md:grid-cols-4 gap-3">
                {simulation.weekly_progression?.map((week, i) => (
                  <div key={i} className="p-3 bg-gray-800 rounded-lg">
                    <p className="text-purple-400 text-xs font-medium mb-2">Week {week.week}</p>
                    <p className="text-gray-300 text-sm mb-2">{week.focus}</p>
                    <div className="flex gap-2 mb-2">
                      <Badge variant="outline" className="text-[10px] border-purple-700 text-purple-400">
                        F: {week.expected_fulfillment}%
                      </Badge>
                      <Badge variant="outline" className="text-[10px] border-amber-700 text-amber-400">
                        O: {week.expected_operational}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Team Impact */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-red-900/10 border border-red-900 rounded-lg">
                <p className="text-red-400 text-xs font-medium mb-2 flex items-center gap-1">
                  <Users className="w-3 h-3" /> Origin Team Impact
                </p>
                <p className="text-gray-300 text-sm mb-2">{simulation.team_impact?.origin_team?.impact}</p>
                <p className="text-gray-400 text-xs">Mitigation: {simulation.team_impact?.origin_team?.mitigation}</p>
                <p className="text-gray-500 text-xs mt-1">Stabilizes in: {simulation.team_impact?.origin_team?.timeline_to_stabilize}</p>
              </div>
              <div className="p-4 bg-green-900/10 border border-green-900 rounded-lg">
                <p className="text-green-400 text-xs font-medium mb-2 flex items-center gap-1">
                  <Building2 className="w-3 h-3" /> Destination Team Impact
                </p>
                <p className="text-gray-300 text-sm mb-2">{simulation.team_impact?.destination_team?.impact}</p>
                <p className="text-gray-400 text-xs">Integration: {simulation.team_impact?.destination_team?.integration_timeline}</p>
              </div>
            </div>

            {/* Training Requirements */}
            {simulation.training_requirements?.length > 0 && (
              <div>
                <p className="text-white font-medium mb-3">Training Requirements</p>
                <div className="grid md:grid-cols-2 gap-3">
                  {simulation.training_requirements.map((training, i) => (
                    <div key={i} className="p-3 bg-gray-800 rounded-lg flex items-start justify-between">
                      <div>
                        <p className="text-gray-300 text-sm">{training.area}</p>
                        <p className="text-gray-500 text-xs">{training.duration} • {training.resources_needed}</p>
                      </div>
                      <Badge className={
                        training.priority === 'high' ? 'bg-red-600' :
                        training.priority === 'medium' ? 'bg-amber-600' : 'bg-blue-600'
                      }>
                        {training.priority}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Success Indicators */}
            <div className="p-4 bg-cyan-900/20 border border-cyan-800 rounded-lg">
              <p className="text-cyan-400 text-xs font-medium mb-2">Key Success Indicators to Monitor</p>
              <div className="flex flex-wrap gap-2">
                {simulation.success_indicators?.map((indicator, i) => (
                  <Badge key={i} variant="outline" className="border-cyan-700 text-cyan-400 text-xs">
                    {indicator}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}