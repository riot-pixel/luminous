import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ArrowRight, Building2 } from "lucide-react";

export default function DepartmentalAISection({ onComplete, onBack, initialData, userDepartment, userRole }) {
  const [data, setData] = useState(initialData || {
    department_strengths: ["", "", ""],
    department_aspirations: ["", "", ""],
    cross_team_collaboration: "",
    contribution_vision: "",
  });

  const handleStrengthChange = (index, value) => {
    const newStrengths = [...data.department_strengths];
    newStrengths[index] = value;
    setData({ ...data, department_strengths: newStrengths });
  };

  const handleAspirationChange = (index, value) => {
    const newAspirations = [...data.department_aspirations];
    newAspirations[index] = value;
    setData({ ...data, department_aspirations: newAspirations });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card className="border-2 border-blue-200">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl">Departmental Appreciative Inquiry</CardTitle>
              <p className="text-sm text-gray-600">{userDepartment} • {userRole}</p>
            </div>
          </div>
          <CardDescription className="text-base">
            Your insights will contribute to organization-wide strategic planning and departmental excellence initiatives
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Your Impact:</strong> These responses are aggregated with your colleagues to identify 
              department-wide strengths, aspirations, and strategic opportunities. Your voice shapes the future 
              direction of {userDepartment} and the broader organization.
            </p>
          </div>

          <div className="space-y-3">
            <Label className="text-lg font-semibold text-blue-700">
              Discover: What makes {userDepartment} excellent?
            </Label>
            <p className="text-sm text-gray-600">
              Identify the top 3 strengths, capabilities, or achievements of your department
            </p>
            {[0, 1, 2].map((index) => (
              <Input
                key={index}
                value={data.department_strengths[index]}
                onChange={(e) => handleStrengthChange(index, e.target.value)}
                placeholder={`Department strength ${index + 1}`}
                required
              />
            ))}
          </div>

          <div className="space-y-3">
            <Label className="text-lg font-semibold text-blue-700">
              Dream: Where could {userDepartment} go?
            </Label>
            <p className="text-sm text-gray-600">
              What are the top 3 aspirations or possibilities for your department's future?
            </p>
            {[0, 1, 2].map((index) => (
              <Input
                key={index}
                value={data.department_aspirations[index]}
                onChange={(e) => handleAspirationChange(index, e.target.value)}
                placeholder={`Department aspiration ${index + 1}`}
                required
              />
            ))}
          </div>

          <div className="space-y-2">
            <Label className="text-lg font-semibold text-blue-700">
              Design: How can we collaborate better across teams?
            </Label>
            <p className="text-sm text-gray-600">
              What opportunities do you see for {userDepartment} to collaborate more effectively with other departments?
            </p>
            <Textarea
              value={data.cross_team_collaboration}
              onChange={(e) => setData({ ...data, cross_team_collaboration: e.target.value })}
              placeholder="Describe collaboration opportunities, breaking down silos, shared initiatives..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label className="text-lg font-semibold text-blue-700">
              Destiny: How do you envision contributing to organizational success?
            </Label>
            <p className="text-sm text-gray-600">
              From your role in {userDepartment}, how can you personally contribute to the organization's strategic goals?
            </p>
            <Textarea
              value={data.contribution_vision}
              onChange={(e) => setData({ ...data, contribution_vision: e.target.value })}
              placeholder="Your personal commitments, how you'll leverage your strengths, impact you want to create..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
              Continue
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}