import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowRight, ArrowLeft, Heart, Sparkles } from "lucide-react";

export default function AppreciativeInquirySection({ onComplete, onBack, initialData, isProcessing }) {
  const [data, setData] = useState(
    initialData || {
      define: { core_topic: "", focus_area: "" },
      discover: { peak_experiences: ["", "", ""], core_values: ["", "", "", ""] },
      dream: { aspirations: ["", "", ""], ideal_future: "" },
      design: { action_commitments: ["", "", ""], support_needed: ["", ""] },
      destiny: { next_steps: ["", "", ""], accountability_plan: "" },
    }
  );

  const updateField = (section, field, value, index = null) => {
    setData(prev => {
      const newData = { ...prev };
      if (index !== null) {
        newData[section][field][index] = value;
      } else {
        newData[section][field] = value;
      }
      return newData;
    });
  };

  const handleComplete = () => {
    onComplete(data);
  };

  const isComplete = () => {
    return (
      data.define.core_topic &&
      data.define.focus_area &&
      data.discover.peak_experiences.some(e => e) &&
      data.discover.core_values.some(v => v) &&
      data.dream.aspirations.some(a => a) &&
      data.dream.ideal_future &&
      data.design.action_commitments.some(c => c) &&
      data.destiny.next_steps.some(s => s)
    );
  };

  return (
    <Card className="bg-white border-none shadow-xl">
      <CardHeader className="bg-gradient-to-r from-pink-600 to-rose-600 text-white rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Heart className="w-7 h-7" />
          </div>
          <div>
            <CardTitle className="text-2xl">Appreciative Inquiry - The 5 D's</CardTitle>
            <CardDescription className="text-pink-100">
              Design your ideal future through strength-based reflection
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-8 space-y-10">
        {/* Define */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-500 rounded-lg flex items-center justify-center text-white font-bold">
              1
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Define</h3>
              <p className="text-sm text-gray-600">What do you want to focus on?</p>
            </div>
          </div>
          <div className="pl-13 space-y-4">
            <div>
              <Label htmlFor="core_topic">Core Topic or Area of Life</Label>
              <Input
                id="core_topic"
                value={data.define.core_topic}
                onChange={(e) => updateField("define", "core_topic", e.target.value)}
                placeholder="e.g., Career, Relationships, Health"
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="focus_area">Specific Focus Within This Area</Label>
              <Input
                id="focus_area"
                value={data.define.focus_area}
                onChange={(e) => updateField("define", "focus_area", e.target.value)}
                placeholder="What specific aspect do you want to explore?"
                className="mt-2"
              />
            </div>
          </div>
        </div>

        {/* Discover */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-500 rounded-lg flex items-center justify-center text-white font-bold">
              2
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Discover</h3>
              <p className="text-sm text-gray-600">Appreciate what has worked well</p>
            </div>
          </div>
          <div className="pl-13 space-y-4">
            <div>
              <Label>Peak Experiences (Times when you felt most alive and fulfilled)</Label>
              {data.discover.peak_experiences.map((exp, index) => (
                <Input
                  key={index}
                  value={exp}
                  onChange={(e) => updateField("discover", "peak_experiences", e.target.value, index)}
                  placeholder={`Peak experience ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
            <div>
              <Label>Core Values (What matters most to you)</Label>
              {data.discover.core_values.map((value, index) => (
                <Input
                  key={index}
                  value={value}
                  onChange={(e) => updateField("discover", "core_values", e.target.value, index)}
                  placeholder={`Core value ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
          </div>
        </div>

        {/* Dream */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center text-white font-bold">
              3
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Dream</h3>
              <p className="text-sm text-gray-600">Envision your ideal future</p>
            </div>
          </div>
          <div className="pl-13 space-y-4">
            <div>
              <Label>Your Aspirations</Label>
              {data.dream.aspirations.map((asp, index) => (
                <Input
                  key={index}
                  value={asp}
                  onChange={(e) => updateField("dream", "aspirations", e.target.value, index)}
                  placeholder={`Aspiration ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
            <div>
              <Label htmlFor="ideal_future">Describe Your Ideal Future (3-5 years from now)</Label>
              <Textarea
                id="ideal_future"
                value={data.dream.ideal_future}
                onChange={(e) => updateField("dream", "ideal_future", e.target.value)}
                placeholder="Paint a vivid picture of your ideal future..."
                rows={4}
                className="mt-2"
              />
            </div>
          </div>
        </div>

        {/* Design */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center text-white font-bold">
              4
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Design</h3>
              <p className="text-sm text-gray-600">Create action commitments</p>
            </div>
          </div>
          <div className="pl-13 space-y-4">
            <div>
              <Label>Action Commitments (Specific steps you'll take)</Label>
              {data.design.action_commitments.map((comm, index) => (
                <Input
                  key={index}
                  value={comm}
                  onChange={(e) => updateField("design", "action_commitments", e.target.value, index)}
                  placeholder={`Action commitment ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
            <div>
              <Label>Support Needed (Resources, people, or systems)</Label>
              {data.design.support_needed.map((sup, index) => (
                <Input
                  key={index}
                  value={sup}
                  onChange={(e) => updateField("design", "support_needed", e.target.value, index)}
                  placeholder={`Support needed ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
          </div>
        </div>

        {/* Destiny */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-amber-500 rounded-lg flex items-center justify-center text-white font-bold">
              5
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Destiny</h3>
              <p className="text-sm text-gray-600">Sustain momentum and accountability</p>
            </div>
          </div>
          <div className="pl-13 space-y-4">
            <div>
              <Label>Next Steps (Actions in the next 30 days)</Label>
              {data.destiny.next_steps.map((step, index) => (
                <Input
                  key={index}
                  value={step}
                  onChange={(e) => updateField("destiny", "next_steps", e.target.value, index)}
                  placeholder={`Next step ${index + 1}`}
                  className="mt-2"
                />
              ))}
            </div>
            <div>
              <Label htmlFor="accountability_plan">Accountability Plan</Label>
              <Textarea
                id="accountability_plan"
                value={data.destiny.accountability_plan}
                onChange={(e) => updateField("destiny", "accountability_plan", e.target.value)}
                placeholder="How will you track progress and stay accountable?"
                rows={3}
                className="mt-2"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4 pt-6">
          {onBack && (
            <Button
              variant="outline"
              size="lg"
              onClick={onBack}
              disabled={isProcessing}
              className="flex-1"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          )}
          <Button
            size="lg"
            onClick={handleComplete}
            disabled={!isComplete() || isProcessing}
            className="flex-1 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700"
          >
            {isProcessing ? (
              <>
                <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                Generating Your Insights...
              </>
            ) : (
              <>
                Complete Assessment
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}