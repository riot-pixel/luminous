import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowRight, ArrowLeft, Brain } from "lucide-react";

const questions = [
  {
    id: 1,
    text: "I find deep meaning in exploring my inner thoughts and consciousness",
    quadrant: "individual_interior",
    category: "intentional"
  },
  {
    id: 2,
    text: "I'm naturally drawn to understanding my own behaviors and habits",
    quadrant: "individual_exterior",
    category: "behavioral"
  },
  {
    id: 3,
    text: "I feel energized by shared cultural experiences and collective values",
    quadrant: "collective_interior",
    category: "cultural"
  },
  {
    id: 4,
    text: "I'm interested in systems, structures, and how society functions",
    quadrant: "collective_exterior",
    category: "social"
  },
  {
    id: 5,
    text: "Meditation or self-reflection practices deeply resonate with me",
    quadrant: "individual_interior",
    category: "intentional"
  },
  {
    id: 6,
    text: "I track my physical health metrics and enjoy optimizing performance",
    quadrant: "individual_exterior",
    category: "behavioral"
  },
  {
    id: 7,
    text: "Understanding different worldviews and belief systems fascinates me",
    quadrant: "collective_interior",
    category: "cultural"
  },
  {
    id: 8,
    text: "I pay attention to economic systems and societal infrastructure",
    quadrant: "collective_exterior",
    category: "social"
  },
  {
    id: 9,
    text: "I regularly examine my motivations and values",
    quadrant: "individual_interior",
    category: "intentional"
  },
  {
    id: 10,
    text: "I enjoy learning new skills and measuring my progress",
    quadrant: "individual_exterior",
    category: "behavioral"
  },
  {
    id: 11,
    text: "I'm drawn to art, music, and expressions of collective consciousness",
    quadrant: "collective_interior",
    category: "cultural"
  },
  {
    id: 12,
    text: "I think about how organizations and governments can be improved",
    quadrant: "collective_exterior",
    category: "social"
  },
];

const developmentLevels = [
  { id: "concrete", label: "Concrete/Literal thinking", description: "Focus on physical, tangible reality" },
  { id: "rational", label: "Rational/Analytical thinking", description: "Logic, reason, and systematic analysis" },
  { id: "pluralistic", label: "Pluralistic/Inclusive thinking", description: "Multiple perspectives and relativism" },
  { id: "integral", label: "Integral/Systemic thinking", description: "Integration of all perspectives" },
  { id: "transpersonal", label: "Transpersonal awareness", description: "Beyond personal ego, unity consciousness" },
];

const intelligenceLines = [
  { id: "cognitive", label: "Cognitive Intelligence", description: "Thinking and reasoning" },
  { id: "emotional", label: "Emotional Intelligence", description: "Understanding and managing emotions" },
  { id: "moral", label: "Moral Intelligence", description: "Ethics and values" },
  { id: "interpersonal", label: "Interpersonal Intelligence", description: "Relating to others" },
  { id: "creative", label: "Creative Intelligence", description: "Innovation and artistry" },
  { id: "spiritual", label: "Spiritual Intelligence", description: "Meaning and transcendence" },
];

export default function IntegralTheorySection({ onComplete, onBack, initialData, isProcessing }) {
  const [responses, setResponses] = useState(initialData?.responses || {});
  const [selectedLevels, setSelectedLevels] = useState(initialData?.selectedLevels || []);
  const [primaryLine, setPrimaryLine] = useState(initialData?.primaryLine || "");

  const handleResponseChange = (questionId, value) => {
    setResponses(prev => ({
      ...prev,
      [questionId]: parseInt(value)
    }));
  };

  const handleComplete = () => {
    const quadrantScores = {
      individual_interior: 0,
      individual_exterior: 0,
      collective_interior: 0,
      collective_exterior: 0,
    };

    questions.forEach(q => {
      const response = responses[q.id] || 0;
      quadrantScores[q.quadrant] += response;
    });

    // Normalize scores to 0-100
    Object.keys(quadrantScores).forEach(key => {
      const maxScore = questions.filter(q => q.quadrant === key).length * 5;
      quadrantScores[key] = Math.round((quadrantScores[key] / maxScore) * 100);
    });

    onComplete({
      quadrants: quadrantScores,
      levels: selectedLevels,
      primary_line: primaryLine,
      responses,
      selectedLevels,
      primaryLine,
    });
  };

  const allQuestionsAnswered = questions.every(q => responses[q.id]);
  const canProceed = allQuestionsAnswered && selectedLevels.length > 0 && primaryLine;

  return (
    <div className="space-y-8">
      <Card className="bg-white border-none shadow-xl">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
              <Brain className="w-7 h-7" />
            </div>
            <div>
              <CardTitle className="text-2xl">Integral Theory Assessment</CardTitle>
              <CardDescription className="text-purple-100">
                Exploring the four quadrants of consciousness and development
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-8 space-y-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Part 1: Quadrant Preferences
            </h3>
            <p className="text-gray-600 mb-6">
              Rate how much each statement resonates with you (1 = Not at all, 5 = Completely)
            </p>
            
            <div className="space-y-6">
              {questions.map((question) => (
                <div key={question.id} className="p-5 bg-purple-50 rounded-xl">
                  <p className="text-gray-800 mb-4 font-medium">{question.text}</p>
                  <RadioGroup
                    value={responses[question.id]?.toString()}
                    onValueChange={(value) => handleResponseChange(question.id, value)}
                    className="flex gap-4"
                  >
                    {[1, 2, 3, 4, 5].map((value) => (
                      <div key={value} className="flex items-center space-x-2">
                        <RadioGroupItem value={value.toString()} id={`q${question.id}-${value}`} />
                        <Label htmlFor={`q${question.id}-${value}`} className="cursor-pointer">
                          {value}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Part 2: Development Levels
            </h3>
            <p className="text-gray-600 mb-6">
              Select all development levels you identify with or have experienced
            </p>
            
            <div className="space-y-3">
              {developmentLevels.map((level) => (
                <div
                  key={level.id}
                  onClick={() => {
                    setSelectedLevels(prev =>
                      prev.includes(level.id)
                        ? prev.filter(l => l !== level.id)
                        : [...prev, level.id]
                    );
                  }}
                  className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                    selectedLevels.includes(level.id)
                      ? "border-purple-600 bg-purple-50"
                      : "border-gray-200 hover:border-purple-300"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-gray-900">{level.label}</p>
                      <p className="text-sm text-gray-600">{level.description}</p>
                    </div>
                    <div className={`w-6 h-6 rounded-full border-2 ${
                      selectedLevels.includes(level.id)
                        ? "border-purple-600 bg-purple-600"
                        : "border-gray-300"
                    }`}>
                      {selectedLevels.includes(level.id) && (
                        <div className="w-full h-full flex items-center justify-center text-white text-xs">✓</div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Part 3: Primary Intelligence Line
            </h3>
            <p className="text-gray-600 mb-6">
              Which area represents your most developed intelligence?
            </p>
            
            <div className="grid md:grid-cols-2 gap-4">
              {intelligenceLines.map((line) => (
                <div
                  key={line.id}
                  onClick={() => setPrimaryLine(line.id)}
                  className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                    primaryLine === line.id
                      ? "border-purple-600 bg-purple-50"
                      : "border-gray-200 hover:border-purple-300"
                  }`}
                >
                  <p className="font-semibold text-gray-900">{line.label}</p>
                  <p className="text-sm text-gray-600 mt-1">{line.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-4 pt-6">
            {onBack && (
              <Button
                variant="outline"
                size="lg"
                onClick={onBack}
                className="flex-1"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back
              </Button>
            )}
            <Button
              size="lg"
              onClick={handleComplete}
              disabled={!canProceed || isProcessing}
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isProcessing ? "Processing..." : "Continue"}
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}