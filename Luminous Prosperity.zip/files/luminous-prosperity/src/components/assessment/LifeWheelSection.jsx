import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { ArrowRight, ArrowLeft, BarChart3 } from "lucide-react";

const lifeAreas = [
  { id: "career", label: "Career & Work", description: "Professional fulfillment and growth" },
  { id: "finances", label: "Finances", description: "Financial security and management" },
  { id: "health", label: "Health & Fitness", description: "Physical and mental well-being" },
  { id: "relationships", label: "Relationships", description: "Quality of personal connections" },
  { id: "personal_growth", label: "Personal Growth", description: "Learning and self-development" },
  { id: "fun_recreation", label: "Fun & Recreation", description: "Leisure and enjoyment" },
  { id: "environment", label: "Physical Environment", description: "Home and surroundings" },
  { id: "contribution", label: "Contribution & Purpose", description: "Making a difference" },
];

export default function LifeWheelSection({ onComplete, onBack, initialData }) {
  const [scores, setScores] = useState(
    initialData?.scores || {
      career: 5,
      finances: 5,
      health: 5,
      relationships: 5,
      personal_growth: 5,
      fun_recreation: 5,
      environment: 5,
      contribution: 5,
    }
  );

  const handleScoreChange = (area, value) => {
    setScores(prev => ({
      ...prev,
      [area]: value[0],
    }));
  };

  const calculateOverallSatisfaction = () => {
    const total = Object.values(scores).reduce((sum, score) => sum + score, 0);
    return Math.round((total / (lifeAreas.length * 10)) * 100);
  };

  const handleComplete = () => {
    onComplete({
      ...scores,
      overall_satisfaction: calculateOverallSatisfaction(),
      scores,
    });
  };

  return (
    <Card className="bg-white border-none shadow-xl">
      <CardHeader className="bg-gradient-to-r from-violet-600 to-purple-600 text-white rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-7 h-7" />
          </div>
          <div>
            <CardTitle className="text-2xl">Life Wheel Assessment</CardTitle>
            <CardDescription className="text-violet-100">
              Evaluate your satisfaction across key life areas
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-8 space-y-8">
        <div>
          <p className="text-gray-600 mb-8">
            Rate your current satisfaction in each life area from 1 (very dissatisfied) to 10 (completely satisfied)
          </p>

          <div className="space-y-8">
            {lifeAreas.map((area) => (
              <div key={area.id} className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <p className="font-semibold text-gray-900">{area.label}</p>
                      <p className="text-sm text-gray-600">{area.description}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-2xl font-bold text-violet-600">{scores[area.id]}</span>
                      <span className="text-sm text-gray-500">/ 10</span>
                    </div>
                  </div>
                </div>
                <div className="px-2">
                  <Slider
                    value={[scores[area.id]]}
                    onValueChange={(value) => handleScoreChange(area.id, value)}
                    min={1}
                    max={10}
                    step={1}
                    className="py-2"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>1</span>
                    <span>5</span>
                    <span>10</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-gradient-to-r from-violet-50 to-purple-50 rounded-xl">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">Overall Life Satisfaction</p>
            <div className="flex items-center justify-center gap-2">
              <div className="text-5xl font-bold text-violet-600">
                {calculateOverallSatisfaction()}
              </div>
              <span className="text-xl text-gray-500">/ 100</span>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              {calculateOverallSatisfaction() >= 80 && "Excellent balance across life areas"}
              {calculateOverallSatisfaction() >= 60 && calculateOverallSatisfaction() < 80 && "Good overall balance with room for growth"}
              {calculateOverallSatisfaction() >= 40 && calculateOverallSatisfaction() < 60 && "Moderate balance - several areas need attention"}
              {calculateOverallSatisfaction() < 40 && "Significant opportunities for improvement"}
            </p>
          </div>
        </div>

        <div className="flex gap-4 pt-6">
          {onBack && (
            <Button
              variant="outline"
              size="lg"
              onClick={onBack}
              className="flex-1"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          )}
          <Button
            size="lg"
            onClick={handleComplete}
            className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
          >
            Continue
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}