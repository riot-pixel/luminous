import React from "react";
import { CheckCircle2 } from "lucide-react";

export default function ProgressTracker({ sections, currentSection, completedSections }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-8 border border-purple-100">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Your Assessment Journey</h2>
          <p className="text-gray-600 mt-1">
            Section {currentSection + 1} of {sections.length}
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-purple-600">{Math.round((completedSections / sections.length) * 100)}%</div>
          <p className="text-sm text-gray-500">Complete</p>
        </div>
      </div>

      <div className="relative">
        <div className="absolute top-5 left-0 w-full h-1 bg-gray-200 rounded-full">
          <div 
            className="h-full bg-gradient-to-r from-purple-600 to-blue-600 rounded-full transition-all duration-500"
            style={{ width: `${(completedSections / sections.length) * 100}%` }}
          />
        </div>

        <div className="relative flex justify-between">
          {sections.map((section, index) => (
            <div key={index} className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                  index < currentSection
                    ? "bg-gradient-to-br from-purple-600 to-blue-600 border-purple-600"
                    : index === currentSection
                    ? "bg-white border-purple-600 ring-4 ring-purple-100"
                    : "bg-white border-gray-300"
                }`}
              >
                {index < currentSection ? (
                  <CheckCircle2 className="w-6 h-6 text-white" />
                ) : (
                  <span className={`text-sm font-semibold ${
                    index === currentSection ? "text-purple-600" : "text-gray-400"
                  }`}>
                    {index + 1}
                  </span>
                )}
              </div>
              <span className={`text-xs mt-2 text-center max-w-[80px] ${
                index === currentSection ? "text-purple-600 font-semibold" : "text-gray-500"
              }`}>
                {section}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}