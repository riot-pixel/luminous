import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowRight, ArrowLeft, Target } from "lucide-react";

const strengths = {
  wisdom: [
    { id: "creativity", name: "Creativity", description: "Original thinking and innovation" },
    { id: "curiosity", name: "Curiosity", description: "Interest and exploration" },
    { id: "judgment", name: "Judgment", description: "Critical thinking" },
    { id: "love_of_learning", name: "Love of Learning", description: "Mastering new skills" },
    { id: "perspective", name: "Perspective", description: "Wisdom and insight" },
  ],
  courage: [
    { id: "bravery", name: "Bravery", description: "Facing fears and challenges" },
    { id: "perseverance", name: "Perseverance", description: "Finishing what you start" },
    { id: "honesty", name: "Honesty", description: "Authenticity and integrity" },
    { id: "zest", name: "Zest", description: "Enthusiasm and energy" },
  ],
  humanity: [
    { id: "love", name: "Love", description: "Valuing close relationships" },
    { id: "kindness", name: "Kindness", description: "Generosity and compassion" },
    { id: "social_intelligence", name: "Social Intelligence", description: "Understanding people" },
  ],
  justice: [
    { id: "teamwork", name: "Teamwork", description: "Working well in groups" },
    { id: "fairness", name: "Fairness", description: "Treating all equally" },
    { id: "leadership", name: "Leadership", description: "Organizing and motivating" },
  ],
  temperance: [
    { id: "forgiveness", name: "Forgiveness", description: "Mercy and compassion" },
    { id: "humility", name: "Humility", description: "Modest and grounded" },
    { id: "prudence", name: "Prudence", description: "Careful and thoughtful" },
    { id: "self_regulation", name: "Self-Regulation", description: "Discipline and control" },
  ],
  transcendence: [
    { id: "appreciation", name: "Appreciation of Beauty", description: "Noticing excellence" },
    { id: "gratitude", name: "Gratitude", description: "Thankfulness" },
    { id: "hope", name: "Hope", description: "Optimism about the future" },
    { id: "humor", name: "Humor", description: "Playfulness and laughter" },
    { id: "spirituality", name: "Spirituality", description: "Meaning and purpose" },
  ],
};

export default function StrengthsSection({ onComplete, onBack, initialData }) {
  const [ratings, setRatings] = useState(initialData?.ratings || {});

  const handleRatingChange = (strengthId, value) => {
    setRatings(prev => ({
      ...prev,
      [strengthId]: parseInt(value),
    }));
  };

  const handleComplete = () => {
    const allStrengths = Object.values(strengths).flat();
    const strengthsWithScores = allStrengths.map(s => ({
      name: s.name,
      score: ratings[s.id] || 0,
      category: Object.keys(strengths).find(cat => 
        strengths[cat].some(str => str.id === s.id)
      ),
    }));

    const topStrengths = strengthsWithScores
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    const categoryScores = {};
    Object.keys(strengths).forEach(category => {
      const categoryStrengths = strengths[category];
      const totalScore = categoryStrengths.reduce((sum, s) => sum + (ratings[s.id] || 0), 0);
      const maxScore = categoryStrengths.length * 5;
      categoryScores[category] = Math.round((totalScore / maxScore) * 100);
    });

    onComplete({
      top_strengths: topStrengths,
      strength_categories: categoryScores,
      ratings,
    });
  };

  const allRated = Object.values(strengths)
    .flat()
    .every(s => ratings[s.id] !== undefined);

  return (
    <Card className="bg-white border-none shadow-xl">
      <CardHeader className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Target className="w-7 h-7" />
          </div>
          <div>
            <CardTitle className="text-2xl">Strengths Assessment</CardTitle>
            <CardDescription className="text-indigo-100">
              Identify your signature character strengths
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-8 space-y-8">
        <p className="text-gray-600">
          Rate how much each strength describes you (1 = Not like me at all, 5 = Very much like me)
        </p>

        {Object.entries(strengths).map(([category, categoryStrengths]) => (
          <div key={category} className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 capitalize border-b pb-2">
              {category}
            </h3>
            <div className="space-y-4">
              {categoryStrengths.map((strength) => (
                <div key={strength.id} className="p-5 bg-indigo-50 rounded-xl">
                  <div className="mb-3">
                    <p className="font-semibold text-gray-900">{strength.name}</p>
                    <p className="text-sm text-gray-600">{strength.description}</p>
                  </div>
                  <RadioGroup
                    value={ratings[strength.id]?.toString()}
                    onValueChange={(value) => handleRatingChange(strength.id, value)}
                    className="flex gap-4"
                  >
                    {[1, 2, 3, 4, 5].map((value) => (
                      <div key={value} className="flex items-center space-x-2">
                        <RadioGroupItem
                          value={value.toString()}
                          id={`${strength.id}-${value}`}
                        />
                        <Label htmlFor={`${strength.id}-${value}`} className="cursor-pointer">
                          {value}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              ))}
            </div>
          </div>
        ))}

        <div className="flex gap-4 pt-6">
          {onBack && (
            <Button
              variant="outline"
              size="lg"
              onClick={onBack}
              className="flex-1"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          )}
          <Button
            size="lg"
            onClick={handleComplete}
            disabled={!allRated}
            className="flex-1 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700"
          >
            Continue
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}