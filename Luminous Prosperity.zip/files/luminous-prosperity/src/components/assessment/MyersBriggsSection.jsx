import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { ArrowRight, ArrowLeft, Users } from "lucide-react";

const dimensions = [
  {
    id: "ei",
    name: "Extraversion - Introversion",
    left: "Extraversion (E)",
    right: "Introversion (I)",
    leftDesc: "Energized by external world",
    rightDesc: "Energized by internal world",
  },
  {
    id: "sn",
    name: "Sensing - Intuition",
    left: "Sensing (S)",
    right: "Intuition (N)",
    leftDesc: "Focus on concrete facts",
    rightDesc: "Focus on patterns and possibilities",
  },
  {
    id: "tf",
    name: "Thinking - Feeling",
    left: "Thinking (T)",
    right: "Feeling (F)",
    leftDesc: "Decisions based on logic",
    rightDesc: "Decisions based on values",
  },
  {
    id: "jp",
    name: "Judging - Perceiving",
    left: "Judging (J)",
    right: "Perceiving (P)",
    leftDesc: "Prefer structure and plans",
    rightDesc: "Prefer flexibility and spontaneity",
  },
  {
    id: "at",
    name: "Assertive - Turbulent",
    left: "Assertive (A)",
    right: "Turbulent (T)",
    leftDesc: "Self-assured and stress-resistant",
    rightDesc: "Success-driven and perfectionistic",
  },
];

const cognitiveFunctions = [
  { id: "Te", label: "Extraverted Thinking", description: "Organizing external world logically" },
  { id: "Ti", label: "Introverted Thinking", description: "Internal logical analysis" },
  { id: "Fe", label: "Extraverted Feeling", description: "Harmony in external relationships" },
  { id: "Fi", label: "Introverted Feeling", description: "Internal values and emotions" },
  { id: "Se", label: "Extraverted Sensing", description: "Present moment awareness" },
  { id: "Si", label: "Introverted Sensing", description: "Memory and past experiences" },
  { id: "Ne", label: "Extraverted Intuition", description: "Exploring possibilities" },
  { id: "Ni", label: "Introverted Intuition", description: "Internal insights and visions" },
];

export default function MyersBriggsSection({ onComplete, onBack, initialData }) {
  const [scores, setScores] = useState(
    initialData?.scores || {
      ei: 50,
      sn: 50,
      tf: 50,
      jp: 50,
      at: 50,
    }
  );
  const [selectedFunctions, setSelectedFunctions] = useState(initialData?.selectedFunctions || []);

  const handleScoreChange = (id, value) => {
    setScores(prev => ({
      ...prev,
      [id]: value[0],
    }));
  };

  const calculateType = () => {
    const type = [];
    type.push(scores.ei < 50 ? "E" : "I");
    type.push(scores.sn < 50 ? "S" : "N");
    type.push(scores.tf < 50 ? "T" : "F");
    type.push(scores.jp < 50 ? "J" : "P");
    return type.join("");
  };

  const handleComplete = () => {
    const type = calculateType();
    const dimensions = {
      extraversion_introversion: scores.ei - 50,
      sensing_intuition: scores.sn - 50,
      thinking_feeling: scores.tf - 50,
      judging_perceiving: scores.jp - 50,
      assertive_turbulent: scores.at - 50,
    };

    onComplete({
      type,
      dimensions,
      cognitive_functions: selectedFunctions,
      scores,
      selectedFunctions,
    });
  };

  const canProceed = selectedFunctions.length >= 3;

  return (
    <Card className="bg-white border-none shadow-xl">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Users className="w-7 h-7" />
          </div>
          <div>
            <CardTitle className="text-2xl">Extended Myers-Briggs Assessment</CardTitle>
            <CardDescription className="text-blue-100">
              Discover your personality type and cognitive functions
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-8 space-y-8">
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Personality Dimensions
          </h3>
          <p className="text-gray-600 mb-8">
            Move each slider to indicate where you fall on each dimension
          </p>

          <div className="space-y-8">
            {dimensions.map((dimension) => (
              <div key={dimension.id} className="space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold text-gray-900">{dimension.left}</p>
                    <p className="text-sm text-gray-600">{dimension.leftDesc}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{dimension.right}</p>
                    <p className="text-sm text-gray-600">{dimension.rightDesc}</p>
                  </div>
                </div>
                <Slider
                  value={[scores[dimension.id]]}
                  onValueChange={(value) => handleScoreChange(dimension.id, value)}
                  min={0}
                  max={100}
                  step={1}
                  className="py-4"
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Strong {dimension.left.split(' ')[0]}</span>
                  <span>Neutral</span>
                  <span>Strong {dimension.right.split(' ')[0]}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl text-center">
            <p className="text-sm text-gray-600 mb-2">Your Personality Type</p>
            <p className="text-4xl font-bold text-blue-600">{calculateType()}-{scores.at < 50 ? "A" : "T"}</p>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-4">
            Cognitive Functions
          </h3>
          <p className="text-gray-600 mb-6">
            Select your top 3-4 cognitive functions (how you process information)
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            {cognitiveFunctions.map((func) => (
              <div
                key={func.id}
                onClick={() => {
                  setSelectedFunctions(prev =>
                    prev.includes(func.id)
                      ? prev.filter(f => f !== func.id)
                      : [...prev, func.id]
                  );
                }}
                className={`p-5 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedFunctions.includes(func.id)
                    ? "border-blue-600 bg-blue-50"
                    : "border-gray-200 hover:border-blue-300"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-gray-900">{func.label}</p>
                    <p className="text-sm text-gray-600 mt-1">{func.description}</p>
                  </div>
                  {selectedFunctions.includes(func.id) && (
                    <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold">
                      {selectedFunctions.indexOf(func.id) + 1}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-4 pt-6">
          {onBack && (
            <Button
              variant="outline"
              size="lg"
              onClick={onBack}
              className="flex-1"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
          )}
          <Button
            size="lg"
            onClick={handleComplete}
            disabled={!canProceed}
            className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
          >
            Continue
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}