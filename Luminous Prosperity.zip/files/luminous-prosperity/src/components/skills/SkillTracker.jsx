import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Target, TrendingUp, Sparkles, Plus, RefreshCw, Award,
  BookOpen, Briefcase, ChevronRight, Star, Brain
} from "lucide-react";

const PROFICIENCY_CONFIG = {
  beginner: { color: 'bg-gray-600', score: 25, label: 'Beginner' },
  intermediate: { color: 'bg-blue-600', score: 50, label: 'Intermediate' },
  advanced: { color: 'bg-purple-600', score: 75, label: 'Advanced' },
  expert: { color: 'bg-green-600', score: 100, label: 'Expert' }
};

export default function SkillTracker({ user }) {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);
  const [suggestedSkills, setSuggestedSkills] = useState([]);
  const [newSkill, setNewSkill] = useState({ name: '', category: 'technical', proficiency: 'beginner' });

  const { data: userSkills, isLoading } = useQuery({
    queryKey: ['mySkillsTracking', user?.email],
    queryFn: () => base44.entities.UserSkill.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: learningJourneys } = useQuery({
    queryKey: ['completedJourneys', user?.email],
    queryFn: () => base44.entities.LearningJourney.filter({ user_email: user?.email, status: 'completed' }),
    enabled: !!user?.email,
    initialData: [],
  });

  const createSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.UserSkill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySkillsTracking'] });
      setShowAddDialog(false);
      setNewSkill({ name: '', category: 'technical', proficiency: 'beginner' });
    },
  });

  const updateSkillMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserSkill.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['mySkillsTracking'] }),
  });

  const addSkill = async () => {
    await createSkillMutation.mutateAsync({
      user_email: user.email,
      skill_name: newSkill.name,
      skill_category: newSkill.category,
      self_assessed_proficiency: newSkill.proficiency,
      proficiency_score: PROFICIENCY_CONFIG[newSkill.proficiency].score,
      evidence: [],
      project_contributions: [],
      learning_journey_completions: [],
      endorsements: [],
      ai_suggested: false,
      growth_trend: 'stable'
    });
  };

  const updateProficiency = async (skill, newProficiency) => {
    await updateSkillMutation.mutateAsync({
      id: skill.id,
      data: {
        self_assessed_proficiency: newProficiency,
        proficiency_score: PROFICIENCY_CONFIG[newProficiency].score
      }
    });
  };

  const generateSkillSuggestions = async () => {
    setIsGeneratingSuggestions(true);
    try {
      const currentSkills = userSkills?.map(s => s.skill_name).join(', ') || 'None';
      const completedJourneyTopics = learningJourneys?.map(j => j.target_skills?.join(', ')).join('; ') || 'None';

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Suggest new skills for a professional to develop based on industry trends and their profile.

CURRENT SKILLS: ${currentSkills}
COMPLETED LEARNING: ${completedJourneyTopics}
USER ROLE: ${user?.user_role || 'Professional'}

Suggest 5-7 skills they should develop next. Consider:
1. Current industry trends and emerging technologies
2. Skills that complement their existing expertise
3. High-demand skills in the job market
4. Skills that support career growth

For each skill, explain why it's valuable and how it connects to their current skills.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_name: { type: "string" },
                  category: { type: "string" },
                  reason: { type: "string" },
                  market_demand: { type: "string" },
                  connection_to_current: { type: "string" },
                  learning_path: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSuggestedSkills(result.suggestions || []);
    } catch (error) {
      console.error("Error generating suggestions:", error);
    }
    setIsGeneratingSuggestions(false);
  };

  const addSuggestedSkill = async (suggestion) => {
    await createSkillMutation.mutateAsync({
      user_email: user.email,
      skill_name: suggestion.skill_name,
      skill_category: suggestion.category?.toLowerCase() || 'technical',
      self_assessed_proficiency: 'beginner',
      proficiency_score: 25,
      ai_suggested: true,
      ai_suggestion_reason: suggestion.reason,
      development_plan: suggestion.learning_path,
      growth_trend: 'improving',
      target_proficiency: 'advanced'
    });
    setSuggestedSkills(prev => prev.filter(s => s.skill_name !== suggestion.skill_name));
  };

  const skillsByCategory = userSkills?.reduce((acc, skill) => {
    const cat = skill.skill_category || 'other';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(skill);
    return acc;
  }, {}) || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-light text-white">Skill Tracker</h2>
          <p className="text-gray-400 text-sm">{userSkills?.length || 0} skills tracked</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={generateSkillSuggestions} disabled={isGeneratingSuggestions} variant="outline" className="border-purple-600 text-purple-400">
            {isGeneratingSuggestions ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />...</> : <><Brain className="w-4 h-4 mr-2" />AI Suggest</>}
          </Button>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-white text-black hover:bg-gray-200"><Plus className="w-4 h-4 mr-2" />Add Skill</Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-800 text-white">
              <DialogHeader><DialogTitle>Add New Skill</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4">
                <Input value={newSkill.name} onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })} placeholder="Skill name" className="bg-gray-800 border-gray-700" />
                <Select value={newSkill.category} onValueChange={(v) => setNewSkill({ ...newSkill, category: v })}>
                  <SelectTrigger className="bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="communication">Communication</SelectItem>
                    <SelectItem value="analytical">Analytical</SelectItem>
                    <SelectItem value="creative">Creative</SelectItem>
                    <SelectItem value="strategic">Strategic</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={newSkill.proficiency} onValueChange={(v) => setNewSkill({ ...newSkill, proficiency: v })}>
                  <SelectTrigger className="bg-gray-800 border-gray-700"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(PROFICIENCY_CONFIG).map(([key, config]) => (
                      <SelectItem key={key} value={key}>{config.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={addSkill} disabled={!newSkill.name} className="w-full bg-green-600 hover:bg-green-700">Add Skill</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* AI Suggestions */}
      {suggestedSkills.length > 0 && (
        <Card className="bg-purple-900/20 border-purple-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-purple-300 text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4" />AI-Suggested Skills to Develop
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {suggestedSkills.map((suggestion, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <div className="flex-1">
                  <p className="text-white font-medium">{suggestion.skill_name}</p>
                  <p className="text-gray-400 text-xs">{suggestion.reason}</p>
                  <Badge variant="outline" className="mt-1 text-xs border-green-700 text-green-400">{suggestion.market_demand}</Badge>
                </div>
                <Button size="sm" onClick={() => addSuggestedSkill(suggestion)} className="bg-purple-600 hover:bg-purple-700">
                  <Plus className="w-3 h-3 mr-1" />Add
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Skills by Category */}
      <Tabs defaultValue={Object.keys(skillsByCategory)[0] || 'technical'} className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
          {Object.keys(skillsByCategory).map(cat => (
            <TabsTrigger key={cat} value={cat} className="capitalize">{cat} ({skillsByCategory[cat].length})</TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(skillsByCategory).map(([category, skills]) => (
          <TabsContent key={category} value={category}>
            <div className="grid md:grid-cols-2 gap-4">
              {skills.map((skill) => {
                const config = PROFICIENCY_CONFIG[skill.self_assessed_proficiency] || PROFICIENCY_CONFIG.beginner;
                return (
                  <Card key={skill.id} className="bg-gray-900 border-gray-800">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-white font-medium flex items-center gap-2">
                            {skill.skill_name}
                            {skill.ai_suggested && <Sparkles className="w-3 h-3 text-purple-400" />}
                          </h4>
                          {skill.ai_suggestion_reason && (
                            <p className="text-purple-400 text-xs mt-1">{skill.ai_suggestion_reason}</p>
                          )}
                        </div>
                        <Badge className={config.color}>{config.label}</Badge>
                      </div>
                      
                      <div className="mb-3">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-gray-500">Proficiency</span>
                          <span className="text-white">{skill.proficiency_score || config.score}%</span>
                        </div>
                        <Progress value={skill.proficiency_score || config.score} className="h-2" />
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-gray-500 text-xs">Update:</span>
                        {Object.entries(PROFICIENCY_CONFIG).map(([key, cfg]) => (
                          <button
                            key={key}
                            onClick={() => updateProficiency(skill, key)}
                            className={`w-6 h-6 rounded-full ${skill.self_assessed_proficiency === key ? cfg.color : 'bg-gray-700'} hover:opacity-80`}
                            title={cfg.label}
                          />
                        ))}
                      </div>

                      {(skill.project_contributions?.length > 0 || skill.learning_journey_completions?.length > 0) && (
                        <div className="mt-3 pt-3 border-t border-gray-800 flex gap-3 text-xs">
                          {skill.project_contributions?.length > 0 && (
                            <span className="text-blue-400 flex items-center gap-1">
                              <Briefcase className="w-3 h-3" />{skill.project_contributions.length} projects
                            </span>
                          )}
                          {skill.learning_journey_completions?.length > 0 && (
                            <span className="text-green-400 flex items-center gap-1">
                              <BookOpen className="w-3 h-3" />{skill.learning_journey_completions.length} courses
                            </span>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {userSkills?.length === 0 && (
        <Card className="bg-gray-900 border-gray-800 text-center py-12">
          <CardContent>
            <Target className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-medium mb-2">No Skills Tracked Yet</h3>
            <p className="text-gray-400 text-sm mb-4">Add skills to track your professional development</p>
            <Button onClick={() => setShowAddDialog(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />Add Your First Skill
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}