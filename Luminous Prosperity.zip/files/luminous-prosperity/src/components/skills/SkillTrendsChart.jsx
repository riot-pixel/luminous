import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, Sparkles, Zap } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";
import { format, subMonths } from "date-fns";

export default function SkillTrendsChart({ userSkills, skills, assessments }) {
  // Generate trend data for the last 6 months
  const generateTrendData = () => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthStr = format(date, 'MMM yyyy');
      
      // Count skills created/updated in that month
      const monthSkills = userSkills.filter(us => {
        const skillDate = new Date(us.created_date || us.updated_date);
        return skillDate.getMonth() === date.getMonth() && 
               skillDate.getFullYear() === date.getFullYear();
      });

      // Calculate proficiency distribution for that month (cumulative)
      const cumulative = userSkills.filter(us => {
        const skillDate = new Date(us.created_date || us.updated_date);
        return skillDate <= date;
      });

      const expertCount = cumulative.filter(s => s.current_proficiency === 'Expert').length;
      const advancedCount = cumulative.filter(s => s.current_proficiency === 'Advanced').length;

      months.push({
        month: format(date, 'MMM'),
        fullMonth: monthStr,
        newSkills: monthSkills.length,
        totalSkills: cumulative.length,
        expertLevel: expertCount,
        advancedLevel: advancedCount,
      });
    }
    return months;
  };

  // Identify emerging skills (recently added, growing in frequency)
  const identifyEmergingSkills = () => {
    const threeMonthsAgo = subMonths(new Date(), 3);
    const recentSkills = userSkills.filter(us => {
      const skillDate = new Date(us.created_date || us.updated_date);
      return skillDate >= threeMonthsAgo;
    });

    // Count frequency of each skill in recent additions
    const skillFrequency = recentSkills.reduce((acc, us) => {
      acc[us.skill_name] = (acc[us.skill_name] || 0) + 1;
      return acc;
    }, {});

    // Get emerging skills sorted by frequency
    return Object.entries(skillFrequency)
      .map(([name, count]) => {
        const skill = skills.find(s => s.name === name);
        return {
          name,
          count,
          category: skill?.category || 'unknown',
          growth: 'rising',
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  };

  // Calculate proficiency growth
  const calculateProficiencyGrowth = () => {
    const categories = ['technical', 'leadership', 'communication', 'analytical', 'creative', 'operational', 'strategic'];
    
    return categories.map(cat => {
      const catSkills = userSkills.filter(us => us.skill_category === cat);
      const proficiencyScore = catSkills.reduce((sum, s) => {
        const scores = { 'Beginner': 25, 'Intermediate': 50, 'Advanced': 75, 'Expert': 100 };
        return sum + (scores[s.current_proficiency] || 0);
      }, 0);
      const avgScore = catSkills.length > 0 ? Math.round(proficiencyScore / catSkills.length) : 0;

      return {
        category: cat.charAt(0).toUpperCase() + cat.slice(1),
        score: avgScore,
        count: catSkills.length,
        trend: avgScore > 50 ? 'up' : avgScore > 25 ? 'stable' : 'down',
      };
    }).filter(c => c.count > 0);
  };

  const trendData = generateTrendData();
  const emergingSkills = identifyEmergingSkills();
  const proficiencyGrowth = calculateProficiencyGrowth();

  return (
    <div className="space-y-6">
      {/* Skill Acquisition Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Skill Proficiency Trends
          </CardTitle>
          <CardDescription>Expert and advanced level skill growth over time</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 border rounded-lg shadow-lg">
                        <p className="font-semibold">{payload[0]?.payload?.fullMonth}</p>
                        {payload.map((p, i) => (
                          <p key={i} style={{ color: p.color }} className="text-sm">
                            {p.name}: {p.value}
                          </p>
                        ))}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="expertLevel" stackId="1" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.8} name="Expert" />
              <Area type="monotone" dataKey="advancedLevel" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} name="Advanced" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Emerging Skills */}
        <Card className="border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-900">
              <Sparkles className="w-5 h-5" />
              Emerging Skills
            </CardTitle>
            <CardDescription>Skills gaining traction in the last 3 months</CardDescription>
          </CardHeader>
          <CardContent>
            {emergingSkills.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No emerging skills detected yet</p>
            ) : (
              <div className="space-y-3">
                {emergingSkills.map((skill, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                        <Zap className="w-4 h-4 text-amber-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{skill.name}</p>
                        <Badge variant="outline" className="text-xs">{skill.category}</Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-semibold text-green-600">+{skill.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Category Proficiency */}
        <Card>
          <CardHeader>
            <CardTitle>Category Proficiency</CardTitle>
            <CardDescription>Average proficiency score by skill category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {proficiencyGrowth.map((cat, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">{cat.category}</span>
                    <div className="flex items-center gap-2">
                      {cat.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-500" />}
                      {cat.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-500" />}
                      {cat.trend === 'stable' && <Minus className="w-4 h-4 text-gray-400" />}
                      <span className="text-sm text-gray-600">{cat.score}%</span>
                    </div>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        cat.score >= 75 ? 'bg-green-500' :
                        cat.score >= 50 ? 'bg-blue-500' :
                        cat.score >= 25 ? 'bg-amber-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${cat.score}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{cat.count} skills</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* New Skills Over Time */}
      <Card>
        <CardHeader>
          <CardTitle>Skill Acquisition Rate</CardTitle>
          <CardDescription>New skills added per month</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="newSkills" stroke="#10b981" strokeWidth={2} name="New Skills" dot={{ fill: '#10b981' }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}