import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { 
  Sun, Moon, Coffee, Sparkles, Heart, Brain, Target, 
  Lightbulb, RefreshCw, Quote, ArrowRight
} from "lucide-react";
import { motion } from "framer-motion";

export default function DailyWellnessCard({ user, assessment, variant = "dark" }) {
  const [content, setContent] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const getTimeOfDay = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "morning";
    if (hour < 17) return "afternoon";
    return "evening";
  };

  const getGreeting = () => {
    const time = getTimeOfDay();
    const name = user?.full_name?.split(' ')[0] || 'there';
    if (time === "morning") return `Good morning, ${name}`;
    if (time === "afternoon") return `Good afternoon, ${name}`;
    return `Good evening, ${name}`;
  };

  const getTimeIcon = () => {
    const time = getTimeOfDay();
    if (time === "morning") return Sun;
    if (time === "afternoon") return Coffee;
    return Moon;
  };

  const generateDailyContent = async () => {
    setIsLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate personalized daily wellness content for someone with these characteristics:
- Name: ${user?.full_name || 'Friend'}
- Personality Type: ${assessment?.myers_briggs?.type || 'Unknown'}
- Top Strength: ${assessment?.strengths?.top_strengths?.[0]?.name || 'Not specified'}
- Time of Day: ${getTimeOfDay()}
- Day: ${new Date().toLocaleDateString('en-US', { weekday: 'long' })}

Create brief, meaningful content that includes:
1. A personalized motivational quote or insight
2. A quick wellness tip tailored to their personality
3. A micro-challenge for today
4. An affirmation based on their top strength

Keep each item to 1-2 sentences max. Be warm but not cheesy.`,
        response_json_schema: {
          type: "object",
          properties: {
            quote: { type: "string" },
            wellness_tip: { type: "string" },
            micro_challenge: { type: "string" },
            affirmation: { type: "string" },
            focus_word: { type: "string" }
          }
        }
      });
      setContent(result);
    } catch (error) {
      console.error("Error generating daily content:", error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    // Check if we should auto-generate (once per session)
    const lastGenerated = sessionStorage.getItem('dailyWellnessGenerated');
    const today = new Date().toDateString();
    if (lastGenerated !== today && user) {
      generateDailyContent();
      sessionStorage.setItem('dailyWellnessGenerated', today);
    }
  }, [user]);

  const TimeIcon = getTimeIcon();
  const isDark = variant === "dark";

  if (!content && !isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-2xl p-6 ${
          isDark 
            ? "bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20"
            : "bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200"
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <TimeIcon className={`w-6 h-6 ${isDark ? "text-amber-400" : "text-indigo-600"}`} />
            <div>
              <p className={`font-medium ${isDark ? "text-white" : "text-gray-900"}`}>
                {getGreeting()}
              </p>
              <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>
                Ready for your daily wellness moment?
              </p>
            </div>
          </div>
          <Button
            onClick={generateDailyContent}
            size="sm"
            className={isDark 
              ? "bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 border border-amber-500/30"
              : "bg-indigo-600 text-white hover:bg-indigo-700"
            }
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Generate
          </Button>
        </div>
      </motion.div>
    );
  }

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={`rounded-2xl p-8 text-center ${
          isDark 
            ? "bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20"
            : "bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200"
        }`}
      >
        <Sparkles className={`w-8 h-8 animate-spin mx-auto mb-3 ${
          isDark ? "text-amber-400" : "text-indigo-600"
        }`} />
        <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>
          Crafting your personalized wellness moment...
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl overflow-hidden ${
        isDark 
          ? "bg-gradient-to-br from-amber-500/10 to-amber-600/5 border border-amber-500/20"
          : "bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200"
      }`}
    >
      {/* Header */}
      <div className={`p-4 border-b ${isDark ? "border-amber-500/10" : "border-indigo-200"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <TimeIcon className={`w-5 h-5 ${isDark ? "text-amber-400" : "text-indigo-600"}`} />
            <span className={`text-sm font-medium ${isDark ? "text-white" : "text-gray-900"}`}>
              {getGreeting()}
            </span>
          </div>
          <button
            onClick={generateDailyContent}
            className={`p-1.5 rounded-lg transition ${
              isDark ? "hover:bg-white/5 text-gray-500" : "hover:bg-gray-100 text-gray-400"
            }`}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content Grid */}
      <div className="p-4 grid grid-cols-2 gap-3">
        {/* Quote */}
        <div className={`col-span-2 p-4 rounded-xl ${isDark ? "bg-black/30" : "bg-white"}`}>
          <Quote className={`w-4 h-4 mb-2 ${isDark ? "text-amber-400" : "text-indigo-600"}`} />
          <p className={`text-sm italic ${isDark ? "text-gray-300" : "text-gray-700"}`}>
            "{content.quote}"
          </p>
        </div>

        {/* Wellness Tip */}
        <div className={`p-3 rounded-xl ${isDark ? "bg-black/30" : "bg-white"}`}>
          <Heart className={`w-4 h-4 mb-2 ${isDark ? "text-rose-400" : "text-rose-500"}`} />
          <p className={`text-[10px] uppercase tracking-widest mb-1 ${isDark ? "text-gray-500" : "text-gray-400"}`}>
            Wellness Tip
          </p>
          <p className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
            {content.wellness_tip}
          </p>
        </div>

        {/* Micro Challenge */}
        <div className={`p-3 rounded-xl ${isDark ? "bg-black/30" : "bg-white"}`}>
          <Target className={`w-4 h-4 mb-2 ${isDark ? "text-emerald-400" : "text-emerald-500"}`} />
          <p className={`text-[10px] uppercase tracking-widest mb-1 ${isDark ? "text-gray-500" : "text-gray-400"}`}>
            Today's Challenge
          </p>
          <p className={`text-xs ${isDark ? "text-gray-400" : "text-gray-600"}`}>
            {content.micro_challenge}
          </p>
        </div>

        {/* Affirmation */}
        <div className={`col-span-2 p-4 rounded-xl text-center ${
          isDark ? "bg-amber-500/10 border border-amber-500/20" : "bg-indigo-100"
        }`}>
          <p className={`text-sm font-medium ${isDark ? "text-amber-400" : "text-indigo-700"}`}>
            {content.affirmation}
          </p>
          {content.focus_word && (
            <p className={`text-xs mt-2 ${isDark ? "text-gray-500" : "text-gray-500"}`}>
              Today's focus: <span className={isDark ? "text-white" : "text-gray-900"}>{content.focus_word}</span>
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}