import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X, Play, Pause, Wind } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function BreathingExercise({ onClose, variant = "dark" }) {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState("inhale"); // inhale, hold, exhale
  const [seconds, setSeconds] = useState(4);
  const [cycles, setCycles] = useState(0);

  const phaseDurations = { inhale: 4, hold: 4, exhale: 6 };
  const phaseMessages = {
    inhale: "Breathe In",
    hold: "Hold",
    exhale: "Breathe Out"
  };

  useEffect(() => {
    if (!isActive) return;

    const timer = setInterval(() => {
      setSeconds(prev => {
        if (prev <= 1) {
          // Move to next phase
          if (phase === "inhale") {
            setPhase("hold");
            return phaseDurations.hold;
          } else if (phase === "hold") {
            setPhase("exhale");
            return phaseDurations.exhale;
          } else {
            setPhase("inhale");
            setCycles(c => c + 1);
            return phaseDurations.inhale;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, phase]);

  const getCircleScale = () => {
    if (phase === "inhale") return 1.5;
    if (phase === "hold") return 1.5;
    return 1;
  };

  const isDark = variant === "dark";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isDark ? "bg-black/95" : "bg-white/95"
      } backdrop-blur-xl`}
    >
      <button
        onClick={onClose}
        className={`absolute top-6 right-6 p-2 rounded-full ${
          isDark ? "hover:bg-white/10 text-gray-400" : "hover:bg-gray-100 text-gray-600"
        }`}
      >
        <X className="w-6 h-6" />
      </button>

      <div className="text-center">
        <motion.p
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`text-xs uppercase tracking-[0.3em] mb-8 ${
            isDark ? "text-gray-500" : "text-gray-400"
          }`}
        >
          Mindful Breathing
        </motion.p>

        <div className="relative w-72 h-72 mx-auto mb-8 flex items-center justify-center">
          {/* Outer ring */}
          <div className={`absolute inset-0 rounded-full border ${
            isDark ? "border-white/10" : "border-gray-200"
          }`} />
          
          {/* Animated breathing circle */}
          <motion.div
            animate={{
              scale: isActive ? getCircleScale() : 1,
              opacity: isActive ? (phase === "hold" ? 0.8 : 1) : 0.5,
            }}
            transition={{
              duration: phase === "inhale" ? 4 : phase === "exhale" ? 6 : 0.3,
              ease: "easeInOut"
            }}
            className={`w-32 h-32 rounded-full ${
              isDark 
                ? "bg-gradient-to-br from-amber-400/30 to-amber-600/30 border border-amber-500/30"
                : "bg-gradient-to-br from-indigo-400/30 to-purple-600/30 border border-indigo-500/30"
            }`}
          />

          {/* Center content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {isActive ? (
              <>
                <motion.p
                  key={phase}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`text-2xl font-light ${isDark ? "text-white" : "text-gray-900"}`}
                >
                  {phaseMessages[phase]}
                </motion.p>
                <p className={`text-5xl font-light mt-2 ${
                  isDark ? "text-amber-400" : "text-indigo-600"
                }`}>
                  {seconds}
                </p>
              </>
            ) : (
              <Wind className={`w-12 h-12 ${isDark ? "text-gray-600" : "text-gray-400"}`} />
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <Button
            onClick={() => {
              setIsActive(!isActive);
              if (!isActive) {
                setPhase("inhale");
                setSeconds(4);
              }
            }}
            className={isDark 
              ? "bg-white text-black hover:bg-gray-200 px-12 py-6 text-xs font-bold tracking-[0.2em] uppercase"
              : "bg-indigo-600 text-white hover:bg-indigo-700 px-12 py-6 text-xs font-bold tracking-[0.2em] uppercase"
            }
          >
            {isActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isActive ? "Pause" : "Begin"}
          </Button>

          {cycles > 0 && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className={`text-sm ${isDark ? "text-gray-500" : "text-gray-400"}`}
            >
              {cycles} breath cycle{cycles > 1 ? "s" : ""} completed
            </motion.p>
          )}
        </div>

        <p className={`mt-12 text-xs max-w-sm mx-auto ${
          isDark ? "text-gray-600" : "text-gray-400"
        }`}>
          Take a moment to center yourself. Deep breathing reduces stress, 
          improves focus, and promotes mental clarity.
        </p>
      </div>
    </motion.div>
  );
}