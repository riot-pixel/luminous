import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sparkles, FileText, Copy, Check, RefreshCw, Download, Wand2 } from "lucide-react";

export default function AIContentGenerator({ 
  contentType, 
  context, 
  onContentGenerated 
}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [copied, setCopied] = useState(false);
  const [customPrompt, setCustomPrompt] = useState("");

  const generateContent = async (useCustom = false) => {
    setIsGenerating(true);
    try {
      let prompt = "";

      if (useCustom && customPrompt) {
        prompt = customPrompt;
      } else {
        switch (contentType) {
          case "learning_module":
            prompt = `Create detailed learning module content for: ${context.skillName}

TARGET AUDIENCE:
- Current Level: ${context.currentLevel || 'Beginner'}
- Career Goal: ${context.careerGoal || 'Skill development'}
- Learning Style: ${context.personalityType || 'Not specified'}

Create a comprehensive module with:
1. Clear learning objectives (4-5 items)
2. Key concepts to master
3. 3 detailed lessons with actual educational content (not placeholders)
4. Practical exercises with instructions
5. Assessment questions with explanations
6. Reflection prompts

Make content practical, actionable, and immediately applicable to ${context.careerGoal || 'their career'}.`;
            break;

          case "course_description":
            prompt = `Create a compelling course description and outline for: ${context.courseTitle}

CONTEXT:
- Target Skills: ${context.targetSkills?.join(', ') || 'Various'}
- Difficulty: ${context.difficulty || 'Intermediate'}
- Duration: ${context.duration || '15 hours'}

Generate:
1. Engaging course description (2-3 paragraphs)
2. Who this course is for
3. What you'll learn (bullet points)
4. Prerequisites
5. Course outline with 4-6 modules
6. Skills you'll gain
7. Career outcomes`;
            break;

          case "profile_summary":
            prompt = `Create a compelling professional profile summary for:

NAME: ${context.userName}
ROLE: ${context.role || 'Professional'}
DEPARTMENT: ${context.department || 'Various'}

SKILLS:
${context.skills?.map(s => `- ${s.skill_name} (${s.self_assessed_proficiency || 'Proficient'})`).join('\n') || 'Various skills'}

ACHIEVEMENTS:
${context.achievements?.join('\n') || 'Multiple achievements'}

CAREER GOALS:
${context.careerGoals || 'Professional growth'}

Create a 3-paragraph professional summary that:
1. Opens with their current role and core strengths
2. Highlights key skills and achievements
3. Connects their experience to career aspirations

Make it compelling, authentic, and achievement-focused.`;
            break;

          case "skill_gap_report":
            prompt = `Generate a comprehensive skill gap report based on audit data.

ORGANIZATION: ${context.organizationName || 'The Organization'}
AUDIT DATE: ${context.auditDate || new Date().toLocaleDateString()}
OVERALL READINESS: ${context.overallReadiness || 'Unknown'}%

CRITICAL GAPS:
${context.criticalGaps?.map(g => `- ${g.skill_name}: ${g.affected_count} affected, Severity: ${g.severity}`).join('\n') || 'None'}

FUTURE PREDICTIONS:
${context.predictions?.map(p => `- ${p.skill_name}: Shortage by ${p.predicted_shortage_date}`).join('\n') || 'None'}

DEPARTMENTS:
${context.departments?.map(d => `- ${d.department}: ${d.readiness_score}% ready, ${d.gap_count} gaps`).join('\n') || 'Various'}

Create a professional executive report with:
1. Executive Summary (key findings in 2-3 paragraphs)
2. Current State Analysis
3. Critical Gaps Deep Dive
4. Future Outlook and Predictions
5. Recommended Actions (prioritized)
6. Investment Requirements
7. Timeline for Implementation
8. Success Metrics

Write in professional business language suitable for C-suite presentation.`;
            break;

          case "coaching_scenario":
            prompt = `Create a detailed coaching scenario for practicing: ${context.scenarioType}

USER PROFILE:
- Personality Type: ${context.personalityType || 'Unknown'}
- Communication Style: ${context.communicationStyle || 'Professional'}
- Career Goal: ${context.careerGoal || 'Professional development'}
- Experience Level: ${context.experienceLevel || 'Mid-level'}

SCENARIO CONTEXT: ${context.scenarioContext || 'Workplace situation'}

Create a realistic roleplay scenario with:
1. Detailed situation setup and background
2. Key characters and their motivations
3. 3-4 decision branch points with different outcomes
4. Realistic dialogue examples
5. Success criteria and learning objectives
6. Common pitfalls to avoid
7. Expert tips for handling this situation

Make it engaging, realistic, and educational.`;
            break;

          case "team_analysis":
            prompt = `Generate a team dynamics and performance analysis.

TEAM: ${context.teamName || 'Team'}
MEMBERS: ${context.members?.length || 0}

TEAM COMPOSITION:
${context.members?.map(m => `- ${m.name}: ${m.role}, MBTI: ${m.mbti || 'Unknown'}, Top Strength: ${m.topStrength || 'N/A'}`).join('\n') || 'Team members'}

TEAM METRICS:
- Average Fulfillment: ${context.avgFulfillment || 'N/A'}%
- Average Operational Score: ${context.avgOperational || 'N/A'}%
- Skill Coverage: ${context.skillCoverage || 'N/A'}%

Generate:
1. Team personality dynamics analysis
2. Strengths and potential blind spots
3. Communication patterns to leverage
4. Conflict prevention strategies
5. Optimal task allocation suggestions
6. Team development recommendations`;
            break;
        }
      }

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            content: { type: "string" },
            metadata: {
              type: "object",
              properties: {
                word_count: { type: "number" },
                tone: { type: "string" },
                key_themes: { type: "array", items: { type: "string" } }
              }
            },
            suggestions: { type: "array", items: { type: "string" } }
          }
        }
      });

      setGeneratedContent(result);
      onContentGenerated?.(result.content);
    } catch (error) {
      console.error("Error generating content:", error);
    }
    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const contentTypeLabels = {
    learning_module: "Learning Module",
    course_description: "Course Description",
    profile_summary: "Profile Summary",
    skill_gap_report: "Skill Gap Report",
    coaching_scenario: "Coaching Scenario",
    team_analysis: "Team Analysis"
  };

  const downloadContent = () => {
    const blob = new Blob([generatedContent.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${contentType}_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 border-cyan-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          AI Content Generator - {contentTypeLabels[contentType]}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!generatedContent ? (
          <div className="space-y-4">
            <Tabs defaultValue="auto">
              <TabsList className="bg-gray-800">
                <TabsTrigger value="auto">Auto-Generate</TabsTrigger>
                <TabsTrigger value="custom">Custom Prompt</TabsTrigger>
              </TabsList>
              <TabsContent value="auto" className="pt-4">
                <Button onClick={() => generateContent(false)} disabled={isGenerating} className="w-full bg-cyan-600 hover:bg-cyan-700">
                  {isGenerating ? (
                    <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Generating...</>
                  ) : (
                    <><Sparkles className="w-4 h-4 mr-2" />Generate Content</>
                  )}
                </Button>
              </TabsContent>
              <TabsContent value="custom" className="pt-4 space-y-3">
                <Textarea
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="Enter your custom prompt for AI content generation..."
                  className="bg-gray-800 border-gray-700 text-white h-32"
                />
                <Button onClick={() => generateContent(true)} disabled={isGenerating || !customPrompt} className="w-full bg-cyan-600 hover:bg-cyan-700">
                  {isGenerating ? (
                    <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Generating...</>
                  ) : (
                    <><Sparkles className="w-4 h-4 mr-2" />Generate with Custom Prompt</>
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <Badge className="bg-cyan-600">{generatedContent.metadata?.word_count} words</Badge>
                <Badge variant="outline" className="border-gray-700 text-gray-400">{generatedContent.metadata?.tone}</Badge>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={copyToClipboard} className="border-gray-700">
                  {copied ? <Check className="w-4 h-4 mr-1" /> : <Copy className="w-4 h-4 mr-1" />}
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
                <Button size="sm" variant="outline" onClick={downloadContent} className="border-gray-700">
                  <Download className="w-4 h-4 mr-1" />Download
                </Button>
                <Button size="sm" variant="outline" onClick={() => setGeneratedContent(null)} className="border-gray-700">
                  <RefreshCw className="w-4 h-4 mr-1" />Regenerate
                </Button>
              </div>
            </div>

            <ScrollArea className="h-[400px] p-4 bg-gray-800 rounded-lg">
              <div className="prose prose-sm prose-invert max-w-none">
                <div className="whitespace-pre-wrap text-gray-200">{generatedContent.content}</div>
              </div>
            </ScrollArea>

            {generatedContent.metadata?.key_themes?.length > 0 && (
              <div>
                <p className="text-gray-400 text-xs mb-2">Key Themes:</p>
                <div className="flex flex-wrap gap-2">
                  {generatedContent.metadata.key_themes.map((theme, i) => (
                    <Badge key={i} variant="outline" className="border-cyan-700 text-cyan-400">{theme}</Badge>
                  ))}
                </div>
              </div>
            )}

            {generatedContent.suggestions?.length > 0 && (
              <div className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                <p className="text-blue-400 text-xs mb-2">Suggestions for enhancement:</p>
                {generatedContent.suggestions.map((s, i) => (
                  <p key={i} className="text-gray-300 text-xs">• {s}</p>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}