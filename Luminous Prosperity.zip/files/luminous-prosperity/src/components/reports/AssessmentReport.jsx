import React from "react";
import { format } from "date-fns";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

export default function AssessmentReport({ assessment, user, organization }) {
  const integralData = assessment.integral_theory?.quadrants ? [
    { subject: 'Individual Interior', value: assessment.integral_theory.quadrants.individual_interior },
    { subject: 'Individual Exterior', value: assessment.integral_theory.quadrants.individual_exterior },
    { subject: 'Collective Interior', value: assessment.integral_theory.quadrants.collective_interior },
    { subject: 'Collective Exterior', value: assessment.integral_theory.quadrants.collective_exterior },
  ] : [];

  const lifeWheelData = assessment.life_wheel ? Object.entries(assessment.life_wheel)
    .filter(([key]) => key !== 'overall_satisfaction')
    .map(([key, value]) => ({
      subject: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      value: value * 10,
    })) : [];

  const strengthCategoryData = assessment.strengths?.strength_categories ? 
    Object.entries(assessment.strengths.strength_categories).map(([name, value]) => ({
      name: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      score: value,
    })) : [];

  return (
    <div className="max-w-5xl mx-auto p-8 bg-white">
      <style>{`
        @media print {
          body { margin: 0; padding: 0; }
          .print\\:hidden { display: none !important; }
          .page-break { page-break-before: always; }
        }
      `}</style>

      {/* Header with Branding */}
      <div className="border-b-4 border-[#B8967D] pb-6 mb-8 flex items-start justify-between">
        <div className="flex-1">
          {organization?.logo_url && (
            <img 
              src={organization.logo_url} 
              alt={organization.name}
              className="h-16 mb-4 object-contain"
            />
          )}
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            {organization?.name || 'Organization'} Assessment Report
          </h1>
          <p className="text-gray-600 text-lg">Comprehensive Personal Development Analysis</p>
        </div>
        <div>
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png"
            alt="Luminous Prosperity"
            className="h-12 object-contain"
          />
          <p className="text-xs text-gray-500 mt-2">Powered by Luminous Prosperity</p>
        </div>
      </div>

      {/* Participant Information */}
      <div className="mb-8 bg-stone-50 p-6 rounded-lg">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Participant Information</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600">Name</p>
            <p className="font-semibold text-gray-900">{user?.full_name || 'Not specified'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Department</p>
            <p className="font-semibold text-gray-900">{assessment.department || user?.department || 'Not specified'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Role</p>
            <p className="font-semibold text-gray-900">{assessment.role || user?.job_title || 'Not specified'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Assessment Date</p>
            <p className="font-semibold text-gray-900">
              {format(new Date(assessment.completed_date), 'MMMM d, yyyy')}
            </p>
          </div>
        </div>
      </div>

      {/* AI Insights - Executive Summary */}
      {assessment.overall_insights && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Executive Summary</h2>
          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
            {assessment.overall_insights}
          </div>
        </div>
      )}

      {/* Page Break */}
      <div className="page-break"></div>

      {/* Integral Theory Section */}
      {assessment.integral_theory && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Integral Theory Assessment</h2>
          <p className="text-gray-600 mb-4">Your orientation across Ken Wilber's AQAL framework</p>
          
          {integralData.length > 0 && (
            <div className="mb-6">
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={integralData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="subject" />
                  <PolarRadiusAxis domain={[0, 100]} />
                  <Radar name="Score" dataKey="value" stroke="#B8967D" fill="#B8967D" fillOpacity={0.6} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}

          {assessment.integral_theory.levels && (
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Development Levels</h3>
              <div className="flex flex-wrap gap-2">
                {assessment.integral_theory.levels.map((level, idx) => (
                  <span key={idx} className="px-3 py-1 bg-stone-100 text-stone-700 rounded-full text-sm">
                    {level.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </span>
                ))}
              </div>
            </div>
          )}

          {assessment.integral_theory.primary_line && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Primary Intelligence Line</h3>
              <p className="text-xl font-bold text-[#B8967D]">
                {assessment.integral_theory.primary_line.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Myers-Briggs Section */}
      {assessment.myers_briggs && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Personality Type (MBTI)</h2>
          <div className="bg-blue-50 p-6 rounded-lg mb-4">
            <p className="text-6xl font-bold text-blue-600 text-center mb-2">
              {assessment.myers_briggs.type}
            </p>
            <p className="text-center text-gray-600">Extended Myers-Briggs Type</p>
          </div>
          
          {assessment.myers_briggs.cognitive_functions && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Cognitive Function Stack</h3>
              <div className="space-y-2">
                {assessment.myers_briggs.cognitive_functions.map((func, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                      {idx + 1}
                    </div>
                    <span className="font-medium text-gray-900">{func}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Page Break */}
      <div className="page-break"></div>

      {/* Character Strengths Section */}
      {assessment.strengths && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Character Strengths</h2>
          
          {assessment.strengths.top_strengths && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Top 5 Signature Strengths</h3>
              <div className="space-y-3">
                {assessment.strengths.top_strengths.map((strength, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-indigo-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-600 text-white rounded-lg flex items-center justify-center font-bold">
                        {idx + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{strength.name}</p>
                        <p className="text-sm text-gray-600 capitalize">{strength.category}</p>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-indigo-600">{strength.score}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {strengthCategoryData.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Strength Categories Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={strengthCategoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="score" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Life Balance Wheel Section */}
      {assessment.life_wheel && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Life Balance Assessment</h2>
          
          <div className="bg-violet-50 p-6 rounded-lg mb-6 text-center">
            <p className="text-sm text-gray-600 mb-2">Overall Life Satisfaction</p>
            <p className="text-6xl font-bold text-violet-600">
              {assessment.life_wheel.overall_satisfaction}%
            </p>
          </div>

          {lifeWheelData.length > 0 && (
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={lifeWheelData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" />
                <PolarRadiusAxis domain={[0, 100]} />
                <Radar name="Satisfaction" dataKey="value" stroke="#a855f7" fill="#a855f7" fillOpacity={0.6} />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="mt-12 pt-6 border-t border-gray-200 text-center text-sm text-gray-500">
        <p>This report is confidential and intended solely for the use of {user?.full_name || 'the participant'}</p>
        <p className="mt-1">Generated on {format(new Date(), 'MMMM d, yyyy')} by Luminous Prosperity</p>
        <p className="mt-2 text-xs">© {new Date().getFullYear()} {organization?.name || 'Organization'}. All rights reserved.</p>
      </div>
    </div>
  );
}