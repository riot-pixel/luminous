import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Calendar, Clock, Mail, FileText, Plus, Trash2, Play, 
  Sparkles, BarChart3, Brain, Users, CheckCircle2, AlertTriangle, 
  TrendingUp, Target, Download, Send, Eye, Settings2, Zap,
  TrendingDown, Shield, Activity, PieChart
} from "lucide-react";

const reportTemplates = [
  {
    id: "weekly_engagement",
    name: "Weekly Engagement Summary",
    description: "Assessment activity, satisfaction trends, and team highlights",
    frequency: "weekly",
    icon: BarChart3,
    sections: ["assessment_metrics", "satisfaction_trends", "top_performers"],
    category: "engagement"
  },
  {
    id: "monthly_skills",
    name: "Monthly Skill Gap Analysis",
    description: "Skill coverage, critical gaps, and training recommendations",
    frequency: "monthly",
    icon: Brain,
    sections: ["skill_coverage", "critical_gaps", "training_recs"],
    category: "skills"
  },
  {
    id: "quarterly_predictive",
    name: "Quarterly Predictive Insights",
    description: "Risk forecasts, trend analysis, and strategic recommendations",
    frequency: "quarterly",
    icon: Sparkles,
    sections: ["risk_forecast", "trend_analysis", "strategic_recs"],
    category: "predictive"
  },
  {
    id: "team_performance",
    name: "Team Performance Report",
    description: "Department comparisons, benchmarks, and improvement areas",
    frequency: "monthly",
    icon: Users,
    sections: ["dept_comparison", "benchmarks", "improvements"],
    category: "performance"
  },
  {
    id: "predictive_risks",
    name: "Predictive Risk Alert Report",
    description: "AI-identified risks, turnover predictions, and proactive interventions",
    frequency: "weekly",
    icon: AlertTriangle,
    sections: ["risk_alerts", "turnover_prediction", "interventions"],
    category: "predictive"
  },
  {
    id: "career_development",
    name: "Career Development Tracker",
    description: "Learning path progress, skill acquisitions, and career milestones",
    frequency: "monthly",
    icon: TrendingUp,
    sections: ["learning_progress", "skill_gains", "milestones"],
    category: "development"
  },
  {
    id: "executive_kpi",
    name: "Executive KPI Dashboard",
    description: "High-level KPIs, strategic alignment, and organizational health",
    frequency: "weekly",
    icon: Target,
    sections: ["kpi_summary", "strategic_alignment", "org_health"],
    category: "executive"
  },
  {
    id: "executive_analytics_summary",
    name: "Executive Analytics Summary",
    description: "Comprehensive org-wide analytics with department breakdowns and trends",
    frequency: "weekly",
    icon: PieChart,
    sections: ["org_overview", "dept_analytics", "satisfaction_index", "engagement_trends"],
    category: "executive"
  },
  {
    id: "predictive_workforce",
    name: "Predictive Workforce Planning",
    description: "AI-driven workforce predictions, skill demand forecasting, and talent pipeline",
    frequency: "monthly",
    icon: Activity,
    sections: ["workforce_forecast", "skill_demand", "talent_pipeline", "succession_risks"],
    category: "predictive"
  },
  {
    id: "flight_risk_analysis",
    name: "Flight Risk & Retention Analysis",
    description: "Employee retention predictions, flight risk indicators, and intervention recommendations",
    frequency: "weekly",
    icon: Shield,
    sections: ["flight_risk_scores", "retention_factors", "intervention_plan", "cost_analysis"],
    category: "predictive"
  }
];

export default function AutomatedReportScheduler({ user, departmentMetrics, skillGaps, predictions }) {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isCustomDialogOpen, setIsCustomDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedReport, setGeneratedReport] = useState(null);
  const [activeTab, setActiveTab] = useState("templates");
  const [filterCategory, setFilterCategory] = useState("all");
  const [scheduleConfig, setScheduleConfig] = useState({
    recipients: user?.email || "",
    frequency: "weekly",
    dayOfWeek: "monday",
    timeOfDay: "09:00",
    includeExecutiveSummary: true,
    includeActionItems: true,
    includeCharts: true,
    includePredictions: true,
    includeBenchmarks: false,
    emailSubjectPrefix: "[Luminous Report]"
  });
  const [customReport, setCustomReport] = useState({
    name: "",
    sections: [],
    metrics: []
  });

  const availableSections = [
    { id: "assessment_metrics", label: "Assessment Metrics", category: "engagement" },
    { id: "satisfaction_trends", label: "Satisfaction Trends", category: "engagement" },
    { id: "skill_coverage", label: "Skill Coverage", category: "skills" },
    { id: "critical_gaps", label: "Critical Gaps", category: "skills" },
    { id: "risk_forecast", label: "Risk Forecast", category: "predictive" },
    { id: "top_performers", label: "Top Performers", category: "performance" },
    { id: "dept_comparison", label: "Department Comparison", category: "performance" },
    { id: "training_recs", label: "Training Recommendations", category: "development" },
    { id: "turnover_prediction", label: "Turnover Predictions", category: "predictive" },
    { id: "learning_progress", label: "Learning Progress", category: "development" },
    { id: "flight_risk_scores", label: "Flight Risk Analysis", category: "predictive" },
    { id: "workforce_forecast", label: "Workforce Forecasting", category: "predictive" },
    { id: "engagement_index", label: "Engagement Index", category: "engagement" },
    { id: "succession_planning", label: "Succession Planning", category: "executive" },
    { id: "roi_analysis", label: "Training ROI Analysis", category: "executive" }
  ];

  const categories = [
    { id: "all", label: "All Reports" },
    { id: "executive", label: "Executive" },
    { id: "predictive", label: "Predictive" },
    { id: "engagement", label: "Engagement" },
    { id: "skills", label: "Skills" },
    { id: "performance", label: "Performance" },
    { id: "development", label: "Development" }
  ];

  const filteredTemplates = filterCategory === "all" 
    ? reportTemplates 
    : reportTemplates.filter(t => t.category === filterCategory);

  const { data: scheduledReports } = useQuery({
    queryKey: ['scheduledReports'],
    queryFn: async () => {
      // In a real app, this would fetch from an entity
      return JSON.parse(localStorage.getItem('scheduledReports') || '[]');
    },
    initialData: []
  });

  const saveSchedule = (newSchedule) => {
    const existing = JSON.parse(localStorage.getItem('scheduledReports') || '[]');
    existing.push({ ...newSchedule, id: Date.now(), createdAt: new Date().toISOString() });
    localStorage.setItem('scheduledReports', JSON.stringify(existing));
    queryClient.invalidateQueries({ queryKey: ['scheduledReports'] });
  };

  const deleteSchedule = (id) => {
    const existing = JSON.parse(localStorage.getItem('scheduledReports') || '[]');
    localStorage.setItem('scheduledReports', JSON.stringify(existing.filter(r => r.id !== id)));
    queryClient.invalidateQueries({ queryKey: ['scheduledReports'] });
  };

  const generateReportNow = async (template) => {
    setIsGenerating(true);
    setSelectedTemplate(template);
    
    try {
      // Build context from actual data if available
      const contextData = {
        departmentCount: departmentMetrics?.length || 0,
        avgSatisfaction: departmentMetrics?.length > 0 
          ? Math.round(departmentMetrics.reduce((s, d) => s + (d.avgSatisfaction || 0), 0) / departmentMetrics.length)
          : 0,
        skillGapsCount: skillGaps?.length || 0,
        activePredictions: predictions?.filter(p => p.status === 'active')?.length || 0,
        criticalPredictions: predictions?.filter(p => p.severity === 'critical' || p.severity === 'high')?.length || 0,
        departments: departmentMetrics?.map(d => ({
          name: d.department,
          employees: d.employees,
          assessmentRate: d.assessmentRate,
          satisfaction: d.avgSatisfaction
        })) || []
      };

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a comprehensive executive report for "${template.name}".

Report Type: ${template.description}
Sections to include: ${template.sections.join(', ')}
Generated: ${new Date().toLocaleDateString()}

ACTUAL ORGANIZATIONAL DATA:
- Total Departments: ${contextData.departmentCount}
- Average Satisfaction: ${contextData.avgSatisfaction}%
- Critical Skill Gaps: ${contextData.skillGapsCount}
- Active Predictions: ${contextData.activePredictions}
- High-Priority Alerts: ${contextData.criticalPredictions}
${contextData.departments.length > 0 ? `
DEPARTMENT BREAKDOWN:
${contextData.departments.map(d => `- ${d.name}: ${d.employees} employees, ${d.assessmentRate}% assessed, ${d.satisfaction}% satisfaction`).join('\n')}
` : ''}

Create a professional executive report with:
1. Executive Summary (3-4 impactful sentences with specific numbers)
2. Key Metrics (6-8 important KPIs with values and trends)
3. Trends Analysis (specific improvements and areas needing attention)
4. Top 5 Actionable Recommendations with priority, owner, and timeline
5. Risk Alerts with severity and recommended interventions
6. Predictive Insights (future-looking analysis based on current data)
7. Benchmarks (how the organization compares to industry standards)

Be specific, data-driven, and actionable. Use actual numbers where provided.`,
        response_json_schema: {
          type: "object",
          properties: {
            report_title: { type: "string" },
            generated_date: { type: "string" },
            executive_summary: { type: "string" },
            key_metrics: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  label: { type: "string" },
                  value: { type: "string" },
                  trend: { type: "string" },
                  status: { type: "string" },
                  change_percent: { type: "string" }
                }
              }
            },
            trends_analysis: {
              type: "object",
              properties: {
                improving: { type: "array", items: { type: "string" } },
                needs_attention: { type: "array", items: { type: "string" } },
                stable: { type: "array", items: { type: "string" } }
              }
            },
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string" },
                  impact: { type: "string" },
                  owner: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            risk_alerts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  alert: { type: "string" },
                  severity: { type: "string" },
                  department: { type: "string" },
                  intervention: { type: "string" }
                }
              }
            },
            predictive_insights: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  prediction: { type: "string" },
                  confidence: { type: "string" },
                  timeframe: { type: "string" },
                  recommended_action: { type: "string" }
                }
              }
            },
            benchmarks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  metric: { type: "string" },
                  org_value: { type: "string" },
                  industry_avg: { type: "string" },
                  status: { type: "string" }
                }
              }
            }
          }
        }
      });

      setGeneratedReport(result);
    } catch (error) {
      console.error("Error generating report:", error);
    }
    setIsGenerating(false);
  };

  const scheduleReport = () => {
    if (!selectedTemplate) return;
    
    saveSchedule({
      templateId: selectedTemplate.id,
      templateName: selectedTemplate.name,
      ...scheduleConfig
    });
    
    setIsDialogOpen(false);
    setSelectedTemplate(null);
  };

  const createCustomReport = () => {
    if (!customReport.name || customReport.sections.length === 0) return;
    
    const newTemplate = {
      id: `custom_${Date.now()}`,
      name: customReport.name,
      description: `Custom report with: ${customReport.sections.join(', ')}`,
      frequency: scheduleConfig.frequency,
      icon: FileText,
      sections: customReport.sections,
      isCustom: true
    };

    saveSchedule({
      templateId: newTemplate.id,
      templateName: newTemplate.name,
      ...scheduleConfig,
      customSections: customReport.sections
    });

    setIsCustomDialogOpen(false);
    setCustomReport({ name: "", sections: [], metrics: [] });
  };

  const toggleSection = (sectionId) => {
    setCustomReport(prev => ({
      ...prev,
      sections: prev.sections.includes(sectionId)
        ? prev.sections.filter(s => s !== sectionId)
        : [...prev.sections, sectionId]
    }));
  };

  const sendReportEmail = async () => {
    try {
      if (!generatedReport || !scheduleConfig.recipients) return;
      
      const emailBody = `
${scheduleConfig.emailSubjectPrefix} ${selectedTemplate?.name}

Generated: ${new Date().toLocaleDateString()}

EXECUTIVE SUMMARY
${generatedReport.executive_summary}

KEY METRICS
${generatedReport.key_metrics?.map(m => `• ${m.label}: ${m.value} (${m.trend})`).join('\n')}

TOP RECOMMENDATIONS
${generatedReport.recommendations?.slice(0, 3).map((r, i) => `${i + 1}. [${r.priority}] ${r.title}: ${r.description}`).join('\n')}

${generatedReport.risk_alerts?.length > 0 ? `
RISK ALERTS
${generatedReport.risk_alerts.map(a => `⚠️ [${a.severity}] ${a.alert}`).join('\n')}
` : ''}

This report was automatically generated by Luminous Prosperity.
      `;

      await base44.integrations.Core.SendEmail({
        to: scheduleConfig.recipients,
        subject: `${scheduleConfig.emailSubjectPrefix} ${selectedTemplate?.name} - ${new Date().toLocaleDateString()}`,
        body: emailBody
      });

      alert('Report sent successfully to: ' + scheduleConfig.recipients);
    } catch (error) {
      console.error("Error sending report:", error);
      alert('Failed to send report. Please try again.');
    }
  };

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-6 h-6 text-blue-600" />
              Automated Reports & Analytics
            </CardTitle>
            <CardDescription>
              Schedule AI-generated reports with executive summaries and actionable insights
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => (
                  <SelectItem key={cat.id} value={cat.id}>{cat.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isCustomDialogOpen} onOpenChange={setIsCustomDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-purple-600 to-indigo-600">
                  <Plus className="w-4 h-4 mr-2" /> Custom Report
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Create Custom Report</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label>Report Name</Label>
                    <Input
                      value={customReport.name}
                      onChange={(e) => setCustomReport({...customReport, name: e.target.value})}
                      placeholder="My Custom Report"
                    />
                  </div>
                  <div>
                    <Label className="mb-2 block">Select Sections</Label>
                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                      {availableSections.map(section => (
                        <div
                          key={section.id}
                          onClick={() => toggleSection(section.id)}
                          className={`p-2 rounded border cursor-pointer text-sm transition-all ${
                            customReport.sections.includes(section.id)
                              ? 'bg-blue-100 border-blue-400 text-blue-900'
                              : 'bg-white border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {customReport.sections.includes(section.id) && (
                              <CheckCircle2 className="w-3 h-3 text-blue-600" />
                            )}
                            <span>{section.label}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label>Recipients</Label>
                    <Input
                      value={scheduleConfig.recipients}
                      onChange={(e) => setScheduleConfig({...scheduleConfig, recipients: e.target.value})}
                      placeholder="email@company.com"
                    />
                  </div>
                  <div>
                    <Label>Frequency</Label>
                    <Select value={scheduleConfig.frequency} onValueChange={(v) => setScheduleConfig({...scheduleConfig, frequency: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Include AI Predictions</Label>
                    <Switch
                      checked={scheduleConfig.includePredictions}
                      onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includePredictions: v})}
                    />
                  </div>
                  <Button 
                    onClick={createCustomReport} 
                    disabled={!customReport.name || customReport.sections.length === 0}
                    className="w-full bg-gradient-to-r from-purple-600 to-indigo-600"
                  >
                    <Plus className="w-4 h-4 mr-2" /> Create & Schedule Report
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Tabs for Templates vs Scheduled */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="templates">Report Templates</TabsTrigger>
            <TabsTrigger value="scheduled">Scheduled ({scheduledReports.length})</TabsTrigger>
            <TabsTrigger value="history">Report History</TabsTrigger>
          </TabsList>

          <TabsContent value="templates">
            {/* Report Templates */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTemplates.map((template) => {
            const Icon = template.icon;
            return (
              <div
                key={template.id}
                className="p-4 bg-white rounded-lg border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{template.name}</h4>
                      <Badge variant="outline" className="text-xs">{template.frequency}</Badge>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => generateReportNow(template)}
                    disabled={isGenerating}
                  >
                    {isGenerating && selectedTemplate?.id === template.id ? (
                      <><Sparkles className="w-3 h-3 mr-1 animate-spin" /> Generating...</>
                    ) : (
                      <><Play className="w-3 h-3 mr-1" /> Generate Now</>
                    )}
                  </Button>
                  <Dialog open={isDialogOpen && selectedTemplate?.id === template.id} onOpenChange={(open) => {
                    setIsDialogOpen(open);
                    if (open) setSelectedTemplate(template);
                  }}>
                    <DialogTrigger asChild>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <Clock className="w-3 h-3 mr-1" /> Schedule
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Schedule {template.name}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div>
                          <Label>Recipients (comma-separated emails)</Label>
                          <Input
                            value={scheduleConfig.recipients}
                            onChange={(e) => setScheduleConfig({...scheduleConfig, recipients: e.target.value})}
                            placeholder="email@company.com"
                          />
                        </div>
                        <div>
                          <Label>Frequency</Label>
                          <Select value={scheduleConfig.frequency} onValueChange={(v) => setScheduleConfig({...scheduleConfig, frequency: v})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="quarterly">Quarterly</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        {scheduleConfig.frequency === 'weekly' && (
                          <div>
                            <Label>Day of Week</Label>
                            <Select value={scheduleConfig.dayOfWeek} onValueChange={(v) => setScheduleConfig({...scheduleConfig, dayOfWeek: v})}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="monday">Monday</SelectItem>
                                <SelectItem value="tuesday">Tuesday</SelectItem>
                                <SelectItem value="wednesday">Wednesday</SelectItem>
                                <SelectItem value="thursday">Thursday</SelectItem>
                                <SelectItem value="friday">Friday</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <Label>Include Executive Summary</Label>
                          <Switch
                            checked={scheduleConfig.includeExecutiveSummary}
                            onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includeExecutiveSummary: v})}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Include Action Items</Label>
                          <Switch
                            checked={scheduleConfig.includeActionItems}
                            onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includeActionItems: v})}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Include Visual Charts</Label>
                          <Switch
                            checked={scheduleConfig.includeCharts}
                            onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includeCharts: v})}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Include Predictive Insights</Label>
                          <Switch
                            checked={scheduleConfig.includePredictions}
                            onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includePredictions: v})}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Include Industry Benchmarks</Label>
                          <Switch
                            checked={scheduleConfig.includeBenchmarks}
                            onCheckedChange={(v) => setScheduleConfig({...scheduleConfig, includeBenchmarks: v})}
                          />
                        </div>
                        <div>
                          <Label>Email Subject Prefix</Label>
                          <Input
                            value={scheduleConfig.emailSubjectPrefix}
                            onChange={(e) => setScheduleConfig({...scheduleConfig, emailSubjectPrefix: e.target.value})}
                            placeholder="[Luminous Report]"
                          />
                        </div>
                        <Button onClick={scheduleReport} className="w-full bg-blue-600 hover:bg-blue-700">
                          <Calendar className="w-4 h-4 mr-2" /> Schedule Report
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            );
          })}
            </div>
          </TabsContent>

          <TabsContent value="scheduled">
            {/* Scheduled Reports */}
            {scheduledReports.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg border">
                <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No scheduled reports yet</p>
                <p className="text-sm text-gray-400">Select a template and click "Schedule" to set up automated delivery</p>
              </div>
            ) : (
              <div className="space-y-3">
                {scheduledReports.map((schedule) => (
                  <div key={schedule.id} className="flex items-center justify-between p-4 bg-white rounded-lg border hover:border-blue-300 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{schedule.templateName}</p>
                        <div className="flex gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{schedule.frequency}</Badge>
                          {schedule.dayOfWeek && <Badge variant="outline" className="text-xs">{schedule.dayOfWeek}</Badge>}
                          {schedule.includeExecutiveSummary && <Badge className="bg-blue-100 text-blue-700 text-xs">Exec Summary</Badge>}
                          {schedule.includePredictions && <Badge className="bg-purple-100 text-purple-700 text-xs">Predictions</Badge>}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          <Mail className="w-3 h-3 inline mr-1" />
                          {schedule.recipients}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline" onClick={() => {
                        const template = reportTemplates.find(t => t.id === schedule.templateId);
                        if (template) generateReportNow(template);
                      }}>
                        <Play className="w-3 h-3 mr-1" /> Run Now
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteSchedule(schedule.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="history">
            <div className="text-center py-12 bg-white rounded-lg border">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Report history will appear here</p>
              <p className="text-sm text-gray-400">Generated reports are stored for 30 days</p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Generated Report Preview */}
        {generatedReport && (
          <div className="mt-6 p-4 bg-white rounded-lg border-2 border-green-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-green-600" />
                <h4 className="font-semibold text-gray-900">Generated Report: {selectedTemplate?.name}</h4>
              </div>
              <Badge className="bg-green-600">Ready</Badge>
            </div>
            
            {/* Executive Summary */}
            <div className="mb-4 p-3 bg-green-50 rounded-lg">
              <p className="text-xs font-semibold text-green-700 mb-1">EXECUTIVE SUMMARY</p>
              <p className="text-sm text-gray-700">{generatedReport.executive_summary}</p>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {generatedReport.key_metrics?.slice(0, 6).map((metric, i) => (
                <div key={i} className="p-2 bg-gray-50 rounded text-center">
                  <p className="text-lg font-bold text-gray-900">{metric.value}</p>
                  <p className="text-xs text-gray-500">{metric.label}</p>
                  <Badge variant="outline" className={`text-[10px] ${
                    metric.trend === 'up' ? 'text-green-600' : 
                    metric.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                  }`}>{metric.trend || 'stable'}</Badge>
                </div>
              ))}
            </div>

            {/* Trends Analysis */}
            {generatedReport.trends_analysis && (
              <div className="grid md:grid-cols-2 gap-3 mb-4">
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-xs font-semibold text-green-700 mb-2">IMPROVING</p>
                  <ul className="space-y-1">
                    {generatedReport.trends_analysis.improving?.map((item, i) => (
                      <li key={i} className="text-xs text-green-800 flex items-start gap-1">
                        <TrendingUp className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-3 bg-orange-50 rounded-lg">
                  <p className="text-xs font-semibold text-orange-700 mb-2">NEEDS ATTENTION</p>
                  <ul className="space-y-1">
                    {generatedReport.trends_analysis.needs_attention?.map((item, i) => (
                      <li key={i} className="text-xs text-orange-800 flex items-start gap-1">
                        <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* Risk Alerts */}
            {generatedReport.risk_alerts?.length > 0 && (
              <div className="mb-4 p-3 bg-red-50 rounded-lg border border-red-200">
                <p className="text-xs font-semibold text-red-700 mb-2">RISK ALERTS</p>
                <div className="space-y-2">
                  {generatedReport.risk_alerts.map((alert, i) => (
                    <div key={i} className="p-2 bg-white rounded border border-red-200">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-2">
                          <Badge className={`text-[10px] ${
                            alert.severity === 'critical' ? 'bg-red-600' :
                            alert.severity === 'high' ? 'bg-orange-600' : 'bg-yellow-600'
                          }`}>{alert.severity}</Badge>
                          <span className="text-xs text-red-800">{alert.alert}</span>
                        </div>
                      </div>
                      {alert.department && <p className="text-[10px] text-gray-500 mt-1">Department: {alert.department}</p>}
                      {alert.intervention && <p className="text-[10px] text-blue-600 mt-1">→ {alert.intervention}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Predictive Insights */}
            {generatedReport.predictive_insights?.length > 0 && (
              <div className="mb-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-xs font-semibold text-purple-700 mb-2">PREDICTIVE INSIGHTS</p>
                <div className="space-y-2">
                  {generatedReport.predictive_insights.slice(0, 3).map((insight, i) => (
                    <div key={i} className="p-2 bg-white rounded border border-purple-200">
                      <p className="text-xs text-purple-900 font-medium">{insight.prediction}</p>
                      <div className="flex gap-2 mt-1">
                        <span className="text-[10px] px-1.5 py-0.5 bg-purple-100 text-purple-700 rounded">{insight.confidence} confidence</span>
                        <span className="text-[10px] px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded">{insight.timeframe}</span>
                      </div>
                      {insight.recommended_action && (
                        <p className="text-[10px] text-blue-600 mt-1">Action: {insight.recommended_action}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Benchmarks */}
            {generatedReport.benchmarks?.length > 0 && (
              <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-xs font-semibold text-gray-700 mb-2">INDUSTRY BENCHMARKS</p>
                <div className="grid grid-cols-2 gap-2">
                  {generatedReport.benchmarks.slice(0, 4).map((bench, i) => (
                    <div key={i} className="p-2 bg-white rounded border">
                      <p className="text-xs text-gray-600">{bench.metric}</p>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-sm font-bold text-gray-900">{bench.org_value}</span>
                        <span className="text-[10px] text-gray-500">vs {bench.industry_avg}</span>
                      </div>
                      <Badge variant="outline" className={`text-[10px] mt-1 ${
                        bench.status === 'above' ? 'text-green-600 border-green-300' :
                        bench.status === 'below' ? 'text-red-600 border-red-300' : 'text-gray-600'
                      }`}>{bench.status}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommendations */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-gray-700">TOP RECOMMENDATIONS</p>
              {generatedReport.recommendations?.slice(0, 5).map((rec, i) => (
                <div key={i} className="p-2 bg-blue-50 rounded">
                  <div className="flex items-start gap-2">
                    <Badge className={`text-[10px] flex-shrink-0 ${
                      rec.priority === 'high' ? 'bg-red-600' : 
                      rec.priority === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'
                    }`}>{rec.priority}</Badge>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{rec.title}</p>
                      <p className="text-xs text-gray-600">{rec.description}</p>
                      <div className="flex gap-2 mt-1 flex-wrap">
                        {rec.impact && <span className="text-[10px] text-green-600">Impact: {rec.impact}</span>}
                        {rec.owner && <span className="text-[10px] text-gray-500">Owner: {rec.owner}</span>}
                        {rec.timeline && <span className="text-[10px] text-blue-600">Timeline: {rec.timeline}</span>}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-2 mt-4">
              <Button 
                variant="outline"
                onClick={() => setGeneratedReport(null)}
              >
                Close
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  // Download as text
                  const content = `${selectedTemplate?.name}\n\nEXECUTIVE SUMMARY\n${generatedReport.executive_summary}\n\nKEY METRICS\n${generatedReport.key_metrics?.map(m => `${m.label}: ${m.value}`).join('\n')}`;
                  const blob = new Blob([content], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `${selectedTemplate?.name?.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
                  a.click();
                }}
              >
                <Download className="w-4 h-4 mr-2" /> Download
              </Button>
              <Button 
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={sendReportEmail}
              >
                <Send className="w-4 h-4 mr-2" /> Email Report
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}