import React from "react";
import { format } from "date-fns";

export default function ExecutiveReport({ assessment, user, organization }) {
  return (
    <div className="max-w-5xl mx-auto p-8 bg-white">
      <style>{`
        @media print {
          body { margin: 0; padding: 0; }
          .print\\:hidden { display: none !important; }
          .page-break { page-break-before: always; }
        }
      `}</style>

      {/* Header with Branding */}
      <div className="border-b-4 border-[#B8967D] pb-6 mb-8 flex items-start justify-between">
        <div className="flex-1">
          {organization?.logo_url && (
            <img 
              src={organization.logo_url} 
              alt={organization.name}
              className="h-16 mb-4 object-contain"
            />
          )}
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Executive Leadership Assessment
          </h1>
          <p className="text-gray-600 text-lg">{organization?.name || 'Organization'}</p>
        </div>
        <div>
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6915fd2f6855a53a3152f254/e3df2aa7f_HighResLuminousLogoWithTransparencypngcopy.png"
            alt="Luminous Prosperity"
            className="h-12 object-contain"
          />
          <p className="text-xs text-gray-500 mt-2">Powered by Luminous Prosperity</p>
        </div>
      </div>

      {/* Executive Information */}
      <div className="mb-8 bg-stone-50 p-6 rounded-lg">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Executive Profile</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600">Name</p>
            <p className="font-semibold text-gray-900">{user?.full_name || 'Not specified'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Title</p>
            <p className="font-semibold text-gray-900">{user?.job_title || 'Executive'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Organization</p>
            <p className="font-semibold text-gray-900">{organization?.name || 'Not specified'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Assessment Date</p>
            <p className="font-semibold text-gray-900">
              {format(new Date(assessment.completed_date), 'MMMM d, yyyy')}
            </p>
          </div>
        </div>
      </div>

      {/* AI Insights - Executive Summary */}
      {assessment.ai_insights && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Leadership Insights</h2>
          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
            {assessment.ai_insights}
          </div>
        </div>
      )}

      {/* Page Break */}
      <div className="page-break"></div>

      {/* Leadership Style */}
      {assessment.leadership_style && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Leadership Style</h2>
          <div className="bg-blue-50 p-6 rounded-lg space-y-4">
            {Object.entries(assessment.leadership_style).map(([key, value]) => (
              <div key={key}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                  {key.replace(/_/g, ' ')}
                </h3>
                <p className="text-gray-700">{typeof value === 'string' ? value : JSON.stringify(value)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Strategic Vision */}
      {assessment.strategic_vision && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Strategic Vision</h2>
          <div className="bg-purple-50 p-6 rounded-lg space-y-4">
            {Object.entries(assessment.strategic_vision).map(([key, value]) => (
              <div key={key}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                  {key.replace(/_/g, ' ')}
                </h3>
                <p className="text-gray-700">{typeof value === 'string' ? value : JSON.stringify(value)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stakeholder Orientation */}
      {assessment.stakeholder_orientation && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Stakeholder Orientation</h2>
          <div className="bg-green-50 p-6 rounded-lg space-y-4">
            {Object.entries(assessment.stakeholder_orientation).map(([key, value]) => (
              <div key={key}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                  {key.replace(/_/g, ' ')}
                </h3>
                <p className="text-gray-700">{typeof value === 'string' ? value : JSON.stringify(value)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Page Break */}
      <div className="page-break"></div>

      {/* Integral Perspective */}
      {assessment.integral_perspective && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Integral Leadership Perspective</h2>
          <div className="bg-indigo-50 p-6 rounded-lg space-y-4">
            {Object.entries(assessment.integral_perspective).map(([key, value]) => {
              if (typeof value === 'object' && value !== null) {
                return (
                  <div key={key}>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                      {key.replace(/_/g, ' ')}
                    </h3>
                    {Object.entries(value).map(([subKey, subValue]) => (
                      <div key={subKey} className="ml-4 mb-2">
                        <p className="text-sm font-medium text-gray-700 capitalize">{subKey.replace(/_/g, ' ')}:</p>
                        <p className="text-gray-600">{typeof subValue === 'string' ? subValue : JSON.stringify(subValue)}</p>
                      </div>
                    ))}
                  </div>
                );
              }
              return (
                <div key={key}>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                    {key.replace(/_/g, ' ')}
                  </h3>
                  <p className="text-gray-700">{typeof value === 'string' ? value : JSON.stringify(value)}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Appreciative Inquiry */}
      {assessment.appreciative_inquiry && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-[#B8967D]">Organizational Transformation Vision</h2>
          <div className="bg-amber-50 p-6 rounded-lg space-y-4">
            {Object.entries(assessment.appreciative_inquiry).map(([key, value]) => (
              <div key={key}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 capitalize">
                  {key.replace(/_/g, ' ')}
                </h3>
                {Array.isArray(value) ? (
                  <ul className="list-disc list-inside space-y-1">
                    {value.map((item, idx) => (
                      <li key={idx} className="text-gray-700">{item}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-700">{typeof value === 'string' ? value : JSON.stringify(value)}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="mt-12 pt-6 border-t border-gray-200 text-center text-sm text-gray-500">
        <p>This executive report is confidential and intended solely for leadership development purposes</p>
        <p className="mt-1">Generated on {format(new Date(), 'MMMM d, yyyy')} by Luminous Prosperity</p>
        <p className="mt-2 text-xs">© {new Date().getFullYear()} {organization?.name || 'Organization'}. All rights reserved.</p>
      </div>
    </div>
  );
}