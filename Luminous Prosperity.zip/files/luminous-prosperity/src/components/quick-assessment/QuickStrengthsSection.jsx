import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Target, ArrowLeft } from "lucide-react";

export default function QuickStrengthsSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "What do people come to you for help with? What are you naturally good at?",
      placeholder: "Example: People often ask me to help them think through complex problems. I'm good at seeing patterns and coming up with creative solutions...",
    },
    {
      id: 'q2',
      question: "Think about your best days at work. What were you doing that made those days great?",
      placeholder: "Example: My best days are when I'm helping others learn something new or when I'm organizing a process that makes everyone's work easier...",
    },
    {
      id: 'q3',
      question: "What feels effortless to you that others seem to struggle with?",
      placeholder: "Example: I find it easy to stay calm under pressure and help others do the same. While my teammates stress about deadlines, I naturally prioritize and stay focused...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'strengths'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center shadow-lg">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Your Superpowers</CardTitle>
            <CardDescription className="text-base">What makes you uniquely valuable</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm text-amber-900">
            <strong>Discover your strengths!</strong> Don't be modest - this helps us understand what makes you exceptional.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={4}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-amber-400 to-amber-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}