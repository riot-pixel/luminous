import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Brain, ArrowLeft } from "lucide-react";

export default function QuickIntegralSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: '', q4: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "What brings you the most joy and energy at work?",
      placeholder: "Example: I love when I can help solve a problem that's been frustrating the team, or when I get to work on creative projects that let me think outside the box...",
    },
    {
      id: 'q2',
      question: "Describe a time when you felt really proud of what you accomplished.",
      placeholder: "Example: I led a project that brought three departments together, and seeing everyone collaborate so well made me realize how much I value teamwork...",
    },
    {
      id: 'q3',
      question: "What frustrates you most at work, and how do you typically handle it?",
      placeholder: "Example: I get frustrated when communication breaks down between teams. I usually try to bring people together for a quick chat to clear things up...",
    },
    {
      id: 'q4',
      question: "If you could change one thing about how your organization works, what would it be and why?",
      placeholder: "Example: I'd love for us to have more structured processes for sharing knowledge across departments, so we don't reinvent the wheel...",
    },
  ];

  const handleComplete = () => {
    // Pass raw answers - AI will analyze them
    onComplete({
      responses: answers,
      analysis_type: 'integral_theory'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-[#B8967D] to-[#A68364] rounded-xl flex items-center justify-center shadow-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">How You Work Best</CardTitle>
            <CardDescription className="text-base">Share your work experiences in your own words</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm text-amber-900">
            <strong>Just be yourself!</strong> Write freely - there are no wrong answers. We're learning how you naturally think and work.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={4}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-[#B8967D] to-[#A68364] text-white hover:from-[#A68364] hover:to-[#948054]"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}