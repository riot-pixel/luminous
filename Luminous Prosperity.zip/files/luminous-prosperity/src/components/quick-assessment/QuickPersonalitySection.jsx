import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Users, ArrowLeft } from "lucide-react";

export default function QuickPersonalitySection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "How do you prefer to spend your free time? What recharges you?",
      placeholder: "Example: I love quiet evenings at home with a good book, or hanging out with a small group of close friends rather than big parties...",
    },
    {
      id: 'q2',
      question: "When you're working on a project, what's your natural approach? Describe how you typically go about it.",
      placeholder: "Example: I like to start by understanding the big picture and why we're doing it, then I figure out the details as I go. I prefer flexibility over strict plans...",
    },
    {
      id: 'q3',
      question: "Tell me about a disagreement you had with someone. How did you handle it and what mattered most to you?",
      placeholder: "Example: My coworker and I had different ideas about priorities. I tried to understand their perspective first, and we found a compromise that kept everyone happy...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'personality'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Your Natural Style</CardTitle>
            <CardDescription className="text-base">Share how you naturally interact with the world</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <p className="text-sm text-orange-900">
            <strong>Share your experiences.</strong> Tell us stories - they reveal your authentic style better than any checklist!
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={4}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete} 
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-orange-400 to-orange-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}