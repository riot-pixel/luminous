import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Heart, ArrowLeft } from "lucide-react";

export default function QuickLifeBalanceSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "What areas of your life are going really well right now? What are you happy about?",
      placeholder: "Example: My career is on a great track and I'm learning a lot. My relationships with family are strong. Though I wish I had more time for hobbies and exercise...",
    },
    {
      id: 'q2',
      question: "What areas of your life need more attention? What would you like to improve?",
      placeholder: "Example: I'd love to have better work-life balance. I've been neglecting my health and personal time. Also want to improve my financial planning...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'life_balance'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-rose-400 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Life Balance Check-In</CardTitle>
            <CardDescription className="text-base">How's life going overall?</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-rose-50 border border-rose-200 rounded-lg p-4">
          <p className="text-sm text-rose-900">
            <strong>Be honest with yourself.</strong> Understanding where you are helps us provide better support for where you want to go.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete}
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-rose-400 to-pink-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}