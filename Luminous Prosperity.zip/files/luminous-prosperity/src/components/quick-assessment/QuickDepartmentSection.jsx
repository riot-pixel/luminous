import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Users, ArrowLeft, Loader2 } from "lucide-react";

export default function QuickDepartmentSection({ onComplete, onBack, initialData, isProcessing, userDepartment }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: `What does ${userDepartment} do really well? What are our collective strengths?`,
      placeholder: `Example: Our team is great at collaborating across functions. We bring different perspectives together and really listen to each other. We're also known for being reliable and delivering quality work...`,
    },
    {
      id: 'q2',
      question: `What could ${userDepartment} improve? Where do you see opportunities for growth?`,
      placeholder: "Example: We could be better at sharing knowledge - sometimes people reinvent solutions that already exist. We could also improve our planning process to avoid last-minute rushes...",
    },
    {
      id: 'q3',
      question: "How can you personally contribute to making the organization more successful?",
      placeholder: "Example: I can share my technical expertise with other teams, help onboard new members more effectively, and bring ideas from my previous experience in other industries...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'department'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Team & Organization</CardTitle>
            <CardDescription className="text-base">How we work together and grow together</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-sm text-green-900">
            <strong>Almost done!</strong> Your insights help shape our organizational strategy and team development.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} disabled={isProcessing} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete}
            disabled={!allAnswered || isProcessing}
            className="flex-1 bg-gradient-to-r from-green-400 to-emerald-500 text-white"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating Your Insights...
              </>
            ) : (
              'Complete Assessment'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}