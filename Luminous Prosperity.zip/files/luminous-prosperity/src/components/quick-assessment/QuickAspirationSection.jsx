import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Sparkles, ArrowLeft } from "lucide-react";

export default function QuickAspirationSection({ onComplete, onBack, initialData }) {
  const [answers, setAnswers] = useState(initialData || {
    q1: '', q2: '', q3: ''
  });

  const questions = [
    {
      id: 'q1',
      question: "Where do you see yourself in 2-3 years? What would make you feel successful and fulfilled?",
      placeholder: "Example: I'd love to be leading projects and mentoring others. Success for me means having more influence on strategy while maintaining work-life balance...",
    },
    {
      id: 'q2',
      question: "What impact do you want to have? How do you want to be remembered by your colleagues?",
      placeholder: "Example: I want to be known as someone who made things better - whether that's improving processes, helping people grow, or bringing the team together...",
    },
    {
      id: 'q3',
      question: "What's holding you back from achieving your goals? What support would help you get there?",
      placeholder: "Example: I need more confidence in public speaking and would benefit from leadership training. Also need clearer career progression paths in our organization...",
    },
  ];

  const handleComplete = () => {
    onComplete({
      responses: answers,
      analysis_type: 'aspirations'
    });
  };

  const allAnswered = Object.values(answers).every(a => a.trim().length > 10);

  return (
    <Card className="border-2 border-[#B8967D]/20">
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-violet-500 rounded-xl flex items-center justify-center shadow-lg">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Your Vision & Goals</CardTitle>
            <CardDescription className="text-base">Dream big - where are you headed?</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <p className="text-sm text-purple-900">
            <strong>Think about your future!</strong> The clearer your vision, the better we can help you create pathways to get there.
          </p>
        </div>

        {questions.map((q) => (
          <div key={q.id} className="space-y-3">
            <Label className="text-lg font-medium text-stone-800">{q.question}</Label>
            <Textarea
              value={answers[q.id]}
              onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
              placeholder={q.placeholder}
              rows={5}
              className="resize-none text-base"
            />
            <div className="flex justify-between items-center">
              <p className="text-xs text-stone-500">
                {answers[q.id].length} characters
              </p>
              {answers[q.id].trim().length > 10 && (
                <p className="text-xs text-green-600 font-medium">✓ Complete</p>
              )}
            </div>
          </div>
        ))}

        <div className="flex gap-3 pt-6">
          {onBack && (
            <Button variant="outline" onClick={onBack} className="flex-1">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          <Button 
            onClick={handleComplete}
            disabled={!allAnswered}
            className="flex-1 bg-gradient-to-r from-purple-400 to-violet-500 text-white"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}