import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function CEOStakeholderSection({ onComplete, onBack, initialData }) {
  const [data, setData] = useState(initialData || {
    stakeholder_priorities: {
      shareholders: 50,
      employees: 50,
      customers: 50,
      community: 50,
      environment: 50,
      suppliers: 50,
    },
    stakeholder_engagement: "",
    social_responsibility: "",
    sustainability_commitment: "",
  });

  const handleSliderChange = (stakeholder, value) => {
    setData({
      ...data,
      stakeholder_priorities: {
        ...data.stakeholder_priorities,
        [stakeholder]: value[0],
      },
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  const stakeholders = [
    { key: "shareholders", label: "Shareholders/Investors", desc: "Financial returns and value creation" },
    { key: "employees", label: "Employees", desc: "Well-being, development, and fulfillment" },
    { key: "customers", label: "Customers", desc: "Value delivery and satisfaction" },
    { key: "community", label: "Community", desc: "Local impact and social contribution" },
    { key: "environment", label: "Environment", desc: "Ecological sustainability" },
    { key: "suppliers", label: "Suppliers/Partners", desc: "Partnership and fair treatment" },
  ];

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Stakeholder Orientation</CardTitle>
          <CardDescription>
            How you balance and prioritize different stakeholder interests
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Rate the importance of each stakeholder group (0-100)</Label>
            <p className="text-sm text-gray-600">
              This helps understand your priorities when stakeholder interests conflict
            </p>
            {stakeholders.map((stakeholder) => (
              <div key={stakeholder.key} className="space-y-2">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">{stakeholder.label}</p>
                    <p className="text-sm text-gray-600">{stakeholder.desc}</p>
                  </div>
                  <span className="text-lg font-bold text-indigo-600">
                    {data.stakeholder_priorities[stakeholder.key]}
                  </span>
                </div>
                <Slider
                  value={[data.stakeholder_priorities[stakeholder.key]]}
                  onValueChange={(value) => handleSliderChange(stakeholder.key, value)}
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label>How do you actively engage with different stakeholder groups?</Label>
            <Textarea
              value={data.stakeholder_engagement}
              onChange={(e) => setData({ ...data, stakeholder_engagement: e.target.value })}
              placeholder="Describe your approach to listening, communicating, and building relationships with stakeholders..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>What is your philosophy on corporate social responsibility?</Label>
            <Textarea
              value={data.social_responsibility}
              onChange={(e) => setData({ ...data, social_responsibility: e.target.value })}
              placeholder="How do you balance profit with purpose, social impact, and community benefit..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Describe your commitment to environmental sustainability</Label>
            <Textarea
              value={data.sustainability_commitment}
              onChange={(e) => setData({ ...data, sustainability_commitment: e.target.value })}
              placeholder="Your approach to environmental impact, sustainability initiatives, and long-term ecological responsibility..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600">
              Next Section
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}