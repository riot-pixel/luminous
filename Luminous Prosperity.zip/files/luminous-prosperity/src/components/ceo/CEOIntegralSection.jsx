import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function CEOIntegralSection({ onComplete, onBack, initialData }) {
  const [data, setData] = useState(initialData || {
    quadrants: {
      individual_interior: 50,
      individual_exterior: 50,
      collective_interior: 50,
      collective_exterior: 50,
    },
    systems_thinking: "",
    complexity_navigation: "",
    paradox_management: "",
  });

  const handleSliderChange = (quadrant, value) => {
    setData({
      ...data,
      quadrants: {
        ...data.quadrants,
        [quadrant]: value[0],
      },
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  const quadrants = [
    {
      key: "individual_interior",
      label: "Individual Interior (I)",
      desc: "Focus on personal mindsets, beliefs, values, psychology"
    },
    {
      key: "individual_exterior",
      label: "Individual Exterior (IT)",
      desc: "Focus on behaviors, skills, competencies, performance"
    },
    {
      key: "collective_interior",
      label: "Collective Interior (WE)",
      desc: "Focus on culture, shared values, relationships, collaboration"
    },
    {
      key: "collective_exterior",
      label: "Collective Exterior (ITS)",
      desc: "Focus on systems, structures, processes, infrastructure"
    },
  ];

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Integral Leadership Perspective</CardTitle>
          <CardDescription>
            Your awareness and focus across the four quadrants of organizational reality
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-700">
              <strong>Integral Theory</strong> suggests that effective leaders must attend to all four quadrants: 
              individual and collective, interior (subjective) and exterior (objective). Rate how much attention 
              you currently give to each quadrant.
            </p>
          </div>

          <div className="space-y-4">
            {quadrants.map((quadrant) => (
              <div key={quadrant.key} className="space-y-2">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">{quadrant.label}</p>
                    <p className="text-sm text-gray-600">{quadrant.desc}</p>
                  </div>
                  <span className="text-lg font-bold text-indigo-600">
                    {data.quadrants[quadrant.key]}
                  </span>
                </div>
                <Slider
                  value={[data.quadrants[quadrant.key]]}
                  onValueChange={(value) => handleSliderChange(quadrant.key, value)}
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label>How do you practice systems thinking in your leadership?</Label>
            <Textarea
              value={data.systems_thinking}
              onChange={(e) => setData({ ...data, systems_thinking: e.target.value })}
              placeholder="How you see connections, feedback loops, and interconnections across the organization..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>How do you navigate complexity and ambiguity?</Label>
            <Textarea
              value={data.complexity_navigation}
              onChange={(e) => setData({ ...data, complexity_navigation: e.target.value })}
              placeholder="Your approach to making decisions in complex, uncertain environments..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>How do you manage organizational paradoxes? (e.g., stability vs. change, efficiency vs. innovation)</Label>
            <Textarea
              value={data.paradox_management}
              onChange={(e) => setData({ ...data, paradox_management: e.target.value })}
              placeholder="How you hold and integrate seemingly contradictory organizational needs..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600">
              Next Section
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}