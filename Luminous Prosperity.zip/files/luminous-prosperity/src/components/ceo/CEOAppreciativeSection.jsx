import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Sparkles } from "lucide-react";

export default function CEOAppreciativeSection({ onComplete, onBack, initialData, isProcessing }) {
  const [data, setData] = useState(initialData || {
    define: "",
    discover: ["", "", ""],
    dream: "",
    design: ["", "", ""],
    destiny: "",
  });

  const handleDiscoverChange = (index, value) => {
    const newDiscover = [...data.discover];
    newDiscover[index] = value;
    setData({ ...data, discover: newDiscover });
  };

  const handleDesignChange = (index, value) => {
    const newDesign = [...data.design];
    newDesign[index] = value;
    setData({ ...data, design: newDesign });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Organizational Appreciative Inquiry</CardTitle>
          <CardDescription>
            Envision and design the future of your organization using the 5D approach
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label className="text-lg font-semibold text-indigo-600">1. Define</Label>
            <p className="text-sm text-gray-600">What is the core topic you want to focus on for organizational transformation?</p>
            <Input
              value={data.define}
              onChange={(e) => setData({ ...data, define: e.target.value })}
              placeholder="e.g., Building a culture of innovation, Sustainable growth, Employee thriving..."
              required
            />
          </div>

          <div className="space-y-3">
            <Label className="text-lg font-semibold text-indigo-600">2. Discover</Label>
            <p className="text-sm text-gray-600">What are the organization's greatest achievements and strengths?</p>
            {[0, 1, 2].map((index) => (
              <Input
                key={index}
                value={data.discover[index]}
                onChange={(e) => handleDiscoverChange(index, e.target.value)}
                placeholder={`Peak achievement ${index + 1}`}
                required
              />
            ))}
          </div>

          <div className="space-y-2">
            <Label className="text-lg font-semibold text-indigo-600">3. Dream</Label>
            <p className="text-sm text-gray-600">What would your organization look like at its absolute best?</p>
            <Textarea
              value={data.dream}
              onChange={(e) => setData({ ...data, dream: e.target.value })}
              placeholder="Paint a vivid picture of your organization's ideal future state - culture, impact, relationships, success..."
              rows={5}
              required
            />
          </div>

          <div className="space-y-3">
            <Label className="text-lg font-semibold text-indigo-600">4. Design</Label>
            <p className="text-sm text-gray-600">What specific structures, strategies, or initiatives will bring the dream to life?</p>
            {[0, 1, 2].map((index) => (
              <Input
                key={index}
                value={data.design[index]}
                onChange={(e) => handleDesignChange(index, e.target.value)}
                placeholder={`Key design element ${index + 1}`}
                required
              />
            ))}
          </div>

          <div className="space-y-2">
            <Label className="text-lg font-semibold text-indigo-600">5. Destiny</Label>
            <p className="text-sm text-gray-600">What commitments will you make to sustain this transformation?</p>
            <Textarea
              value={data.destiny}
              onChange={(e) => setData({ ...data, destiny: e.target.value })}
              placeholder="Your personal leadership commitments, what you'll do differently, how you'll hold yourself accountable..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button 
              type="submit" 
              disabled={isProcessing}
              className="bg-gradient-to-r from-indigo-600 to-purple-600"
            >
              {isProcessing ? (
                <>
                  <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Complete Assessment
                  <Sparkles className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}