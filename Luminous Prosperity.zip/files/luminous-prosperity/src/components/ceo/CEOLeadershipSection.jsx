import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function CEOLeadershipSection({ onComplete, onBack, initialData }) {
  const [data, setData] = useState(initialData || {
    style: "",
    decision_approach: "",
    team_empowerment: "",
    conflict_resolution: "",
    change_management: "",
    communication_philosophy: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Leadership Style & Philosophy</CardTitle>
          <CardDescription>
            Understanding your leadership approach and how you guide your organization
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Label>Which leadership style best describes your approach?</Label>
            <RadioGroup value={data.style} onValueChange={(value) => setData({ ...data, style: value })}>
              <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                <RadioGroupItem value="transformational" id="transformational" />
                <Label htmlFor="transformational" className="cursor-pointer flex-1">
                  <div className="font-medium">Transformational</div>
                  <div className="text-sm text-gray-600">Inspiring change through vision and motivation</div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                <RadioGroupItem value="servant" id="servant" />
                <Label htmlFor="servant" className="cursor-pointer flex-1">
                  <div className="font-medium">Servant Leadership</div>
                  <div className="text-sm text-gray-600">Prioritizing team needs and growth</div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                <RadioGroupItem value="democratic" id="democratic" />
                <Label htmlFor="democratic" className="cursor-pointer flex-1">
                  <div className="font-medium">Democratic/Participative</div>
                  <div className="text-sm text-gray-600">Collaborative decision-making</div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                <RadioGroupItem value="strategic" id="strategic" />
                <Label htmlFor="strategic" className="cursor-pointer flex-1">
                  <div className="font-medium">Strategic</div>
                  <div className="text-sm text-gray-600">Data-driven, long-term focused</div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                <RadioGroupItem value="adaptive" id="adaptive" />
                <Label htmlFor="adaptive" className="cursor-pointer flex-1">
                  <div className="font-medium">Adaptive/Situational</div>
                  <div className="text-sm text-gray-600">Flexible approach based on context</div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>How do you approach major strategic decisions?</Label>
            <Textarea
              value={data.decision_approach}
              onChange={(e) => setData({ ...data, decision_approach: e.target.value })}
              placeholder="Describe your decision-making process, who you consult, how you weigh different factors..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>How do you empower and develop your leadership team?</Label>
            <Textarea
              value={data.team_empowerment}
              onChange={(e) => setData({ ...data, team_empowerment: e.target.value })}
              placeholder="Describe your approach to delegation, development, and building leadership capacity..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Describe your approach to conflict resolution at the executive level</Label>
            <Textarea
              value={data.conflict_resolution}
              onChange={(e) => setData({ ...data, conflict_resolution: e.target.value })}
              placeholder="How do you handle disagreements, competing priorities, and difficult conversations..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>How do you lead organizational change and transformation?</Label>
            <Textarea
              value={data.change_management}
              onChange={(e) => setData({ ...data, change_management: e.target.value })}
              placeholder="Your philosophy and approach to driving change, managing resistance, building momentum..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>What is your communication philosophy as a leader?</Label>
            <Textarea
              value={data.communication_philosophy}
              onChange={(e) => setData({ ...data, communication_philosophy: e.target.value })}
              placeholder="How you communicate vision, values, and decisions throughout the organization..."
              rows={4}
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            {onBack && (
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            )}
            <Button type="submit" className="ml-auto bg-gradient-to-r from-indigo-600 to-purple-600">
              Next Section
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}