import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function CEOVisionSection({ onComplete, onBack, initialData }) {
  const [data, setData] = useState(initialData || {
    vision_statement: "",
    strategic_priorities: ["", "", ""],
    innovation_approach: "",
    competitive_advantage: "",
    growth_strategy: "",
    time_horizon: "",
  });

  const handlePriorityChange = (index, value) => {
    const newPriorities = [...data.strategic_priorities];
    newPriorities[index] = value;
    setData({ ...data, strategic_priorities: newPriorities });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(data);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Strategic Vision & Direction</CardTitle>
          <CardDescription>
            Your vision for the organization's future and strategic direction
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>What is your vision for the organization in 5-10 years?</Label>
            <Textarea
              value={data.vision_statement}
              onChange={(e) => setData({ ...data, vision_statement: e.target.value })}
              placeholder="Paint a vivid picture of where you see the organization heading..."
              rows={5}
              required
            />
          </div>

          <div className="space-y-3">
            <Label>Top 3 Strategic Priorities (in order of importance)</Label>
            {[0, 1, 2].map((index) => (
              <Input
                key={index}
                value={data.strategic_priorities[index]}
                onChange={(e) => handlePriorityChange(index, e.target.value)}
                placeholder={`Strategic Priority ${index + 1}`}
                required
              />
            ))}
          </div>

          <div className="space-y-2">
            <Label>How do you approach innovation and staying competitive?</Label>
            <Textarea
              value={data.innovation_approach}
              onChange={(e) => setData({ ...data, innovation_approach: e.target.value })}
              placeholder="Your philosophy on R&D, experimentation, market sensing, and staying ahead..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>What do you see as your organization's core competitive advantage?</Label>
            <Textarea
              value={data.competitive_advantage}
              onChange={(e) => setData({ ...data, competitive_advantage: e.target.value })}
              placeholder="What makes your organization unique and defensible in the market..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>What is your growth strategy and philosophy?</Label>
            <Textarea
              value={data.growth_strategy}
              onChange={(e) => setData({ ...data, growth_strategy: e.target.value })}
              placeholder="Organic vs. acquisition, scaling approach, market expansion strategy..."
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>What is your strategic time horizon - how far ahead do you typically plan?</Label>
            <Input
              value={data.time_horizon}
              onChange={(e) => setData({ ...data, time_horizon: e.target.value })}
              placeholder="e.g., 3-year rolling plans, 10-year vision with annual reviews..."
              required
            />
          </div>

          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-indigo-600 to-purple-600">
              Next Section
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}