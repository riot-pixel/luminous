import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Brain, Sparkles, TrendingUp, Target, RefreshCw, Lightbulb,
  Building2, GitBranch, ArrowRight, Zap, BookOpen, Route,
  AlertTriangle, CheckCircle2, BarChart3
} from "lucide-react";

const STRATEGY_TEMPLATES = [
  { id: "digital_transformation", name: "Digital Transformation", description: "Accelerate digital capabilities and automation" },
  { id: "market_expansion", name: "Market Expansion", description: "Enter new markets or geographic regions" },
  { id: "product_innovation", name: "Product Innovation", description: "Focus on R&D and new product development" },
  { id: "operational_excellence", name: "Operational Excellence", description: "Optimize processes and reduce costs" },
  { id: "customer_centricity", name: "Customer Centricity", description: "Enhance customer experience and retention" },
  { id: "sustainability", name: "Sustainability Focus", description: "Green initiatives and sustainable practices" },
  { id: "ai_integration", name: "AI/ML Integration", description: "Adopt AI and machine learning across operations" },
  { id: "remote_first", name: "Remote-First Culture", description: "Build distributed team capabilities" }
];

export default function PredictiveSkillModeling({ 
  skills, 
  userSkills, 
  roleRequirements, 
  employees, 
  latestAudit,
  learningJourneys 
}) {
  const [isModeling, setIsModeling] = useState(false);
  const [selectedStrategies, setSelectedStrategies] = useState([]);
  const [customStrategy, setCustomStrategy] = useState("");
  const [timeHorizon, setTimeHorizon] = useState("1y");
  const [scenarios, setScenarios] = useState(null);
  const [reskillingPaths, setReskillingPaths] = useState(null);

  const toggleStrategy = (strategyId) => {
    setSelectedStrategies(prev => 
      prev.includes(strategyId) 
        ? prev.filter(s => s !== strategyId)
        : [...prev, strategyId]
    );
  };

  const runPredictiveModeling = async () => {
    if (selectedStrategies.length === 0 && !customStrategy) return;
    setIsModeling(true);

    try {
      const selectedStrategyDetails = STRATEGY_TEMPLATES.filter(s => selectedStrategies.includes(s.id));
      const currentSkillDistribution = {};
      userSkills?.forEach(us => {
        currentSkillDistribution[us.skill_name] = (currentSkillDistribution[us.skill_name] || 0) + 1;
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a strategic workforce planning expert. Analyze how business strategies will impact skill requirements and create what-if scenarios.

CURRENT ORGANIZATION STATE:
- Total Employees: ${employees?.length || 0}
- Current Skills Distribution: ${Object.entries(currentSkillDistribution).slice(0, 15).map(([s, c]) => `${s}: ${c}`).join(', ')}
- Current Skill Gaps: ${latestAudit?.critical_gaps?.map(g => g.skill_name).join(', ') || 'None identified'}
- Industry Alignment: ${latestAudit?.industry_trend_alignment?.alignment_score || 'Unknown'}%

SELECTED BUSINESS STRATEGIES:
${selectedStrategyDetails.map(s => `- ${s.name}: ${s.description}`).join('\n')}
${customStrategy ? `- Custom Strategy: ${customStrategy}` : ''}

TIME HORIZON: ${timeHorizon === '6m' ? '6 months' : timeHorizon === '1y' ? '1 year' : timeHorizon === '2y' ? '2 years' : '5 years'}

For EACH strategy, provide:
1. Skills that will become CRITICAL (demand spike)
2. Skills that will become LESS relevant
3. NEW skills that don't exist yet in the org
4. Specific role transformations needed
5. Hiring vs. reskilling recommendations
6. Risk assessment if skills aren't developed

Also provide:
- Combined scenario showing all strategies together
- Best-case and worst-case outcomes
- Specific reskilling pathways mapping current skills to needed skills`,
        response_json_schema: {
          type: "object",
          properties: {
            strategy_impacts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  strategy_name: { type: "string" },
                  critical_skills: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        skill: { type: "string" },
                        demand_increase: { type: "string" },
                        timeline: { type: "string" },
                        current_gap: { type: "number" }
                      }
                    }
                  },
                  declining_skills: { type: "array", items: { type: "string" } },
                  new_skills_needed: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        skill: { type: "string" },
                        urgency: { type: "string" },
                        source: { type: "string" }
                      }
                    }
                  },
                  role_transformations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        from_role: { type: "string" },
                        to_role: { type: "string" },
                        skill_changes: { type: "array", items: { type: "string" } }
                      }
                    }
                  },
                  hiring_vs_reskilling: {
                    type: "object",
                    properties: {
                      hire_externally: { type: "array", items: { type: "string" } },
                      reskill_internally: { type: "array", items: { type: "string" } },
                      reasoning: { type: "string" }
                    }
                  },
                  risk_if_not_addressed: { type: "string" }
                }
              }
            },
            combined_scenario: {
              type: "object",
              properties: {
                summary: { type: "string" },
                top_priority_skills: { type: "array", items: { type: "string" } },
                total_skill_gap: { type: "number" },
                investment_required: { type: "string" },
                timeline_to_readiness: { type: "string" }
              }
            },
            best_case_outcome: {
              type: "object",
              properties: {
                description: { type: "string" },
                readiness_score: { type: "number" },
                competitive_advantage: { type: "string" }
              }
            },
            worst_case_outcome: {
              type: "object",
              properties: {
                description: { type: "string" },
                risks: { type: "array", items: { type: "string" } },
                mitigation_needed: { type: "string" }
              }
            },
            reskilling_pathways: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  pathway_name: { type: "string" },
                  from_skills: { type: "array", items: { type: "string" } },
                  to_skills: { type: "array", items: { type: "string" } },
                  affected_employees_estimate: { type: "number" },
                  duration: { type: "string" },
                  learning_modules: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        module_title: { type: "string" },
                        skills_covered: { type: "array", items: { type: "string" } },
                        duration: { type: "string" },
                        format: { type: "string" }
                      }
                    }
                  },
                  success_metrics: { type: "array", items: { type: "string" } },
                  milestone_badges: { type: "array", items: { type: "string" } }
                }
              }
            },
            immediate_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  owner: { type: "string" },
                  deadline: { type: "string" },
                  impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      setScenarios(result);
      setReskillingPaths(result.reskilling_pathways);
    } catch (error) {
      console.error("Error in predictive modeling:", error);
    }
    setIsModeling(false);
  };

  return (
    <div className="space-y-6">
      {/* Strategy Selection */}
      <Card className="bg-gradient-to-r from-indigo-900/30 to-purple-900/30 border-indigo-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <GitBranch className="w-6 h-6 text-indigo-400" />
            Predictive Skill Modeling & What-If Scenarios
          </CardTitle>
          <CardDescription className="text-gray-400">
            Select business strategies to model their impact on skill requirements
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-4 gap-3">
            {STRATEGY_TEMPLATES.map(strategy => (
              <button
                key={strategy.id}
                onClick={() => toggleStrategy(strategy.id)}
                className={`p-3 rounded-lg text-left transition-all ${
                  selectedStrategies.includes(strategy.id)
                    ? 'bg-indigo-600 border-2 border-indigo-400'
                    : 'bg-gray-800 border-2 border-gray-700 hover:border-gray-600'
                }`}
              >
                <p className="text-white text-sm font-medium">{strategy.name}</p>
                <p className="text-gray-400 text-xs mt-1">{strategy.description}</p>
              </button>
            ))}
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                value={customStrategy}
                onChange={(e) => setCustomStrategy(e.target.value)}
                placeholder="Or describe a custom strategy..."
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <Select value={timeHorizon} onValueChange={setTimeHorizon}>
              <SelectTrigger className="w-40 bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6m">6 Months</SelectItem>
                <SelectItem value="1y">1 Year</SelectItem>
                <SelectItem value="2y">2 Years</SelectItem>
                <SelectItem value="5y">5 Years</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={runPredictiveModeling} 
              disabled={isModeling || (selectedStrategies.length === 0 && !customStrategy)}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              {isModeling ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Modeling...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" />Run Prediction</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {scenarios && (
        <>
          {/* Combined Scenario Overview */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Combined Strategy Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">{scenarios.combined_scenario?.summary}</p>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="p-4 bg-purple-900/30 rounded-lg text-center">
                  <p className="text-3xl font-bold text-purple-400">{scenarios.combined_scenario?.total_skill_gap}</p>
                  <p className="text-gray-400 text-sm">Total Skill Gap</p>
                </div>
                <div className="p-4 bg-blue-900/30 rounded-lg text-center">
                  <p className="text-lg font-bold text-blue-400">{scenarios.combined_scenario?.investment_required}</p>
                  <p className="text-gray-400 text-sm">Investment Required</p>
                </div>
                <div className="p-4 bg-green-900/30 rounded-lg text-center">
                  <p className="text-lg font-bold text-green-400">{scenarios.combined_scenario?.timeline_to_readiness}</p>
                  <p className="text-gray-400 text-sm">Time to Readiness</p>
                </div>
                <div className="p-4 bg-orange-900/30 rounded-lg">
                  <p className="text-gray-400 text-xs mb-2">Priority Skills:</p>
                  <div className="flex flex-wrap gap-1">
                    {scenarios.combined_scenario?.top_priority_skills?.slice(0, 4).map((s, i) => (
                      <Badge key={i} className="bg-orange-600 text-xs">{s}</Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Best/Worst Case */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="bg-green-900/20 border-green-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-green-400 text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />Best Case Scenario
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-2">{scenarios.best_case_outcome?.description}</p>
                <div className="flex items-center gap-4">
                  <Badge className="bg-green-600">Readiness: {scenarios.best_case_outcome?.readiness_score}%</Badge>
                  <span className="text-green-400 text-xs">{scenarios.best_case_outcome?.competitive_advantage}</span>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-red-900/20 border-red-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-red-400 text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />Worst Case Scenario
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm mb-2">{scenarios.worst_case_outcome?.description}</p>
                <div className="space-y-1">
                  {scenarios.worst_case_outcome?.risks?.slice(0, 2).map((r, i) => (
                    <p key={i} className="text-red-400 text-xs">• {r}</p>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Strategy Details */}
          <Tabs defaultValue={scenarios.strategy_impacts?.[0]?.strategy_name} className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800 flex-wrap h-auto gap-1 p-1">
              {scenarios.strategy_impacts?.map((impact, i) => (
                <TabsTrigger key={i} value={impact.strategy_name} className="text-xs">
                  {impact.strategy_name}
                </TabsTrigger>
              ))}
              <TabsTrigger value="reskilling" className="text-xs">
                <Route className="w-3 h-3 mr-1" />Reskilling Paths
              </TabsTrigger>
              <TabsTrigger value="actions" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />Actions
              </TabsTrigger>
            </TabsList>

            {scenarios.strategy_impacts?.map((impact, i) => (
              <TabsContent key={i} value={impact.strategy_name}>
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Critical Skills */}
                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-white text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />Critical Skills Needed
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {impact.critical_skills?.map((skill, j) => (
                          <div key={j} className="p-2 bg-green-900/20 rounded flex items-center justify-between">
                            <span className="text-white text-sm">{skill.skill}</span>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-green-600 text-xs">{skill.demand_increase}</Badge>
                              <span className="text-gray-400 text-xs">{skill.timeline}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* New Skills */}
                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-white text-sm flex items-center gap-2">
                        <Lightbulb className="w-4 h-4 text-yellow-400" />New Skills to Develop
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {impact.new_skills_needed?.map((skill, j) => (
                          <div key={j} className="p-2 bg-yellow-900/20 rounded">
                            <div className="flex items-center justify-between">
                              <span className="text-white text-sm">{skill.skill}</span>
                              <Badge className={skill.urgency === 'high' ? 'bg-red-600' : 'bg-yellow-600'} variant="outline">
                                {skill.urgency}
                              </Badge>
                            </div>
                            <p className="text-gray-400 text-xs mt-1">Source: {skill.source}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Role Transformations */}
                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-white text-sm flex items-center gap-2">
                        <GitBranch className="w-4 h-4 text-purple-400" />Role Transformations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {impact.role_transformations?.map((trans, j) => (
                          <div key={j} className="p-2 bg-purple-900/20 rounded">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-gray-400 text-sm">{trans.from_role}</span>
                              <ArrowRight className="w-3 h-3 text-purple-400" />
                              <span className="text-white text-sm">{trans.to_role}</span>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {trans.skill_changes?.slice(0, 3).map((s, k) => (
                                <Badge key={k} variant="outline" className="text-xs border-purple-600 text-purple-400">{s}</Badge>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Hire vs Reskill */}
                  <Card className="bg-gray-900 border-gray-800">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-white text-sm flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-blue-400" />Hire vs Reskill
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <p className="text-red-400 text-xs mb-1">Hire Externally:</p>
                          <div className="flex flex-wrap gap-1">
                            {impact.hiring_vs_reskilling?.hire_externally?.map((s, j) => (
                              <Badge key={j} className="bg-red-600 text-xs">{s}</Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-green-400 text-xs mb-1">Reskill Internally:</p>
                          <div className="flex flex-wrap gap-1">
                            {impact.hiring_vs_reskilling?.reskill_internally?.map((s, j) => (
                              <Badge key={j} className="bg-green-600 text-xs">{s}</Badge>
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-400 text-xs">{impact.hiring_vs_reskilling?.reasoning}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Risk Warning */}
                <Card className="bg-red-900/20 border-red-800 mt-4">
                  <CardContent className="p-4">
                    <p className="text-red-400 text-sm flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <span><strong>Risk if not addressed:</strong> {impact.risk_if_not_addressed}</span>
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}

            {/* Reskilling Pathways */}
            <TabsContent value="reskilling">
              <div className="space-y-4">
                {reskillingPaths?.map((pathway, i) => (
                  <Card key={i} className="bg-gray-900 border-gray-800">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-white text-lg">{pathway.pathway_name}</CardTitle>
                          <CardDescription className="text-gray-400">
                            ~{pathway.affected_employees_estimate} employees • {pathway.duration}
                          </CardDescription>
                        </div>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <BookOpen className="w-3 h-3 mr-1" />Create Journey
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4 mb-4">
                        <div>
                          <p className="text-gray-400 text-xs mb-1">From Skills:</p>
                          <div className="flex flex-wrap gap-1">
                            {pathway.from_skills?.map((s, j) => (
                              <Badge key={j} variant="outline" className="text-xs border-gray-600">{s}</Badge>
                            ))}
                          </div>
                        </div>
                        <ArrowRight className="w-6 h-6 text-green-400 flex-shrink-0" />
                        <div>
                          <p className="text-gray-400 text-xs mb-1">To Skills:</p>
                          <div className="flex flex-wrap gap-1">
                            {pathway.to_skills?.map((s, j) => (
                              <Badge key={j} className="bg-green-600 text-xs">{s}</Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-3">
                        {pathway.learning_modules?.map((mod, j) => (
                          <div key={j} className="p-3 bg-gray-800 rounded-lg">
                            <p className="text-white text-sm font-medium mb-1">{mod.module_title}</p>
                            <div className="flex gap-2 text-xs text-gray-400">
                              <span>{mod.duration}</span>
                              <span>•</span>
                              <span>{mod.format}</span>
                            </div>
                            <div className="flex flex-wrap gap-1 mt-2">
                              {mod.skills_covered?.slice(0, 2).map((s, k) => (
                                <Badge key={k} variant="outline" className="text-[10px] border-blue-600 text-blue-400">{s}</Badge>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-4 p-3 bg-purple-900/20 rounded-lg">
                        <p className="text-purple-400 text-xs mb-2">Milestone Badges:</p>
                        <div className="flex gap-2">
                          {pathway.milestone_badges?.map((badge, j) => (
                            <span key={j} className="text-lg">🏆</span>
                          ))}
                          <span className="text-gray-400 text-sm">{pathway.milestone_badges?.join(' • ')}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Immediate Actions */}
            <TabsContent value="actions">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Immediate Actions Required</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {scenarios.immediate_actions?.map((action, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-white font-medium">{action.action}</p>
                          <div className="flex gap-4 mt-2 text-xs text-gray-400">
                            <span>Owner: {action.owner}</span>
                            <span>Deadline: {action.deadline}</span>
                          </div>
                        </div>
                        <Badge className={action.impact === 'high' ? 'bg-red-600' : action.impact === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'}>
                          {action.impact} impact
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}