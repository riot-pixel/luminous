import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Brain, Sparkles, AlertTriangle, TrendingUp, Target, Users, 
  GraduationCap, RefreshCw, Calendar, BarChart3, Zap, Building2,
  ArrowRight, Clock, DollarSign, CheckCircle2, GitBranch
} from "lucide-react";
import PredictiveSkillModeling from "./PredictiveSkillModeling";

export default function SkillGapAuditEngine({ 
  skills, 
  userSkills, 
  roleRequirements, 
  employees, 
  teams,
  forecasts,
  learningJourneys 
}) {
  const queryClient = useQueryClient();
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditScope, setAuditScope] = useState('organization');
  const [selectedTeam, setSelectedTeam] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');

  const { data: previousAudits } = useQuery({
    queryKey: ['skillGapAudits'],
    queryFn: () => base44.entities.SkillGapAudit.list('-audit_date', 10),
    initialData: [],
  });

  const createAuditMutation = useMutation({
    mutationFn: (data) => base44.entities.SkillGapAudit.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['skillGapAudits'] }),
  });

  const departments = [...new Set(employees?.map(e => e.department).filter(Boolean))];
  const latestAudit = previousAudits?.[0];

  const runSkillGapAudit = async () => {
    setIsAuditing(true);
    try {
      // Calculate current skill gaps
      const skillGaps = [];
      const skillCounts = {};
      
      employees?.forEach(emp => {
        const empSkills = userSkills?.filter(us => us.user_email === emp.email) || [];
        const reqs = roleRequirements?.filter(rr => rr.role_title === emp.job_title) || [];
        
        empSkills.forEach(s => {
          skillCounts[s.skill_name] = (skillCounts[s.skill_name] || 0) + 1;
        });
        
        reqs.forEach(req => {
          const has = empSkills.find(s => s.skill_id === req.skill_id);
          const profOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
          if (!has || profOrder.indexOf(has.self_assessed_proficiency || has.current_proficiency) < profOrder.indexOf(req.required_proficiency)) {
            skillGaps.push({
              employee: emp.full_name || emp.email,
              department: emp.department,
              role: emp.job_title,
              skill: req.skill_name,
              required: req.required_proficiency,
              current: has?.self_assessed_proficiency || has?.current_proficiency || 'None',
              priority: req.priority
            });
          }
        });
      });

      // Group gaps by skill
      const gapsBySkill = {};
      skillGaps.forEach(g => {
        if (!gapsBySkill[g.skill]) {
          gapsBySkill[g.skill] = { count: 0, roles: new Set(), priority: g.priority };
        }
        gapsBySkill[g.skill].count++;
        gapsBySkill[g.skill].roles.add(g.role);
      });

      // Department breakdown
      const deptStats = departments.map(dept => {
        const deptGaps = skillGaps.filter(g => g.department === dept);
        const deptEmps = employees?.filter(e => e.department === dept).length || 1;
        return {
          department: dept,
          gap_count: deptGaps.length,
          readiness_score: Math.max(0, Math.round(100 - (deptGaps.length / deptEmps) * 20))
        };
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an organizational development expert conducting a comprehensive skill gap audit.

ORGANIZATION OVERVIEW:
- Total Employees: ${employees?.length || 0}
- Departments: ${departments.join(', ')}
- Total Skills Tracked: ${Object.keys(skillCounts).length}
- Active Teams: ${teams?.filter(t => t.status === 'active').length || 0}

CURRENT SKILL DISTRIBUTION:
${Object.entries(skillCounts).slice(0, 20).map(([skill, count]) => `- ${skill}: ${count} employees`).join('\n')}

IDENTIFIED SKILL GAPS (Top 15):
${Object.entries(gapsBySkill).slice(0, 15).map(([skill, data]) => 
  `- ${skill}: ${data.count} gaps across ${data.roles.size} roles (Priority: ${data.priority})`
).join('\n')}

DEPARTMENT BREAKDOWN:
${deptStats.map(d => `- ${d.department}: ${d.gap_count} gaps, Readiness: ${d.readiness_score}%`).join('\n')}

EXISTING FORECASTS (if available):
${forecasts?.high_demand_skills?.slice(0, 5).map(s => `- ${s.skill}: ${s.demand_growth}% growth expected`).join('\n') || 'No forecasts available'}

Based on this data, provide a comprehensive skill gap audit with:
1. Overall readiness score and assessment
2. Critical gaps requiring immediate attention
3. Future shortage predictions based on industry trends
4. Industry trend alignment analysis
5. Specific upskilling initiatives with ROI estimates
6. Reskilling recommendations for declining skills
7. Department-specific priorities`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_readiness_score: { type: "number" },
            executive_summary: { type: "string" },
            critical_gaps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_name: { type: "string" },
                  severity: { type: "string" },
                  affected_count: { type: "number" },
                  affected_roles: { type: "array", items: { type: "string" } },
                  business_impact: { type: "string" },
                  recommended_action: { type: "string" }
                }
              }
            },
            future_shortage_predictions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_name: { type: "string" },
                  predicted_shortage_date: { type: "string" },
                  confidence: { type: "number" },
                  demand_driver: { type: "string" },
                  current_supply: { type: "number" },
                  projected_demand: { type: "number" }
                }
              }
            },
            industry_trend_alignment: {
              type: "object",
              properties: {
                alignment_score: { type: "number" },
                trending_skills_present: { type: "array", items: { type: "string" } },
                trending_skills_missing: { type: "array", items: { type: "string" } },
                industry_benchmark: { type: "string" }
              }
            },
            upskilling_initiatives: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  initiative_name: { type: "string" },
                  target_skills: { type: "array", items: { type: "string" } },
                  target_audience: { type: "string" },
                  priority: { type: "string" },
                  estimated_duration: { type: "string" },
                  estimated_cost: { type: "string" },
                  expected_roi: { type: "string" },
                  implementation_steps: { type: "array", items: { type: "string" } }
                }
              }
            },
            reskilling_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  from_skill: { type: "string" },
                  to_skill: { type: "string" },
                  affected_employees: { type: "number" },
                  transition_path: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            department_priorities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  department: { type: "string" },
                  priority_skills: { type: "array", items: { type: "string" } },
                  recommended_focus: { type: "string" }
                }
              }
            },
            ai_confidence: { type: "number" }
          }
        }
      });

      // Save audit
      await createAuditMutation.mutateAsync({
        audit_date: new Date().toISOString(),
        audit_type: auditScope,
        scope_name: auditScope === 'organization' ? 'Full Organization' : selectedDepartment || selectedTeam,
        overall_readiness_score: result.overall_readiness_score,
        critical_gaps: result.critical_gaps,
        future_shortage_predictions: result.future_shortage_predictions,
        industry_trend_alignment: result.industry_trend_alignment,
        upskilling_initiatives: result.upskilling_initiatives,
        reskilling_recommendations: result.reskilling_recommendations,
        department_breakdown: deptStats.map(d => ({
          ...d,
          priority_skills: result.department_priorities?.find(dp => dp.department === d.department)?.priority_skills || []
        })),
        next_audit_recommended: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        ai_confidence: result.ai_confidence
      });

    } catch (error) {
      console.error("Error running audit:", error);
    }
    setIsAuditing(false);
  };

  const severityColors = {
    critical: 'bg-red-600',
    high: 'bg-orange-600',
    medium: 'bg-yellow-600',
    low: 'bg-blue-600'
  };

  return (
    <div className="space-y-6">
      {/* Audit Controls */}
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            AI Skill Gap Audit Engine
          </CardTitle>
          <CardDescription className="text-gray-400">
            Automated analysis of skill gaps, future shortages, and upskilling recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4 mb-4">
            <Select value={auditScope} onValueChange={setAuditScope}>
              <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="organization">Full Organization</SelectItem>
                <SelectItem value="department">By Department</SelectItem>
                <SelectItem value="team">By Team</SelectItem>
              </SelectContent>
            </Select>

            {auditScope === 'department' && (
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {auditScope === 'team' && (
              <Select value={selectedTeam} onValueChange={setSelectedTeam}>
                <SelectTrigger className="w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Select team" />
                </SelectTrigger>
                <SelectContent>
                  {teams?.filter(t => t.status === 'active').map(t => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Button onClick={runSkillGapAudit} disabled={isAuditing} className="bg-purple-600 hover:bg-purple-700">
              {isAuditing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Running Audit...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" />Run Skill Gap Audit</>
              )}
            </Button>
          </div>

          {latestAudit && (
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>Last audit: {new Date(latestAudit.audit_date).toLocaleDateString()}</span>
              <span>•</span>
              <span>Readiness: {latestAudit.overall_readiness_score}%</span>
              <span>•</span>
              <span>Confidence: {latestAudit.ai_confidence}%</span>
            </div>
          )}
        </CardContent>
      </Card>

      {latestAudit && (
        <>
          {/* Overview Metrics */}
          <div className="grid md:grid-cols-4 gap-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-purple-400 mb-2">{latestAudit.overall_readiness_score}%</div>
                <p className="text-gray-400 text-sm">Readiness Score</p>
                <Progress value={latestAudit.overall_readiness_score} className="mt-2 h-2" />
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-red-400 mb-2">{latestAudit.critical_gaps?.length || 0}</div>
                <p className="text-gray-400 text-sm">Critical Gaps</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-orange-400 mb-2">{latestAudit.future_shortage_predictions?.length || 0}</div>
                <p className="text-gray-400 text-sm">Predicted Shortages</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">{latestAudit.industry_trend_alignment?.alignment_score || 0}%</div>
                <p className="text-gray-400 text-sm">Industry Alignment</p>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Results */}
          <Tabs defaultValue="critical" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="critical"><AlertTriangle className="w-4 h-4 mr-1" />Critical Gaps</TabsTrigger>
              <TabsTrigger value="predictions"><TrendingUp className="w-4 h-4 mr-1" />Predictions</TabsTrigger>
              <TabsTrigger value="upskilling"><GraduationCap className="w-4 h-4 mr-1" />Upskilling</TabsTrigger>
              <TabsTrigger value="reskilling"><RefreshCw className="w-4 h-4 mr-1" />Reskilling</TabsTrigger>
              <TabsTrigger value="departments"><Building2 className="w-4 h-4 mr-1" />Departments</TabsTrigger>
              <TabsTrigger value="predictive"><GitBranch className="w-4 h-4 mr-1" />Predictive Modeling</TabsTrigger>
              </TabsList>

            <TabsContent value="critical">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Critical Skill Gaps</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestAudit.critical_gaps?.map((gap, i) => (
                      <div key={i} className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{gap.skill_name}</h4>
                          <Badge className={severityColors[gap.severity]}>{gap.severity}</Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{gap.business_impact}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500 mb-2">
                          <span><Users className="w-3 h-3 inline mr-1" />{gap.affected_count} affected</span>
                          <span>Roles: {gap.affected_roles?.join(', ')}</span>
                        </div>
                        <div className="p-2 bg-gray-800 rounded text-sm">
                          <span className="text-green-400">Recommended:</span> {gap.recommended_action}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="predictions">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Future Shortage Predictions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestAudit.future_shortage_predictions?.map((pred, i) => (
                      <div key={i} className="p-4 bg-orange-900/20 border border-orange-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{pred.skill_name}</h4>
                          <Badge className="bg-orange-600">
                            <Clock className="w-3 h-3 mr-1" />{pred.predicted_shortage_date}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{pred.demand_driver}</p>
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div className="p-2 bg-gray-800 rounded">
                            <p className="text-xl font-bold text-blue-400">{pred.current_supply}</p>
                            <p className="text-xs text-gray-500">Current</p>
                          </div>
                          <div className="p-2 bg-gray-800 rounded">
                            <p className="text-xl font-bold text-red-400">{pred.projected_demand}</p>
                            <p className="text-xs text-gray-500">Projected Need</p>
                          </div>
                          <div className="p-2 bg-gray-800 rounded">
                            <p className="text-xl font-bold text-purple-400">{pred.confidence}%</p>
                            <p className="text-xs text-gray-500">Confidence</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="upskilling">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Recommended Upskilling Initiatives</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestAudit.upskilling_initiatives?.map((init, i) => (
                      <div key={i} className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{init.initiative_name}</h4>
                          <Badge className={init.priority === 'critical' ? 'bg-red-600' : init.priority === 'high' ? 'bg-orange-600' : 'bg-blue-600'}>
                            {init.priority}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">Target: {init.target_audience}</p>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {init.target_skills?.map((skill, j) => (
                            <Badge key={j} variant="outline" className="text-xs border-green-600 text-green-400">{skill}</Badge>
                          ))}
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs mb-3">
                          <div className="p-2 bg-gray-800 rounded">
                            <Clock className="w-3 h-3 inline mr-1 text-gray-500" />{init.estimated_duration}
                          </div>
                          <div className="p-2 bg-gray-800 rounded">
                            <DollarSign className="w-3 h-3 inline mr-1 text-gray-500" />{init.estimated_cost}
                          </div>
                          <div className="p-2 bg-gray-800 rounded text-green-400">
                            ROI: {init.expected_roi}
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Implementation Steps:</p>
                          <ol className="list-decimal list-inside text-xs text-gray-400 space-y-1">
                            {init.implementation_steps?.slice(0, 3).map((step, j) => (
                              <li key={j}>{step}</li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reskilling">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Reskilling Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {latestAudit.reskilling_recommendations?.map((rec, i) => (
                      <div key={i} className="p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                        <div className="flex items-center gap-4 mb-2">
                          <Badge variant="outline" className="border-red-600 text-red-400">{rec.from_skill}</Badge>
                          <ArrowRight className="w-4 h-4 text-gray-500" />
                          <Badge className="bg-green-600">{rec.to_skill}</Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{rec.transition_path}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span><Users className="w-3 h-3 inline mr-1" />{rec.affected_employees} employees</span>
                          <span><Clock className="w-3 h-3 inline mr-1" />{rec.timeline}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="departments">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Department Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {latestAudit.department_breakdown?.map((dept, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-white font-medium">{dept.department}</h4>
                          <Badge className={dept.readiness_score >= 70 ? 'bg-green-600' : dept.readiness_score >= 50 ? 'bg-yellow-600' : 'bg-red-600'}>
                            {dept.readiness_score}%
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{dept.gap_count} skill gaps identified</p>
                        <Progress value={dept.readiness_score} className="h-2 mb-2" />
                        {dept.priority_skills?.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {dept.priority_skills.map((skill, j) => (
                              <Badge key={j} variant="outline" className="text-xs border-purple-600 text-purple-400">{skill}</Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="predictive">
              <PredictiveSkillModeling
                skills={skills}
                userSkills={userSkills}
                roleRequirements={roleRequirements}
                employees={employees}
                latestAudit={latestAudit}
                learningJourneys={learningJourneys}
              />
            </TabsContent>
          </Tabs>

          {/* Industry Alignment */}
          {latestAudit.industry_trend_alignment && (
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-cyan-400" />
                  Industry Trend Alignment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-cyan-900/20 border border-cyan-800 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">Alignment Score</p>
                    <p className="text-3xl font-bold text-cyan-400">{latestAudit.industry_trend_alignment.alignment_score}%</p>
                    <Progress value={latestAudit.industry_trend_alignment.alignment_score} className="mt-2 h-2" />
                  </div>
                  <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                    <p className="text-gray-400 text-sm mb-2">Trending Skills Present</p>
                    <div className="flex flex-wrap gap-1">
                      {latestAudit.industry_trend_alignment.trending_skills_present?.map((s, i) => (
                        <Badge key={i} className="bg-green-600 text-xs">{s}</Badge>
                      ))}
                    </div>
                  </div>
                  <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                    <p className="text-gray-400 text-sm mb-2">Trending Skills Missing</p>
                    <div className="flex flex-wrap gap-1">
                      {latestAudit.industry_trend_alignment.trending_skills_missing?.map((s, i) => (
                        <Badge key={i} className="bg-red-600 text-xs">{s}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mt-4 p-3 bg-gray-800 rounded">
                  {latestAudit.industry_trend_alignment.industry_benchmark}
                </p>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}