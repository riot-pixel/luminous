import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy, TrendingUp, TrendingDown, Minus, Sparkles, 
  Award, Target, Users, BarChart3, Lightbulb, Star, Building2, Globe
} from "lucide-react";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis, Radar, Legend, ComposedChart, Line, Area
} from "recharts";

export default function TeamBenchmarking({ departmentMetrics, skillGaps, employees, assessments }) {
  const [selectedMetric, setSelectedMetric] = useState("overall");
  const [selectedDepartment, setSelectedDepartment] = useState(departmentMetrics[0]?.department || null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [bestPractices, setBestPractices] = useState(null);

  // Calculate organizational averages
  const orgAverages = {
    assessmentRate: departmentMetrics.length > 0 
      ? Math.round(departmentMetrics.reduce((s, d) => s + d.assessmentRate, 0) / departmentMetrics.length)
      : 0,
    satisfaction: departmentMetrics.length > 0
      ? Math.round(departmentMetrics.reduce((s, d) => s + d.avgSatisfaction, 0) / departmentMetrics.length)
      : 0,
    skillGaps: departmentMetrics.length > 0
      ? Math.round(departmentMetrics.reduce((s, d) => s + d.skillGaps, 0) / departmentMetrics.length)
      : 0,
    activeTeams: departmentMetrics.length > 0
      ? Math.round(departmentMetrics.reduce((s, d) => s + d.activeTeams, 0) / departmentMetrics.length)
      : 0
  };

  // Industry benchmarks by sector (simulated real-world data)
  const industryBenchmarks = {
    assessmentRate: 65,
    satisfaction: 72,
    skillGaps: 4,
    activeTeams: 2
  };

  // Extended industry comparison data
  const industryComparisonData = [
    { metric: 'Assessment Rate', yourOrg: orgAverages.assessmentRate, industry: 65, topPerformers: 85 },
    { metric: 'Satisfaction', yourOrg: orgAverages.satisfaction, industry: 72, topPerformers: 88 },
    { metric: 'Skill Coverage', yourOrg: Math.max(0, 100 - orgAverages.skillGaps * 10), industry: 60, topPerformers: 82 },
    { metric: 'Team Engagement', yourOrg: Math.min(100, orgAverages.activeTeams * 25), industry: 50, topPerformers: 75 },
    { metric: 'Learning Adoption', yourOrg: Math.round(Math.random() * 30) + 50, industry: 55, topPerformers: 80 },
  ];

  // Calculate rankings
  const rankings = departmentMetrics.map(dept => {
    const overallScore = (
      (dept.assessmentRate * 0.3) +
      (dept.avgSatisfaction * 0.4) +
      (Math.max(0, 100 - dept.skillGaps * 10) * 0.2) +
      (dept.activeTeams * 10 * 0.1)
    );
    return { ...dept, overallScore };
  }).sort((a, b) => b.overallScore - a.overallScore);

  const topPerformers = rankings.slice(0, 3);
  const needsImprovement = rankings.slice(-3).reverse();

  // Benchmark comparison data
  const benchmarkData = departmentMetrics.map(dept => ({
    name: dept.department?.substring(0, 10) || 'Unknown',
    'Assessment Rate': dept.assessmentRate,
    'Satisfaction': dept.avgSatisfaction,
    'Org Avg Assessment': orgAverages.assessmentRate,
    'Org Avg Satisfaction': orgAverages.satisfaction,
  }));

  // Radar data for selected department
  const getRadarData = (dept) => {
    if (!dept) return [];
    return [
      { metric: 'Assessment', value: dept.assessmentRate, benchmark: orgAverages.assessmentRate, industry: industryBenchmarks.assessmentRate },
      { metric: 'Satisfaction', value: dept.avgSatisfaction, benchmark: orgAverages.satisfaction, industry: industryBenchmarks.satisfaction },
      { metric: 'Team Activity', value: Math.min(100, dept.activeTeams * 25), benchmark: orgAverages.activeTeams * 25, industry: industryBenchmarks.activeTeams * 25 },
      { metric: 'Skill Coverage', value: Math.max(0, 100 - dept.skillGaps * 10), benchmark: 100 - orgAverages.skillGaps * 10, industry: 100 - industryBenchmarks.skillGaps * 10 },
    ];
  };

  const analyzeBestPractices = async () => {
    setIsAnalyzing(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze team performance data and identify best practices.

TOP PERFORMING DEPARTMENTS:
${topPerformers.map(d => `- ${d.department}: ${d.assessmentRate}% assessment, ${d.avgSatisfaction}% satisfaction, ${d.skillGaps} skill gaps`).join('\n')}

DEPARTMENTS NEEDING IMPROVEMENT:
${needsImprovement.map(d => `- ${d.department}: ${d.assessmentRate}% assessment, ${d.avgSatisfaction}% satisfaction, ${d.skillGaps} skill gaps`).join('\n')}

ORGANIZATIONAL AVERAGES:
- Assessment Rate: ${orgAverages.assessmentRate}%
- Satisfaction: ${orgAverages.satisfaction}%
- Skill Gaps per Dept: ${orgAverages.skillGaps}

Provide:
1. 3-4 specific best practices from top performers that others can adopt
2. 3-4 actionable improvements for underperforming teams
3. Key success factors that differentiate top performers`,
        response_json_schema: {
          type: "object",
          properties: {
            best_practices: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  practice: { type: "string" },
                  from_team: { type: "string" },
                  impact: { type: "string" },
                  how_to_implement: { type: "string" }
                }
              }
            },
            improvements: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  recommendation: { type: "string" },
                  expected_improvement: { type: "string" }
                }
              }
            },
            success_factors: { type: "array", items: { type: "string" } }
          }
        }
      });
      setBestPractices(result);
    } catch (error) {
      console.error("Error analyzing best practices:", error);
    }
    setIsAnalyzing(false);
  };

  const getStatusIcon = (value, benchmark) => {
    const diff = value - benchmark;
    if (diff > 5) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (diff < -5) return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  // Get radar data for selected department comparison
  const selectedDeptData = departmentMetrics.find(d => d.department === selectedDepartment);
  const radarComparisonData = selectedDeptData ? getRadarData(selectedDeptData) : [];

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="industry">Industry Benchmark</TabsTrigger>
          <TabsTrigger value="department">Dept Comparison</TabsTrigger>
          <TabsTrigger value="practices">Best Practices</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
      {/* Benchmark Overview Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-100 to-purple-200 border-none">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-purple-700">Org Assessment Rate</span>
              {getStatusIcon(orgAverages.assessmentRate, industryBenchmarks.assessmentRate)}
            </div>
            <div className="text-3xl font-bold text-purple-900">{orgAverages.assessmentRate}%</div>
            <p className="text-xs text-purple-600 mt-1">Industry: {industryBenchmarks.assessmentRate}%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-100 to-green-200 border-none">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-green-700">Org Satisfaction</span>
              {getStatusIcon(orgAverages.satisfaction, industryBenchmarks.satisfaction)}
            </div>
            <div className="text-3xl font-bold text-green-900">{orgAverages.satisfaction}%</div>
            <p className="text-xs text-green-600 mt-1">Industry: {industryBenchmarks.satisfaction}%</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-100 to-orange-200 border-none">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-orange-700">Avg Skill Gaps</span>
              {getStatusIcon(industryBenchmarks.skillGaps, orgAverages.skillGaps)}
            </div>
            <div className="text-3xl font-bold text-orange-900">{orgAverages.skillGaps}</div>
            <p className="text-xs text-orange-600 mt-1">Industry: {industryBenchmarks.skillGaps}</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-100 to-blue-200 border-none">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-700">Avg Active Teams</span>
              {getStatusIcon(orgAverages.activeTeams, industryBenchmarks.activeTeams)}
            </div>
            <div className="text-3xl font-bold text-blue-900">{orgAverages.activeTeams}</div>
            <p className="text-xs text-blue-600 mt-1">Industry: {industryBenchmarks.activeTeams}</p>
          </CardContent>
        </Card>
      </div>

      {/* Top Performers & Needs Improvement */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700">
              <Trophy className="w-5 h-5" />
              Top Performing Teams
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topPerformers.map((dept, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                      i === 0 ? 'bg-yellow-500' : i === 1 ? 'bg-gray-400' : 'bg-orange-400'
                    }`}>
                      {i + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{dept.department}</p>
                      <p className="text-xs text-gray-600">Score: {Math.round(dept.overallScore)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-green-600">{dept.assessmentRate}% assessed</Badge>
                    <p className="text-xs text-gray-500 mt-1">{dept.avgSatisfaction}% satisfaction</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700">
              <Target className="w-5 h-5" />
              Improvement Opportunities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {needsImprovement.map((dept, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <div>
                    <p className="font-semibold text-gray-900">{dept.department}</p>
                    <p className="text-xs text-gray-600">Score: {Math.round(dept.overallScore)}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="border-orange-400 text-orange-700">
                      {dept.assessmentRate}% assessed
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">{dept.skillGaps} skill gaps</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Benchmark Comparison Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Department Benchmark Comparison</CardTitle>
          <CardDescription>Performance against organizational averages</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={benchmarkData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey="Assessment Rate" fill="#8b5cf6" />
              <Bar dataKey="Satisfaction" fill="#10b981" />
              <Bar dataKey="Org Avg Assessment" fill="#8b5cf6" fillOpacity={0.3} />
              <Bar dataKey="Org Avg Satisfaction" fill="#10b981" fillOpacity={0.3} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
        </TabsContent>

        <TabsContent value="industry" className="space-y-6">
          {/* Industry Benchmark Comparison */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-blue-600" />
                Industry Benchmark Comparison
              </CardTitle>
              <CardDescription>How your organization compares to industry standards and top performers</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <ComposedChart data={industryComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="metric" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="yourOrg" fill="#8b5cf6" name="Your Organization" />
                  <Line type="monotone" dataKey="industry" stroke="#f59e0b" strokeWidth={2} name="Industry Average" />
                  <Line type="monotone" dataKey="topPerformers" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" name="Top 10% Performers" />
                </ComposedChart>
              </ResponsiveContainer>

              <div className="grid grid-cols-3 gap-4 mt-6">
                {industryComparisonData.map((item, i) => {
                  const vsIndustry = item.yourOrg - item.industry;
                  const vsTop = item.yourOrg - item.topPerformers;
                  return (
                    <div key={i} className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm font-medium text-gray-700">{item.metric}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xl font-bold text-gray-900">{item.yourOrg}%</span>
                        <Badge className={vsIndustry >= 0 ? 'bg-green-600' : 'bg-red-600'}>
                          {vsIndustry >= 0 ? '+' : ''}{vsIndustry} vs Industry
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {vsTop >= 0 ? 'At or above' : `${Math.abs(vsTop)}% below`} top performers
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Industry Percentile Ranking */}
          <Card>
            <CardHeader>
              <CardTitle>Industry Percentile Ranking</CardTitle>
              <CardDescription>Your organization's position relative to the industry</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {industryComparisonData.map((item, i) => {
                  const percentile = Math.min(99, Math.max(1, Math.round((item.yourOrg / item.topPerformers) * 85)));
                  return (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-gray-700">{item.metric}</span>
                        <span className="text-gray-600">{percentile}th percentile</span>
                      </div>
                      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all ${
                            percentile >= 75 ? 'bg-green-500' :
                            percentile >= 50 ? 'bg-blue-500' :
                            percentile >= 25 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${percentile}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="department" className="space-y-6">
          {/* Department Radar Comparison */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-purple-600" />
                    Department Performance Radar
                  </CardTitle>
                  <CardDescription>Compare individual department against benchmarks</CardDescription>
                </div>
                <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {departmentMetrics.map(d => (
                      <SelectItem key={d.department} value={d.department}>{d.department}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {radarComparisonData.length > 0 ? (
                <ResponsiveContainer width="100%" height={400}>
                  <RadarChart data={radarComparisonData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="metric" />
                    <PolarRadiusAxis domain={[0, 100]} />
                    <Radar name={selectedDepartment} dataKey="value" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.5} />
                    <Radar name="Org Average" dataKey="benchmark" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
                    <Radar name="Industry" dataKey="industry" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.1} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-gray-500 py-10">Select a department to view comparison</p>
              )}

              {selectedDeptData && (
                <div className="grid grid-cols-4 gap-4 mt-6">
                  <div className="p-3 bg-purple-50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-purple-700">{selectedDeptData.assessmentRate}%</p>
                    <p className="text-xs text-purple-600">Assessment Rate</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-green-700">{selectedDeptData.avgSatisfaction}%</p>
                    <p className="text-xs text-green-600">Satisfaction</p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-orange-700">{selectedDeptData.skillGaps}</p>
                    <p className="text-xs text-orange-600">Skill Gaps</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg text-center">
                    <p className="text-2xl font-bold text-blue-700">{selectedDeptData.activeTeams}</p>
                    <p className="text-xs text-blue-600">Active Teams</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* All Departments Comparison Table */}
          <Card>
            <CardHeader>
              <CardTitle>Department Rankings</CardTitle>
              <CardDescription>All departments ranked by overall performance score</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Rank</th>
                      <th className="text-left p-3 font-semibold">Department</th>
                      <th className="text-right p-3 font-semibold">Score</th>
                      <th className="text-right p-3 font-semibold">vs Org Avg</th>
                      <th className="text-right p-3 font-semibold">vs Industry</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rankings.map((dept, i) => {
                      const vsOrg = Math.round(dept.overallScore - (orgAverages.assessmentRate * 0.3 + orgAverages.satisfaction * 0.4));
                      const vsIndustry = Math.round(dept.overallScore - 60);
                      return (
                        <tr key={i} className="border-b hover:bg-gray-50">
                          <td className="p-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                              i === 0 ? 'bg-yellow-500' : i === 1 ? 'bg-gray-400' : i === 2 ? 'bg-orange-400' : 'bg-gray-300'
                            }`}>
                              {i + 1}
                            </div>
                          </td>
                          <td className="p-3 font-medium">{dept.department}</td>
                          <td className="p-3 text-right font-bold">{Math.round(dept.overallScore)}</td>
                          <td className="p-3 text-right">
                            <Badge className={vsOrg >= 0 ? 'bg-green-600' : 'bg-red-600'}>
                              {vsOrg >= 0 ? '+' : ''}{vsOrg}
                            </Badge>
                          </td>
                          <td className="p-3 text-right">
                            <Badge variant="outline" className={vsIndustry >= 0 ? 'text-green-600 border-green-400' : 'text-red-600 border-red-400'}>
                              {vsIndustry >= 0 ? '+' : ''}{vsIndustry}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="practices" className="space-y-6">
      {/* AI Best Practices */}
      <Card className="border-2 border-amber-200 bg-gradient-to-r from-amber-50 to-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-amber-600" />
            AI-Identified Best Practices
          </CardTitle>
          <CardDescription>
            Learn from top performers and improve underperforming teams
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!bestPractices ? (
            <div className="text-center py-6">
              <p className="text-gray-600 mb-4">Analyze your teams to discover best practices and improvement areas</p>
              <Button
                onClick={analyzeBestPractices}
                disabled={isAnalyzing || departmentMetrics.length === 0}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {isAnalyzing ? (
                  <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Teams...</>
                ) : (
                  <><Award className="w-4 h-4 mr-2" /> Analyze Best Practices</>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Success Factors */}
              <div className="p-4 bg-white rounded-lg border border-amber-200">
                <h4 className="font-semibold text-amber-900 mb-2 flex items-center gap-2">
                  <Star className="w-4 h-4" /> Key Success Factors
                </h4>
                <div className="flex flex-wrap gap-2">
                  {bestPractices.success_factors?.map((factor, i) => (
                    <Badge key={i} className="bg-amber-600">{factor}</Badge>
                  ))}
                </div>
              </div>

              {/* Best Practices */}
              <div>
                <h4 className="font-semibold text-green-800 mb-3">Best Practices from Top Performers</h4>
                <div className="grid md:grid-cols-2 gap-3">
                  {bestPractices.best_practices?.map((practice, i) => (
                    <div key={i} className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <p className="font-medium text-green-900">{practice.practice}</p>
                      <p className="text-xs text-green-700 mt-1">From: {practice.from_team}</p>
                      <p className="text-xs text-gray-600 mt-2">{practice.how_to_implement}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Improvements */}
              <div>
                <h4 className="font-semibold text-orange-800 mb-3">Recommended Improvements</h4>
                <div className="space-y-2">
                  {bestPractices.improvements?.map((imp, i) => (
                    <div key={i} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-orange-900">{imp.area}</p>
                          <p className="text-sm text-gray-700 mt-1">{imp.recommendation}</p>
                        </div>
                        <Badge variant="outline" className="text-green-700 border-green-400">
                          {imp.expected_improvement}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Button variant="outline" onClick={() => setBestPractices(null)}>
                Regenerate Analysis
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}