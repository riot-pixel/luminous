import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, Brain, Sparkles, Target, Users, AlertTriangle,
  Lightbulb, BarChart3, Clock, Zap, GraduationCap, Building2,
  ArrowUpRight, ArrowDownRight, Minus
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts";

export default function SkillForecastingModule({ 
  skills, 
  userSkills, 
  roleRequirements, 
  employees, 
  teams,
  assessments 
}) {
  const [isForecasting, setIsForecasting] = useState(false);
  const [forecast, setForecast] = useState(null);
  const [timeHorizon, setTimeHorizon] = useState('6m');

  const generateForecast = async () => {
    setIsForecasting(true);
    try {
      // Calculate current skill distribution
      const skillCounts = userSkills.reduce((acc, us) => {
        acc[us.skill_name] = (acc[us.skill_name] || 0) + 1;
        return acc;
      }, {});

      // Calculate skill gaps by role
      const gapsByRole = {};
      employees.forEach(emp => {
        const empSkills = userSkills.filter(us => us.user_email === emp.email);
        const reqs = roleRequirements.filter(rr => rr.role_title === emp.job_title);
        reqs.forEach(req => {
          const has = empSkills.find(s => s.skill_id === req.skill_id);
          if (!has || ['Beginner'].includes(has.current_proficiency)) {
            const key = `${emp.job_title}|${req.skill_name}`;
            gapsByRole[key] = (gapsByRole[key] || 0) + 1;
          }
        });
      });

      // Get departments and team info
      const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];
      const activeTeams = teams.filter(t => t.status === 'active');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an organizational workforce planning expert and skill forecasting specialist.

Analyze this data and forecast future skill needs for the next ${timeHorizon === '6m' ? '6 months' : timeHorizon === '1y' ? '1 year' : '2 years'}:

CURRENT SKILL DISTRIBUTION:
${Object.entries(skillCounts).slice(0, 20).map(([skill, count]) => `- ${skill}: ${count} employees`).join('\n')}

CURRENT SKILL GAPS BY ROLE:
${Object.entries(gapsByRole).slice(0, 15).map(([key, count]) => `- ${key}: ${count} gaps`).join('\n')}

ORGANIZATION PROFILE:
- Total Employees: ${employees.length}
- Departments: ${departments.join(', ')}
- Active Teams: ${activeTeams.length}
- Recent Assessment Count: ${assessments.length}

AVAILABLE ROLES:
${[...new Set(roleRequirements.map(r => r.role_title))].join(', ')}

Based on:
1. Current skill gaps and their severity
2. Industry trends in technology and business
3. Typical organizational growth patterns
4. The roles and departments present

Provide:
1. Skills projected to be in HIGH DEMAND (with demand growth %)
2. Skills at risk of becoming OBSOLETE
3. EMERGING skills the org should invest in
4. Department-specific skill forecasts
5. Recommendations for training programs
6. Recruitment priorities
7. Risk assessment for skill shortages`,
        response_json_schema: {
          type: "object",
          properties: {
            forecast_summary: {
              type: "object",
              properties: {
                overall_readiness: { type: "number" },
                risk_level: { type: "string" },
                key_insight: { type: "string" },
                confidence_score: { type: "number" }
              }
            },
            high_demand_skills: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  current_coverage: { type: "string" },
                  projected_demand: { type: "string" },
                  demand_growth: { type: "number" },
                  urgency: { type: "string" },
                  reason: { type: "string" },
                  affected_roles: { type: "array", items: { type: "string" } }
                }
              }
            },
            declining_skills: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  current_investment: { type: "string" },
                  decline_rate: { type: "number" },
                  replacement_skills: { type: "array", items: { type: "string" } },
                  recommendation: { type: "string" }
                }
              }
            },
            emerging_skills: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  category: { type: "string" },
                  relevance_score: { type: "number" },
                  adoption_timeline: { type: "string" },
                  why_important: { type: "string" },
                  learning_path_suggestion: { type: "string" }
                }
              }
            },
            department_forecasts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  department: { type: "string" },
                  priority_skills: { type: "array", items: { type: "string" } },
                  skill_gap_risk: { type: "string" },
                  recommended_hires: { type: "number" },
                  training_budget_suggestion: { type: "string" }
                }
              }
            },
            training_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  program_name: { type: "string" },
                  target_skills: { type: "array", items: { type: "string" } },
                  target_audience: { type: "string" },
                  duration: { type: "string" },
                  priority: { type: "string" },
                  expected_roi: { type: "string" },
                  implementation_steps: { type: "array", items: { type: "string" } }
                }
              }
            },
            recruitment_priorities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  role: { type: "string" },
                  key_skills_needed: { type: "array", items: { type: "string" } },
                  urgency: { type: "string" },
                  market_availability: { type: "string" },
                  salary_range_insight: { type: "string" }
                }
              }
            },
            risk_assessment: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  severity: { type: "string" },
                  likelihood: { type: "string" },
                  affected_areas: { type: "array", items: { type: "string" } },
                  mitigation_strategy: { type: "string" }
                }
              }
            },
            quarterly_milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  quarter: { type: "string" },
                  focus_areas: { type: "array", items: { type: "string" } },
                  target_metrics: { type: "array", items: { type: "string" } }
                }
              }
            }
          }
        }
      });

      setForecast(result);
    } catch (error) {
      console.error("Error generating forecast:", error);
    }
    setIsForecasting(false);
  };

  const getTrendIcon = (growth) => {
    if (growth > 10) return <ArrowUpRight className="w-4 h-4 text-emerald-400" />;
    if (growth < -10) return <ArrowDownRight className="w-4 h-4 text-red-400" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  if (!forecast) {
    return (
      <Card className="border-2 border-blue-500/20 bg-gradient-to-r from-blue-500/10 to-indigo-500/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-400" />
            AI Skill Demand Forecasting
          </CardTitle>
          <CardDescription>
            Predict future skill needs based on current gaps, industry trends, and organizational growth
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-sm text-gray-400">Forecast Horizon:</span>
            <div className="flex gap-2">
              {[
                { value: '6m', label: '6 Months' },
                { value: '1y', label: '1 Year' },
                { value: '2y', label: '2 Years' },
              ].map(opt => (
                <Button
                  key={opt.value}
                  variant={timeHorizon === opt.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTimeHorizon(opt.value)}
                  className={timeHorizon === opt.value ? 'bg-blue-600' : 'border-gray-600 text-gray-400'}
                >
                  {opt.label}
                </Button>
              ))}
            </div>
          </div>
          <Button
            onClick={generateForecast}
            disabled={isForecasting}
            className="w-full bg-blue-600 hover:bg-blue-500"
          >
            {isForecasting ? (
              <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Analyzing Trends...</>
            ) : (
              <><Brain className="w-4 h-4 mr-2" /> Generate Skill Forecast</>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Forecast Summary */}
      <Card className="border-2 border-blue-500/20 bg-gradient-to-r from-blue-500/10 to-indigo-500/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <TrendingUp className="w-6 h-6 text-blue-400" />
            Skill Demand Forecast
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <div className="p-4 bg-white/5 rounded-xl text-center">
              <p className="text-3xl font-light text-blue-400">{forecast.forecast_summary?.overall_readiness}%</p>
              <p className="text-xs text-gray-500">Readiness Score</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl text-center">
              <Badge className={`text-sm ${
                forecast.forecast_summary?.risk_level === 'high' ? 'bg-red-500' :
                forecast.forecast_summary?.risk_level === 'medium' ? 'bg-amber-500' : 'bg-emerald-500'
              }`}>{forecast.forecast_summary?.risk_level}</Badge>
              <p className="text-xs text-gray-500 mt-1">Risk Level</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl text-center">
              <p className="text-3xl font-light text-purple-400">{forecast.forecast_summary?.confidence_score}%</p>
              <p className="text-xs text-gray-500">Confidence</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl">
              <p className="text-sm text-gray-300">{forecast.forecast_summary?.key_insight}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="demand" className="space-y-6">
        <TabsList className="bg-white/5">
          <TabsTrigger value="demand">High Demand</TabsTrigger>
          <TabsTrigger value="emerging">Emerging</TabsTrigger>
          <TabsTrigger value="declining">Declining</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="recruitment">Recruitment</TabsTrigger>
          <TabsTrigger value="risks">Risks</TabsTrigger>
        </TabsList>

        <TabsContent value="demand">
          <Card className="border border-emerald-500/20 bg-emerald-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emerald-400">
                <Zap className="w-5 h-5" />
                High Demand Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {forecast.high_demand_skills?.map((skill, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="text-white font-medium">{skill.skill}</h4>
                        <p className="text-xs text-gray-500">{skill.reason}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {getTrendIcon(skill.demand_growth)}
                        <span className={`text-sm font-bold ${skill.demand_growth > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {skill.demand_growth > 0 ? '+' : ''}{skill.demand_growth}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                      <span className="text-gray-400">Current: {skill.current_coverage}</span>
                      <span className="text-gray-400">Projected: {skill.projected_demand}</span>
                      <Badge className={`${
                        skill.urgency === 'critical' ? 'bg-red-500' :
                        skill.urgency === 'high' ? 'bg-amber-500' : 'bg-blue-500'
                      }`}>{skill.urgency}</Badge>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {skill.affected_roles?.map((role, j) => (
                        <Badge key={j} variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-400">{role}</Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="emerging">
          <Card className="border border-purple-500/20 bg-purple-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Lightbulb className="w-5 h-5" />
                Emerging Skills to Invest In
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {forecast.emerging_skills?.map((skill, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{skill.skill}</h4>
                      <Badge className="bg-purple-500/20 text-purple-400 border-none">{skill.category}</Badge>
                    </div>
                    <p className="text-xs text-gray-400 mb-3">{skill.why_important}</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Relevance</span>
                        <span className="text-purple-400">{skill.relevance_score}/100</span>
                      </div>
                      <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-500 rounded-full" style={{ width: `${skill.relevance_score}%` }} />
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      <Clock className="w-3 h-3 inline mr-1" />
                      Adopt by: {skill.adoption_timeline}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="declining">
          <Card className="border border-amber-500/20 bg-amber-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-400">
                <AlertTriangle className="w-5 h-5" />
                Declining Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {forecast.declining_skills?.map((skill, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{skill.skill}</h4>
                      <span className="text-red-400 text-sm">{skill.decline_rate}% decline</span>
                    </div>
                    <p className="text-xs text-gray-400 mb-2">{skill.recommendation}</p>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Replace with:</p>
                      <div className="flex flex-wrap gap-1">
                        {skill.replacement_skills?.map((rep, j) => (
                          <Badge key={j} className="bg-emerald-500/20 text-emerald-400 border-none text-xs">{rep}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training">
          <Card className="border border-blue-500/20 bg-blue-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-400">
                <GraduationCap className="w-5 h-5" />
                Recommended Training Programs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {forecast.training_recommendations?.map((prog, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{prog.program_name}</h4>
                      <Badge className={`${
                        prog.priority === 'critical' ? 'bg-red-500' :
                        prog.priority === 'high' ? 'bg-amber-500' : 'bg-blue-500'
                      }`}>{prog.priority}</Badge>
                    </div>
                    <div className="flex gap-4 text-xs text-gray-400 mb-3">
                      <span>{prog.target_audience}</span>
                      <span>•</span>
                      <span>{prog.duration}</span>
                      <span>•</span>
                      <span className="text-emerald-400">ROI: {prog.expected_roi}</span>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {prog.target_skills?.map((skill, j) => (
                        <Badge key={j} variant="outline" className="text-xs border-blue-500/30 text-blue-400">{skill}</Badge>
                      ))}
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Implementation:</p>
                      <ul className="space-y-1">
                        {prog.implementation_steps?.slice(0, 3).map((step, j) => (
                          <li key={j} className="text-xs text-gray-400">{j + 1}. {step}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recruitment">
          <Card className="border border-indigo-500/20 bg-indigo-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-400">
                <Users className="w-5 h-5" />
                Recruitment Priorities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {forecast.recruitment_priorities?.map((rec, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{rec.role}</h4>
                      <Badge className={`${
                        rec.urgency === 'immediate' ? 'bg-red-500' :
                        rec.urgency === 'high' ? 'bg-amber-500' : 'bg-blue-500'
                      }`}>{rec.urgency}</Badge>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {rec.key_skills_needed?.map((skill, j) => (
                        <Badge key={j} variant="outline" className="text-xs border-indigo-500/30 text-indigo-400">{skill}</Badge>
                      ))}
                    </div>
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>Market: {rec.market_availability}</span>
                      <span>{rec.salary_range_insight}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risks">
          <Card className="border border-red-500/20 bg-red-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-400">
                <AlertTriangle className="w-5 h-5" />
                Risk Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {forecast.risk_assessment?.map((risk, i) => (
                  <div key={i} className="p-4 bg-white/5 rounded-xl">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{risk.risk}</h4>
                      <div className="flex gap-2">
                        <Badge className={`${
                          risk.severity === 'high' ? 'bg-red-500' :
                          risk.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                        }`}>{risk.severity}</Badge>
                        <Badge variant="outline" className="border-white/20 text-gray-400">{risk.likelihood}</Badge>
                      </div>
                    </div>
                    <p className="text-xs text-gray-400 mb-2">{risk.mitigation_strategy}</p>
                    <div className="flex flex-wrap gap-1">
                      {risk.affected_areas?.map((area, j) => (
                        <Badge key={j} variant="outline" className="text-[10px] border-red-500/30 text-red-400">{area}</Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Quarterly Milestones */}
      {forecast.quarterly_milestones?.length > 0 && (
        <Card className="border border-white/10 bg-white/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-400" />
              Quarterly Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              {forecast.quarterly_milestones.map((q, i) => (
                <div key={i} className="p-4 bg-white/5 rounded-xl">
                  <h4 className="text-white font-medium mb-2">{q.quarter}</h4>
                  <div className="space-y-2">
                    {q.focus_areas?.map((focus, j) => (
                      <p key={j} className="text-xs text-gray-400">• {focus}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="text-center">
        <Button variant="outline" onClick={() => setForecast(null)} className="border-white/20 text-gray-400">
          Regenerate Forecast
        </Button>
      </div>
    </div>
  );
}