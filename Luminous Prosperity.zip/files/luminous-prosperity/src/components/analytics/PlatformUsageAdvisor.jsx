import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Brain, Sparkles, TrendingUp, TrendingDown, Eye, Clock, Users,
  Lightbulb, BarChart3, RefreshCw, Star, AlertTriangle, Zap,
  ArrowUpRight, ArrowDownRight, Target, CheckCircle2
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

// Simulated feature tracking (in production, this would come from actual analytics)
const PLATFORM_FEATURES = [
  { name: "Assessment", path: "/assessment", category: "Core" },
  { name: "Quick Assessment", path: "/quick-assessment", category: "Core" },
  { name: "Career Paths", path: "/career-paths", category: "Development" },
  { name: "AI Learning Journeys", path: "/ai-learning-journeys", category: "Learning" },
  { name: "Skill Tracker", path: "/skill-tracker", category: "Skills" },
  { name: "Ecosystem Network", path: "/ecosystem-network", category: "Collaboration" },
  { name: "Wellness Companion", path: "/wellness-companion", category: "Wellbeing" },
  { name: "Report Generator", path: "/report-generator", category: "Analytics" },
  { name: "Team Collaboration Hub", path: "/team-collaboration", category: "Collaboration" },
  { name: "Executive Portal", path: "/executive-portal", category: "Leadership" },
  { name: "Custom Report Builder", path: "/custom-report-builder", category: "Analytics" },
  { name: "Knowledge Synthesis", path: "/knowledge-synthesis", category: "AI" },
  { name: "Coaching Journey", path: "/coaching-journey", category: "Development" },
  { name: "Impact Ledger", path: "/holistic-impact", category: "Engagement" }
];

export default function PlatformUsageAdvisor({ users, assessments, reports, learningJourneys }) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);

  const { data: previousAnalyses } = useQuery({
    queryKey: ['platformUsageAnalytics'],
    queryFn: () => base44.entities.PlatformUsageAnalytics.list('-analysis_date', 5),
    initialData: [],
  });

  const createAnalysisMutation = useMutation({
    mutationFn: (data) => base44.entities.PlatformUsageAnalytics.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['platformUsageAnalytics'] }),
  });

  // Simulate usage data based on entity counts
  const simulateUsageData = () => {
    return PLATFORM_FEATURES.map(feature => {
      // Base usage simulation
      let baseUsage = Math.floor(Math.random() * 100) + 10;
      let uniqueUsers = Math.floor(baseUsage * 0.7);
      let avgTime = Math.floor(Math.random() * 300) + 60;
      
      // Adjust based on actual data where available
      if (feature.category === "Core" && assessments?.length > 0) {
        baseUsage = assessments.length * 2;
        uniqueUsers = [...new Set(assessments.map(a => a.user_email))].length;
      }
      if (feature.category === "Learning" && learningJourneys?.length > 0) {
        baseUsage = learningJourneys.length * 3;
        uniqueUsers = [...new Set(learningJourneys.map(j => j.user_email))].length;
      }
      if (feature.category === "Analytics" && reports?.length > 0) {
        baseUsage = reports.length;
      }

      return {
        feature_name: feature.name,
        page_path: feature.path,
        category: feature.category,
        usage_count: baseUsage,
        unique_users: Math.min(uniqueUsers, users?.length || 10),
        avg_time_spent_seconds: avgTime,
        trend: Math.random() > 0.5 ? "up" : Math.random() > 0.3 ? "stable" : "down",
        growth_rate: Math.floor(Math.random() * 40) - 10
      };
    });
  };

  const runUsageAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const usageData = simulateUsageData();
      const sortedByUsage = [...usageData].sort((a, b) => b.usage_count - a.usage_count);
      const popular = sortedByUsage.slice(0, 5);
      const underutilized = sortedByUsage.slice(-5).reverse();

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a product analytics expert analyzing platform usage data to provide actionable insights.

PLATFORM OVERVIEW:
- Total Users: ${users?.length || 0}
- Total Assessments: ${assessments?.length || 0}
- Total Reports Generated: ${reports?.length || 0}
- Active Learning Journeys: ${learningJourneys?.length || 0}

FEATURE USAGE DATA:
${usageData.map(f => `- ${f.feature_name} (${f.category}): ${f.usage_count} uses, ${f.unique_users} unique users, ${f.avg_time_spent_seconds}s avg time, trend: ${f.trend} (${f.growth_rate}%)`).join('\n')}

TOP 5 POPULAR FEATURES:
${popular.map(f => `- ${f.feature_name}: ${f.usage_count} uses`).join('\n')}

TOP 5 UNDERUTILIZED FEATURES:
${underutilized.map(f => `- ${f.feature_name}: ${f.usage_count} uses`).join('\n')}

Based on this data, provide:
1. Analysis of underutilized features with promotion strategies
2. Expansion opportunities for popular features
3. UI/UX improvement suggestions
4. New feature recommendations based on usage patterns
5. User journey insights
6. Engagement optimization strategies`,
        response_json_schema: {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            underutilized_features: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  feature_name: { type: "string" },
                  current_usage: { type: "number" },
                  potential_value: { type: "string" },
                  promotion_strategy: { type: "string" },
                  target_audience: { type: "string" }
                }
              }
            },
            popular_features: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  feature_name: { type: "string" },
                  engagement_score: { type: "number" },
                  expansion_opportunities: { type: "array", items: { type: "string" } },
                  user_satisfaction: { type: "string" }
                }
              }
            },
            improvement_suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  suggestion: { type: "string" },
                  category: { type: "string" },
                  impact: { type: "string" },
                  effort: { type: "string" },
                  priority_score: { type: "number" }
                }
              }
            },
            new_feature_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  feature_idea: { type: "string" },
                  based_on: { type: "string" },
                  expected_adoption: { type: "string" },
                  development_complexity: { type: "string" }
                }
              }
            },
            user_journey_insights: {
              type: "object",
              properties: {
                common_paths: { type: "array", items: { type: "string" } },
                drop_off_points: { type: "array", items: { type: "string" } },
                engagement_boosters: { type: "array", items: { type: "string" } }
              }
            },
            engagement_strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  strategy: { type: "string" },
                  target_metric: { type: "string" },
                  expected_improvement: { type: "string" }
                }
              }
            }
          }
        }
      });

      setAnalysis({ ...result, featureUsage: usageData });

      // Save analysis
      await createAnalysisMutation.mutateAsync({
        analysis_date: new Date().toISOString(),
        analysis_period: "weekly",
        total_active_users: users?.length || 0,
        feature_usage: usageData,
        underutilized_features: result.underutilized_features,
        popular_features: result.popular_features,
        ai_improvement_suggestions: result.improvement_suggestions,
        new_feature_recommendations: result.new_feature_recommendations,
        user_journey_insights: result.user_journey_insights,
        report_generation_stats: {
          total_reports: reports?.length || 0,
          avg_reports_per_user: users?.length > 0 ? Math.round((reports?.length || 0) / users.length * 10) / 10 : 0
        }
      });

    } catch (error) {
      console.error("Error analyzing usage:", error);
    }
    setIsAnalyzing(false);
  };

  const latestAnalysis = previousAnalyses?.[0];

  return (
    <div className="space-y-6">
      {/* Analysis Controls */}
      <Card className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 border-cyan-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-cyan-400" />
            AI Platform Usage Advisor
          </CardTitle>
          <CardDescription className="text-gray-400">
            Analyze feature usage, identify improvement opportunities, and get AI-powered recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={runUsageAnalysis} disabled={isAnalyzing} className="bg-cyan-600 hover:bg-cyan-700">
            {isAnalyzing ? (
              <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Analyzing Usage...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" />Analyze Platform Usage</>
            )}
          </Button>
          {latestAnalysis && (
            <p className="text-sm text-gray-400 mt-2">
              Last analysis: {new Date(latestAnalysis.analysis_date).toLocaleDateString()}
            </p>
          )}
        </CardContent>
      </Card>

      {analysis && (
        <>
          {/* Overview */}
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <p className="text-gray-300">{analysis.executive_summary}</p>
            </CardContent>
          </Card>

          {/* Usage Chart */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Feature Usage Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analysis.featureUsage?.slice(0, 10)}>
                  <XAxis dataKey="feature_name" angle={-45} textAnchor="end" height={100} stroke="#666" fontSize={10} />
                  <YAxis stroke="#666" />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151' }} />
                  <Bar dataKey="usage_count" fill="#06b6d4" name="Usage Count" />
                  <Bar dataKey="unique_users" fill="#8b5cf6" name="Unique Users" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Tabs defaultValue="underutilized" className="space-y-4">
            <TabsList className="bg-gray-900 border border-gray-800">
              <TabsTrigger value="underutilized"><TrendingDown className="w-4 h-4 mr-1" />Underutilized</TabsTrigger>
              <TabsTrigger value="popular"><Star className="w-4 h-4 mr-1" />Popular</TabsTrigger>
              <TabsTrigger value="improvements"><Lightbulb className="w-4 h-4 mr-1" />Improvements</TabsTrigger>
              <TabsTrigger value="new-features"><Zap className="w-4 h-4 mr-1" />New Features</TabsTrigger>
              <TabsTrigger value="journey"><Target className="w-4 h-4 mr-1" />User Journey</TabsTrigger>
            </TabsList>

            <TabsContent value="underutilized">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingDown className="w-5 h-5 text-orange-400" />
                    Underutilized Features - Promotion Strategies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.underutilized_features?.map((feature, i) => (
                      <div key={i} className="p-4 bg-orange-900/20 border border-orange-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{feature.feature_name}</h4>
                          <Badge variant="outline" className="border-orange-600 text-orange-400">
                            {feature.current_usage} uses
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">{feature.potential_value}</p>
                        <div className="p-3 bg-gray-800 rounded mb-2">
                          <p className="text-xs text-gray-500 mb-1">Promotion Strategy:</p>
                          <p className="text-cyan-400 text-sm">{feature.promotion_strategy}</p>
                        </div>
                        <Badge className="bg-gray-700 text-xs">Target: {feature.target_audience}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="popular">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-400" />
                    Popular Features - Expansion Opportunities
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.popular_features?.map((feature, i) => (
                      <div key={i} className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{feature.feature_name}</h4>
                          <Badge className="bg-green-600">
                            Score: {feature.engagement_score}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-sm mb-2">Satisfaction: {feature.user_satisfaction}</p>
                        <div>
                          <p className="text-xs text-gray-500 mb-2">Expansion Opportunities:</p>
                          <div className="space-y-1">
                            {feature.expansion_opportunities?.map((opp, j) => (
                              <div key={j} className="flex items-center gap-2 text-sm text-green-400">
                                <ArrowUpRight className="w-3 h-3" />{opp}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="improvements">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-purple-400" />
                    AI-Suggested Improvements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.improvement_suggestions?.sort((a, b) => b.priority_score - a.priority_score).map((sugg, i) => (
                      <div key={i} className="p-4 bg-purple-900/20 border border-purple-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="text-white font-medium">{sugg.suggestion}</h4>
                          <Badge className="bg-purple-600">
                            Priority: {sugg.priority_score}/100
                          </Badge>
                        </div>
                        <div className="flex gap-2 mb-2">
                          <Badge variant="outline" className="text-xs border-gray-600">{sugg.category}</Badge>
                          <Badge variant="outline" className={`text-xs ${sugg.impact === 'high' ? 'border-green-600 text-green-400' : 'border-gray-600'}`}>
                            Impact: {sugg.impact}
                          </Badge>
                          <Badge variant="outline" className={`text-xs ${sugg.effort === 'low' ? 'border-green-600 text-green-400' : 'border-orange-600 text-orange-400'}`}>
                            Effort: {sugg.effort}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="new-features">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    New Feature Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {analysis.new_feature_recommendations?.map((rec, i) => (
                      <div key={i} className="p-4 bg-yellow-900/20 border border-yellow-800 rounded-lg">
                        <h4 className="text-white font-medium mb-2">{rec.feature_idea}</h4>
                        <p className="text-gray-400 text-sm mb-3">{rec.based_on}</p>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="text-xs border-green-600 text-green-400">
                            Adoption: {rec.expected_adoption}
                          </Badge>
                          <Badge variant="outline" className={`text-xs ${
                            rec.development_complexity === 'low' ? 'border-green-600 text-green-400' : 
                            rec.development_complexity === 'medium' ? 'border-yellow-600 text-yellow-400' : 
                            'border-red-600 text-red-400'
                          }`}>
                            Complexity: {rec.development_complexity}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="journey">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-400" />
                    User Journey Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                      <h4 className="text-blue-400 font-medium mb-3 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />Common Paths
                      </h4>
                      <ul className="space-y-2">
                        {analysis.user_journey_insights?.common_paths?.map((path, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                            <span className="text-blue-400">→</span>{path}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
                      <h4 className="text-red-400 font-medium mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />Drop-off Points
                      </h4>
                      <ul className="space-y-2">
                        {analysis.user_journey_insights?.drop_off_points?.map((point, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                            <span className="text-red-400">!</span>{point}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 bg-green-900/20 border border-green-800 rounded-lg">
                      <h4 className="text-green-400 font-medium mb-3 flex items-center gap-2">
                        <Zap className="w-4 h-4" />Engagement Boosters
                      </h4>
                      <ul className="space-y-2">
                        {analysis.user_journey_insights?.engagement_boosters?.map((booster, i) => (
                          <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                            <span className="text-green-400">★</span>{booster}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {analysis.engagement_strategies?.length > 0 && (
                    <div className="mt-6">
                      <h4 className="text-white font-medium mb-3">Recommended Engagement Strategies</h4>
                      <div className="space-y-2">
                        {analysis.engagement_strategies.map((strat, i) => (
                          <div key={i} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                            <span className="text-gray-300">{strat.strategy}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs border-gray-600">{strat.target_metric}</Badge>
                              <Badge className="bg-green-600 text-xs">{strat.expected_improvement}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}