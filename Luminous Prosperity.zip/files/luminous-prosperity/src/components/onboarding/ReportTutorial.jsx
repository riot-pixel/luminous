import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { FileText, ArrowRight, Printer, Download, Eye } from "lucide-react";

export default function ReportTutorial({ isOpen, onClose, user }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const queryClient = useQueryClient();

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const slides = [
    {
      icon: FileText,
      title: "Generate Professional Reports",
      description: "Create beautiful, shareable PDF reports of your assessment results and insights.",
      color: "from-amber-600 to-orange-600",
    },
    {
      icon: Eye,
      title: "Preview Before Download",
      description: "Review your report in the browser first. Make sure it looks perfect before saving.",
      color: "from-blue-600 to-indigo-600",
    },
    {
      icon: Printer,
      title: "Print or Save as PDF",
      description: "Use your browser's print function (Ctrl/Cmd + P) and choose 'Save as PDF' to download your report.",
      color: "from-green-600 to-emerald-600",
    },
    {
      icon: Download,
      title: "Branded for Your Organization",
      description: "Reports include your organization's logo and branding—perfect for sharing with coaches or stakeholders.",
      color: "from-purple-600 to-pink-600",
    },
  ];

  const currentSlideData = slides[currentSlide];
  const Icon = currentSlideData.icon;
  const isLastSlide = currentSlide === slides.length - 1;

  const handleNext = () => {
    if (isLastSlide) {
      handleComplete();
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const handleComplete = async () => {
    await updateUserMutation.mutateAsync({
      tutorials_seen: {
        ...user?.tutorials_seen,
        report_tutorial: true,
      },
    });
    onClose();
  };

  const handleSkip = () => {
    handleComplete();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className={`w-16 h-16 bg-gradient-to-br ${currentSlideData.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
          <DialogTitle className="text-2xl text-center">{currentSlideData.title}</DialogTitle>
          <DialogDescription className="text-center text-base leading-relaxed pt-2">
            {currentSlideData.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Progress Dots */}
          <div className="flex justify-center gap-2">
            {slides.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all ${
                  idx === currentSlide
                    ? 'w-8 bg-amber-600'
                    : 'w-2 bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex-1"
            >
              Skip Tutorial
            </Button>
            <Button
              onClick={handleNext}
              className={`flex-1 bg-gradient-to-r ${currentSlideData.color}`}
            >
              {isLastSlide ? "Got It!" : "Next"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}