import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { 
  X, MessageCircle, ChevronRight, ChevronLeft, Sparkles, 
  BarChart3, Brain, Users, Target, Lightbulb, CheckCircle2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const tourSteps = {
  executive: [
    {
      id: "welcome",
      title: "Welcome to Luminous Prosperity",
      content: "I'm your AI assistant. Let me guide you through the executive features designed for strategic decision-making.",
      icon: Sparkles,
      highlight: null
    },
    {
      id: "analytics",
      title: "Executive Analytics",
      content: "This dashboard provides organization-wide metrics, department performance, and trend analysis. You can filter by department and time range.",
      icon: BarChart3,
      page: "ExecutiveAnalytics",
      highlight: "overview"
    },
    {
      id: "predictions",
      title: "Predictive Insights",
      content: "AI analyzes patterns to predict turnover risks, engagement drops, and skill gaps before they become problems.",
      icon: Brain,
      page: "PredictiveInsights",
      highlight: "predictions"
    },
    {
      id: "benchmarking",
      title: "Team Benchmarking",
      content: "Compare your teams against organizational averages. Identify top performers and discover best practices.",
      icon: Target,
      page: "ExecutiveAnalytics",
      highlight: "benchmarks"
    },
    {
      id: "reports",
      title: "Automated Reports",
      content: "Schedule custom reports delivered to your inbox. Get executive summaries with actionable insights.",
      icon: Users,
      page: "ExecutiveAnalytics",
      highlight: "reports"
    }
  ],
  manager: [
    {
      id: "welcome",
      title: "Welcome, Team Leader",
      content: "Let me show you the tools to understand and develop your team effectively.",
      icon: Sparkles,
      highlight: null
    },
    {
      id: "team_performance",
      title: "Team Performance",
      content: "Track your team's assessment completion, engagement scores, and skill development progress.",
      icon: BarChart3,
      page: "TeamPerformanceDashboard",
      highlight: "metrics"
    },
    {
      id: "collaboration",
      title: "Team Collaboration Hub",
      content: "Build optimal teams, generate AI discussions, and discover team-building activities tailored to your team.",
      icon: Users,
      page: "TeamCollaborationHub",
      highlight: "tools"
    },
    {
      id: "assessments",
      title: "Team Assessments",
      content: "Launch assessment campaigns and view aggregated team insights while respecting individual privacy.",
      icon: Target,
      page: "TeamAssessments",
      highlight: "campaigns"
    }
  ],
  employee: [
    {
      id: "welcome",
      title: "Welcome to Your Growth Journey",
      content: "I'll help you navigate your personal development path.",
      icon: Sparkles,
      highlight: null
    },
    {
      id: "portal",
      title: "Your Portal",
      content: "This is your home base. Access assessments, view results, and track your development.",
      icon: BarChart3,
      page: "EmployeePortal",
      highlight: "actions"
    },
    {
      id: "assessment",
      title: "Take Assessments",
      content: "Start with a Quick Assessment (15 min) or dive deep with a Full Assessment for comprehensive insights.",
      icon: Brain,
      page: "QuickAssessment",
      highlight: "start"
    },
    {
      id: "career",
      title: "Career Paths",
      content: "AI analyzes your profile to suggest personalized career transitions, training, and mentorship opportunities.",
      icon: Target,
      page: "CareerPaths",
      highlight: "paths"
    }
  ]
};

export default function AIOnboardingAssistant({ user, onComplete }) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [isGeneratingTip, setIsGeneratingTip] = useState(false);
  const [personalizedTip, setPersonalizedTip] = useState(null);

  const userRole = user?.user_role || 'employee';
  const steps = tourSteps[userRole] || tourSteps.employee;

  useEffect(() => {
    // Auto-open for new users who haven't seen the tour
    if (user && !user.tutorials_seen?.onboarding_assistant) {
      setTimeout(() => setIsOpen(true), 1500);
    }
  }, [user]);

  const generatePersonalizedTip = async () => {
    setIsGeneratingTip(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a brief, personalized tip for a ${userRole} user named ${user?.full_name || 'there'} 
who is exploring an enterprise intelligence platform. 
Focus on one actionable insight they can implement today.
Keep it to 2 sentences max.`,
      });
      setPersonalizedTip(result);
    } catch (error) {
      console.error("Error generating tip:", error);
    }
    setIsGeneratingTip(false);
  };

  const handleComplete = async () => {
    if (user) {
      await base44.auth.updateMe({
        tutorials_seen: {
          ...(user.tutorials_seen || {}),
          onboarding_assistant: true
        }
      });
    }
    setIsOpen(false);
    onComplete?.();
  };

  const currentStepData = steps[currentStep];
  const StepIcon = currentStepData?.icon || Sparkles;

  if (!isOpen) {
    return (
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-full shadow-lg flex items-center justify-center text-white z-50"
      >
        <MessageCircle className="w-6 h-6" />
      </motion.button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        className="fixed bottom-6 right-6 w-96 bg-white rounded-2xl shadow-2xl z-50 overflow-hidden border border-gray-200"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-4 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              <span className="font-semibold">AI Assistant</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
          {/* Progress */}
          <div className="flex gap-1 mt-3">
            {steps.map((_, i) => (
              <div
                key={i}
                className={`h-1 flex-1 rounded-full transition-colors ${
                  i <= currentStep ? 'bg-white' : 'bg-white/30'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <StepIcon className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-1">{currentStepData?.title}</h3>
              <p className="text-sm text-gray-600">{currentStepData?.content}</p>
            </div>
          </div>

          {/* Personalized Tip */}
          {currentStep === steps.length - 1 && (
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-center gap-2 text-amber-700 text-xs font-medium mb-2">
                <Lightbulb className="w-4 h-4" />
                Personalized Tip
              </div>
              {personalizedTip ? (
                <p className="text-sm text-amber-800">{personalizedTip}</p>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={generatePersonalizedTip}
                  disabled={isGeneratingTip}
                  className="text-amber-700 border-amber-300"
                >
                  {isGeneratingTip ? (
                    <><Sparkles className="w-3 h-3 mr-1 animate-spin" /> Generating...</>
                  ) : (
                    <>Get Your Tip</>
                  )}
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="px-6 pb-6 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
          >
            <ChevronLeft className="w-4 h-4 mr-1" /> Back
          </Button>
          
          {currentStep < steps.length - 1 ? (
            <Button
              size="sm"
              onClick={() => setCurrentStep(currentStep + 1)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Next <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={handleComplete}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-1" /> Complete Tour
            </Button>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}