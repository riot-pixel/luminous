import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowRight, CheckCircle2, Clock, Brain } from "lucide-react";

export default function AssessmentTutorial({ isOpen, onClose, user }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const queryClient = useQueryClient();

  const updateUserMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  const slides = [
    {
      icon: Sparkles,
      title: "Welcome to Your Assessment!",
      description: "This comprehensive assessment will help you understand yourself better and unlock personalized insights.",
      color: "from-purple-600 to-indigo-600",
    },
    {
      icon: Clock,
      title: "It Takes About 15-60 Minutes",
      description: "You can choose between a Quick Assessment (15 min) or Comprehensive Assessment (60 min). Your progress is saved, so you can take breaks.",
      color: "from-blue-600 to-cyan-600",
    },
    {
      icon: Brain,
      title: "Five Integrated Frameworks",
      description: "We use Integral Theory, Myers-Briggs, Character Strengths, Life Balance, and Appreciative Inquiry to give you a complete picture.",
      color: "from-indigo-600 to-purple-600",
    },
    {
      icon: CheckCircle2,
      title: "You're All Set!",
      description: "Answer honestly and thoughtfully. There are no right or wrong answers—this is about discovering your unique profile.",
      color: "from-green-600 to-emerald-600",
    },
  ];

  const currentSlideData = slides[currentSlide];
  const Icon = currentSlideData.icon;
  const isLastSlide = currentSlide === slides.length - 1;

  const handleNext = () => {
    if (isLastSlide) {
      handleComplete();
    } else {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const handleComplete = async () => {
    // Mark tutorial as seen
    await updateUserMutation.mutateAsync({
      tutorials_seen: {
        ...user?.tutorials_seen,
        assessment_tutorial: true,
      },
    });
    onClose();
  };

  const handleSkip = () => {
    handleComplete();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className={`w-16 h-16 bg-gradient-to-br ${currentSlideData.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
          <DialogTitle className="text-2xl text-center">{currentSlideData.title}</DialogTitle>
          <DialogDescription className="text-center text-base leading-relaxed pt-2">
            {currentSlideData.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Progress Dots */}
          <div className="flex justify-center gap-2">
            {slides.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all ${
                  idx === currentSlide
                    ? 'w-8 bg-indigo-600'
                    : 'w-2 bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex-1"
            >
              Skip Tutorial
            </Button>
            <Button
              onClick={handleNext}
              className={`flex-1 bg-gradient-to-r ${currentSlideData.color}`}
            >
              {isLastSlide ? "Let's Begin!" : "Next"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}