import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, Sparkles, FileText, Eye, Printer, Compass } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function OnboardingChecklist({ user, onDismiss }) {
  const tasks = [
    {
      id: 'completed_profile',
      title: 'Complete Your Profile',
      description: 'Set up your department and role',
      completed: user?.onboarding_tasks?.completed_profile || false,
      icon: Sparkles,
      action: null, // Already completed during onboarding
    },
    {
      id: 'completed_assessment',
      title: 'Take Your First Assessment',
      description: 'Unlock personalized insights',
      completed: user?.onboarding_tasks?.completed_assessment || false,
      icon: Sparkles,
      action: createPageUrl("QuickAssessment"),
      actionLabel: 'Start Assessment',
    },
    {
      id: 'viewed_results',
      title: 'View Your Results',
      description: 'Explore your comprehensive analysis',
      completed: user?.onboarding_tasks?.viewed_results || false,
      icon: Eye,
      action: createPageUrl("Results"),
      actionLabel: 'View Results',
    },
    {
      id: 'generated_report',
      title: 'Generate a Report',
      description: 'Create a downloadable PDF report',
      completed: user?.onboarding_tasks?.generated_report || false,
      icon: Printer,
      action: createPageUrl("ReportGenerator"),
      actionLabel: 'Generate Report',
    },
    {
      id: 'explored_portal',
      title: 'Explore Your Portal',
      description: 'Discover all available features',
      completed: user?.onboarding_tasks?.explored_portal || false,
      icon: Compass,
      action: createPageUrl("EmployeePortal"),
      actionLabel: 'Go to Portal',
    },
  ];

  const completedCount = tasks.filter(t => t.completed).length;
  const totalCount = tasks.length;
  const progress = (completedCount / totalCount) * 100;
  const allCompleted = completedCount === totalCount;

  if (allCompleted && onDismiss) {
    return (
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Onboarding Complete! 🎉</h3>
              <p className="text-gray-600 mb-4">
                You've completed all onboarding tasks. You're ready to make the most of Luminous Prosperity!
              </p>
              <Button 
                onClick={onDismiss}
                className="bg-gradient-to-r from-green-600 to-emerald-600"
              >
                Dismiss
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-indigo-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              Getting Started
            </CardTitle>
            <CardDescription>Complete these steps to unlock the full experience</CardDescription>
          </div>
          {onDismiss && (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onDismiss}
              className="text-gray-500"
            >
              Dismiss
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Bar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              {completedCount} of {totalCount} completed
            </span>
            <span className="text-sm font-medium text-indigo-600">
              {Math.round(progress)}%
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Task List */}
        <div className="space-y-3">
          {tasks.map((task) => {
            const Icon = task.icon;
            return (
              <div
                key={task.id}
                className={`flex items-start gap-3 p-4 rounded-lg border-2 transition-all ${
                  task.completed
                    ? 'bg-green-50 border-green-200'
                    : 'bg-white border-gray-200 hover:border-indigo-200'
                }`}
              >
                <div className="mt-0.5">
                  {task.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  ) : (
                    <Circle className="w-5 h-5 text-gray-400" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className={`font-semibold ${task.completed ? 'text-green-900' : 'text-gray-900'}`}>
                    {task.title}
                  </h4>
                  <p className="text-sm text-gray-600">{task.description}</p>
                </div>
                {!task.completed && task.action && (
                  <Link to={task.action}>
                    <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
                      {task.actionLabel}
                    </Button>
                  </Link>
                )}
                {task.completed && (
                  <span className="text-xs font-medium text-green-600">Done ✓</span>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}