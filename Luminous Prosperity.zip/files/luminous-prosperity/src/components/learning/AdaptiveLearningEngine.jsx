import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, Sparkles, RefreshCw, TrendingUp, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function AdaptiveLearningEngine({ user, journey, userSkills, assessmentResults, onUpdateJourney }) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendations, setRecommendations] = useState(null);

  const updateJourneyMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LearningJourney.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] }),
  });

  const analyzeAndAdapt = async () => {
    if (!journey) return;
    setIsAnalyzing(true);

    try {
      // Gather performance data
      const completedModules = journey.modules?.filter(m => m.status === 'completed') || [];
      const moduleScores = completedModules.map(m => m.score || 0);
      const avgScore = moduleScores.length > 0 ? moduleScores.reduce((a, b) => a + b, 0) / moduleScores.length : 0;
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this learner's performance and provide adaptive recommendations.

LEARNER PROFILE:
- Current Journey: ${journey.title}
- Career Goal: ${journey.career_goal}
- Progress: ${journey.progress_percentage}%
- Difficulty Level: ${journey.difficulty_level}

COMPLETED MODULES:
${completedModules.map(m => `- ${m.title}: Score ${m.score || 'N/A'}%`).join('\n') || 'None yet'}

AVERAGE ASSESSMENT SCORE: ${avgScore.toFixed(1)}%

CURRENT SKILLS: ${userSkills?.map(s => `${s.skill_name} (${s.self_assessed_proficiency})`).join(', ') || 'Not assessed'}

Based on this data, provide:
1. Performance analysis
2. Recommended difficulty adjustments
3. Suggested focus areas
4. Additional resources or modules to add
5. Personalized tips for improvement`,
        response_json_schema: {
          type: "object",
          properties: {
            performance_summary: { type: "string" },
            performance_level: { type: "string" },
            difficulty_recommendation: { type: "string" },
            focus_areas: { type: "array", items: { type: "string" } },
            strengths: { type: "array", items: { type: "string" } },
            improvement_areas: { type: "array", items: { type: "string" } },
            additional_modules: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  reason: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            personalized_tips: { type: "array", items: { type: "string" } },
            pace_adjustment: { type: "string" }
          }
        }
      });

      setRecommendations(result);

      // Update journey with AI recommendations
      await updateJourneyMutation.mutateAsync({
        id: journey.id,
        data: {
          ai_recommendations: result.personalized_tips || [],
          difficulty_level: result.difficulty_recommendation === 'increase' ? 
            (journey.difficulty_level === 'beginner' ? 'intermediate' : 'advanced') :
            journey.difficulty_level
        }
      });

    } catch (error) {
      console.error("Error analyzing performance:", error);
    }
    setIsAnalyzing(false);
  };

  const performanceColor = recommendations?.performance_level === 'excellent' ? 'text-green-400' :
    recommendations?.performance_level === 'good' ? 'text-blue-400' :
    recommendations?.performance_level === 'needs_improvement' ? 'text-yellow-400' : 'text-gray-400';

  return (
    <Card className="bg-gradient-to-r from-purple-900/30 to-cyan-900/30 border-purple-800">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            AI Adaptive Learning
          </CardTitle>
          <Button onClick={analyzeAndAdapt} disabled={isAnalyzing} size="sm" className="bg-purple-600 hover:bg-purple-700">
            {isAnalyzing ? <><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Analyzing...</> : <><Sparkles className="w-3 h-3 mr-1" />Analyze & Adapt</>}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!recommendations ? (
          <p className="text-gray-400 text-sm text-center py-4">
            Click "Analyze & Adapt" to get personalized recommendations based on your performance
          </p>
        ) : (
          <div className="space-y-4">
            {/* Performance Summary */}
            <div className="p-3 bg-gray-800 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">Performance Level</span>
                <Badge className={`capitalize ${
                  recommendations.performance_level === 'excellent' ? 'bg-green-600' :
                  recommendations.performance_level === 'good' ? 'bg-blue-600' : 'bg-yellow-600'
                }`}>
                  {recommendations.performance_level}
                </Badge>
              </div>
              <p className="text-gray-300 text-sm">{recommendations.performance_summary}</p>
            </div>

            {/* Strengths & Improvements */}
            <div className="grid md:grid-cols-2 gap-3">
              <div className="p-3 bg-green-900/20 border border-green-800 rounded-lg">
                <p className="text-green-400 text-xs font-medium mb-2 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Strengths
                </p>
                <ul className="space-y-1">
                  {recommendations.strengths?.map((s, i) => (
                    <li key={i} className="text-gray-300 text-xs">• {s}</li>
                  ))}
                </ul>
              </div>
              <div className="p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg">
                <p className="text-yellow-400 text-xs font-medium mb-2 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Focus Areas
                </p>
                <ul className="space-y-1">
                  {recommendations.improvement_areas?.map((s, i) => (
                    <li key={i} className="text-gray-300 text-xs">• {s}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Recommended Adjustments */}
            <div className="p-3 bg-purple-900/20 border border-purple-800 rounded-lg">
              <p className="text-purple-400 text-xs font-medium mb-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Pace Adjustment
              </p>
              <p className="text-gray-300 text-sm">{recommendations.pace_adjustment}</p>
            </div>

            {/* Personalized Tips */}
            {recommendations.personalized_tips?.length > 0 && (
              <div>
                <p className="text-gray-400 text-xs font-medium mb-2">Personalized Tips</p>
                <div className="space-y-2">
                  {recommendations.personalized_tips.map((tip, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <Sparkles className="w-3 h-3 text-purple-400 mt-1 flex-shrink-0" />
                      <span className="text-gray-300">{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}