import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BookOpen, CheckCircle2, ChevronLeft, ChevronRight, 
  FileText, HelpCircle, Lightbulb, PenTool, Trophy,
  Target, Award, Sparkles
} from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function JourneyModuleViewer({ journey, module, moduleIndex, onComplete, onBack }) {
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);
  const [showAssessment, setShowAssessment] = useState(false);
  const [assessmentAnswers, setAssessmentAnswers] = useState({});
  const [assessmentSubmitted, setAssessmentSubmitted] = useState(false);
  const [assessmentScore, setAssessmentScore] = useState(0);
  const [reflectionResponses, setReflectionResponses] = useState({});

  const lessons = module.content?.lessons || [];
  const currentLesson = lessons[currentLessonIndex];
  const assessment = module.content?.assessment;
  const practicalExercises = module.content?.practical_exercises || [];

  const submitAssessment = () => {
    if (!assessment?.questions) return;
    
    let correct = 0;
    assessment.questions.forEach((q, i) => {
      if (assessmentAnswers[i] === q.correct_answer) {
        correct++;
      }
    });
    
    const score = Math.round((correct / assessment.questions.length) * 100);
    setAssessmentScore(score);
    setAssessmentSubmitted(true);
  };

  const passedAssessment = assessmentSubmitted && assessmentScore >= (assessment?.passing_score || 70);

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="ghost" onClick={onBack} className="text-gray-400 hover:text-white">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back to Journey
          </Button>
          <Badge className="bg-purple-600">Module {moduleIndex + 1}</Badge>
        </div>

        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardHeader>
            <CardTitle className="text-white">{module.title}</CardTitle>
            <p className="text-gray-400">{module.description}</p>
            <div className="flex flex-wrap gap-2 mt-3">
              {module.content?.learning_objectives?.map((obj, i) => (
                <Badge key={i} variant="outline" className="border-green-700 text-green-400">
                  <Target className="w-3 h-3 mr-1" />
                  {obj}
                </Badge>
              ))}
            </div>
          </CardHeader>
        </Card>

        <Tabs defaultValue="lessons" className="space-y-6">
          <TabsList className="bg-gray-900 border border-gray-800">
            <TabsTrigger value="lessons">
              <BookOpen className="w-4 h-4 mr-1" />
              Lessons ({lessons.length})
            </TabsTrigger>
            <TabsTrigger value="exercises">
              <PenTool className="w-4 h-4 mr-1" />
              Exercises ({practicalExercises.length})
            </TabsTrigger>
            <TabsTrigger value="assessment">
              <HelpCircle className="w-4 h-4 mr-1" />
              Assessment
            </TabsTrigger>
          </TabsList>

          {/* Lessons Tab */}
          <TabsContent value="lessons">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                {currentLesson ? (
                  <div className="space-y-6">
                    {/* Lesson Navigation */}
                    <div className="flex items-center justify-between">
                      <h3 className="text-white font-medium text-lg">{currentLesson.title}</h3>
                      <span className="text-gray-500 text-sm">
                        Lesson {currentLessonIndex + 1} of {lessons.length}
                      </span>
                    </div>

                    <Progress value={((currentLessonIndex + 1) / lessons.length) * 100} className="h-1" />

                    {/* Lesson Content */}
                    <ScrollArea className="h-[400px]">
                      <div className="prose prose-invert max-w-none">
                        <ReactMarkdown>{currentLesson.content}</ReactMarkdown>
                      </div>

                      {/* Exercises within lesson */}
                      {currentLesson.exercises?.length > 0 && (
                        <div className="mt-6 p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                          <h4 className="text-blue-300 font-medium mb-3 flex items-center gap-2">
                            <Lightbulb className="w-4 h-4" />
                            Practice Exercises
                          </h4>
                          <ul className="space-y-2">
                            {currentLesson.exercises.map((ex, i) => (
                              <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                                <span className="text-blue-400">•</span>
                                {ex}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Reflection Prompts */}
                      {currentLesson.reflection_prompts?.length > 0 && (
                        <div className="mt-6 p-4 bg-purple-900/20 border border-purple-800 rounded-lg">
                          <h4 className="text-purple-300 font-medium mb-3 flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            Reflection Questions
                          </h4>
                          {currentLesson.reflection_prompts.map((prompt, i) => (
                            <div key={i} className="mb-4">
                              <p className="text-gray-300 text-sm mb-2">{prompt}</p>
                              <Textarea
                                value={reflectionResponses[`${currentLessonIndex}_${i}`] || ''}
                                onChange={(e) => setReflectionResponses({
                                  ...reflectionResponses,
                                  [`${currentLessonIndex}_${i}`]: e.target.value
                                })}
                                placeholder="Write your reflection..."
                                className="bg-gray-800 border-gray-700 text-white h-20"
                              />
                            </div>
                          ))}
                        </div>
                      )}
                    </ScrollArea>

                    {/* Navigation Buttons */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-800">
                      <Button
                        variant="outline"
                        onClick={() => setCurrentLessonIndex(i => Math.max(0, i - 1))}
                        disabled={currentLessonIndex === 0}
                        className="border-gray-700 text-gray-400"
                      >
                        <ChevronLeft className="w-4 h-4 mr-1" />
                        Previous
                      </Button>
                      {currentLessonIndex < lessons.length - 1 ? (
                        <Button
                          onClick={() => setCurrentLessonIndex(i => i + 1)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          Next Lesson
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      ) : (
                        <Button
                          onClick={() => setShowAssessment(true)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Take Assessment
                          <CheckCircle2 className="w-4 h-4 ml-1" />
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-400 text-center py-8">No lessons available</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Exercises Tab */}
          <TabsContent value="exercises">
            <div className="space-y-4">
              {practicalExercises.map((exercise, i) => (
                <Card key={i} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-blue-900 flex items-center justify-center flex-shrink-0">
                        <PenTool className="w-5 h-5 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-white font-medium mb-2">{exercise.title}</h4>
                        <p className="text-gray-400 text-sm mb-3">{exercise.instructions}</p>
                        <div className="flex items-center gap-4 text-xs">
                          <Badge variant="outline" className="border-gray-700 text-gray-400">
                            {exercise.time_estimate}
                          </Badge>
                          <span className="text-green-400">Expected: {exercise.expected_outcome}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Assessment Tab */}
          <TabsContent value="assessment">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                {assessmentSubmitted ? (
                  <div className="text-center py-8">
                    {passedAssessment ? (
                      <>
                        <div className="w-20 h-20 rounded-full bg-green-900 flex items-center justify-center mx-auto mb-4">
                          <Trophy className="w-10 h-10 text-green-400" />
                        </div>
                        <h3 className="text-white text-xl font-medium mb-2">Congratulations!</h3>
                        <p className="text-gray-400 mb-2">You scored {assessmentScore}%</p>
                        <p className="text-green-400 mb-6">You've passed this module!</p>
                        <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700">
                          <Award className="w-4 h-4 mr-2" />
                          Complete Module & Earn Badge
                        </Button>
                      </>
                    ) : (
                      <>
                        <div className="w-20 h-20 rounded-full bg-yellow-900 flex items-center justify-center mx-auto mb-4">
                          <HelpCircle className="w-10 h-10 text-yellow-400" />
                        </div>
                        <h3 className="text-white text-xl font-medium mb-2">Keep Learning!</h3>
                        <p className="text-gray-400 mb-2">You scored {assessmentScore}%</p>
                        <p className="text-yellow-400 mb-6">You need {assessment?.passing_score || 70}% to pass. Review the lessons and try again!</p>
                        <Button 
                          onClick={() => {
                            setAssessmentSubmitted(false);
                            setAssessmentAnswers({});
                          }} 
                          className="bg-yellow-600 hover:bg-yellow-700"
                        >
                          Retake Assessment
                        </Button>
                      </>
                    )}

                    {/* Show answers */}
                    <div className="mt-8 text-left">
                      <h4 className="text-white font-medium mb-4">Review Answers</h4>
                      {assessment?.questions?.map((q, i) => (
                        <div key={i} className={`p-4 rounded-lg mb-3 ${
                          assessmentAnswers[i] === q.correct_answer ? 'bg-green-900/20' : 'bg-red-900/20'
                        }`}>
                          <p className="text-white text-sm mb-2">{q.question}</p>
                          <p className="text-sm">
                            Your answer: <span className={assessmentAnswers[i] === q.correct_answer ? 'text-green-400' : 'text-red-400'}>
                              {assessmentAnswers[i]}
                            </span>
                          </p>
                          {assessmentAnswers[i] !== q.correct_answer && (
                            <p className="text-sm text-green-400">Correct: {q.correct_answer}</p>
                          )}
                          <p className="text-gray-400 text-xs mt-2">{q.explanation}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-white font-medium">Module Assessment</h3>
                      <Badge className="bg-purple-600">Passing: {assessment?.passing_score || 70}%</Badge>
                    </div>

                    {assessment?.questions?.map((question, i) => (
                      <div key={i} className="p-4 bg-gray-800 rounded-lg">
                        <p className="text-white mb-4">{i + 1}. {question.question}</p>
                        <RadioGroup
                          value={assessmentAnswers[i]}
                          onValueChange={(value) => setAssessmentAnswers({...assessmentAnswers, [i]: value})}
                        >
                          {question.options?.map((option, j) => (
                            <div key={j} className="flex items-center space-x-2 mb-2">
                              <RadioGroupItem value={option} id={`q${i}_o${j}`} />
                              <Label htmlFor={`q${i}_o${j}`} className="text-gray-300">{option}</Label>
                            </div>
                          ))}
                        </RadioGroup>
                      </div>
                    ))}

                    <Button 
                      onClick={submitAssessment}
                      disabled={Object.keys(assessmentAnswers).length < (assessment?.questions?.length || 0)}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                      Submit Assessment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}