import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Play, RotateCcw, CheckCircle2, XCircle, Lightbulb, Copy } from "lucide-react";

export default function InteractiveCodeEditor({ exercise, language = "python", onComplete }) {
  const [code, setCode] = useState(exercise?.starterCode || "# Write your code here\n");
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState(null);
  const [showHint, setShowHint] = useState(false);

  const runCode = async () => {
    setIsRunning(true);
    setOutput("");
    setTestResults(null);

    // Simulate code execution (in production, this would call a sandboxed execution API)
    setTimeout(() => {
      try {
        // Simple simulation of code output
        const lines = code.split('\n');
        const printStatements = lines.filter(l => l.includes('print('));
        let simulatedOutput = "";
        
        printStatements.forEach(line => {
          const match = line.match(/print\(["'](.+?)["']\)/);
          if (match) {
            simulatedOutput += match[1] + "\n";
          } else if (line.includes('print(')) {
            simulatedOutput += "[Output]\n";
          }
        });

        if (!simulatedOutput) {
          simulatedOutput = "Code executed successfully (no output)";
        }

        setOutput(simulatedOutput);

        // Check against expected output if provided
        if (exercise?.expectedOutput) {
          const passed = simulatedOutput.trim().includes(exercise.expectedOutput.trim());
          setTestResults({
            passed,
            message: passed ? "All tests passed!" : "Output doesn't match expected result"
          });
          if (passed) onComplete?.();
        }
      } catch (error) {
        setOutput(`Error: ${error.message}`);
        setTestResults({ passed: false, message: error.message });
      }
      setIsRunning(false);
    }, 1000);
  };

  const resetCode = () => {
    setCode(exercise?.starterCode || "# Write your code here\n");
    setOutput("");
    setTestResults(null);
  };

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Badge className="bg-blue-600">{language}</Badge>
            {exercise?.title || "Code Exercise"}
          </CardTitle>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setShowHint(!showHint)} className="text-yellow-400">
              <Lightbulb className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={() => navigator.clipboard.writeText(code)} className="text-gray-400">
              <Copy className="w-4 h-4" />
            </Button>
          </div>
        </div>
        {exercise?.instructions && (
          <p className="text-gray-400 text-sm mt-2">{exercise.instructions}</p>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {showHint && exercise?.hint && (
          <div className="p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg">
            <p className="text-yellow-300 text-sm">💡 {exercise.hint}</p>
          </div>
        )}

        {/* Code Editor */}
        <div className="relative">
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-48 bg-gray-950 text-green-400 font-mono text-sm p-4 rounded-lg border border-gray-700 focus:border-blue-600 focus:outline-none resize-none"
            spellCheck={false}
          />
          <div className="absolute top-2 right-2 text-xs text-gray-600">{language}</div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button onClick={runCode} disabled={isRunning} className="bg-green-600 hover:bg-green-700">
            <Play className="w-4 h-4 mr-2" />
            {isRunning ? "Running..." : "Run Code"}
          </Button>
          <Button onClick={resetCode} variant="outline" className="border-gray-700 text-gray-400">
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>

        {/* Output */}
        {output && (
          <div className="space-y-2">
            <p className="text-gray-400 text-xs font-medium uppercase">Output:</p>
            <pre className="bg-gray-950 text-gray-300 font-mono text-sm p-4 rounded-lg border border-gray-700 overflow-x-auto">
              {output}
            </pre>
          </div>
        )}

        {/* Test Results */}
        {testResults && (
          <div className={`p-3 rounded-lg border ${testResults.passed ? 'bg-green-900/20 border-green-800' : 'bg-red-900/20 border-red-800'}`}>
            <div className="flex items-center gap-2">
              {testResults.passed ? (
                <CheckCircle2 className="w-5 h-5 text-green-400" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400" />
              )}
              <span className={testResults.passed ? 'text-green-300' : 'text-red-300'}>
                {testResults.message}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}