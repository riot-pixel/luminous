import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BookOpen, Clock, Target, Search, Code, Cloud, Brain, 
  BarChart3, Shield, Users, Sparkles, CheckCircle2, Play, Calculator
} from "lucide-react";

const COURSE_CATALOG = [
  {
    id: "python_fundamentals",
    title: "Python Fundamentals",
    description: "Master the basics of Python programming from variables to functions",
    category: "programming",
    difficulty: "beginner",
    duration_hours: 12,
    icon: Code,
    color: "bg-blue-600",
    skills: ["Python", "Programming Basics", "Problem Solving"],
    modules: [
      {
        module_id: "py_intro",
        title: "Introduction to Python",
        description: "Set up your environment and write your first Python program",
        duration_minutes: 45,
        skill_focus: "Python Basics",
        content: {
          learning_objectives: [
            "Understand what Python is and why it's popular",
            "Set up a Python development environment",
            "Write and run your first Python program",
            "Understand basic syntax rules"
          ],
          key_concepts: ["Interpreter", "REPL", "Syntax", "Indentation", "Comments"],
          lessons: [
            {
              lesson_id: "py_intro_1",
              title: "What is Python?",
              content: `Python is a high-level, interpreted programming language created by Guido van Rossum in 1991. It emphasizes code readability with its notable use of significant whitespace.

**Why Python is Popular:**
- Easy to learn and read
- Versatile: web development, data science, AI, automation
- Large community and extensive libraries
- Cross-platform compatibility

**Python Philosophy (The Zen of Python):**
- Beautiful is better than ugly
- Explicit is better than implicit
- Simple is better than complex
- Readability counts

To see the full Zen of Python, type: import this`,
              exercises: [
                "Install Python 3.x from python.org",
                "Open a terminal and type 'python --version' to verify installation",
                "Open Python REPL by typing 'python' and try: print('Hello, World!')"
              ],
              reflection_prompts: [
                "What aspects of Python's philosophy appeal to you?",
                "What projects would you like to build with Python?"
              ]
            },
            {
              lesson_id: "py_intro_2",
              title: "Variables and Data Types",
              content: `Variables in Python are containers for storing data values. Unlike other languages, Python has no command for declaring a variable - it's created when you assign a value.

**Basic Data Types:**
\`\`\`python
# Strings - text data
name = "Alice"
message = 'Hello, World!'

# Integers - whole numbers
age = 25
count = -10

# Floats - decimal numbers
price = 19.99
temperature = -3.5

# Booleans - True or False
is_active = True
has_permission = False

# None - represents absence of value
result = None
\`\`\`

**Type Checking:**
\`\`\`python
print(type(name))      # <class 'str'>
print(type(age))       # <class 'int'>
print(type(price))     # <class 'float'>
print(type(is_active)) # <class 'bool'>
\`\`\`

**Variable Naming Rules:**
- Must start with a letter or underscore
- Can contain letters, numbers, underscores
- Case-sensitive (age, Age, AGE are different)
- Cannot be Python keywords (if, for, while, etc.)`,
              exercises: [
                "Create variables for your name, age, and favorite number",
                "Use type() to check each variable's type",
                "Try assigning different types to the same variable"
              ],
              reflection_prompts: [
                "How does Python's dynamic typing differ from statically typed languages?",
                "What naming conventions will you adopt for your variables?"
              ]
            }
          ],
          assessment: {
            questions: [
              { question: "What symbol is used for comments in Python?", type: "multiple_choice", options: ["//", "#", "/*", "--"], correct_answer: "#", explanation: "Python uses # for single-line comments" },
              { question: "Which is NOT a valid Python data type?", type: "multiple_choice", options: ["int", "str", "char", "float"], correct_answer: "char", explanation: "Python doesn't have a char type - single characters are strings" },
              { question: "What will type(3.14) return?", type: "multiple_choice", options: ["<class 'int'>", "<class 'float'>", "<class 'decimal'>", "<class 'number'>"], correct_answer: "<class 'float'>", explanation: "Decimal numbers in Python are float type" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Personal Info Script", instructions: "Create a script that stores your name, age, city in variables and prints them in a formatted sentence", expected_outcome: "A script that outputs something like: 'My name is Alice, I am 25 years old and live in New York'", time_estimate: "15 minutes" }
          ]
        }
      },
      {
        module_id: "py_control",
        title: "Control Flow",
        description: "Master if statements, loops, and program flow control",
        duration_minutes: 60,
        skill_focus: "Logic and Control Structures",
        content: {
          learning_objectives: [
            "Write conditional statements with if, elif, else",
            "Create loops using for and while",
            "Understand loop control with break and continue",
            "Combine conditions with logical operators"
          ],
          key_concepts: ["Conditionals", "Loops", "Boolean Logic", "Iteration", "Flow Control"],
          lessons: [
            {
              lesson_id: "py_control_1",
              title: "Conditional Statements",
              content: `Conditional statements allow your program to make decisions based on conditions.

**Basic If Statement:**
\`\`\`python
age = 18

if age >= 18:
    print("You are an adult")
\`\`\`

**If-Else:**
\`\`\`python
temperature = 25

if temperature > 30:
    print("It's hot outside!")
else:
    print("The weather is pleasant")
\`\`\`

**If-Elif-Else:**
\`\`\`python
score = 85

if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
elif score >= 60:
    grade = "D"
else:
    grade = "F"

print(f"Your grade is: {grade}")
\`\`\`

**Logical Operators:**
\`\`\`python
age = 25
has_license = True

# AND - both conditions must be true
if age >= 18 and has_license:
    print("You can drive")

# OR - at least one condition must be true
if age < 13 or age > 65:
    print("Discount available")

# NOT - inverts the condition
if not has_license:
    print("You need a license")
\`\`\``,
              exercises: [
                "Write a program that checks if a number is positive, negative, or zero",
                "Create a simple login check with username and password",
                "Build a program that determines if a year is a leap year"
              ],
              reflection_prompts: [
                "When would you use elif vs multiple if statements?",
                "How can nested conditions make code harder to read?"
              ]
            },
            {
              lesson_id: "py_control_2",
              title: "Loops",
              content: `Loops allow you to execute code repeatedly.

**For Loop - iterate over a sequence:**
\`\`\`python
# Loop through a list
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)

# Loop with range
for i in range(5):        # 0, 1, 2, 3, 4
    print(i)

for i in range(2, 6):     # 2, 3, 4, 5
    print(i)

for i in range(0, 10, 2): # 0, 2, 4, 6, 8
    print(i)
\`\`\`

**While Loop - repeat while condition is true:**
\`\`\`python
count = 0
while count < 5:
    print(count)
    count += 1
\`\`\`

**Loop Control:**
\`\`\`python
# break - exit the loop entirely
for i in range(10):
    if i == 5:
        break
    print(i)  # prints 0, 1, 2, 3, 4

# continue - skip to next iteration
for i in range(5):
    if i == 2:
        continue
    print(i)  # prints 0, 1, 3, 4
\`\`\`

**Nested Loops:**
\`\`\`python
for i in range(3):
    for j in range(3):
        print(f"({i}, {j})")
\`\`\``,
              exercises: [
                "Print the multiplication table for a given number",
                "Sum all numbers from 1 to 100 using a loop",
                "Find all prime numbers between 1 and 50"
              ],
              reflection_prompts: [
                "When would you choose a for loop over a while loop?",
                "What are the risks of infinite loops?"
              ]
            }
          ],
          assessment: {
            questions: [
              { question: "What does 'break' do in a loop?", type: "multiple_choice", options: ["Pauses the loop", "Exits the loop completely", "Skips current iteration", "Restarts the loop"], correct_answer: "Exits the loop completely", explanation: "break terminates the loop entirely" },
              { question: "What is range(3, 8)?", type: "multiple_choice", options: ["3, 4, 5, 6, 7, 8", "3, 4, 5, 6, 7", "0, 1, 2", "3, 8"], correct_answer: "3, 4, 5, 6, 7", explanation: "range(start, stop) excludes the stop value" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Number Guessing Game", instructions: "Create a game where the computer picks a random number and the user has to guess it with hints (higher/lower)", expected_outcome: "An interactive game that gives feedback and counts attempts", time_estimate: "30 minutes" }
          ]
        }
      },
      {
        module_id: "py_functions",
        title: "Functions",
        description: "Learn to write reusable code with functions",
        duration_minutes: 50,
        skill_focus: "Code Organization",
        content: {
          learning_objectives: [
            "Define and call functions",
            "Use parameters and return values",
            "Understand scope and variable visibility",
            "Work with default and keyword arguments"
          ],
          key_concepts: ["Functions", "Parameters", "Return Values", "Scope", "DRY Principle"],
          lessons: [
            {
              lesson_id: "py_func_1",
              title: "Defining Functions",
              content: `Functions are reusable blocks of code that perform a specific task.

**Basic Function:**
\`\`\`python
def greet():
    print("Hello, World!")

greet()  # Call the function
\`\`\`

**Function with Parameters:**
\`\`\`python
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")  # Hello, Alice!
greet("Bob")    # Hello, Bob!
\`\`\`

**Return Values:**
\`\`\`python
def add(a, b):
    return a + b

result = add(5, 3)
print(result)  # 8
\`\`\`

**Default Parameters:**
\`\`\`python
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"

print(greet("Alice"))           # Hello, Alice!
print(greet("Bob", "Hi"))       # Hi, Bob!
\`\`\`

**Multiple Return Values:**
\`\`\`python
def get_stats(numbers):
    return min(numbers), max(numbers), sum(numbers)/len(numbers)

minimum, maximum, average = get_stats([1, 2, 3, 4, 5])
\`\`\``,
              exercises: [
                "Write a function that calculates the area of a rectangle",
                "Create a function that checks if a string is a palindrome",
                "Build a function that converts Celsius to Fahrenheit"
              ],
              reflection_prompts: [
                "How do functions help organize code?",
                "When should you break code into separate functions?"
              ]
            }
          ],
          assessment: {
            questions: [
              { question: "What keyword defines a function in Python?", type: "multiple_choice", options: ["function", "def", "func", "define"], correct_answer: "def", explanation: "Python uses 'def' to define functions" },
              { question: "What happens if a function has no return statement?", type: "multiple_choice", options: ["Error", "Returns 0", "Returns None", "Returns empty string"], correct_answer: "Returns None", explanation: "Functions without explicit return statements return None" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Calculator Functions", instructions: "Create a calculator with functions for add, subtract, multiply, divide that handle edge cases", expected_outcome: "A set of functions that can be used for basic arithmetic", time_estimate: "25 minutes" }
          ]
        }
      },
      {
        module_id: "py_data_structures",
        title: "Data Structures",
        description: "Master lists, dictionaries, tuples, and sets",
        duration_minutes: 70,
        skill_focus: "Data Management",
        content: {
          learning_objectives: [
            "Create and manipulate lists",
            "Use dictionaries for key-value storage",
            "Understand when to use tuples vs lists",
            "Perform set operations"
          ],
          key_concepts: ["Lists", "Dictionaries", "Tuples", "Sets", "Mutability"],
          lessons: [
            {
              lesson_id: "py_ds_1",
              title: "Lists",
              content: `Lists are ordered, mutable collections.

**Creating Lists:**
\`\`\`python
numbers = [1, 2, 3, 4, 5]
mixed = [1, "hello", 3.14, True]
empty = []
\`\`\`

**Accessing Elements:**
\`\`\`python
fruits = ["apple", "banana", "cherry"]
print(fruits[0])   # apple
print(fruits[-1])  # cherry (last element)
print(fruits[1:3]) # ['banana', 'cherry'] (slicing)
\`\`\`

**List Methods:**
\`\`\`python
fruits = ["apple", "banana"]

fruits.append("cherry")      # Add to end
fruits.insert(1, "orange")   # Insert at index
fruits.remove("banana")      # Remove by value
popped = fruits.pop()        # Remove and return last
fruits.sort()                # Sort in place
fruits.reverse()             # Reverse in place
\`\`\`

**List Comprehensions:**
\`\`\`python
# Create list of squares
squares = [x**2 for x in range(10)]
# [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# Filter with condition
evens = [x for x in range(20) if x % 2 == 0]
# [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]
\`\`\``,
              exercises: [
                "Create a list of your favorite movies and add 3 more",
                "Write a function that returns the second largest number in a list",
                "Use list comprehension to create a list of all vowels in a sentence"
              ],
              reflection_prompts: [
                "When would you use a list vs a tuple?",
                "How can list comprehensions make code more readable?"
              ]
            },
            {
              lesson_id: "py_ds_2",
              title: "Dictionaries",
              content: `Dictionaries store key-value pairs.

**Creating Dictionaries:**
\`\`\`python
person = {
    "name": "Alice",
    "age": 30,
    "city": "New York"
}
\`\`\`

**Accessing Values:**
\`\`\`python
print(person["name"])        # Alice
print(person.get("age"))     # 30
print(person.get("job", "Unknown"))  # Unknown (default)
\`\`\`

**Modifying Dictionaries:**
\`\`\`python
person["email"] = "alice@email.com"  # Add new key
person["age"] = 31                    # Update value
del person["city"]                    # Delete key
\`\`\`

**Dictionary Methods:**
\`\`\`python
print(person.keys())    # dict_keys(['name', 'age', 'email'])
print(person.values())  # dict_values(['Alice', 31, 'alice@email.com'])
print(person.items())   # dict_items([('name', 'Alice'), ...])
\`\`\`

**Iterating:**
\`\`\`python
for key, value in person.items():
    print(f"{key}: {value}")
\`\`\``,
              exercises: [
                "Create a dictionary for a book with title, author, year, pages",
                "Write a function that counts word frequency in a sentence",
                "Build a simple contact book with add, search, delete functions"
              ],
              reflection_prompts: [
                "What types of data are best stored in dictionaries?",
                "How do dictionaries compare to lists in terms of lookup speed?"
              ]
            }
          ],
          assessment: {
            questions: [
              { question: "What is the result of [1,2,3] + [4,5]?", type: "multiple_choice", options: ["[1,2,3,4,5]", "[5,7,3]", "Error", "[1,2,3,[4,5]]"], correct_answer: "[1,2,3,4,5]", explanation: "The + operator concatenates lists" },
              { question: "How do you access 'age' from person = {'name': 'Bob', 'age': 25}?", type: "multiple_choice", options: ["person.age", "person['age']", "person(age)", "person->age"], correct_answer: "person['age']", explanation: "Dictionary values are accessed using square bracket notation" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Student Grade Manager", instructions: "Create a program that stores student names and their grades, calculates averages, and finds top performers", expected_outcome: "A dictionary-based grade management system with multiple functions", time_estimate: "40 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "python_advanced",
    title: "Python: Fundamentals to Advanced",
    description: "Take your Python skills to the next level with OOP, decorators, and more",
    category: "programming",
    difficulty: "intermediate",
    duration_hours: 20,
    icon: Code,
    color: "bg-purple-600",
    skills: ["Python", "OOP", "Advanced Programming"],
    modules: [
      {
        module_id: "py_adv_oop",
        title: "Object-Oriented Programming",
        description: "Master classes, objects, inheritance, and encapsulation",
        duration_minutes: 90,
        skill_focus: "OOP Concepts",
        content: {
          learning_objectives: ["Create classes and objects", "Implement inheritance", "Use encapsulation and abstraction", "Apply polymorphism"],
          key_concepts: ["Classes", "Objects", "Inheritance", "Encapsulation", "Polymorphism"],
          lessons: [
            {
              lesson_id: "oop_1",
              title: "Classes and Objects",
              content: `Classes are blueprints for creating objects.

**Defining a Class:**
\`\`\`python
class Dog:
    # Class attribute
    species = "Canis familiaris"
    
    # Constructor
    def __init__(self, name, age):
        self.name = name  # Instance attribute
        self.age = age
    
    # Instance method
    def bark(self):
        return f"{self.name} says woof!"
    
    def description(self):
        return f"{self.name} is {self.age} years old"

# Creating objects
buddy = Dog("Buddy", 3)
max = Dog("Max", 5)

print(buddy.bark())        # Buddy says woof!
print(max.description())   # Max is 5 years old
\`\`\`

**The __init__ Method:**
- Called automatically when creating an object
- Initializes the object's attributes
- self refers to the instance being created

**Instance vs Class Attributes:**
\`\`\`python
class Counter:
    count = 0  # Class attribute - shared by all instances
    
    def __init__(self):
        Counter.count += 1
        self.id = Counter.count  # Instance attribute
\`\`\``,
              exercises: ["Create a BankAccount class with deposit and withdraw methods", "Build a Rectangle class with area and perimeter methods"],
              reflection_prompts: ["How do classes help organize code?", "When should you use class attributes vs instance attributes?"]
            },
            {
              lesson_id: "oop_2",
              title: "Inheritance and Polymorphism",
              content: `Inheritance allows classes to inherit attributes and methods from parent classes.

**Basic Inheritance:**
\`\`\`python
class Animal:
    def __init__(self, name):
        self.name = name
    
    def speak(self):
        raise NotImplementedError("Subclass must implement")

class Dog(Animal):
    def speak(self):
        return f"{self.name} says Woof!"

class Cat(Animal):
    def speak(self):
        return f"{self.name} says Meow!"

# Polymorphism in action
animals = [Dog("Buddy"), Cat("Whiskers")]
for animal in animals:
    print(animal.speak())
\`\`\`

**Super() Function:**
\`\`\`python
class Employee:
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

class Manager(Employee):
    def __init__(self, name, salary, department):
        super().__init__(name, salary)
        self.department = department
\`\`\``,
              exercises: ["Create a Vehicle class hierarchy with Car and Motorcycle subclasses", "Implement a Shape class with Circle and Rectangle children"],
              reflection_prompts: ["When is inheritance the right choice vs composition?", "How does polymorphism make code more flexible?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What is self in a class method?", type: "multiple_choice", options: ["A reserved keyword", "Reference to the class", "Reference to the instance", "A global variable"], correct_answer: "Reference to the instance", explanation: "self refers to the current instance of the class" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Library System", instructions: "Build a library system with Book, Member, and Library classes. Implement borrowing and returning books.", expected_outcome: "A functional library management system using OOP principles", time_estimate: "60 minutes" }
          ]
        }
      },
      {
        module_id: "py_adv_decorators",
        title: "Decorators and Advanced Functions",
        description: "Master decorators, closures, and functional programming",
        duration_minutes: 75,
        skill_focus: "Advanced Functions",
        content: {
          learning_objectives: ["Understand closures", "Create and use decorators", "Apply functools utilities", "Use lambda functions effectively"],
          key_concepts: ["Closures", "Decorators", "Higher-order functions", "Lambda", "functools"],
          lessons: [
            {
              lesson_id: "dec_1",
              title: "Decorators",
              content: `Decorators modify the behavior of functions without changing their code.

**Basic Decorator:**
\`\`\`python
def timer(func):
    import time
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end-start:.4f} seconds")
        return result
    return wrapper

@timer
def slow_function():
    import time
    time.sleep(1)
    return "Done!"

slow_function()  # slow_function took 1.0012 seconds
\`\`\`

**Decorator with Arguments:**
\`\`\`python
def repeat(times):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(3)
def say_hello():
    print("Hello!")

say_hello()  # Prints "Hello!" three times
\`\`\``,
              exercises: ["Create a decorator that logs function calls with arguments", "Build a memoization decorator for caching results"],
              reflection_prompts: ["What problems do decorators solve elegantly?", "When should you avoid using decorators?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What does @decorator syntax do?", type: "multiple_choice", options: ["Defines a function", "Calls a function", "Wraps a function with another function", "Creates a class"], correct_answer: "Wraps a function with another function", explanation: "@decorator is syntactic sugar for func = decorator(func)" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Authentication Decorator", instructions: "Create decorators for login_required, admin_only, and rate_limiting", expected_outcome: "Reusable decorators for common web application patterns", time_estimate: "45 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "javascript_mastery",
    title: "Master JavaScript for Dynamic Applications",
    description: "Build interactive web applications with modern JavaScript",
    category: "programming",
    difficulty: "intermediate",
    duration_hours: 25,
    icon: Code,
    color: "bg-yellow-600",
    skills: ["JavaScript", "DOM", "Async Programming", "ES6+"],
    modules: [
      {
        module_id: "js_fundamentals",
        title: "JavaScript Fundamentals",
        description: "Core concepts of JavaScript programming",
        duration_minutes: 80,
        skill_focus: "JavaScript Basics",
        content: {
          learning_objectives: ["Understand JavaScript data types", "Work with arrays and objects", "Write functions and arrow functions", "Use modern ES6+ features"],
          key_concepts: ["Variables", "Functions", "Arrays", "Objects", "ES6"],
          lessons: [
            {
              lesson_id: "js_1",
              title: "Variables and Modern JavaScript",
              content: `Modern JavaScript uses let and const instead of var.

**Variable Declarations:**
\`\`\`javascript
// const - constant, cannot be reassigned
const PI = 3.14159;
const user = { name: "Alice" };

// let - block-scoped, can be reassigned
let count = 0;
count = 1;  // OK

// Destructuring
const person = { name: "Bob", age: 30 };
const { name, age } = person;

const numbers = [1, 2, 3];
const [first, second] = numbers;

// Spread operator
const arr1 = [1, 2, 3];
const arr2 = [...arr1, 4, 5];  // [1, 2, 3, 4, 5]

const obj1 = { a: 1, b: 2 };
const obj2 = { ...obj1, c: 3 };  // { a: 1, b: 2, c: 3 }

// Template literals
const greeting = \`Hello, \${name}! You are \${age} years old.\`;
\`\`\``,
              exercises: ["Convert var declarations to let/const", "Use destructuring to extract values from nested objects", "Create functions using template literals for formatting"],
              reflection_prompts: ["When should you use const vs let?", "How does destructuring improve code readability?"]
            },
            {
              lesson_id: "js_2",
              title: "Functions and Arrow Functions",
              content: `JavaScript functions can be written in multiple ways.

**Function Declaration:**
\`\`\`javascript
function greet(name) {
    return \`Hello, \${name}!\`;
}
\`\`\`

**Arrow Functions:**
\`\`\`javascript
// Single parameter, single expression
const double = x => x * 2;

// Multiple parameters
const add = (a, b) => a + b;

// Multiple statements need curly braces
const calculate = (a, b) => {
    const sum = a + b;
    const product = a * b;
    return { sum, product };
};

// Arrow functions and 'this'
const obj = {
    name: "Alice",
    // Regular function - 'this' refers to obj
    sayHi: function() {
        console.log(\`Hi, I'm \${this.name}\`);
    },
    // Arrow function - 'this' is inherited
    sayHiArrow: () => {
        console.log(\`Hi, I'm \${this.name}\`);  // 'this' is not obj!
    }
};
\`\`\`

**Default Parameters:**
\`\`\`javascript
const greet = (name = "Guest") => \`Hello, \${name}!\`;
greet();        // "Hello, Guest!"
greet("Bob");   // "Hello, Bob!"
\`\`\``,
              exercises: ["Rewrite traditional functions as arrow functions", "Create a function that accepts another function as a parameter"],
              reflection_prompts: ["When should you use arrow functions vs regular functions?", "How does 'this' behave differently in arrow functions?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What's the difference between let and const?", type: "multiple_choice", options: ["No difference", "let can be reassigned, const cannot", "const is faster", "let is deprecated"], correct_answer: "let can be reassigned, const cannot", explanation: "const creates a constant binding that cannot be reassigned" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Modern JS Refactor", instructions: "Take legacy JavaScript code and refactor using ES6+ features", expected_outcome: "Clean, modern JavaScript code using best practices", time_estimate: "35 minutes" }
          ]
        }
      },
      {
        module_id: "js_async",
        title: "Asynchronous JavaScript",
        description: "Master promises, async/await, and API calls",
        duration_minutes: 90,
        skill_focus: "Async Programming",
        content: {
          learning_objectives: ["Understand the event loop", "Work with Promises", "Use async/await syntax", "Handle errors in async code"],
          key_concepts: ["Event Loop", "Callbacks", "Promises", "Async/Await", "Fetch API"],
          lessons: [
            {
              lesson_id: "js_async_1",
              title: "Promises and Async/Await",
              content: `Promises represent the eventual completion of an asynchronous operation.

**Creating Promises:**
\`\`\`javascript
const fetchData = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const success = true;
            if (success) {
                resolve({ data: "Hello!" });
            } else {
                reject(new Error("Failed to fetch"));
            }
        }, 1000);
    });
};

// Using .then()
fetchData()
    .then(result => console.log(result))
    .catch(error => console.error(error));
\`\`\`

**Async/Await:**
\`\`\`javascript
const getData = async () => {
    try {
        const result = await fetchData();
        console.log(result);
    } catch (error) {
        console.error(error);
    }
};

// Fetch API with async/await
const fetchUsers = async () => {
    try {
        const response = await fetch('https://api.example.com/users');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching users:', error);
    }
};

// Parallel requests
const fetchAll = async () => {
    const [users, posts] = await Promise.all([
        fetch('/api/users').then(r => r.json()),
        fetch('/api/posts').then(r => r.json())
    ]);
    return { users, posts };
};
\`\`\``,
              exercises: ["Convert callback-based code to promises", "Implement error handling with async/await", "Make parallel API calls with Promise.all"],
              reflection_prompts: ["How does async/await improve code readability?", "When would you use Promise.all vs sequential awaits?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What does await do?", type: "multiple_choice", options: ["Stops the program", "Waits for a promise to resolve", "Creates a new promise", "Catches errors"], correct_answer: "Waits for a promise to resolve", explanation: "await pauses async function execution until the promise settles" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "API Dashboard", instructions: "Build a dashboard that fetches data from multiple APIs and displays them", expected_outcome: "A working dashboard with error handling and loading states", time_estimate: "60 minutes" }
          ]
        }
      },
      {
        module_id: "js_dom",
        title: "DOM Manipulation",
        description: "Create interactive web pages by manipulating the DOM",
        duration_minutes: 75,
        skill_focus: "Web Interactivity",
        content: {
          learning_objectives: ["Select and modify DOM elements", "Handle events effectively", "Create elements dynamically", "Build interactive components"],
          key_concepts: ["DOM", "Events", "Event Delegation", "Dynamic Elements"],
          lessons: [
            {
              lesson_id: "js_dom_1",
              title: "Working with the DOM",
              content: `The DOM (Document Object Model) lets JavaScript interact with HTML.

**Selecting Elements:**
\`\`\`javascript
// Single element
const header = document.getElementById('header');
const title = document.querySelector('.title');

// Multiple elements
const buttons = document.querySelectorAll('button');
const items = document.getElementsByClassName('item');
\`\`\`

**Modifying Elements:**
\`\`\`javascript
// Content
element.textContent = 'New text';
element.innerHTML = '<strong>Bold text</strong>';

// Attributes
element.setAttribute('data-id', '123');
element.classList.add('active');
element.classList.toggle('hidden');

// Styles
element.style.color = 'red';
element.style.display = 'none';
\`\`\`

**Event Handling:**
\`\`\`javascript
// Adding event listeners
button.addEventListener('click', (event) => {
    console.log('Button clicked!');
    event.target.textContent = 'Clicked!';
});

// Event delegation
document.querySelector('.list').addEventListener('click', (e) => {
    if (e.target.matches('.item')) {
        console.log('Item clicked:', e.target.textContent);
    }
});
\`\`\`

**Creating Elements:**
\`\`\`javascript
const newDiv = document.createElement('div');
newDiv.textContent = 'Hello!';
newDiv.className = 'card';
document.body.appendChild(newDiv);
\`\`\``,
              exercises: ["Build a todo list with add/remove functionality", "Create a modal that opens and closes", "Implement form validation with real-time feedback"],
              reflection_prompts: ["Why is event delegation more efficient?", "What are the performance implications of DOM manipulation?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Which method selects multiple elements?", type: "multiple_choice", options: ["getElementById", "querySelector", "querySelectorAll", "getElement"], correct_answer: "querySelectorAll", explanation: "querySelectorAll returns a NodeList of all matching elements" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Interactive Gallery", instructions: "Build an image gallery with lightbox, navigation, and keyboard controls", expected_outcome: "A fully interactive image gallery component", time_estimate: "50 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "cloud_architecture",
    title: "Introduction to Cloud Architecture",
    description: "Learn cloud computing fundamentals with AWS, Azure, and GCP",
    category: "infrastructure",
    difficulty: "beginner",
    duration_hours: 18,
    icon: Cloud,
    color: "bg-cyan-600",
    skills: ["Cloud Computing", "AWS", "Architecture", "DevOps"],
    modules: [
      {
        module_id: "cloud_intro",
        title: "Cloud Computing Fundamentals",
        description: "Understand cloud concepts and service models",
        duration_minutes: 60,
        skill_focus: "Cloud Basics",
        content: {
          learning_objectives: ["Understand cloud service models (IaaS, PaaS, SaaS)", "Compare major cloud providers", "Learn cloud deployment models", "Understand cloud economics"],
          key_concepts: ["IaaS", "PaaS", "SaaS", "Public/Private/Hybrid Cloud", "Pay-as-you-go"],
          lessons: [
            {
              lesson_id: "cloud_1",
              title: "What is Cloud Computing?",
              content: `Cloud computing delivers computing services over the internet ("the cloud").

**Key Characteristics:**
- **On-demand self-service**: Provision resources without human interaction
- **Broad network access**: Available over the network
- **Resource pooling**: Multi-tenant model
- **Rapid elasticity**: Scale up or down quickly
- **Measured service**: Pay for what you use

**Service Models:**

**IaaS (Infrastructure as a Service):**
- Virtual machines, storage, networks
- You manage: OS, runtime, applications
- Examples: AWS EC2, Azure VMs, Google Compute Engine

**PaaS (Platform as a Service):**
- Platform for deploying applications
- Provider manages: infrastructure, OS, runtime
- Examples: Heroku, AWS Elastic Beanstalk, Google App Engine

**SaaS (Software as a Service):**
- Complete applications delivered via browser
- Provider manages everything
- Examples: Salesforce, Google Workspace, Microsoft 365

**Deployment Models:**
- **Public Cloud**: Resources shared among customers
- **Private Cloud**: Dedicated to single organization
- **Hybrid Cloud**: Combination of public and private`,
              exercises: ["Identify which service model fits different scenarios", "Compare pricing models of AWS, Azure, and GCP", "Design a simple architecture using IaaS components"],
              reflection_prompts: ["What factors influence cloud vs on-premises decisions?", "How does the shared responsibility model work?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Which service model provides the most control?", type: "multiple_choice", options: ["SaaS", "PaaS", "IaaS", "FaaS"], correct_answer: "IaaS", explanation: "IaaS provides virtual infrastructure where you control everything from OS upward" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Cloud Comparison", instructions: "Research and compare AWS, Azure, and GCP for a specific use case", expected_outcome: "A comparison document with recommendations", time_estimate: "45 minutes" }
          ]
        }
      },
      {
        module_id: "cloud_compute",
        title: "Compute Services",
        description: "Virtual machines, containers, and serverless computing",
        duration_minutes: 75,
        skill_focus: "Cloud Compute",
        content: {
          learning_objectives: ["Provision and manage virtual machines", "Understand containerization", "Implement serverless functions", "Choose the right compute service"],
          key_concepts: ["VMs", "Containers", "Serverless", "Auto-scaling", "Load Balancing"],
          lessons: [
            {
              lesson_id: "compute_1",
              title: "Virtual Machines and Containers",
              content: `Different compute options for different needs.

**Virtual Machines:**
- Full operating system with dedicated resources
- Good for: Legacy apps, full OS control, stateful applications

**AWS EC2 Instance Types:**
- t3.micro: 2 vCPU, 1 GB RAM - Development, testing
- m5.large: 2 vCPU, 8 GB RAM - General purpose
- c5.xlarge: 4 vCPU, 8 GB RAM - Compute intensive
- r5.large: 2 vCPU, 16 GB RAM - Memory intensive

**Containers (Docker):**
\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
\`\`\`

**Container Orchestration:**
- Kubernetes (EKS, AKS, GKE)
- Docker Swarm
- AWS ECS

**Serverless Functions:**
\`\`\`javascript
// AWS Lambda function
exports.handler = async (event) => {
    const name = event.queryStringParameters?.name || 'World';
    return {
        statusCode: 200,
        body: JSON.stringify({ message: \`Hello, \${name}!\` })
    };
};
\`\`\``,
              exercises: ["Launch an EC2 instance and SSH into it", "Create a Docker container for a simple web app", "Deploy a Lambda function that responds to HTTP requests"],
              reflection_prompts: ["When would you choose VMs over containers?", "What are the cold start implications of serverless?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What is the main advantage of containers over VMs?", type: "multiple_choice", options: ["More secure", "Lighter weight and faster startup", "Better performance", "Easier to manage"], correct_answer: "Lighter weight and faster startup", explanation: "Containers share the host OS kernel, making them much lighter than VMs" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Microservices Deployment", instructions: "Deploy a simple microservice using containers on a cloud platform", expected_outcome: "A running containerized application in the cloud", time_estimate: "60 minutes" }
          ]
        }
      },
      {
        module_id: "cloud_storage",
        title: "Storage and Databases",
        description: "Object storage, block storage, and managed databases",
        duration_minutes: 65,
        skill_focus: "Cloud Storage",
        content: {
          learning_objectives: ["Choose appropriate storage types", "Configure object storage", "Work with managed databases", "Implement data backup strategies"],
          key_concepts: ["Object Storage", "Block Storage", "RDS", "NoSQL", "Data Lifecycle"],
          lessons: [
            {
              lesson_id: "storage_1",
              title: "Cloud Storage Types",
              content: `Different storage services for different use cases.

**Object Storage (S3, Azure Blob, GCS):**
- Unlimited scalability
- Great for: Images, videos, backups, static websites
- Access via HTTP/HTTPS

**Block Storage (EBS, Azure Disks):**
- Attached to compute instances
- Great for: Databases, file systems
- High performance IOPS

**File Storage (EFS, Azure Files):**
- Shared file system
- Great for: Shared data, CMS, development environments

**Database Services:**

**Relational (SQL):**
- AWS RDS, Azure SQL, Cloud SQL
- MySQL, PostgreSQL, SQL Server

**NoSQL:**
- DynamoDB, CosmosDB, Firestore
- Key-value, document, graph databases

**S3 Example:**
\`\`\`javascript
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

// Upload file
await s3.putObject({
    Bucket: 'my-bucket',
    Key: 'uploads/image.jpg',
    Body: fileBuffer,
    ContentType: 'image/jpeg'
}).promise();

// Get signed URL
const url = s3.getSignedUrl('getObject', {
    Bucket: 'my-bucket',
    Key: 'uploads/image.jpg',
    Expires: 3600
});
\`\`\``,
              exercises: ["Create an S3 bucket and configure public access", "Set up lifecycle rules for data archiving", "Connect an application to RDS"],
              reflection_prompts: ["How do you choose between SQL and NoSQL?", "What factors affect storage costs?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Which storage type is best for serving static website files?", type: "multiple_choice", options: ["Block storage", "Object storage", "File storage", "Database"], correct_answer: "Object storage", explanation: "Object storage (like S3) is ideal for serving static files via HTTP" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Static Website Hosting", instructions: "Host a static website on S3/Azure Blob with custom domain and CDN", expected_outcome: "A live static website with fast global delivery", time_estimate: "45 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "data_analysis",
    title: "Data Analysis with Python",
    description: "Master pandas, numpy, and data visualization",
    category: "data",
    difficulty: "intermediate",
    duration_hours: 22,
    icon: BarChart3,
    color: "bg-green-600",
    skills: ["Python", "Pandas", "Data Analysis", "Visualization"],
    modules: [
      {
        module_id: "data_pandas",
        title: "Pandas Fundamentals",
        description: "Master data manipulation with pandas",
        duration_minutes: 90,
        skill_focus: "Data Manipulation",
        content: {
          learning_objectives: ["Create and manipulate DataFrames", "Clean and transform data", "Aggregate and group data", "Handle missing values"],
          key_concepts: ["DataFrames", "Series", "Indexing", "GroupBy", "Merging"],
          lessons: [
            {
              lesson_id: "pandas_1",
              title: "Working with DataFrames",
              content: `Pandas DataFrames are the foundation of data analysis in Python.

**Creating DataFrames:**
\`\`\`python
import pandas as pd

# From dictionary
df = pd.DataFrame({
    'name': ['Alice', 'Bob', 'Charlie'],
    'age': [25, 30, 35],
    'city': ['NYC', 'LA', 'Chicago']
})

# From CSV
df = pd.read_csv('data.csv')
\`\`\`

**Basic Operations:**
\`\`\`python
# View data
df.head()           # First 5 rows
df.tail(10)         # Last 10 rows
df.info()           # Column types and non-null counts
df.describe()       # Statistical summary

# Selecting columns
df['name']          # Single column (Series)
df[['name', 'age']] # Multiple columns (DataFrame)

# Filtering
df[df['age'] > 25]
df[(df['age'] > 25) & (df['city'] == 'NYC')]
df.query('age > 25 and city == "NYC"')
\`\`\`

**Data Manipulation:**
\`\`\`python
# Adding columns
df['birth_year'] = 2024 - df['age']

# Applying functions
df['name_upper'] = df['name'].apply(str.upper)
df['age_group'] = df['age'].apply(lambda x: 'Young' if x < 30 else 'Adult')

# Sorting
df.sort_values('age', ascending=False)

# Grouping
df.groupby('city')['age'].mean()
df.groupby('city').agg({'age': ['mean', 'min', 'max']})
\`\`\``,
              exercises: ["Load a CSV and explore its structure", "Filter data based on multiple conditions", "Create summary statistics grouped by category"],
              reflection_prompts: ["How does pandas compare to SQL for data manipulation?", "What are the memory implications of large DataFrames?"]
            }
          ],
          assessment: {
            questions: [
              { question: "How do you select rows where age > 30?", type: "multiple_choice", options: ["df.age > 30", "df[df['age'] > 30]", "df.filter(age > 30)", "df.where(age > 30)"], correct_answer: "df[df['age'] > 30]", explanation: "Boolean indexing with df[condition] filters rows" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Sales Analysis", instructions: "Analyze a sales dataset to find top products, seasonal trends, and customer segments", expected_outcome: "A comprehensive analysis with insights and visualizations", time_estimate: "60 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "leadership_essentials",
    title: "Leadership Essentials",
    description: "Develop core leadership skills for managing teams effectively",
    category: "leadership",
    difficulty: "beginner",
    duration_hours: 15,
    icon: Users,
    color: "bg-orange-600",
    skills: ["Leadership", "Communication", "Team Management"],
    modules: [
      {
        module_id: "lead_comm",
        title: "Effective Communication",
        description: "Master the art of clear, impactful communication",
        duration_minutes: 60,
        skill_focus: "Communication",
        content: {
          learning_objectives: ["Adapt communication style to audience", "Give and receive feedback effectively", "Lead productive meetings", "Handle difficult conversations"],
          key_concepts: ["Active Listening", "Feedback", "Meeting Facilitation", "Conflict Resolution"],
          lessons: [
            {
              lesson_id: "comm_1",
              title: "Active Listening and Feedback",
              content: `Great leaders are great communicators - and that starts with listening.

**Active Listening:**
- Give full attention
- Show you're listening (nodding, eye contact)
- Defer judgment
- Respond appropriately
- Ask clarifying questions

**The SBI Feedback Model:**
- **Situation**: Describe the specific situation
- **Behavior**: Describe the observed behavior
- **Impact**: Explain the impact of that behavior

**Example:**
"In yesterday's team meeting (Situation), when you interrupted Sarah twice while she was presenting (Behavior), it made her lose her train of thought and the team missed important context (Impact)."

**Receiving Feedback:**
1. Listen without defending
2. Ask clarifying questions
3. Thank the person
4. Reflect on the feedback
5. Take action

**Difficult Conversations Framework:**
1. **Prepare**: Know your goal, anticipate reactions
2. **Open**: State purpose clearly and calmly
3. **Listen**: Understand their perspective
4. **Explore**: Find common ground
5. **Close**: Agree on next steps`,
              exercises: ["Practice the SBI model on a recent situation", "Have a peer observe your listening skills", "Prepare for a difficult conversation using the framework"],
              reflection_prompts: ["What barriers prevent you from listening actively?", "How do you typically react to negative feedback?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What does 'I' stand for in the SBI feedback model?", type: "multiple_choice", options: ["Intention", "Impact", "Improvement", "Issue"], correct_answer: "Impact", explanation: "SBI stands for Situation, Behavior, Impact" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Feedback Practice", instructions: "Give feedback to a colleague using the SBI model and document the conversation", expected_outcome: "A documented feedback conversation with reflection on what went well", time_estimate: "30 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "machine_learning",
    title: "Machine Learning Fundamentals",
    description: "Introduction to ML algorithms and practical applications",
    category: "data",
    difficulty: "advanced",
    duration_hours: 30,
    icon: Brain,
    color: "bg-pink-600",
    skills: ["Machine Learning", "Python", "scikit-learn", "Data Science"],
    modules: [
      {
        module_id: "ml_intro",
        title: "ML Foundations",
        description: "Understand core ML concepts and workflows",
        duration_minutes: 75,
        skill_focus: "ML Concepts",
        content: {
          learning_objectives: ["Understand supervised vs unsupervised learning", "Prepare data for ML models", "Train and evaluate models", "Avoid common pitfalls"],
          key_concepts: ["Supervised Learning", "Unsupervised Learning", "Training/Test Split", "Overfitting", "Cross-validation"],
          lessons: [
            {
              lesson_id: "ml_1",
              title: "Introduction to Machine Learning",
              content: `Machine learning enables computers to learn from data without explicit programming.

**Types of ML:**

**Supervised Learning:**
- Training data includes labels/answers
- Classification: Predict categories (spam/not spam)
- Regression: Predict continuous values (price, temperature)

**Unsupervised Learning:**
- No labels in training data
- Clustering: Group similar items
- Dimensionality reduction: Simplify data

**The ML Workflow:**
\`\`\`python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# 1. Load and explore data
import pandas as pd
df = pd.read_csv('data.csv')

# 2. Prepare features and target
X = df[['feature1', 'feature2', 'feature3']]
y = df['target']

# 3. Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 4. Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. Train model
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# 6. Evaluate
predictions = model.predict(X_test_scaled)
accuracy = accuracy_score(y_test, predictions)
print(f"Accuracy: {accuracy:.2%}")
\`\`\`

**Avoiding Overfitting:**
- Use train/test split
- Cross-validation
- Regularization
- Keep models simple`,
              exercises: ["Build a classifier to predict customer churn", "Compare different algorithms on the same dataset", "Implement cross-validation for more robust evaluation"],
              reflection_prompts: ["How do you know if a model is overfitting?", "What factors determine which algorithm to use?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What type of problem is predicting house prices?", type: "multiple_choice", options: ["Classification", "Regression", "Clustering", "Reinforcement Learning"], correct_answer: "Regression", explanation: "Predicting continuous values like prices is a regression problem" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "End-to-End ML Project", instructions: "Build a complete ML pipeline from data loading to model evaluation", expected_outcome: "A trained model with documented performance metrics", time_estimate: "90 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "accounting_fundamentals",
    title: "Accounting Fundamentals",
    description: "Master the basics of accounting from debits and credits to financial statements",
    category: "accounting",
    difficulty: "beginner",
    duration_hours: 16,
    icon: Calculator,
    color: "bg-emerald-600",
    skills: ["Accounting", "Financial Statements", "Bookkeeping", "Excel"],
    modules: [
      {
        module_id: "acct_basics",
        title: "Introduction to Accounting",
        description: "Understand the fundamental principles and concepts of accounting",
        duration_minutes: 60,
        skill_focus: "Accounting Basics",
        content: {
          learning_objectives: ["Understand the accounting equation", "Learn debits and credits", "Know the types of accounts", "Create T-accounts"],
          key_concepts: ["Assets", "Liabilities", "Equity", "Debits", "Credits", "Double-entry"],
          lessons: [
            {
              lesson_id: "acct_1",
              title: "The Accounting Equation",
              content: `The foundation of all accounting is the accounting equation:

**Assets = Liabilities + Equity**

This equation MUST always balance. Every transaction affects at least two accounts.

**What Are Assets?**
Resources owned by the business:
- 💵 Cash
- 📦 Inventory
- 🏢 Equipment
- 🚗 Vehicles
- 📝 Accounts Receivable (money owed TO you)

**What Are Liabilities?**
Obligations owed to others:
- 💳 Accounts Payable (money YOU owe)
- 🏦 Loans Payable
- 📅 Unearned Revenue

**What Is Equity?**
Owner's claim on assets:
- 💰 Owner's Capital (money invested)
- 📈 Retained Earnings (profits kept in business)
- 📊 Revenue - Expenses = Net Income

**Example Transaction:**
You start a business with $10,000 cash:
- Assets (Cash) ↑ $10,000
- Equity (Owner's Capital) ↑ $10,000
- $10,000 = $0 + $10,000 ✓ BALANCED!

**Try This! 🎯**
You buy equipment for $2,000 cash:
- Assets (Equipment) ↑ $2,000
- Assets (Cash) ↓ $2,000
- Net effect on Assets = $0
- Still balanced! ✓`,
              exercises: ["Identify whether each item is an Asset, Liability, or Equity", "Calculate total Assets given Liabilities of $5,000 and Equity of $15,000", "List 5 assets and 5 liabilities a restaurant would have"],
              reflection_prompts: ["Why must the accounting equation always balance?", "How would taking a loan affect each part of the equation?"]
            },
            {
              lesson_id: "acct_2",
              title: "Debits and Credits - The Fun Way!",
              content: `Think of debits and credits as the "left" and "right" sides of an account. Every transaction has EQUAL debits and credits!

**The Rules (memorize these! 🧠):**

| Account Type | Debit (Left) | Credit (Right) |
|--------------|--------------|----------------|
| Assets       | ↑ Increase   | ↓ Decrease     |
| Liabilities  | ↓ Decrease   | ↑ Increase     |
| Equity       | ↓ Decrease   | ↑ Increase     |
| Revenue      | ↓ Decrease   | ↑ Increase     |
| Expenses     | ↑ Increase   | ↓ Decrease     |

**Memory Trick: "DEALER"**
- **D**ividends - Debit to increase
- **E**xpenses - Debit to increase
- **A**ssets - Debit to increase
- **L**iabilities - Credit to increase
- **E**quity - Credit to increase
- **R**evenue - Credit to increase

**Journal Entry Example:**
Purchased supplies for $500 cash:
\`\`\`
Date: Jan 15
Dr. Supplies (Asset)         $500
    Cr. Cash (Asset)              $500
\`\`\`

**T-Account Format:**
\`\`\`
       Supplies                    Cash
    ____________              ____________
    |     |     |             |     |     |
Dr. |500  |     | Cr.     Dr. |     | 500 | Cr.
    |_____|_____|             |_____|_____|
\`\`\`

**Practice Entry - Customer pays you $1,000:**
\`\`\`
Dr. Cash (Asset ↑)           $1,000
    Cr. Service Revenue              $1,000
\`\`\``,
              exercises: ["Record a journal entry for paying $200 rent", "Create T-accounts for a $5,000 bank loan", "Identify which entries are debits vs credits in a list of transactions"],
              reflection_prompts: ["Why do expenses have opposite rules from revenue?", "What happens if debits don't equal credits?"]
            }
          ],
          assessment: {
            questions: [
              { question: "In the accounting equation, what equals Assets?", type: "multiple_choice", options: ["Revenue + Expenses", "Liabilities + Equity", "Debits + Credits", "Income - Expenses"], correct_answer: "Liabilities + Equity", explanation: "Assets = Liabilities + Equity is the fundamental accounting equation" },
              { question: "To increase an Asset account, you...", type: "multiple_choice", options: ["Credit it", "Debit it", "Close it", "Reverse it"], correct_answer: "Debit it", explanation: "Assets increase with debits (left side)" },
              { question: "Which memory trick helps remember debit-increase accounts?", type: "multiple_choice", options: ["DEALER", "ALOE", "GAAP", "FIFO"], correct_answer: "DEALER", explanation: "DEALER: Dividends, Expenses, Assets all increase with Debits" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Week in the Life", instructions: "Record journal entries for these transactions: 1) Owner invests $20,000, 2) Buy equipment $5,000 cash, 3) Receive $3,000 for services, 4) Pay $800 rent, 5) Buy supplies on credit $400", expected_outcome: "Five complete journal entries with correct debits and credits", time_estimate: "25 minutes" }
          ]
        }
      },
      {
        module_id: "acct_statements",
        title: "Financial Statements",
        description: "Learn to read and create the four main financial statements",
        duration_minutes: 75,
        skill_focus: "Financial Reporting",
        content: {
          learning_objectives: ["Create an income statement", "Build a balance sheet", "Understand statement of cash flows", "Connect all financial statements"],
          key_concepts: ["Income Statement", "Balance Sheet", "Cash Flow Statement", "Statement of Equity"],
          lessons: [
            {
              lesson_id: "stmt_1",
              title: "The Income Statement (Profit & Loss)",
              content: `The Income Statement shows profitability over a period of time.

**The Formula:**
Revenue - Expenses = Net Income (or Net Loss)

**Income Statement Structure:**
\`\`\`
SUNSHINE BAKERY
Income Statement
For the Month Ended January 31, 2024

REVENUE:
  Sales Revenue                    $25,000
  Service Revenue                   $3,000
    Total Revenue                           $28,000

EXPENSES:
  Cost of Goods Sold              $10,000
  Rent Expense                     $2,500
  Salaries Expense                 $8,000
  Utilities Expense                  $500
  Supplies Expense                   $300
    Total Expenses                          $21,300

NET INCOME                                   $6,700
                                            ========
\`\`\`

**Key Terms:**
- 📈 **Gross Profit** = Revenue - Cost of Goods Sold
- 💰 **Operating Income** = Gross Profit - Operating Expenses
- 🎯 **Net Income** = Total Revenue - Total Expenses

**Fun Fact! 🎉**
Amazon didn't report a profit for years but became one of the most valuable companies! Investors believed in future growth.`,
              exercises: ["Create an income statement from a list of revenues and expenses", "Calculate gross profit margin percentage", "Identify which items go on income statement vs balance sheet"],
              reflection_prompts: ["What does negative net income tell you about a business?", "Why might a profitable company still fail?"]
            },
            {
              lesson_id: "stmt_2",
              title: "The Balance Sheet",
              content: `The Balance Sheet shows financial position at a specific point in time.

**Remember:** Assets = Liabilities + Equity

**Balance Sheet Structure:**
\`\`\`
SUNSHINE BAKERY
Balance Sheet
As of January 31, 2024

ASSETS
Current Assets:
  Cash                             $15,000
  Accounts Receivable               $3,000
  Inventory                         $5,000
  Supplies                            $500
    Total Current Assets                    $23,500

Non-Current Assets:
  Equipment                        $20,000
  Less: Accumulated Depreciation   ($2,000)
    Net Equipment                           $18,000

TOTAL ASSETS                               $41,500
                                           ========

LIABILITIES
Current Liabilities:
  Accounts Payable                  $4,000
  Salaries Payable                  $1,500
    Total Current Liabilities               $5,500

Long-Term Liabilities:
  Notes Payable                    $10,000
    Total Liabilities                      $15,500

EQUITY
  Owner's Capital                  $20,000
  Retained Earnings                 $6,000
    Total Equity                           $26,000

TOTAL LIABILITIES & EQUITY                 $41,500
                                           ========
\`\`\`

**Balance Sheet Tips:**
- ⚖️ It MUST balance!
- 📅 "As of" specific date
- 💡 Current = converts to cash within 1 year`,
              exercises: ["Classify accounts as current or non-current", "Create a balance sheet from a trial balance", "Calculate working capital (Current Assets - Current Liabilities)"],
              reflection_prompts: ["What does a high debt-to-equity ratio tell investors?", "Why is the balance sheet a 'snapshot' while income statement is a 'movie'?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Which statement shows profitability over time?", type: "multiple_choice", options: ["Balance Sheet", "Income Statement", "Cash Flow Statement", "Trial Balance"], correct_answer: "Income Statement", explanation: "The Income Statement shows Revenue - Expenses = Net Income over a period" },
              { question: "Current Assets are expected to convert to cash within...", type: "multiple_choice", options: ["30 days", "6 months", "1 year", "5 years"], correct_answer: "1 year", explanation: "Current assets are expected to be used or converted to cash within one year" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Financial Statement Creation", instructions: "Given a list of 20 accounts with balances, create both an Income Statement and Balance Sheet", expected_outcome: "Two properly formatted financial statements that connect through Net Income", time_estimate: "40 minutes" }
          ]
        }
      },
      {
        module_id: "acct_analysis",
        title: "Financial Analysis Basics",
        description: "Learn to analyze financial health using ratios and metrics",
        duration_minutes: 55,
        skill_focus: "Financial Analysis",
        content: {
          learning_objectives: ["Calculate key financial ratios", "Interpret ratio results", "Compare companies using ratios", "Identify financial red flags"],
          key_concepts: ["Liquidity Ratios", "Profitability Ratios", "Leverage Ratios", "Efficiency Ratios"],
          lessons: [
            {
              lesson_id: "analysis_1",
              title: "Essential Financial Ratios",
              content: `Ratios help you understand the story behind the numbers!

**Liquidity Ratios - Can they pay bills? 💧**

**Current Ratio:**
\`\`\`
Current Assets / Current Liabilities

Example: $50,000 / $25,000 = 2.0
Meaning: $2 of current assets for every $1 owed
Good: > 1.5   ⚠️ Warning: < 1.0
\`\`\`

**Quick Ratio (Acid Test):**
\`\`\`
(Current Assets - Inventory) / Current Liabilities

Stricter test - excludes inventory!
\`\`\`

**Profitability Ratios - Are they making money? 💰**

**Gross Profit Margin:**
\`\`\`
(Revenue - COGS) / Revenue × 100

Example: ($100,000 - $60,000) / $100,000 = 40%
\`\`\`

**Net Profit Margin:**
\`\`\`
Net Income / Revenue × 100

Example: $15,000 / $100,000 = 15%
Apple: ~25%  Walmart: ~2%  Why the difference? 🤔
\`\`\`

**Return on Equity (ROE):**
\`\`\`
Net Income / Shareholders' Equity × 100

Measures return on owner's investment
Warren Buffett looks for ROE > 15%
\`\`\`

**Leverage Ratios - How much debt? 📊**

**Debt-to-Equity:**
\`\`\`
Total Liabilities / Total Equity

< 1.0 = Conservative  > 2.0 = Aggressive
\`\`\`

**Quick Challenge! 🎯**
Company A: Revenue $500K, Net Income $50K
Company B: Revenue $2M, Net Income $100K
Which is more profitable? (Hint: Calculate margins!)`,
              exercises: ["Calculate all ratios for a sample company", "Compare two competitors using ratio analysis", "Identify which ratios a banker would focus on for a loan"],
              reflection_prompts: ["Why might a company have high revenue but low profit margins?", "How would you use ratios to decide whether to invest in a company?"]
            }
          ],
          assessment: {
            questions: [
              { question: "A current ratio of 0.8 means...", type: "multiple_choice", options: ["Company is very profitable", "Company may struggle to pay short-term debts", "Company has too much inventory", "Company has no liabilities"], correct_answer: "Company may struggle to pay short-term debts", explanation: "Current ratio < 1 means current liabilities exceed current assets" },
              { question: "Which ratio measures return on owner's investment?", type: "multiple_choice", options: ["Current Ratio", "Debt-to-Equity", "ROE", "Gross Margin"], correct_answer: "ROE", explanation: "Return on Equity (ROE) = Net Income / Shareholders' Equity" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Company Health Check", instructions: "Download financial statements for a public company and calculate 10 key ratios. Write a one-page analysis of their financial health.", expected_outcome: "A ratio analysis report with interpretations and recommendations", time_estimate: "60 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "managerial_accounting",
    title: "Managerial Accounting",
    description: "Learn cost accounting, budgeting, and decision-making tools for managers",
    category: "accounting",
    difficulty: "intermediate",
    duration_hours: 20,
    icon: Calculator,
    color: "bg-teal-600",
    skills: ["Cost Accounting", "Budgeting", "CVP Analysis", "Decision Making"],
    modules: [
      {
        module_id: "cost_basics",
        title: "Cost Behavior and Analysis",
        description: "Understand how costs behave and how to analyze them",
        duration_minutes: 70,
        skill_focus: "Cost Analysis",
        content: {
          learning_objectives: ["Classify costs by behavior", "Calculate contribution margin", "Perform break-even analysis", "Use CVP for decision making"],
          key_concepts: ["Fixed Costs", "Variable Costs", "Mixed Costs", "Contribution Margin", "Break-even Point"],
          lessons: [
            {
              lesson_id: "cost_1",
              title: "Understanding Cost Behavior",
              content: `Different costs behave differently as activity changes!

**Fixed Costs - Don't change with volume 🏢**
- Rent: $5,000/month whether you sell 1 or 1,000 units
- Salaries (fixed employees)
- Insurance
- Depreciation

**Per Unit:** Fixed costs decrease per unit as volume increases!
\`\`\`
1,000 units: $5,000 / 1,000 = $5.00 per unit
5,000 units: $5,000 / 5,000 = $1.00 per unit
\`\`\`

**Variable Costs - Change with volume 📦**
- Materials: More products = more materials
- Direct labor (hourly workers)
- Sales commissions
- Shipping costs

**Per Unit:** Variable costs stay constant per unit!
\`\`\`
Materials: $10 per unit
1,000 units: $10,000 total
5,000 units: $50,000 total
\`\`\`

**Mixed Costs - Part fixed, part variable 📱**
- Utilities: Base charge + usage
- Phone: Monthly fee + per-minute charges
- Car rental: Daily rate + per-mile fee

**The High-Low Method to Split Mixed Costs:**
\`\`\`
January: 10,000 miles, $1,500 cost
June: 25,000 miles, $2,625 cost

Variable rate = ($2,625 - $1,500) / (25,000 - 10,000)
             = $1,125 / 15,000 miles
             = $0.075 per mile

Fixed cost = $1,500 - ($0.075 × 10,000)
           = $1,500 - $750 = $750/month
\`\`\``,
              exercises: ["Classify a list of 15 costs as fixed, variable, or mixed", "Calculate variable cost per unit from given data", "Use high-low method on a new dataset"],
              reflection_prompts: ["How can understanding cost behavior help managers make better decisions?", "Why might a 'fixed' cost actually change over time?"]
            },
            {
              lesson_id: "cost_2",
              title: "CVP Analysis - The Magic Numbers! 🎯",
              content: `Cost-Volume-Profit analysis helps answer: "What if...?"

**Key Terms:**
\`\`\`
Selling Price per Unit              $50
Variable Cost per Unit              $30
Contribution Margin per Unit        $20  (SP - VC)
Contribution Margin Ratio           40%  ($20 / $50)
Fixed Costs                         $100,000
\`\`\`

**Break-Even Point - Where profit = $0**

**In Units:**
\`\`\`
Break-Even Units = Fixed Costs / CM per Unit
                 = $100,000 / $20
                 = 5,000 units
\`\`\`

**In Dollars:**
\`\`\`
Break-Even Sales = Fixed Costs / CM Ratio
                 = $100,000 / 0.40
                 = $250,000
\`\`\`

**Target Profit Analysis - "How many to make $50,000 profit?"**
\`\`\`
Units Needed = (Fixed Costs + Target Profit) / CM per Unit
             = ($100,000 + $50,000) / $20
             = 7,500 units
\`\`\`

**What-If Scenarios:**
📊 What if we raise price $5? New CM = $25, Break-even = 4,000 units!
📊 What if we cut fixed costs by $20,000? Break-even = 4,000 units!
📊 What if variable costs increase $2? New CM = $18, Break-even = 5,556 units!

**Margin of Safety - How much cushion?**
\`\`\`
Current Sales: 8,000 units
Break-Even: 5,000 units
Margin of Safety = 3,000 units (37.5%)

You can lose 37.5% of sales before losing money!
\`\`\``,
              exercises: ["Calculate break-even for a new product launch", "Perform sensitivity analysis on three scenarios", "Determine target profit units for quarterly goals"],
              reflection_prompts: ["Why is contribution margin more useful than gross margin for decisions?", "How would you use CVP analysis to evaluate a price change?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Contribution Margin equals...", type: "multiple_choice", options: ["Revenue - Fixed Costs", "Revenue - Variable Costs", "Variable Costs - Fixed Costs", "Profit / Revenue"], correct_answer: "Revenue - Variable Costs", explanation: "CM = Selling Price - Variable Costs, showing what's left to cover fixed costs and profit" },
              { question: "At break-even, profit is...", type: "multiple_choice", options: ["Maximized", "Zero", "Equal to fixed costs", "Equal to variable costs"], correct_answer: "Zero", explanation: "Break-even is where Total Revenue = Total Costs, so Profit = $0" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Product Launch Analysis", instructions: "A company wants to launch a product: Price $75, Variable cost $45, Fixed costs $180,000. Calculate break-even, units for $60,000 profit, and margin of safety at 8,000 units sold.", expected_outcome: "Complete CVP analysis with recommendations", time_estimate: "35 minutes" }
          ]
        }
      },
      {
        module_id: "budgeting",
        title: "Budgeting and Planning",
        description: "Create comprehensive budgets for business planning",
        duration_minutes: 80,
        skill_focus: "Budgeting",
        content: {
          learning_objectives: ["Create master budgets", "Build sales and production budgets", "Prepare cash budgets", "Analyze budget variances"],
          key_concepts: ["Master Budget", "Operating Budget", "Cash Budget", "Variance Analysis"],
          lessons: [
            {
              lesson_id: "budget_1",
              title: "The Master Budget",
              content: `A Master Budget is the company's complete financial plan!

**Budget Hierarchy:**
\`\`\`
                    Sales Budget (Start here!)
                          |
         _________________|_________________
         |                |                 |
    Production      Selling &        Administrative
      Budget        Distribution         Budget
         |             Budget
    _____|_____
    |    |    |
  DM   DL   MOH
Budget Budget Budget
         |
    Cost of Goods
    Sold Budget
         |
    _______|_______
    |             |
 Income       Cash
Statement    Budget
    |             |
    |_______|_____|
          |
    Balance Sheet
\`\`\`

**Sales Budget - The Foundation:**
\`\`\`
                Q1      Q2      Q3      Q4     Total
Expected Sales  1,000   1,200   1,500   1,300   5,000
× Price         $100    $100    $100    $100
Total Revenue   $100K   $120K   $150K   $130K   $500K
\`\`\`

**Production Budget:**
\`\`\`
                Q1      Q2      Q3      Q4
Expected Sales  1,000   1,200   1,500   1,300
+ Desired End Inv.  240     300     260     200
= Total Needed  1,240   1,500   1,760   1,500
- Beginning Inv.  200     240     300     260
= Units to Produce 1,040  1,260   1,460   1,240
\`\`\`

**Desired Ending Inventory = 20% of next period's sales**
(This is a common policy to avoid stockouts!)`,
              exercises: ["Create a sales budget from marketing forecasts", "Build a production budget with inventory policies", "Prepare a direct materials purchases budget"],
              reflection_prompts: ["Why start with the sales budget?", "How do you balance the cost of holding inventory vs stockout risks?"]
            },
            {
              lesson_id: "budget_2",
              title: "Cash Budget - Managing the Lifeblood",
              content: `Cash is king! 👑 Profitable companies can still fail without cash.

**Cash Budget Structure:**
\`\`\`
BAKER COMPANY
Cash Budget - Quarter 1

CASH RECEIPTS:
  Cash sales                           $30,000
  Collections from credit sales        $85,000
  Sale of equipment                     $5,000
    Total Cash Receipts                        $120,000

CASH DISBURSEMENTS:
  Direct materials purchases           $45,000
  Direct labor                         $25,000
  Manufacturing overhead               $15,000
  Selling & administrative             $12,000
  Equipment purchase                   $20,000
  Income tax payment                    $8,000
    Total Cash Disbursements                   $125,000

NET CASH FLOW                                  ($5,000)

Beginning Cash Balance                          $20,000
Net Cash Flow                                   ($5,000)
                                               ________
Ending Cash Balance                             $15,000

Minimum Cash Required                           $10,000
Excess (Shortfall)                              $5,000
\`\`\`

**Collection Pattern for Credit Sales:**
\`\`\`
Month of Sale:     20% collected
Month After:       50% collected
Two Months After:  28% collected
Uncollectible:      2%

January Sales $100,000:
  January: $20,000
  February: $50,000
  March: $28,000
  Bad Debt: $2,000
\`\`\`

**Cash Management Tips:**
- 💡 Offer early payment discounts to speed collections
- 📅 Negotiate longer payment terms with suppliers
- 🏦 Arrange line of credit for seasonal shortfalls
- 📊 Update cash budget weekly during tight periods`,
              exercises: ["Create a cash budget with collection patterns", "Identify months requiring borrowing", "Suggest cash management improvements"],
              reflection_prompts: ["Why might a growing company face cash problems?", "How do seasonal businesses manage cash flow?"]
            }
          ],
          assessment: {
            questions: [
              { question: "Which budget is prepared first?", type: "multiple_choice", options: ["Production Budget", "Cash Budget", "Sales Budget", "Materials Budget"], correct_answer: "Sales Budget", explanation: "Everything flows from expected sales - it's the starting point!" },
              { question: "A company collects 60% of credit sales in the month of sale. January credit sales are $50,000. January collections from January sales are...", type: "multiple_choice", options: ["$50,000", "$30,000", "$20,000", "$0"], correct_answer: "$30,000", explanation: "$50,000 × 60% = $30,000" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Quarterly Budget Package", instructions: "Create a complete quarterly budget package including sales, production, materials, labor, overhead, and cash budgets for a manufacturing company.", expected_outcome: "An integrated set of budgets that link together logically", time_estimate: "75 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "excel_accounting",
    title: "Excel for Accountants",
    description: "Master Excel skills specifically for accounting and financial analysis",
    category: "accounting",
    difficulty: "beginner",
    duration_hours: 14,
    icon: Calculator,
    color: "bg-green-700",
    skills: ["Excel", "Financial Modeling", "Pivot Tables", "Data Analysis"],
    modules: [
      {
        module_id: "excel_basics",
        title: "Excel Fundamentals for Accounting",
        description: "Essential Excel skills every accountant needs",
        duration_minutes: 65,
        skill_focus: "Excel Basics",
        content: {
          learning_objectives: ["Navigate Excel efficiently", "Use essential functions", "Format financial data", "Create professional reports"],
          key_concepts: ["Formulas", "Functions", "Formatting", "Absolute References"],
          lessons: [
            {
              lesson_id: "excel_1",
              title: "Essential Accounting Functions",
              content: `These functions will save you HOURS every week! ⏰

**SUM, AVERAGE, COUNT:**
\`\`\`excel
=SUM(B2:B100)        Total all values
=AVERAGE(B2:B100)    Calculate mean
=COUNT(B2:B100)      Count numbers
=COUNTA(B2:B100)     Count non-empty cells
\`\`\`

**SUMIF and SUMIFS - Conditional Sums:**
\`\`\`excel
=SUMIF(A:A,"Marketing",B:B)
Sum column B where column A = "Marketing"

=SUMIFS(C:C,A:A,"2024",B:B,"Expense")
Sum column C where A="2024" AND B="Expense"
\`\`\`

**VLOOKUP and XLOOKUP:**
\`\`\`excel
=VLOOKUP(A2,Products!A:D,3,FALSE)
Find A2 in Products sheet, return column 3

=XLOOKUP(A2,Products!A:A,Products!C:C)
Modern version - more flexible!
\`\`\`

**IF Statements for Logic:**
\`\`\`excel
=IF(B2>1000,"Large","Small")

=IF(A2="Y",B2*0.1,0)
If approved, calculate 10% commission

Nested IF:
=IF(A2>=90,"A",IF(A2>=80,"B",IF(A2>=70,"C","F")))
\`\`\`

**Absolute vs Relative References:**
\`\`\`excel
=A1*B1      Both change when copied
=A1*$B$1    B1 stays fixed (tax rate cell)
=$A1*B$1    A column and row 1 stay fixed
\`\`\`

**Pro Tip! 💡**
Press F4 to cycle through reference types!`,
              exercises: ["Create a commission calculator using IF and absolute references", "Build a summary using SUMIFS by department and month", "Look up product prices using VLOOKUP"],
              reflection_prompts: ["When should you use SUMIFS vs a pivot table?", "Why are absolute references important for financial models?"]
            },
            {
              lesson_id: "excel_2",
              title: "Financial Functions That Accountants Love",
              content: `These specialized functions are accounting superpowers! 💪

**PMT - Loan Payments:**
\`\`\`excel
=PMT(rate, nper, pv)
=PMT(5%/12, 360, -250000)
Monthly payment on $250K loan, 5% rate, 30 years
Result: $1,342.05

rate = Annual rate / payments per year
nper = Total number of payments
pv = Present value (loan amount, negative)
\`\`\`

**FV - Future Value:**
\`\`\`excel
=FV(rate, nper, pmt, [pv])
=FV(7%/12, 240, -500)
Save $500/month for 20 years at 7%
Result: $260,464!
\`\`\`

**NPV - Net Present Value:**
\`\`\`excel
=NPV(rate, cash_flows) + initial_investment
=NPV(10%, B2:B6) + B1

Initial Investment: -$100,000
Year 1-5 Cash Flows: $30,000 each
NPV = $13,724 (Good investment!)
\`\`\`

**IRR - Internal Rate of Return:**
\`\`\`excel
=IRR(B1:B6)
Returns the rate where NPV = 0

If IRR > your required return, invest!
\`\`\`

**Depreciation Functions:**
\`\`\`excel
=SLN(cost, salvage, life)
=SLN(50000, 5000, 5)
Straight-line: $9,000 per year

=DB(cost, salvage, life, period)
Declining balance method

=SYD(cost, salvage, life, period)
Sum-of-years-digits
\`\`\`

**EOMONTH - End of Month:**
\`\`\`excel
=EOMONTH(A1, 0)    End of current month
=EOMONTH(A1, 1)    End of next month
=EOMONTH(A1, -1)   End of last month
\`\`\``,
              exercises: ["Calculate monthly mortgage payment and total interest", "Evaluate an investment using NPV and IRR", "Create a depreciation schedule using SLN"],
              reflection_prompts: ["How does changing the discount rate affect NPV?", "When would you use declining balance vs straight-line depreciation?"]
            }
          ],
          assessment: {
            questions: [
              { question: "=PMT(6%/12, 60, -20000) calculates...", type: "multiple_choice", options: ["Annual payment on $20K loan", "Monthly payment on $20K loan over 5 years", "Future value of $20K", "Interest on $20K"], correct_answer: "Monthly payment on $20K loan over 5 years", explanation: "6%/12 = monthly rate, 60 = 5 years × 12 months, -20000 = loan amount" },
              { question: "Which function returns the rate where NPV equals zero?", type: "multiple_choice", options: ["NPV", "IRR", "FV", "PMT"], correct_answer: "IRR", explanation: "Internal Rate of Return (IRR) is the discount rate that makes NPV = 0" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Loan Amortization Schedule", instructions: "Create a complete loan amortization schedule showing payment, principal, interest, and balance for each period", expected_outcome: "A dynamic amortization table that updates when you change loan parameters", time_estimate: "45 minutes" }
          ]
        }
      },
      {
        module_id: "excel_pivot",
        title: "Pivot Tables for Financial Analysis",
        description: "Master pivot tables for powerful financial reporting",
        duration_minutes: 60,
        skill_focus: "Pivot Tables",
        content: {
          learning_objectives: ["Create pivot tables from financial data", "Design dynamic reports", "Use slicers for interactive analysis", "Build pivot charts"],
          key_concepts: ["Pivot Tables", "Slicers", "Calculated Fields", "Pivot Charts"],
          lessons: [
            {
              lesson_id: "pivot_1",
              title: "Pivot Tables - Financial Reporting Magic! ✨",
              content: `Pivot Tables can summarize thousands of transactions in seconds!

**Creating Your First Pivot Table:**
1. Select your data (including headers)
2. Insert > PivotTable
3. Drag fields to areas:
   - Rows: Categories to group by
   - Columns: Secondary grouping
   - Values: Numbers to summarize
   - Filters: Slice your data

**Example Financial Data:**
\`\`\`
Date      | Department | Category | Amount
1/1/2024  | Sales      | Revenue  | 5,000
1/1/2024  | Marketing  | Expense  | 2,500
...
\`\`\`

**Pivot Table Layout:**
\`\`\`
                Q1      Q2      Q3      Total
Revenue
  Sales        50,000  55,000  60,000  165,000
  Services     20,000  22,000  25,000   67,000
Expenses  
  Marketing   (15,000)(18,000)(20,000) (53,000)
  Operations  (30,000)(32,000)(35,000) (97,000)
Net Income    25,000  27,000  30,000   82,000
\`\`\`

**Calculated Fields:**
\`\`\`excel
Right-click > Show Field List
Fields, Items & Sets > Calculated Field

Name: Profit Margin
Formula: =Revenue / Total_Revenue

Name: YoY Growth
Formula: =('2024'-'2023')/'2023'
\`\`\`

**Pro Tips:**
- 🔄 Right-click > Refresh when source data changes
- 📊 Group dates by Month/Quarter/Year
- 🎨 Use Slicers for clickable filters
- 📈 Insert Pivot Chart for visualization`,
              exercises: ["Create a monthly P&L pivot table from transaction data", "Add calculated fields for margins and variances", "Build an interactive dashboard with slicers"],
              reflection_prompts: ["How can pivot tables replace manual monthly reports?", "What data structure works best for pivot tables?"]
            }
          ],
          assessment: {
            questions: [
              { question: "To update a pivot table after changing source data, you should...", type: "multiple_choice", options: ["Recreate the pivot table", "Right-click and Refresh", "Press F5", "Delete and start over"], correct_answer: "Right-click and Refresh", explanation: "Refreshing updates the pivot table with new data" },
              { question: "Slicers are used to...", type: "multiple_choice", options: ["Add new data", "Create charts", "Filter pivot table interactively", "Calculate totals"], correct_answer: "Filter pivot table interactively", explanation: "Slicers provide visual, clickable filters for pivot tables" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Financial Dashboard", instructions: "Create an interactive financial dashboard with pivot tables, slicers, and charts that shows revenue by product, expenses by department, and monthly trends", expected_outcome: "A professional dashboard that updates automatically when you click different filters", time_estimate: "60 minutes" }
          ]
        }
      }
    ]
  },
  {
    id: "cybersecurity_basics",
    title: "Cybersecurity Fundamentals",
    description: "Learn essential security concepts and practices",
    category: "security",
    difficulty: "beginner",
    duration_hours: 16,
    icon: Shield,
    color: "bg-red-600",
    skills: ["Security", "Network Security", "Risk Management"],
    modules: [
      {
        module_id: "sec_basics",
        title: "Security Foundations",
        description: "Core security concepts everyone should know",
        duration_minutes: 55,
        skill_focus: "Security Fundamentals",
        content: {
          learning_objectives: ["Understand the CIA triad", "Recognize common threats", "Implement basic security controls", "Follow security best practices"],
          key_concepts: ["Confidentiality", "Integrity", "Availability", "Authentication", "Authorization"],
          lessons: [
            {
              lesson_id: "sec_1",
              title: "The CIA Triad and Security Principles",
              content: `The foundation of all security is the CIA Triad.

**Confidentiality:**
Ensuring information is only accessible to authorized parties.
- Encryption (AES, RSA)
- Access controls
- Data classification

**Integrity:**
Ensuring data hasn't been tampered with.
- Hashing (SHA-256)
- Digital signatures
- Version control

**Availability:**
Ensuring systems and data are accessible when needed.
- Redundancy
- Backups
- DDoS protection

**Common Threats:**

**Phishing:**
- Fake emails/websites to steal credentials
- Defense: Training, email filters, MFA

**Malware:**
- Viruses, ransomware, trojans
- Defense: Antivirus, updates, backups

**Social Engineering:**
- Manipulating people to reveal information
- Defense: Awareness training, verification procedures

**Password Security:**
\`\`\`
DO:
✓ Use 12+ characters
✓ Mix upper, lower, numbers, symbols
✓ Use unique passwords per site
✓ Enable MFA everywhere

DON'T:
✗ Use personal info (birthdays, names)
✗ Use common words
✗ Reuse passwords
✗ Share passwords
\`\`\``,
              exercises: ["Audit your current passwords and update weak ones", "Enable MFA on all critical accounts", "Identify potential phishing emails in your inbox"],
              reflection_prompts: ["Which CIA element is most important for your organization?", "How would you improve security awareness in your team?"]
            }
          ],
          assessment: {
            questions: [
              { question: "What does the 'I' in CIA Triad stand for?", type: "multiple_choice", options: ["Intelligence", "Integrity", "Infrastructure", "Identity"], correct_answer: "Integrity", explanation: "CIA stands for Confidentiality, Integrity, and Availability" }
            ],
            passing_score: 70
          },
          practical_exercises: [
            { title: "Security Audit", instructions: "Perform a basic security audit of your digital life (passwords, MFA, device security)", expected_outcome: "A security improvement plan with prioritized actions", time_estimate: "40 minutes" }
          ]
        }
      }
    ]
  }
];

const CATEGORY_CONFIG = {
  programming: { label: "Programming", icon: Code },
  data: { label: "Data & Analytics", icon: BarChart3 },
  infrastructure: { label: "Infrastructure", icon: Cloud },
  leadership: { label: "Leadership", icon: Users },
  security: { label: "Security", icon: Shield },
  accounting: { label: "Accounting & Finance", icon: Calculator }
};

export default function LearningCatalog({ user, onEnroll, usageInsights }) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");

  const { data: existingJourneys } = useQuery({
    queryKey: ['userJourneys', user?.email],
    queryFn: () => base44.entities.LearningJourney.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const createJourneyMutation = useMutation({
    mutationFn: (data) => base44.entities.LearningJourney.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] });
      queryClient.invalidateQueries({ queryKey: ['userJourneys'] });
    },
  });

  const enrollInCourse = async (course) => {
    const modulesWithStatus = course.modules.map((m, i) => ({
      ...m,
      status: i === 0 ? 'available' : 'locked'
    }));

    await createJourneyMutation.mutateAsync({
      user_email: user.email,
      title: course.title,
      description: course.description,
      career_goal: `Complete ${course.title}`,
      target_skills: course.skills,
      current_skill_gaps: [],
      modules: modulesWithStatus,
      total_duration_hours: course.duration_hours,
      difficulty_level: course.difficulty,
      progress_percentage: 0,
      status: 'not_started',
      badges_earned: [],
      bonus_points_earned: 0,
      ai_recommendations: [],
      start_date: new Date().toISOString(),
      target_completion_date: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    });

    onEnroll?.();
  };

  const isEnrolled = (courseId) => {
    return existingJourneys?.some(j => j.title === COURSE_CATALOG.find(c => c.id === courseId)?.title);
  };

  const filteredCourses = COURSE_CATALOG.filter(course => {
    const matchesSearch = !searchQuery || 
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.skills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || course.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === "all" || course.difficulty === selectedDifficulty;
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  // Determine if course is trending or underutilized based on AI insights
  const getCourseInsight = (courseTitle) => {
    if (!usageInsights) return null;
    const popular = usageInsights.popular_features?.some(f => 
      f.feature_name?.toLowerCase().includes(courseTitle.toLowerCase())
    );
    const underutilized = usageInsights.underutilized_features?.some(f => 
      f.feature_name?.toLowerCase().includes(courseTitle.toLowerCase())
    );
    if (popular) return { type: 'popular', label: 'Trending', color: 'bg-green-600' };
    if (underutilized) return { type: 'underutilized', label: 'Hidden Gem', color: 'bg-orange-600' };
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search courses..."
                className="bg-gray-800 border-gray-700 text-white pl-10"
              />
            </div>
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="bg-gray-800 border border-gray-700">
                <TabsTrigger value="all">All</TabsTrigger>
                {Object.entries(CATEGORY_CONFIG).map(([key, config]) => (
                  <TabsTrigger key={key} value={key}>{config.label}</TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
            <Tabs value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <TabsList className="bg-gray-800 border border-gray-700">
                <TabsTrigger value="all">All Levels</TabsTrigger>
                <TabsTrigger value="beginner">Beginner</TabsTrigger>
                <TabsTrigger value="intermediate">Intermediate</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Course Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => {
          const enrolled = isEnrolled(course.id);
          const CategoryIcon = CATEGORY_CONFIG[course.category]?.icon || BookOpen;
          const insight = getCourseInsight(course.title);
          return (
            <Card key={course.id} className={`bg-gray-900 hover:border-gray-700 transition-colors overflow-hidden ${
              insight?.type === 'popular' ? 'border-green-800' : 
              insight?.type === 'underutilized' ? 'border-orange-800' : 'border-gray-800'
            }`}>
              <div className={`h-2 ${course.color}`} />
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl ${course.color} flex items-center justify-center`}>
                    <course.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex gap-2 flex-wrap justify-end">
                    <Badge variant="outline" className="border-gray-700 text-gray-400 capitalize">{course.difficulty}</Badge>
                    {insight && (
                      <Badge className={`${insight.color} flex items-center gap-1`}>
                        {insight.type === 'popular' ? <TrendingUp className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {insight.label}
                      </Badge>
                    )}
                    {enrolled && <Badge className="bg-green-600"><CheckCircle2 className="w-3 h-3 mr-1" />Enrolled</Badge>}
                  </div>
                </div>
                <h3 className="text-white font-medium text-lg mb-2">{course.title}</h3>
                <p className="text-gray-400 text-sm line-clamp-2 mb-4">{course.description}</p>
                <div className="flex flex-wrap gap-1 mb-4">
                  {course.skills.slice(0, 3).map((skill, i) => (
                    <Badge key={i} variant="outline" className="text-xs border-gray-700 text-gray-400">{skill}</Badge>
                  ))}
                </div>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{course.duration_hours}h</span>
                  <span className="flex items-center gap-1"><Target className="w-4 h-4" />{course.modules.length} modules</span>
                </div>
                <Button 
                  onClick={() => enrollInCourse(course)} 
                  disabled={enrolled}
                  className={enrolled ? "w-full bg-gray-700" : "w-full bg-purple-600 hover:bg-purple-700"}
                >
                  {enrolled ? "Already Enrolled" : <><Play className="w-4 h-4 mr-2" />Enroll Now</>}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredCourses.length === 0 && (
        <Card className="bg-gray-900 border-gray-800 text-center py-12">
          <CardContent>
            <BookOpen className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-medium mb-2">No courses found</h3>
            <p className="text-gray-400 text-sm">Try adjusting your search or filters</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export { COURSE_CATALOG };