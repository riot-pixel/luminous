import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, Sparkles, Target, TrendingUp, BookOpen, Zap,
  AlertTriangle, CheckCircle2, ArrowRight, Star, Lightbulb, Plus
} from "lucide-react";
import AIContentGenerator from "../content/AIContentGenerator";

export default function PersonalizedLearningEngine({ 
  user, 
  completedJourneys, 
  inProgressJourneys,
  userSkills, 
  assessments, 
  availableCourses,
  onCourseSelect 
}) {
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendations, setRecommendations] = useState(null);
  const [generatingModuleFor, setGeneratingModuleFor] = useState(null);

  const createJourneyMutation = useMutation({
    mutationFn: (data) => base44.entities.LearningJourney.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLearningJourneys'] });
      setGeneratingModuleFor(null);
    },
  });

  const generateRecommendations = async () => {
    setIsAnalyzing(true);
    try {
      const completedSkills = completedJourneys?.flatMap(j => j.target_skills) || [];
      const inProgressSkills = inProgressJourneys?.flatMap(j => j.target_skills) || [];
      const currentSkills = userSkills?.map(s => `${s.skill_name} (${s.self_assessed_proficiency || s.current_proficiency})`) || [];
      const careerGoals = [...new Set([
        ...completedJourneys?.map(j => j.career_goal).filter(Boolean) || [],
        ...inProgressJourneys?.map(j => j.career_goal).filter(Boolean) || []
      ])];

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert learning path advisor. Analyze this user's learning history and create personalized recommendations.

USER PROFILE:
- Name: ${user?.full_name}
- Current Role: ${user?.job_title || 'Not specified'}
- Department: ${user?.department || 'Not specified'}

COMPLETED LEARNING:
${completedJourneys?.map(j => `- ${j.title} (${j.progress_percentage}% complete, ${j.badges_earned?.length || 0} badges)`).join('\n') || 'None'}

IN-PROGRESS LEARNING:
${inProgressJourneys?.map(j => `- ${j.title} (${j.progress_percentage}% progress)`).join('\n') || 'None'}

CURRENT SKILLS:
${currentSkills.join(', ') || 'No skills recorded'}

CAREER GOALS MENTIONED:
${careerGoals.join(', ') || 'Not specified'}

PERSONALITY INSIGHTS:
${assessments?.[0]?.myers_briggs?.type ? `Myers-Briggs: ${assessments[0].myers_briggs.type}` : 'No assessment data'}
${assessments?.[0]?.ai_insights?.substring(0, 300) || ''}

AVAILABLE COURSES:
${availableCourses.map(c => `- ${c.title} (${c.category}, ${c.difficulty}, ${c.skills.join(', ')})`).join('\n')}

Provide:
1. Identified skill gaps based on career goals vs current skills
2. Top 5 recommended courses from available catalog with detailed reasoning
3. Suggested learning sequence (what to take first, second, etc.)
4. Long-term development path (6-12 months)
5. Quick wins - skills they can master quickly for immediate impact
6. Stretch goals - ambitious skills for career advancement`,
        response_json_schema: {
          type: "object",
          properties: {
            skill_gaps: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  gap_severity: { type: "string" },
                  current_level: { type: "string" },
                  needed_level: { type: "string" },
                  importance_for_goal: { type: "string" }
                }
              }
            },
            recommended_courses: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  course_title: { type: "string" },
                  priority: { type: "string" },
                  relevance_score: { type: "number" },
                  why_recommended: { type: "string" },
                  fills_gaps: { type: "array", items: { type: "string" } },
                  estimated_impact: { type: "string" },
                  best_time_to_take: { type: "string" }
                }
              }
            },
            learning_sequence: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  step: { type: "number" },
                  course: { type: "string" },
                  duration: { type: "string" },
                  rationale: { type: "string" }
                }
              }
            },
            development_path: {
              type: "object",
              properties: {
                three_month_focus: { type: "array", items: { type: "string" } },
                six_month_goals: { type: "array", items: { type: "string" } },
                twelve_month_vision: { type: "string" },
                skill_trajectory: { type: "string" }
              }
            },
            quick_wins: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  time_to_learn: { type: "string" },
                  immediate_value: { type: "string" },
                  how_to_start: { type: "string" }
                }
              }
            },
            stretch_goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill: { type: "string" },
                  difficulty: { type: "string" },
                  career_impact: { type: "string" },
                  prerequisites: { type: "array", items: { type: "string" } }
                }
              }
            },
            personalization_notes: { type: "string" }
          }
        }
      });

      setRecommendations(result);
    } catch (error) {
      console.error("Error generating recommendations:", error);
    }
    setIsAnalyzing(false);
  };

  if (!recommendations) {
    return (
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            AI Personalized Learning Recommendations
          </CardTitle>
          <CardDescription className="text-gray-400">
            Get custom course recommendations based on your goals, skills, and learning history
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={generateRecommendations} disabled={isAnalyzing} className="w-full bg-purple-600 hover:bg-purple-700">
            {isAnalyzing ? (
              <><Sparkles className="w-4 h-4 mr-2 animate-spin" />Analyzing Your Profile...</>
            ) : (
              <><Brain className="w-4 h-4 mr-2" />Generate Personalized Recommendations</>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Personalization Note */}
      {recommendations.personalization_notes && (
        <Card className="bg-gradient-to-r from-cyan-900/30 to-blue-900/30 border-cyan-800">
          <CardContent className="p-4">
            <p className="text-cyan-300 text-sm flex items-start gap-2">
              <Sparkles className="w-4 h-4 mt-0.5 flex-shrink-0" />
              {recommendations.personalization_notes}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Skill Gaps */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-red-400" />
            Identified Skill Gaps
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-3">
            {recommendations.skill_gaps?.map((gap, i) => (
              <div key={i} className={`p-3 rounded-lg border ${
                gap.gap_severity === 'critical' ? 'bg-red-900/20 border-red-800' :
                gap.gap_severity === 'high' ? 'bg-orange-900/20 border-orange-800' :
                'bg-yellow-900/20 border-yellow-800'
              }`}>
                <div className="flex items-start justify-between mb-2">
                  <p className="text-white font-medium">{gap.skill}</p>
                  <Badge className={
                    gap.gap_severity === 'critical' ? 'bg-red-600' :
                    gap.gap_severity === 'high' ? 'bg-orange-600' : 'bg-yellow-600'
                  }>
                    {gap.gap_severity}
                  </Badge>
                </div>
                <div className="flex gap-2 text-xs mb-2">
                  <span className="text-gray-400">Current: {gap.current_level}</span>
                  <ArrowRight className="w-3 h-3 text-gray-500" />
                  <span className="text-green-400">Need: {gap.needed_level}</span>
                </div>
                <p className="text-gray-400 text-xs">{gap.importance_for_goal}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recommended Courses */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-400" />
            Top Course Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.recommended_courses?.map((rec, i) => (
              <div key={i} className="p-4 bg-gray-800 rounded-lg hover:bg-gray-750 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-xs font-bold">
                      {i + 1}
                    </span>
                    <h4 className="text-white font-medium">{rec.course_title}</h4>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={
                      rec.priority === 'critical' ? 'bg-red-600' :
                      rec.priority === 'high' ? 'bg-orange-600' : 'bg-blue-600'
                    }>
                      {rec.priority}
                    </Badge>
                    <Badge variant="outline" className="border-purple-600 text-purple-400">
                      {rec.relevance_score}/100
                    </Badge>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-3">{rec.why_recommended}</p>
                <div className="grid md:grid-cols-3 gap-3 text-xs">
                  <div className="p-2 bg-gray-700 rounded">
                    <p className="text-gray-500 mb-1">Fills Gaps:</p>
                    <div className="flex flex-wrap gap-1">
                      {rec.fills_gaps?.slice(0, 2).map((gap, j) => (
                        <Badge key={j} className="bg-red-600 text-[10px]">{gap}</Badge>
                      ))}
                    </div>
                  </div>
                  <div className="p-2 bg-gray-700 rounded">
                    <p className="text-gray-500 mb-1">Impact:</p>
                    <p className="text-green-400">{rec.estimated_impact}</p>
                  </div>
                  <div className="p-2 bg-gray-700 rounded">
                    <p className="text-gray-500 mb-1">Best Time:</p>
                    <p className="text-cyan-400">{rec.best_time_to_take}</p>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button 
                    size="sm" 
                    onClick={() => onCourseSelect?.(rec.course_title)}
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    View Course
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setGeneratingModuleFor(rec)}
                    className="border-cyan-600 text-cyan-400 hover:bg-cyan-900/30"
                  >
                    <Sparkles className="w-3 h-3 mr-1" />Generate Custom
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Learning Sequence */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <ArrowRight className="w-5 h-5 text-blue-400" />
              Suggested Learning Sequence
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recommendations.learning_sequence?.map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    {step.step}
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">{step.course}</p>
                    <p className="text-gray-400 text-sm mt-1">{step.rationale}</p>
                    <Badge variant="outline" className="text-xs border-gray-700 text-gray-400 mt-2">
                      {step.duration}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Development Path */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              Your Development Path
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="text-gray-400 text-xs mb-2">Next 3 Months</p>
                <div className="flex flex-wrap gap-1">
                  {recommendations.development_path?.three_month_focus?.map((focus, i) => (
                    <Badge key={i} className="bg-blue-600 text-xs">{focus}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-gray-400 text-xs mb-2">6 Month Goals</p>
                <div className="space-y-1">
                  {recommendations.development_path?.six_month_goals?.map((goal, i) => (
                    <p key={i} className="text-gray-300 text-sm flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 mt-1 text-green-400 flex-shrink-0" />{goal}
                    </p>
                  ))}
                </div>
              </div>
              <div className="p-3 bg-purple-900/30 border border-purple-800 rounded-lg">
                <p className="text-purple-400 text-xs mb-1">12 Month Vision</p>
                <p className="text-gray-300 text-sm">{recommendations.development_path?.twelve_month_vision}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Quick Wins */}
        <Card className="bg-green-900/20 border-green-800">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2 text-lg">
              <Zap className="w-5 h-5" />
              Quick Wins - Start This Week!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recommendations.quick_wins?.map((win, i) => (
                <div key={i} className="p-3 bg-green-900/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white font-medium">{win.skill}</p>
                    <Badge className="bg-green-600 text-xs">{win.time_to_learn}</Badge>
                  </div>
                  <p className="text-green-400 text-sm mb-2">💰 {win.immediate_value}</p>
                  <p className="text-gray-400 text-xs">{win.how_to_start}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stretch Goals */}
        <Card className="bg-orange-900/20 border-orange-800">
          <CardHeader>
            <CardTitle className="text-orange-400 flex items-center gap-2 text-lg">
              <Star className="w-5 h-5" />
              Stretch Goals - Level Up Your Career
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recommendations.stretch_goals?.map((goal, i) => (
                <div key={i} className="p-3 bg-orange-900/20 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white font-medium">{goal.skill}</p>
                    <Badge className="bg-orange-600 text-xs">{goal.difficulty}</Badge>
                  </div>
                  <p className="text-orange-400 text-sm mb-2">🚀 {goal.career_impact}</p>
                  {goal.prerequisites?.length > 0 && (
                    <div>
                      <p className="text-gray-500 text-xs mb-1">Prerequisites:</p>
                      <div className="flex flex-wrap gap-1">
                        {goal.prerequisites.map((pre, j) => (
                          <Badge key={j} variant="outline" className="text-[10px] border-gray-600 text-gray-400">{pre}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-center">
        <Button variant="outline" onClick={() => setRecommendations(null)} className="border-gray-700 text-gray-400">
          <Sparkles className="w-4 h-4 mr-2" />
          Refresh Recommendations
        </Button>
      </div>

      {/* AI Module Generator Modal */}
      {generatingModuleFor && (
        <Card className="bg-gray-900 border-gray-800 mt-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Generate Custom Learning Module</CardTitle>
              <Button size="sm" variant="ghost" onClick={() => setGeneratingModuleFor(null)} className="text-gray-400">
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <AIContentGenerator
              contentType="learning_module"
              context={{
                skillName: generatingModuleFor.fills_gaps?.[0] || "Skill Development",
                currentLevel: userSkills?.find(s => s.skill_name === generatingModuleFor.fills_gaps?.[0])?.self_assessed_proficiency || "beginner",
                careerGoal: completedJourneys?.[0]?.career_goal || inProgressJourneys?.[0]?.career_goal || "Career advancement",
                personalityType: assessments?.[0]?.myers_briggs?.type
              }}
              onContentGenerated={async (content) => {
                // Auto-create journey from generated content
                try {
                  await createJourneyMutation.mutateAsync({
                    user_email: user.email,
                    title: `Custom: ${generatingModuleFor.fills_gaps?.[0]} Mastery`,
                    description: content.substring(0, 200),
                    career_goal: completedJourneys?.[0]?.career_goal || "Skill development",
                    target_skills: generatingModuleFor.fills_gaps || [],
                    modules: [{
                      module_id: "custom_1",
                      title: generatingModuleFor.fills_gaps?.[0] || "Module 1",
                      description: "AI-generated custom content",
                      duration_minutes: 60,
                      skill_focus: generatingModuleFor.fills_gaps?.[0],
                      status: "available",
                      content: { learning_objectives: [], key_concepts: [], lessons: [] }
                    }],
                    total_duration_hours: 8,
                    difficulty_level: "intermediate",
                    progress_percentage: 0,
                    status: 'not_started',
                    start_date: new Date().toISOString()
                  });
                } catch (error) {
                  console.error("Error creating custom journey:", error);
                }
              }}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}