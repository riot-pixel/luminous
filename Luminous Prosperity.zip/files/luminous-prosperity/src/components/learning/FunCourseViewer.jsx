import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ReactMarkdown from "react-markdown";
import {
  Play, CheckCircle2, Star, Zap, Trophy, Target, BookOpen,
  Code, Lightbulb, ChevronRight, ChevronLeft, Flame, Gift,
  PartyPopper, Rocket, Brain, Coffee, Timer, Medal
} from "lucide-react";
import InteractiveCodeEditor from "./InteractiveCodeEditor";

const MOTIVATIONAL_MESSAGES = [
  "You're on fire! 🔥",
  "Keep crushing it! 💪",
  "Unstoppable! 🚀",
  "Brain gains! 🧠",
  "Level up! ⬆️",
  "You're a star! ⭐",
];

const FUN_FACTS = {
  python: [
    "Python is named after Monty Python, not the snake! 🐍",
    "NASA uses Python for space exploration! 🚀",
    "Instagram's backend is built with Python! 📸",
    "Python was created in 1991 - older than Google! 🎂",
  ],
  javascript: [
    "JavaScript was created in just 10 days! ⚡",
    "Despite the name, JavaScript has nothing to do with Java! 🤯",
    "95% of websites use JavaScript! 🌐",
    "Node.js lets you run JavaScript on servers! 🖥️",
  ],
  cloud: [
    "AWS has over 200 services! ☁️",
    "The cloud saves companies 15-40% on IT costs! 💰",
    "Netflix runs entirely on AWS! 🎬",
    "Cloud computing reduces carbon footprint by 30%! 🌱",
  ],
};

export default function FunCourseViewer({ module, journey, onComplete, onBack }) {
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);
  const [completedLessons, setCompletedLessons] = useState([]);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [funFact, setFunFact] = useState("");
  const [timerActive, setTimerActive] = useState(false);
  const [timeSpent, setTimeSpent] = useState(0);

  const lessons = module?.content?.lessons || [];
  const currentLesson = lessons[currentLessonIndex];
  const assessment = module?.content?.assessment;
  const practicalExercises = module?.content?.practical_exercises || [];

  // Timer
  useEffect(() => {
    let interval;
    if (timerActive) {
      interval = setInterval(() => setTimeSpent(t => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive]);

  useEffect(() => {
    setTimerActive(true);
    // Random fun fact
    const category = journey?.title?.toLowerCase().includes('python') ? 'python' :
      journey?.title?.toLowerCase().includes('javascript') ? 'javascript' : 'cloud';
    const facts = FUN_FACTS[category] || FUN_FACTS.python;
    setFunFact(facts[Math.floor(Math.random() * facts.length)]);
  }, []);

  const completeLesson = () => {
    if (!completedLessons.includes(currentLessonIndex)) {
      setCompletedLessons([...completedLessons, currentLessonIndex]);
      setStreak(s => s + 1);
      const xp = 25 + (streak * 5);
      setXpEarned(x => x + xp);
      
      // Show celebration
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 2000);
    }
  };

  const nextLesson = () => {
    completeLesson();
    if (currentLessonIndex < lessons.length - 1) {
      setCurrentLessonIndex(currentLessonIndex + 1);
    } else {
      setShowQuiz(true);
    }
  };

  const prevLesson = () => {
    if (currentLessonIndex > 0) {
      setCurrentLessonIndex(currentLessonIndex - 1);
    }
  };

  const submitQuiz = () => {
    let correct = 0;
    assessment?.questions?.forEach((q, i) => {
      if (quizAnswers[i] === q.correct_answer) correct++;
    });
    const score = Math.round((correct / (assessment?.questions?.length || 1)) * 100);
    setQuizScore(score);
    setQuizSubmitted(true);
    
    // Bonus XP for quiz
    const quizXp = Math.round(score * 2);
    setXpEarned(x => x + quizXp);

    if (score >= (assessment?.passing_score || 70)) {
      setShowCelebration(true);
      setTimeout(() => {
        setShowCelebration(false);
        onComplete?.();
      }, 3000);
    }
  };

  const progress = ((completedLessons.length) / lessons.length) * 100;
  const randomMotivation = MOTIVATIONAL_MESSAGES[Math.floor(Math.random() * MOTIVATIONAL_MESSAGES.length)];

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-4xl mx-auto">
        {/* Celebration Overlay */}
        {showCelebration && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
            <div className="text-center animate-bounce">
              <PartyPopper className="w-24 h-24 text-yellow-400 mx-auto mb-4" />
              <h2 className="text-4xl font-bold text-white mb-2">{randomMotivation}</h2>
              <p className="text-2xl text-yellow-400">+{25 + (streak * 5)} XP</p>
            </div>
          </div>
        )}

        {/* Top Stats Bar */}
        <div className="flex items-center justify-between mb-6 p-4 bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-xl border border-purple-800">
          <Button variant="ghost" onClick={onBack} className="text-gray-400">
            <ChevronLeft className="w-4 h-4 mr-1" />Back
          </Button>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-400" />
              <span className="text-orange-400 font-bold">{streak} streak</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-bold">{xpEarned} XP</span>
            </div>
            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-cyan-400" />
              <span className="text-cyan-400">{Math.floor(timeSpent / 60)}:{(timeSpent % 60).toString().padStart(2, '0')}</span>
            </div>
          </div>
        </div>

        {/* Module Header */}
        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <Badge className="bg-purple-600 mb-2">{module?.skill_focus}</Badge>
                <h1 className="text-2xl font-bold text-white">{module?.title}</h1>
                <p className="text-gray-400 mt-1">{module?.description}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-500 text-sm">Progress</p>
                <p className="text-2xl font-bold text-white">{Math.round(progress)}%</p>
              </div>
            </div>
            <Progress value={progress} className="h-3" />
            
            {/* Fun Fact */}
            <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-800 rounded-lg flex items-center gap-3">
              <Lightbulb className="w-5 h-5 text-yellow-400 flex-shrink-0" />
              <p className="text-yellow-300 text-sm">{funFact}</p>
            </div>
          </CardContent>
        </Card>

        {!showQuiz ? (
          <>
            {/* Lesson Navigation Pills */}
            <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
              {lessons.map((lesson, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentLessonIndex(i)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                    i === currentLessonIndex 
                      ? 'bg-purple-600 text-white' 
                      : completedLessons.includes(i)
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  {completedLessons.includes(i) ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : (
                    <span className="w-4 h-4 rounded-full bg-gray-600 flex items-center justify-center text-xs">{i + 1}</span>
                  )}
                  {lesson.title}
                </button>
              ))}
              <button
                onClick={() => setShowQuiz(true)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap ${
                  completedLessons.length === lessons.length
                    ? 'bg-yellow-600 text-black font-bold animate-pulse'
                    : 'bg-gray-800 text-gray-500'
                }`}
                disabled={completedLessons.length < lessons.length}
              >
                <Trophy className="w-4 h-4" />
                Quiz Challenge
              </button>
            </div>

            {/* Lesson Content */}
            <Tabs defaultValue="learn" className="space-y-4">
              <TabsList className="bg-gray-900 border border-gray-800">
                <TabsTrigger value="learn"><BookOpen className="w-4 h-4 mr-1" />Learn</TabsTrigger>
                <TabsTrigger value="practice"><Code className="w-4 h-4 mr-1" />Practice</TabsTrigger>
                <TabsTrigger value="challenge"><Zap className="w-4 h-4 mr-1" />Challenge</TabsTrigger>
              </TabsList>

              <TabsContent value="learn">
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Target className="w-5 h-5 text-purple-400" />
                      {currentLesson?.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-invert max-w-none">
                      <ReactMarkdown
                        components={{
                          code: ({ inline, children, ...props }) => {
                            if (inline) {
                              return <code className="px-1 py-0.5 bg-gray-800 rounded text-purple-400" {...props}>{children}</code>;
                            }
                            return (
                              <pre className="bg-gray-950 p-4 rounded-lg overflow-x-auto border border-gray-800">
                                <code className="text-green-400" {...props}>{children}</code>
                              </pre>
                            );
                          },
                          h2: ({ children }) => <h2 className="text-xl font-bold text-white mt-6 mb-3">{children}</h2>,
                          h3: ({ children }) => <h3 className="text-lg font-semibold text-purple-300 mt-4 mb-2">{children}</h3>,
                          p: ({ children }) => <p className="text-gray-300 mb-4 leading-relaxed">{children}</p>,
                          ul: ({ children }) => <ul className="list-disc list-inside space-y-2 mb-4 text-gray-300">{children}</ul>,
                          li: ({ children }) => <li className="text-gray-300">{children}</li>,
                          strong: ({ children }) => <strong className="text-white font-semibold">{children}</strong>,
                        }}
                      >
                        {currentLesson?.content}
                      </ReactMarkdown>
                    </div>

                    {/* Quick Exercises */}
                    {currentLesson?.exercises?.length > 0 && (
                      <div className="mt-6 p-4 bg-blue-900/20 border border-blue-800 rounded-lg">
                        <h4 className="text-blue-400 font-medium mb-3 flex items-center gap-2">
                          <Rocket className="w-4 h-4" />Try It Yourself!
                        </h4>
                        <ul className="space-y-2">
                          {currentLesson.exercises.map((ex, i) => (
                            <li key={i} className="flex items-start gap-2 text-gray-300 text-sm">
                              <span className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center text-xs flex-shrink-0">{i + 1}</span>
                              {ex}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Reflection */}
                    {currentLesson?.reflection_prompts?.length > 0 && (
                      <div className="mt-4 p-4 bg-purple-900/20 border border-purple-800 rounded-lg">
                        <h4 className="text-purple-400 font-medium mb-3 flex items-center gap-2">
                          <Brain className="w-4 h-4" />Think About It
                        </h4>
                        <ul className="space-y-2">
                          {currentLesson.reflection_prompts.map((prompt, i) => (
                            <li key={i} className="text-gray-300 text-sm">💭 {prompt}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="practice">
                <InteractiveCodeEditor
                  exercise={{
                    title: `Practice: ${currentLesson?.title}`,
                    instructions: currentLesson?.exercises?.[0] || "Try out what you learned!",
                    starterCode: "# Write your code here\n\n",
                    hint: "Check the lesson content for examples!"
                  }}
                  language={journey?.title?.toLowerCase().includes('javascript') ? 'javascript' : 'python'}
                  onComplete={() => {
                    setXpEarned(x => x + 15);
                    setShowCelebration(true);
                    setTimeout(() => setShowCelebration(false), 1500);
                  }}
                />
              </TabsContent>

              <TabsContent value="challenge">
                <Card className="bg-gradient-to-r from-orange-900/30 to-red-900/30 border-orange-800">
                  <CardHeader>
                    <CardTitle className="text-orange-400 flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Bonus Challenge - Double XP! 🔥
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {practicalExercises[0] ? (
                      <div className="space-y-4">
                        <h3 className="text-white font-medium">{practicalExercises[0].title}</h3>
                        <p className="text-gray-300">{practicalExercises[0].instructions}</p>
                        <div className="flex items-center gap-4 text-sm">
                          <Badge variant="outline" className="border-orange-600 text-orange-400">
                            <Timer className="w-3 h-3 mr-1" />{practicalExercises[0].time_estimate}
                          </Badge>
                          <Badge variant="outline" className="border-yellow-600 text-yellow-400">
                            <Star className="w-3 h-3 mr-1" />+50 XP
                          </Badge>
                        </div>
                        <InteractiveCodeEditor
                          exercise={{
                            title: practicalExercises[0].title,
                            instructions: practicalExercises[0].instructions,
                            starterCode: "# Complete the challenge!\n\n",
                            expectedOutput: practicalExercises[0].expected_outcome
                          }}
                          language={journey?.title?.toLowerCase().includes('javascript') ? 'javascript' : 'python'}
                          onComplete={() => {
                            setXpEarned(x => x + 50);
                            setShowCelebration(true);
                            setTimeout(() => setShowCelebration(false), 2000);
                          }}
                        />
                      </div>
                    ) : (
                      <p className="text-gray-400">Complete the lessons to unlock bonus challenges!</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Navigation */}
            <div className="flex justify-between mt-6">
              <Button 
                onClick={prevLesson} 
                disabled={currentLessonIndex === 0}
                variant="outline"
                className="border-gray-700 text-gray-400"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />Previous
              </Button>
              <Button onClick={nextLesson} className="bg-green-600 hover:bg-green-700">
                {currentLessonIndex < lessons.length - 1 ? (
                  <>Next Lesson<ChevronRight className="w-4 h-4 ml-1" /></>
                ) : (
                  <>Take Quiz<Trophy className="w-4 h-4 ml-1" /></>
                )}
              </Button>
            </div>
          </>
        ) : (
          /* Quiz Section */
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Trophy className="w-6 h-6 text-yellow-400" />
                Quiz Challenge - Test Your Knowledge!
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!quizSubmitted ? (
                <div className="space-y-6">
                  {assessment?.questions?.map((q, i) => (
                    <div key={i} className="p-4 bg-gray-800 rounded-lg">
                      <p className="text-white font-medium mb-3">
                        <span className="text-purple-400 mr-2">Q{i + 1}.</span>
                        {q.question}
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {q.options?.map((opt, j) => (
                          <button
                            key={j}
                            onClick={() => setQuizAnswers({ ...quizAnswers, [i]: opt })}
                            className={`p-3 rounded-lg text-left transition-all ${
                              quizAnswers[i] === opt
                                ? 'bg-purple-600 text-white border-2 border-purple-400'
                                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                  <Button 
                    onClick={submitQuiz}
                    disabled={Object.keys(quizAnswers).length < (assessment?.questions?.length || 0)}
                    className="w-full bg-yellow-600 hover:bg-yellow-700 text-black font-bold py-6 text-lg"
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Submit Quiz & Claim XP!
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8">
                  {quizScore >= (assessment?.passing_score || 70) ? (
                    <>
                      <Medal className="w-24 h-24 text-yellow-400 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-white mb-2">Congratulations! 🎉</h2>
                      <p className="text-2xl text-yellow-400 mb-4">You scored {quizScore}%!</p>
                      <p className="text-gray-400 mb-6">You earned {Math.round(quizScore * 2)} bonus XP!</p>
                      <div className="flex justify-center gap-4">
                        <Button onClick={onBack} variant="outline" className="border-gray-700 text-gray-400">
                          Back to Journey
                        </Button>
                        <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle2 className="w-4 h-4 mr-2" />Complete Module
                        </Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <Coffee className="w-24 h-24 text-orange-400 mx-auto mb-4" />
                      <h2 className="text-3xl font-bold text-white mb-2">Almost there!</h2>
                      <p className="text-xl text-orange-400 mb-4">You scored {quizScore}% (need {assessment?.passing_score || 70}%)</p>
                      <p className="text-gray-400 mb-6">Review the lessons and try again!</p>
                      <Button onClick={() => { setQuizSubmitted(false); setQuizAnswers({}); setShowQuiz(false); }} className="bg-purple-600 hover:bg-purple-700">
                        <BookOpen className="w-4 h-4 mr-2" />Review Lessons
                      </Button>
                    </>
                  )}

                  {/* Show correct answers */}
                  <div className="mt-8 text-left">
                    <h3 className="text-white font-medium mb-4">Answer Review:</h3>
                    {assessment?.questions?.map((q, i) => (
                      <div key={i} className={`p-3 rounded-lg mb-2 ${quizAnswers[i] === q.correct_answer ? 'bg-green-900/30 border border-green-800' : 'bg-red-900/30 border border-red-800'}`}>
                        <p className="text-white text-sm">{q.question}</p>
                        <p className={`text-sm ${quizAnswers[i] === q.correct_answer ? 'text-green-400' : 'text-red-400'}`}>
                          Your answer: {quizAnswers[i]} {quizAnswers[i] === q.correct_answer ? '✓' : `✗ (Correct: ${q.correct_answer})`}
                        </p>
                        {q.explanation && <p className="text-gray-400 text-xs mt-1">{q.explanation}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}