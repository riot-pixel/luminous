import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Star, Flame, Target, Medal, Crown, Zap, Award } from "lucide-react";

const LEVEL_THRESHOLDS = [0, 100, 300, 600, 1000, 1500, 2500, 4000, 6000, 10000];
const LEVEL_NAMES = ["Novice", "Learner", "Explorer", "Achiever", "Expert", "Master", "Guru", "Legend", "Champion", "Grandmaster"];

const ACHIEVEMENT_BADGES = [
  { id: "first_module", name: "First Steps", icon: "🎯", description: "Complete your first module", points: 50 },
  { id: "streak_7", name: "Week Warrior", icon: "🔥", description: "7-day learning streak", points: 100 },
  { id: "streak_30", name: "Monthly Master", icon: "⚡", description: "30-day learning streak", points: 500 },
  { id: "perfect_score", name: "Perfect Score", icon: "💯", description: "Score 100% on an assessment", points: 150 },
  { id: "speed_learner", name: "Speed Learner", icon: "🚀", description: "Complete a module in under 30 minutes", points: 75 },
  { id: "course_complete", name: "Course Champion", icon: "🏆", description: "Complete an entire course", points: 300 },
  { id: "five_courses", name: "Knowledge Seeker", icon: "📚", description: "Complete 5 courses", points: 1000 },
  { id: "helper", name: "Community Helper", icon: "🤝", description: "Help another learner", points: 200 },
];

export default function GamificationPanel({ user }) {
  const { data: journeys } = useQuery({
    queryKey: ['userJourneysGamification', user?.email],
    queryFn: () => base44.entities.LearningJourney.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: allUsers } = useQuery({
    queryKey: ['leaderboardUsers'],
    queryFn: async () => {
      const journeysAll = await base44.entities.LearningJourney.list('-bonus_points_earned', 100);
      const userPoints = {};
      journeysAll.forEach(j => {
        if (j.user_email) {
          userPoints[j.user_email] = (userPoints[j.user_email] || 0) + (j.bonus_points_earned || 0);
        }
      });
      return Object.entries(userPoints)
        .map(([email, points]) => ({ email, points }))
        .sort((a, b) => b.points - a.points)
        .slice(0, 10);
    },
    initialData: [],
  });

  // Calculate user stats
  const totalPoints = journeys?.reduce((acc, j) => acc + (j.bonus_points_earned || 0), 0) || 0;
  const totalBadges = journeys?.reduce((acc, j) => acc + (j.badges_earned?.length || 0), 0) || 0;
  const completedModules = journeys?.reduce((acc, j) => acc + (j.modules?.filter(m => m.status === 'completed').length || 0), 0) || 0;
  const completedCourses = journeys?.filter(j => j.status === 'completed').length || 0;

  // Calculate level
  const currentLevel = LEVEL_THRESHOLDS.findIndex((threshold, i) => 
    totalPoints < (LEVEL_THRESHOLDS[i + 1] || Infinity)
  );
  const levelName = LEVEL_NAMES[currentLevel] || LEVEL_NAMES[0];
  const currentThreshold = LEVEL_THRESHOLDS[currentLevel] || 0;
  const nextThreshold = LEVEL_THRESHOLDS[currentLevel + 1] || LEVEL_THRESHOLDS[currentLevel];
  const levelProgress = ((totalPoints - currentThreshold) / (nextThreshold - currentThreshold)) * 100;

  // Calculate streak (simplified)
  const streak = Math.min(completedModules, 30);

  // Earned badges
  const earnedBadges = [];
  if (completedModules >= 1) earnedBadges.push(ACHIEVEMENT_BADGES[0]);
  if (streak >= 7) earnedBadges.push(ACHIEVEMENT_BADGES[1]);
  if (streak >= 30) earnedBadges.push(ACHIEVEMENT_BADGES[2]);
  if (completedCourses >= 1) earnedBadges.push(ACHIEVEMENT_BADGES[5]);
  if (completedCourses >= 5) earnedBadges.push(ACHIEVEMENT_BADGES[6]);

  const userRank = allUsers.findIndex(u => u.email === user?.email) + 1;

  return (
    <div className="space-y-6">
      {/* User Stats Card */}
      <Card className="bg-gradient-to-r from-purple-900/40 to-blue-900/40 border-purple-800">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar className="w-20 h-20 border-4 border-purple-500">
                <AvatarFallback className="bg-purple-600 text-2xl">{user?.full_name?.[0] || user?.email?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-black font-bold text-sm">
                {currentLevel + 1}
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-white font-medium text-lg">{user?.full_name || 'Learner'}</h3>
              <p className="text-purple-300">{levelName}</p>
              <div className="mt-2">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-gray-400">Level {currentLevel + 1}</span>
                  <span className="text-purple-300">{totalPoints} / {nextThreshold} XP</span>
                </div>
                <Progress value={levelProgress} className="h-2" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-3 bg-black/30 rounded-lg">
                <Star className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
                <p className="text-white font-bold">{totalPoints}</p>
                <p className="text-gray-400 text-xs">XP Points</p>
              </div>
              <div className="p-3 bg-black/30 rounded-lg">
                <Flame className="w-5 h-5 text-orange-400 mx-auto mb-1" />
                <p className="text-white font-bold">{streak}</p>
                <p className="text-gray-400 text-xs">Day Streak</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="achievements" className="space-y-4">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="achievements"><Award className="w-4 h-4 mr-1" />Achievements</TabsTrigger>
          <TabsTrigger value="leaderboard"><Trophy className="w-4 h-4 mr-1" />Leaderboard</TabsTrigger>
          <TabsTrigger value="stats"><Target className="w-4 h-4 mr-1" />Stats</TabsTrigger>
        </TabsList>

        <TabsContent value="achievements">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">Badges & Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {ACHIEVEMENT_BADGES.map(badge => {
                  const isEarned = earnedBadges.some(b => b.id === badge.id);
                  return (
                    <div 
                      key={badge.id} 
                      className={`p-3 rounded-lg text-center ${isEarned ? 'bg-yellow-900/30 border border-yellow-800' : 'bg-gray-800 opacity-50'}`}
                    >
                      <span className="text-3xl">{badge.icon}</span>
                      <p className={`text-sm font-medium mt-1 ${isEarned ? 'text-yellow-300' : 'text-gray-400'}`}>{badge.name}</p>
                      <p className="text-xs text-gray-500 mt-1">{badge.description}</p>
                      <Badge className={`mt-2 ${isEarned ? 'bg-yellow-600' : 'bg-gray-700'}`}>+{badge.points} XP</Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaderboard">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white text-sm">Global Leaderboard</CardTitle>
                {userRank > 0 && <Badge className="bg-purple-600">Your Rank: #{userRank}</Badge>}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {allUsers.map((u, i) => {
                  const isCurrentUser = u.email === user?.email;
                  return (
                    <div 
                      key={u.email} 
                      className={`flex items-center gap-3 p-3 rounded-lg ${isCurrentUser ? 'bg-purple-900/30 border border-purple-800' : 'bg-gray-800'}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                        i === 0 ? 'bg-yellow-500 text-black' :
                        i === 1 ? 'bg-gray-400 text-black' :
                        i === 2 ? 'bg-orange-600 text-white' : 'bg-gray-700 text-white'
                      }`}>
                        {i < 3 ? <Crown className="w-4 h-4" /> : i + 1}
                      </div>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-blue-600 text-xs">{u.email?.[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className={`text-sm ${isCurrentUser ? 'text-purple-300 font-medium' : 'text-white'}`}>
                          {isCurrentUser ? 'You' : u.email.split('@')[0]}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span className="text-white font-medium">{u.points}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-gray-800 rounded-lg text-center">
                  <Target className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{completedModules}</p>
                  <p className="text-gray-400 text-sm">Modules Completed</p>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg text-center">
                  <Trophy className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{completedCourses}</p>
                  <p className="text-gray-400 text-sm">Courses Completed</p>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg text-center">
                  <Medal className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{totalBadges}</p>
                  <p className="text-gray-400 text-sm">Badges Earned</p>
                </div>
                <div className="p-4 bg-gray-800 rounded-lg text-center">
                  <Zap className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{journeys?.length || 0}</p>
                  <p className="text-gray-400 text-sm">Active Journeys</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}