import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Scale, CheckCircle2, HelpCircle, Layers, 
  Clock, Users, AlertTriangle, ArrowDown
} from "lucide-react";
import { motion } from "framer-motion";

export default function DecisionSpineView({ decisionSpine }) {
  if (!decisionSpine) return null;

  return (
    <div className="space-y-6">
      {/* Decision Principles */}
      {decisionSpine.decision_principles?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Scale className="w-5 h-5 text-blue-400" />
              Decision Principles
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {decisionSpine.decision_principles.map((principle, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-blue-500/20"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-400 font-bold">{idx + 1}</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium mb-2">{principle.principle}</h4>
                      <div className="grid md:grid-cols-2 gap-3">
                        <div className="p-3 bg-white/5 rounded-lg">
                          <p className="text-[10px] text-gray-500 uppercase mb-1">When to Apply</p>
                          <p className="text-sm text-gray-300">{principle.when_to_apply}</p>
                        </div>
                        <div className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                          <p className="text-[10px] text-emerald-400 uppercase mb-1">Example</p>
                          <p className="text-sm text-emerald-300">{principle.example}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Decision Hierarchy */}
      {decisionSpine.decision_hierarchy?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Layers className="w-5 h-5 text-purple-400" />
              Decision Hierarchy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              {decisionSpine.decision_hierarchy.map((level, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.15 }}
                  className="relative"
                >
                  {idx > 0 && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <ArrowDown className="w-5 h-5 text-gray-600" />
                    </div>
                  )}
                  <div 
                    className={`p-4 rounded-xl border mb-6 ${
                      idx === 0 
                        ? 'bg-gradient-to-r from-red-500/20 to-orange-500/20 border-red-500/30' 
                        : idx === 1 
                          ? 'bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border-yellow-500/30 ml-8'
                          : idx === 2
                            ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border-blue-500/30 ml-16'
                            : 'bg-white/5 border-white/10 ml-24'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <Badge className={
                          idx === 0 ? 'bg-red-500' : 
                          idx === 1 ? 'bg-yellow-500' : 
                          idx === 2 ? 'bg-blue-500' : 'bg-gray-500'
                        }>
                          {level.level}
                        </Badge>
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {level.decision_maker}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {level.time_to_decide}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {level.decision_types?.map((type, i) => (
                        <span 
                          key={i} 
                          className="text-xs px-2 py-1 bg-white/10 text-gray-300 rounded"
                        >
                          {type}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Strategic Filters */}
      {decisionSpine.strategic_filters?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <HelpCircle className="w-5 h-5 text-amber-400" />
              Strategic Decision Filters
            </CardTitle>
            <p className="text-sm text-gray-500">Questions to ask before making strategic decisions</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {decisionSpine.strategic_filters.map((filter, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-amber-500/30 transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-amber-400 font-bold text-sm">{idx + 1}</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium mb-2">{filter.question}</p>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm text-emerald-400">Pass if: {filter.pass_threshold}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}