import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Star, Target, ArrowRight, AlertTriangle, CheckCircle2, 
  Compass, TrendingUp, Shield, Zap
} from "lucide-react";
import { motion } from "framer-motion";

export default function StrategicMapView({ strategicMap, timeframe }) {
  if (!strategicMap) return null;

  const getSeverityColor = (severity) => {
    switch(severity?.toLowerCase()) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* North Star */}
      {strategicMap.north_star && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500/20 via-yellow-500/10 to-orange-500/20 border border-amber-500/30 p-8"
        >
          <div className="absolute top-4 right-4">
            <Star className="w-12 h-12 text-amber-400/30" />
          </div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-xs text-amber-400 uppercase tracking-widest">North Star • {timeframe?.replace('_', ' ')}</p>
              <h2 className="text-xl font-light text-white">Guiding Vision</h2>
            </div>
          </div>
          <p className="text-lg text-gray-200 leading-relaxed">{strategicMap.north_star}</p>
        </motion.div>
      )}

      {/* 12-Line Strategic Map */}
      {strategicMap.strategic_lines?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Target className="w-5 h-5 text-purple-400" />
              12-Line Strategic Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {strategicMap.strategic_lines.map((line, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-purple-500/30 transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 font-bold text-sm flex-shrink-0">
                      {line.line_number || idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-purple-400 uppercase tracking-widest mb-1">{line.domain}</p>
                      <div className="grid md:grid-cols-2 gap-4 mb-3">
                        <div className="p-3 bg-white/5 rounded-lg">
                          <p className="text-[10px] text-gray-500 uppercase mb-1">Current State</p>
                          <p className="text-sm text-gray-300">{line.current_state}</p>
                        </div>
                        <div className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                          <p className="text-[10px] text-emerald-400 uppercase mb-1">Future State</p>
                          <p className="text-sm text-emerald-300">{line.future_state}</p>
                        </div>
                      </div>
                      {line.key_moves?.length > 0 && (
                        <div className="mb-2">
                          <p className="text-[10px] text-gray-500 uppercase mb-1">Key Moves</p>
                          <div className="flex flex-wrap gap-1">
                            {line.key_moves.map((move, i) => (
                              <span key={i} className="text-xs px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded">
                                {move}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-2">
                        {line.blockers?.length > 0 && (
                          <div>
                            <p className="text-[10px] text-red-400 uppercase mb-1">Blockers</p>
                            <div className="space-y-1">
                              {line.blockers.map((b, i) => (
                                <div key={i} className="text-xs text-red-300 flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3" />
                                  {b}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {line.enablers?.length > 0 && (
                          <div>
                            <p className="text-[10px] text-emerald-400 uppercase mb-1">Enablers</p>
                            <div className="space-y-1">
                              {line.enablers.map((e, i) => (
                                <div key={i} className="text-xs text-emerald-300 flex items-center gap-1">
                                  <Zap className="w-3 h-3" />
                                  {e}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Market Positioning */}
      {strategicMap.market_positioning && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              Market Positioning
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-xl">
                  <p className="text-xs text-gray-500 uppercase mb-2">Current Position</p>
                  <p className="text-gray-300">{strategicMap.market_positioning.current_position}</p>
                </div>
                <div className="flex items-center justify-center">
                  <ArrowRight className="w-6 h-6 text-blue-400" />
                </div>
                <div className="p-4 bg-blue-500/10 rounded-xl border border-blue-500/20">
                  <p className="text-xs text-blue-400 uppercase mb-2">Target Position</p>
                  <p className="text-blue-200">{strategicMap.market_positioning.target_position}</p>
                </div>
              </div>
              <div className="space-y-4">
                {strategicMap.market_positioning.differentiation?.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Differentiation</p>
                    <div className="flex flex-wrap gap-2">
                      {strategicMap.market_positioning.differentiation.map((d, i) => (
                        <Badge key={i} className="bg-purple-500/20 text-purple-300">{d}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                {strategicMap.market_positioning.competitive_moats?.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-500 uppercase mb-2">Competitive Moats</p>
                    <div className="space-y-2">
                      {strategicMap.market_positioning.competitive_moats.map((moat, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-emerald-300">
                          <Shield className="w-4 h-4" />
                          {moat}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bottlenecks */}
      {strategicMap.bottlenecks?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <AlertTriangle className="w-5 h-5 text-orange-400" />
              Internal Bottlenecks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {strategicMap.bottlenecks.map((bottleneck, idx) => (
                <div key={idx} className="p-4 bg-white/5 rounded-xl border border-orange-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <p className="font-medium text-white">{bottleneck.area}</p>
                    <Badge className={getSeverityColor(bottleneck.severity)}>{bottleneck.severity}</Badge>
                  </div>
                  <p className="text-sm text-gray-400 mb-2">{bottleneck.impact}</p>
                  <div className="p-2 bg-emerald-500/10 rounded border border-emerald-500/20">
                    <p className="text-xs text-emerald-400 uppercase mb-1">Resolution Path</p>
                    <p className="text-sm text-emerald-300">{bottleneck.resolution_path}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}