import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target, Users, Clock, AlertCircle, CheckCircle2, 
  ArrowRight, DollarSign, Calendar
} from "lucide-react";
import { motion } from "framer-motion";

export default function PriorityDashboard({ priorityData }) {
  if (!priorityData) return null;

  const getRiskColor = (risk) => {
    switch(risk?.toLowerCase()) {
      case 'high': return 'text-red-400 bg-red-500/20';
      case 'medium': return 'text-yellow-400 bg-yellow-500/20';
      default: return 'text-green-400 bg-green-500/20';
    }
  };

  const getStatusColor = (status) => {
    switch(status?.toLowerCase()) {
      case 'completed': return 'bg-emerald-500';
      case 'in_progress': case 'in progress': return 'bg-blue-500';
      case 'blocked': return 'bg-red-500';
      case 'at_risk': case 'at risk': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Resource Overview */}
      {priorityData.resource_allocation && (
        <div className="grid grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-gradient-to-br from-blue-500/20 to-blue-600/10 rounded-xl border border-blue-500/20"
          >
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span className="text-xs text-blue-400 uppercase tracking-widest">People</span>
            </div>
            <p className="text-3xl font-light text-white">{priorityData.resource_allocation.people || 0}</p>
            <p className="text-xs text-gray-500">Resources Allocated</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="p-4 bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 rounded-xl border border-emerald-500/20"
          >
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              <span className="text-xs text-emerald-400 uppercase tracking-widest">Budget</span>
            </div>
            <p className="text-3xl font-light text-white">${(priorityData.resource_allocation.budget || 0).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Committed</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-4 bg-gradient-to-br from-purple-500/20 to-purple-600/10 rounded-xl border border-purple-500/20"
          >
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-5 h-5 text-purple-400" />
              <span className="text-xs text-purple-400 uppercase tracking-widest">Timeline</span>
            </div>
            <p className="text-2xl font-light text-white">{priorityData.resource_allocation.time || 'TBD'}</p>
            <p className="text-xs text-gray-500">Execution Window</p>
          </motion.div>
        </div>
      )}

      {/* Tier 1 Priorities */}
      {priorityData.tier_1_priorities?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Target className="w-5 h-5 text-red-400" />
              Tier 1 Priorities
              <Badge className="bg-red-500 ml-2">Critical</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {priorityData.tier_1_priorities.map((priority, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 bg-white/5 rounded-xl border border-white/10 hover:border-red-500/30 transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-white mb-1">{priority.priority}</h4>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        {priority.owner && (
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" /> {priority.owner}
                          </span>
                        )}
                        {priority.deadline && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" /> {priority.deadline}
                          </span>
                        )}
                      </div>
                    </div>
                    <Badge className={getRiskColor(priority.risk_level)}>
                      {priority.risk_level} risk
                    </Badge>
                  </div>
                  
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-gray-500">Progress</span>
                      <span className="text-white">{priority.progress || 0}%</span>
                    </div>
                    <Progress value={priority.progress || 0} className="h-2" />
                  </div>

                  {priority.dependencies?.length > 0 && (
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Dependencies</p>
                      <div className="flex flex-wrap gap-1">
                        {priority.dependencies.map((dep, i) => (
                          <span key={i} className="text-xs px-2 py-0.5 bg-white/10 text-gray-400 rounded">
                            {dep}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tier 2 Priorities */}
      {priorityData.tier_2_priorities?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Target className="w-5 h-5 text-yellow-400" />
              Tier 2 Priorities
              <Badge className="bg-yellow-500 ml-2">Important</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {priorityData.tier_2_priorities.map((priority, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-3 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-white mb-1">{priority.priority}</p>
                      {priority.linked_to_tier_1 && (
                        <p className="text-xs text-gray-500 flex items-center gap-1">
                          <ArrowRight className="w-3 h-3" />
                          Linked to: {priority.linked_to_tier_1}
                        </p>
                      )}
                    </div>
                    <Badge className={getStatusColor(priority.status)} variant="outline">
                      {priority.status}
                    </Badge>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}