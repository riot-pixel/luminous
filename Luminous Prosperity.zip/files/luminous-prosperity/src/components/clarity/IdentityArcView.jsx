import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, ArrowRight, Heart, Lightbulb, 
  Zap, RefreshCw, ChevronRight
} from "lucide-react";
import { motion } from "framer-motion";

export default function IdentityArcView({ identityArc }) {
  if (!identityArc) return null;

  return (
    <div className="space-y-6">
      {/* Identity Evolution Timeline */}
      <Card className="bg-white/5 border-white/10 overflow-hidden">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <RefreshCw className="w-5 h-5 text-purple-400" />
            Identity Evolution Arc
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute top-12 left-0 right-0 h-0.5 bg-gradient-to-r from-gray-600 via-purple-500 to-amber-500" />
            
            <div className="grid grid-cols-4 gap-4 relative">
              {/* Origin */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
              >
                <div className="w-10 h-10 rounded-full bg-gray-600 mx-auto mb-4 flex items-center justify-center z-10 relative">
                  <span className="text-xs text-white">Past</span>
                </div>
                <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Origin</p>
                <p className="text-sm text-gray-400">{identityArc.origin_story}</p>
              </motion.div>

              {/* Current */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-center"
              >
                <div className="w-10 h-10 rounded-full bg-blue-500 mx-auto mb-4 flex items-center justify-center z-10 relative">
                  <span className="text-xs text-white">Now</span>
                </div>
                <p className="text-xs text-blue-400 uppercase tracking-widest mb-2">Current</p>
                <p className="text-sm text-blue-300">{identityArc.current_identity}</p>
              </motion.div>

              {/* Emerging */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-center"
              >
                <div className="w-10 h-10 rounded-full bg-purple-500 mx-auto mb-4 flex items-center justify-center z-10 relative animate-pulse">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs text-purple-400 uppercase tracking-widest mb-2">Emerging</p>
                <p className="text-sm text-purple-300">{identityArc.emerging_identity}</p>
              </motion.div>

              {/* Future */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-center"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 mx-auto mb-4 flex items-center justify-center z-10 relative">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Future</p>
                <p className="text-sm text-amber-300">{identityArc.future_identity}</p>
              </motion.div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Identity Tensions */}
      {identityArc.identity_tensions?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Lightbulb className="w-5 h-5 text-yellow-400" />
              Identity Tensions to Navigate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {identityArc.identity_tensions.map((tension, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 bg-white/5 rounded-xl border border-yellow-500/20"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
                      <Zap className="w-4 h-4 text-yellow-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium mb-2">{tension.tension}</p>
                      <div className="p-3 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                        <p className="text-xs text-emerald-400 uppercase mb-1">Resolution Path</p>
                        <p className="text-sm text-emerald-300">{tension.resolution_path}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cultural Markers */}
      {identityArc.cultural_markers?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Heart className="w-5 h-5 text-pink-400" />
              Cultural Markers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              {identityArc.cultural_markers.map((marker, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="px-4 py-2 bg-gradient-to-r from-pink-500/20 to-purple-500/20 rounded-full border border-pink-500/30"
                >
                  <span className="text-sm text-pink-300">{marker}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Values Evolution */}
      {identityArc.values_evolution?.length > 0 && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Sparkles className="w-5 h-5 text-amber-400" />
              Values Evolution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {identityArc.values_evolution.map((value, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 bg-white/5 rounded-xl"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-amber-500">{value.value}</Badge>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-3 bg-gray-500/10 rounded-lg">
                      <p className="text-[10px] text-gray-500 uppercase mb-1">Past Expression</p>
                      <p className="text-sm text-gray-400">{value.past_expression}</p>
                    </div>
                    <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
                      <p className="text-[10px] text-amber-400 uppercase mb-1">Future Expression</p>
                      <p className="text-sm text-amber-300">{value.future_expression}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}