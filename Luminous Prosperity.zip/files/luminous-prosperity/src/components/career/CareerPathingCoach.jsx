import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Brain, Target, Users, BookOpen, Award, Sparkles, ArrowRight, 
  CheckCircle2, Clock, Zap, TrendingUp, Star, Play, MessageCircle,
  Briefcase, GraduationCap, Lightbulb, Route, RefreshCw, Send,
  Trophy, Medal, Flame, Heart, UserPlus, Bot
} from "lucide-react";
import DynamicLearningPath from "./DynamicLearningPath";
import AICoachingSimulator from "./AICoachingSimulator";

export default function CareerPathingCoach({ user, assessment, userSkills, roleRequirements, allUsers }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [careerPlan, setCareerPlan] = useState(null);
  const [showGoalDialog, setShowGoalDialog] = useState(false);
  const [simulatingTransition, setSimulatingTransition] = useState(false);
  const [transitionSimulation, setTransitionSimulation] = useState(null);
  const [showCoachChat, setShowCoachChat] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [isCoachTyping, setIsCoachTyping] = useState(false);
  const [proactiveInsight, setProactiveInsight] = useState(null);
  const [suggestedMentors, setSuggestedMentors] = useState([]);
  const [careerGoals, setCareerGoals] = useState({
    targetRole: '',
    timeline: '1-2 years',
    priorities: [],
    interests: '',
  });

  const priorities = [
    'Higher salary',
    'More leadership',
    'Better work-life balance',
    'Technical depth',
    'People management',
    'Strategic influence',
    'Creative work',
    'Industry expertise',
  ];

  // Get available roles and potential mentors
  const availableRoles = [...new Set(roleRequirements.map(r => r.role_title))];
  const potentialMentors = allUsers?.filter(u => 
    u.user_role === 'executive' || u.user_role === 'manager' || u.user_role === 'c_suite'
  ) || [];

  // Generate proactive insight on mount
  useEffect(() => {
    if (user && assessment && !proactiveInsight) {
      generateProactiveInsight();
    }
  }, [user, assessment]);

  // Generate proactive insight based on user data
  const generateProactiveInsight = async () => {
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a friendly, encouraging AI career coach. Generate a brief proactive insight for this employee:

EMPLOYEE: ${user?.full_name}
ROLE: ${user?.job_title || 'Not specified'}
PERSONALITY: ${assessment?.myers_briggs?.type || 'Unknown'}
TOP STRENGTHS: ${assessment?.strengths?.top_strengths?.slice(0, 3).map(s => s.name).join(', ') || 'Not assessed'}
CAREER SATISFACTION: ${assessment?.life_wheel?.career ? (assessment.life_wheel.career * 10) + '%' : 'Unknown'}
SKILLS COUNT: ${userSkills?.length || 0}

Generate ONE brief, personalized motivational message (2-3 sentences) that:
1. Acknowledges something specific about their profile
2. Suggests ONE actionable next step
3. Encourages them to engage with their career development

Be warm, specific, and actionable. Avoid generic advice.`,
        response_json_schema: {
          type: "object",
          properties: {
            greeting: { type: "string" },
            insight: { type: "string" },
            suggested_action: { type: "string" },
            badge_highlight: { type: "string" }
          }
        }
      });
      setProactiveInsight(result);
    } catch (error) {
      console.error("Error generating proactive insight:", error);
    }
  };

  // Find suggested mentors based on skill profile
  const findSuggestedMentors = async () => {
    if (!userSkills || userSkills.length === 0 || !allUsers) return;

    try {
      const mentorData = potentialMentors.slice(0, 15).map(m => ({
        name: m.full_name,
        email: m.email,
        role: m.job_title,
        department: m.department
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Match this employee with the best mentors from the available list.

EMPLOYEE:
- Name: ${user?.full_name}
- Role: ${user?.job_title}
- Department: ${user?.department}
- Skills: ${userSkills.slice(0, 10).map(s => s.skill_name).join(', ')}
- Personality: ${assessment?.myers_briggs?.type || 'Unknown'}
- Career Goals: ${careerGoals.targetRole || 'Not specified'}

AVAILABLE MENTORS:
${mentorData.map(m => `- ${m.name} (${m.role}, ${m.department})`).join('\n')}

Select the top 3 best mentor matches and explain why each would be valuable.`,
        response_json_schema: {
          type: "object",
          properties: {
            matches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  mentor_name: { type: "string" },
                  match_reason: { type: "string" },
                  topics_to_discuss: { type: "array", items: { type: "string" } },
                  compatibility_score: { type: "number" }
                }
              }
            }
          }
        }
      });

      const matchedMentors = result.matches.map(match => {
        const mentorInfo = potentialMentors.find(m => m.full_name === match.mentor_name);
        return { ...match, ...mentorInfo };
      }).filter(m => m.email);

      setSuggestedMentors(matchedMentors);
    } catch (error) {
      console.error("Error finding mentors:", error);
    }
  };

  // Chat with AI Coach
  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = { role: 'user', content: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsCoachTyping(true);

    try {
      const context = `
EMPLOYEE CONTEXT:
- Name: ${user?.full_name}
- Current Role: ${user?.job_title || 'Not specified'}
- Department: ${user?.department || 'Not specified'}
- Personality Type: ${assessment?.myers_briggs?.type || 'Unknown'}
- Top Strengths: ${assessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ') || 'Not assessed'}
- Current Skills: ${userSkills?.slice(0, 10).map(s => `${s.skill_name}(${s.current_proficiency})`).join(', ') || 'None recorded'}
- Career Goals: ${careerGoals.targetRole || 'Not set'}
- Priorities: ${careerGoals.priorities.join(', ') || 'Not specified'}

CONVERSATION HISTORY:
${chatMessages.slice(-6).map(m => `${m.role}: ${m.content}`).join('\n')}
`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an empathetic, insightful AI career coach named "Luminous Coach". 
        
${context}

USER'S LATEST MESSAGE: ${chatInput}

Respond as a supportive career coach. Be:
1. Warm and encouraging
2. Specific to their situation (reference their skills, strengths, or goals)
3. Actionable - suggest concrete next steps
4. Motivating - highlight badges, achievements, or learning journeys they could pursue

Keep response under 150 words. Use their name occasionally.`,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            suggested_action: { type: "string" },
            related_badge: { type: "string" },
            encouragement: { type: "string" }
          }
        }
      });

      const coachMessage = {
        role: 'coach',
        content: result.response,
        action: result.suggested_action,
        badge: result.related_badge
      };
      setChatMessages(prev => [...prev, coachMessage]);
    } catch (error) {
      console.error("Error in coach chat:", error);
      setChatMessages(prev => [...prev, { 
        role: 'coach', 
        content: "I'm having trouble connecting right now. Let's try again in a moment." 
      }]);
    }
    setIsCoachTyping(false);
  };

  // Initialize chat with welcome message
  const initializeChat = () => {
    setShowCoachChat(true);
    if (chatMessages.length === 0) {
      setChatMessages([{
        role: 'coach',
        content: `Hi ${user?.full_name?.split(' ')[0] || 'there'}! 👋 I'm your Luminous Career Coach. I've reviewed your profile and I'm here to help you navigate your career journey. What's on your mind today?`,
        action: 'Set your career goals to get personalized recommendations',
        badge: null
      }]);
    }
    findSuggestedMentors();
  };

  const generatePersonalizedPlan = async () => {
    setIsAnalyzing(true);
    try {
      // Calculate skill gaps
      const userSkillMap = userSkills.reduce((acc, s) => {
        acc[s.skill_name] = s.current_proficiency;
        return acc;
      }, {});

      const targetRoleReqs = roleRequirements.filter(r => r.role_title === careerGoals.targetRole);
      const skillGaps = targetRoleReqs.filter(req => {
        const profOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
        const current = profOrder.indexOf(userSkillMap[req.skill_name] || 'None');
        const required = profOrder.indexOf(req.required_proficiency);
        return current < required;
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert career coach and organizational development specialist.

Create a comprehensive, personalized career development plan:

EMPLOYEE PROFILE:
- Name: ${user?.full_name}
- Current Role: ${user?.job_title || 'Not specified'}
- Department: ${user?.department || 'Not specified'}
- Personality Type: ${assessment?.myers_briggs?.type || 'Unknown'}
- Top Strengths: ${assessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ') || 'Not assessed'}
- Career Satisfaction: ${assessment?.life_wheel?.career ? assessment.life_wheel.career * 10 : 'Unknown'}%
- Growth Score: ${assessment?.life_wheel?.personal_growth ? assessment.life_wheel.personal_growth * 10 : 'Unknown'}%

CURRENT SKILLS:
${userSkills.map(s => `- ${s.skill_name}: ${s.current_proficiency}`).join('\n') || 'No skills recorded'}

CAREER GOALS:
- Target Role: ${careerGoals.targetRole}
- Desired Timeline: ${careerGoals.timeline}
- Priorities: ${careerGoals.priorities.join(', ')}
- Interests/Notes: ${careerGoals.interests}

SKILL GAPS FOR TARGET ROLE:
${skillGaps.map(g => `- ${g.skill_name}: needs ${g.required_proficiency} (${g.priority})`).join('\n') || 'No gaps identified'}

POTENTIAL MENTORS AVAILABLE:
${potentialMentors.slice(0, 10).map(m => `- ${m.full_name} (${m.job_title}, ${m.department})`).join('\n')}

Provide:
1. A realistic assessment of the transition
2. Detailed phased development plan (3 phases)
3. Specific training recommendations with actual course names and platforms
4. Internal mentorship matches with specific discussion topics
5. Project-based learning opportunities
6. Stretch assignments to build credibility
7. Networking strategies within the organization
8. Risk factors and mitigation strategies
9. Success metrics and milestones`,
        response_json_schema: {
          type: "object",
          properties: {
            assessment: {
              type: "object",
              properties: {
                readiness_score: { type: "number" },
                confidence_level: { type: "string" },
                key_advantages: { type: "array", items: { type: "string" } },
                key_challenges: { type: "array", items: { type: "string" } },
                realistic_timeline: { type: "string" },
                success_probability: { type: "string" }
              }
            },
            development_phases: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  phase_name: { type: "string" },
                  duration: { type: "string" },
                  focus_areas: { type: "array", items: { type: "string" } },
                  key_actions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        action: { type: "string" },
                        category: { type: "string" },
                        priority: { type: "string" },
                        expected_outcome: { type: "string" }
                      }
                    }
                  },
                  success_metrics: { type: "array", items: { type: "string" } },
                  milestones: { type: "array", items: { type: "string" } }
                }
              }
            },
            training_plan: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  skill_area: { type: "string" },
                  current_gap: { type: "string" },
                  courses: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        platform: { type: "string" },
                        duration: { type: "string" },
                        level: { type: "string" },
                        why_recommended: { type: "string" }
                      }
                    }
                  },
                  certifications: { type: "array", items: { type: "string" } },
                  books: { type: "array", items: { type: "string" } },
                  estimated_time_to_proficiency: { type: "string" }
                }
              }
            },
            mentorship_plan: {
              type: "object",
              properties: {
                recommended_mentor_profiles: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      profile_type: { type: "string" },
                      ideal_background: { type: "string" },
                      what_to_learn: { type: "array", items: { type: "string" } },
                      meeting_frequency: { type: "string" },
                      conversation_starters: { type: "array", items: { type: "string" } }
                    }
                  }
                },
                peer_learning: {
                  type: "array",
                  items: { type: "string" }
                },
                reverse_mentoring: { type: "string" }
              }
            },
            project_opportunities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  project_type: { type: "string" },
                  description: { type: "string" },
                  skills_developed: { type: "array", items: { type: "string" } },
                  visibility_level: { type: "string" },
                  how_to_access: { type: "string" },
                  success_criteria: { type: "string" }
                }
              }
            },
            stretch_assignments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  assignment: { type: "string" },
                  growth_area: { type: "string" },
                  risk_level: { type: "string" },
                  support_needed: { type: "string" }
                }
              }
            },
            networking_strategy: {
              type: "object",
              properties: {
                internal_connections: { type: "array", items: { type: "string" } },
                communities_to_join: { type: "array", items: { type: "string" } },
                visibility_tactics: { type: "array", items: { type: "string" } }
              }
            },
            risk_mitigation: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  likelihood: { type: "string" },
                  mitigation: { type: "string" }
                }
              }
            },
            quick_wins: { type: "array", items: { type: "string" } }
          }
        }
      });

      setCareerPlan(result);
      setShowGoalDialog(false);
    } catch (error) {
      console.error("Error generating career plan:", error);
    }
    setIsAnalyzing(false);
  };

  const simulateTransition = async (targetRole) => {
    setSimulatingTransition(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Simulate a career transition for this employee:

FROM: ${user?.job_title} in ${user?.department}
TO: ${targetRole}

EMPLOYEE PROFILE:
- Personality: ${assessment?.myers_briggs?.type}
- Strengths: ${assessment?.strengths?.top_strengths?.slice(0, 3).map(s => s.name).join(', ')}
- Skills: ${userSkills.slice(0, 10).map(s => `${s.skill_name}(${s.current_proficiency})`).join(', ')}

Simulate:
1. Day 1-30: What the transition would look like
2. First 90 days: Key challenges and wins
3. 6-month outlook: Expected outcomes
4. Potential pitfalls and how to avoid them
5. Support systems needed`,
        response_json_schema: {
          type: "object",
          properties: {
            transition_summary: { type: "string" },
            fit_score: { type: "number" },
            day_1_30: {
              type: "object",
              properties: {
                focus: { type: "string" },
                challenges: { type: "array", items: { type: "string" } },
                quick_wins: { type: "array", items: { type: "string" } }
              }
            },
            first_90_days: {
              type: "object",
              properties: {
                milestones: { type: "array", items: { type: "string" } },
                key_relationships: { type: "array", items: { type: "string" } },
                expected_struggles: { type: "array", items: { type: "string" } }
              }
            },
            six_month_outlook: {
              type: "object",
              properties: {
                expected_performance: { type: "string" },
                growth_trajectory: { type: "string" },
                impact_potential: { type: "string" }
              }
            },
            pitfalls: { type: "array", items: { type: "string" } },
            support_needed: { type: "array", items: { type: "string" } },
            recommendation: { type: "string" }
          }
        }
      });

      setTransitionSimulation({ role: targetRole, ...result });
    } catch (error) {
      console.error("Error simulating transition:", error);
    }
    setSimulatingTransition(false);
  };

  const togglePriority = (priority) => {
    setCareerGoals(prev => ({
      ...prev,
      priorities: prev.priorities.includes(priority)
        ? prev.priorities.filter(p => p !== priority)
        : [...prev.priorities, priority]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Goal Setting Dialog */}
      <Dialog open={showGoalDialog} onOpenChange={setShowGoalDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-950 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-white">
              <Target className="w-5 h-5 text-amber-400" />
              Define Your Career Goals
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div>
              <Label className="text-gray-300">Target Role</Label>
              <Select value={careerGoals.targetRole} onValueChange={(v) => setCareerGoals({...careerGoals, targetRole: v})}>
                <SelectTrigger className="bg-black border-white/10 text-white">
                  <SelectValue placeholder="Select target role" />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10">
                  {availableRoles.map(role => (
                    <SelectItem key={role} value={role} className="text-white hover:bg-white/10">{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300">Desired Timeline</Label>
              <Select value={careerGoals.timeline} onValueChange={(v) => setCareerGoals({...careerGoals, timeline: v})}>
                <SelectTrigger className="bg-black border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-white/10">
                  <SelectItem value="6 months" className="text-white">6 months</SelectItem>
                  <SelectItem value="1 year" className="text-white">1 year</SelectItem>
                  <SelectItem value="1-2 years" className="text-white">1-2 years</SelectItem>
                  <SelectItem value="2-3 years" className="text-white">2-3 years</SelectItem>
                  <SelectItem value="3+ years" className="text-white">3+ years</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300 mb-3 block">What's Most Important to You?</Label>
              <div className="flex flex-wrap gap-2">
                {priorities.map(p => (
                  <button
                    key={p}
                    onClick={() => togglePriority(p)}
                    className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                      careerGoals.priorities.includes(p)
                        ? 'bg-amber-500 text-black'
                        : 'bg-white/10 text-gray-400 hover:bg-white/20'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Additional Goals or Interests</Label>
              <Textarea
                value={careerGoals.interests}
                onChange={(e) => setCareerGoals({...careerGoals, interests: e.target.value})}
                placeholder="Any specific interests, constraints, or goals..."
                className="bg-black border-white/10 text-white"
              />
            </div>

            <Button
              onClick={generatePersonalizedPlan}
              disabled={isAnalyzing || !careerGoals.targetRole}
              className="w-full bg-white text-black hover:bg-gray-200"
            >
              {isAnalyzing ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Creating Your Plan...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Generate Career Plan</>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Proactive Coach Engagement */}
      {proactiveInsight && !careerPlan && (
        <Card className="border-2 border-emerald-500/30 bg-gradient-to-r from-emerald-500/10 to-teal-500/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center flex-shrink-0">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-emerald-400 font-medium mb-1">{proactiveInsight.greeting}</p>
                <p className="text-gray-300 text-sm mb-3">{proactiveInsight.insight}</p>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-none">
                    <Lightbulb className="w-3 h-3 mr-1" />
                    {proactiveInsight.suggested_action}
                  </Badge>
                  {proactiveInsight.badge_highlight && (
                    <Badge className="bg-amber-500/20 text-amber-400 border-none">
                      <Trophy className="w-3 h-3 mr-1" />
                      {proactiveInsight.badge_highlight}
                    </Badge>
                  )}
                </div>
              </div>
              <Button 
                onClick={initializeChat} 
                size="sm" 
                className="bg-emerald-500 text-white hover:bg-emerald-400"
              >
                <MessageCircle className="w-4 h-4 mr-1" /> Chat
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Header Action */}
      {!careerPlan && (
        <Card className="border-2 border-amber-500/30 bg-gradient-to-r from-amber-500/10 to-orange-500/10">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/30 to-orange-500/30 flex items-center justify-center">
                  <Brain className="w-7 h-7 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">AI Career Pathing Coach</h3>
                  <p className="text-sm text-gray-400">Get a personalized development plan based on your goals</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={initializeChat} variant="outline" className="border-white/20 text-gray-300 hover:bg-white/10">
                  <MessageCircle className="w-4 h-4 mr-2" /> Talk to Coach
                </Button>
                <Button onClick={() => setShowGoalDialog(true)} className="bg-amber-500 text-black hover:bg-amber-400">
                  <Target className="w-4 h-4 mr-2" /> Set Career Goals
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Coach Chat Dialog */}
      <Dialog open={showCoachChat} onOpenChange={setShowCoachChat}>
        <DialogContent className="max-w-lg max-h-[80vh] bg-gray-950 border-white/10 text-white p-0 overflow-hidden">
          <div className="flex flex-col h-[70vh]">
            {/* Chat Header */}
            <div className="p-4 border-b border-white/10 bg-gradient-to-r from-emerald-500/20 to-teal-500/20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-medium text-white">Luminous Career Coach</h3>
                  <p className="text-xs text-emerald-400">Here to guide your career journey</p>
                </div>
              </div>
            </div>

            {/* Chat Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] ${msg.role === 'user' ? 'bg-amber-500 text-black' : 'bg-white/10 text-white'} rounded-2xl px-4 py-3`}>
                      <p className="text-sm">{msg.content}</p>
                      {msg.action && (
                        <div className="mt-2 pt-2 border-t border-white/20">
                          <p className="text-xs opacity-80">💡 {msg.action}</p>
                        </div>
                      )}
                      {msg.badge && (
                        <Badge className="mt-2 bg-amber-500/30 text-amber-300 border-none text-xs">
                          <Trophy className="w-3 h-3 mr-1" /> {msg.badge}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
                {isCoachTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white/10 rounded-2xl px-4 py-3">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                        <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                        <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Suggested Mentors */}
            {suggestedMentors.length > 0 && (
              <div className="px-4 py-2 border-t border-white/10 bg-white/5">
                <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Suggested Mentors</p>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {suggestedMentors.map((mentor, i) => (
                    <div key={i} className="flex-shrink-0 p-2 bg-white/5 rounded-lg border border-white/10 min-w-[180px]">
                      <div className="flex items-center gap-2 mb-1">
                        <Avatar className="w-6 h-6">
                          <AvatarFallback className="bg-purple-500/30 text-purple-400 text-xs">
                            {mentor.mentor_name?.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-white font-medium truncate">{mentor.mentor_name}</span>
                      </div>
                      <p className="text-[10px] text-gray-400 line-clamp-2">{mentor.match_reason}</p>
                      <Badge className="mt-1 bg-purple-500/20 text-purple-400 border-none text-[10px]">
                        {mentor.compatibility_score}% match
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Chat Input */}
            <div className="p-4 border-t border-white/10">
              <div className="flex gap-2">
                <Input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
                  placeholder="Ask about your career path..."
                  className="bg-white/5 border-white/10 text-white"
                />
                <Button 
                  onClick={sendChatMessage} 
                  disabled={isCoachTyping || !chatInput.trim()}
                  className="bg-emerald-500 hover:bg-emerald-400"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => { setChatInput("What badges should I work toward?"); }}
                  className="text-xs px-2 py-1 bg-white/5 rounded-full text-gray-400 hover:bg-white/10"
                >
                  🏆 Badges
                </button>
                <button
                  onClick={() => { setChatInput("What learning journey fits me best?"); }}
                  className="text-xs px-2 py-1 bg-white/5 rounded-full text-gray-400 hover:bg-white/10"
                >
                  📚 Learning Journeys
                </button>
                <button
                  onClick={() => { setChatInput("How am I progressing?"); }}
                  className="text-xs px-2 py-1 bg-white/5 rounded-full text-gray-400 hover:bg-white/10"
                >
                  📈 Progress
                </button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Career Plan Results */}
      {careerPlan && (
        <div className="space-y-6">
          {/* Assessment Summary */}
          <Card className="border border-white/10 bg-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Star className="w-5 h-5 text-amber-400" />
                Career Transition Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <p className="text-3xl font-light text-amber-400">{careerPlan.assessment?.readiness_score}%</p>
                  <p className="text-xs text-gray-500">Readiness Score</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <p className="text-lg font-medium text-white">{careerPlan.assessment?.confidence_level}</p>
                  <p className="text-xs text-gray-500">Confidence Level</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <p className="text-lg font-medium text-white">{careerPlan.assessment?.realistic_timeline}</p>
                  <p className="text-xs text-gray-500">Realistic Timeline</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <p className="text-lg font-medium text-emerald-400">{careerPlan.assessment?.success_probability}</p>
                  <p className="text-xs text-gray-500">Success Probability</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                  <p className="text-xs text-emerald-400 uppercase tracking-widest mb-2">Key Advantages</p>
                  <ul className="space-y-1">
                    {careerPlan.assessment?.key_advantages?.map((adv, i) => (
                      <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        {adv}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                  <p className="text-xs text-amber-400 uppercase tracking-widest mb-2">Key Challenges</p>
                  <ul className="space-y-1">
                    {careerPlan.assessment?.key_challenges?.map((ch, i) => (
                      <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                        <ArrowRight className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                        {ch}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Wins */}
          {careerPlan.quick_wins?.length > 0 && (
            <Card className="border border-emerald-500/20 bg-emerald-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-emerald-400">
                  <Zap className="w-5 h-5" />
                  Quick Wins - Start This Week
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-3">
                  {careerPlan.quick_wins.map((win, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-white/5 rounded-lg">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-300">{win}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Development Phases */}
          <Card className="border border-white/10 bg-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Route className="w-5 h-5 text-blue-400" />
                Development Phases
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="phase-0">
                <TabsList className="bg-white/5 mb-6">
                  {careerPlan.development_phases?.map((phase, i) => (
                    <TabsTrigger key={i} value={`phase-${i}`} className="data-[state=active]:bg-white data-[state=active]:text-black text-gray-400">
                      Phase {i + 1}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {careerPlan.development_phases?.map((phase, i) => (
                  <TabsContent key={i} value={`phase-${i}`} className="space-y-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="text-xl font-medium text-white">{phase.phase_name}</h4>
                        <p className="text-sm text-gray-500">{phase.duration}</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Focus Areas</p>
                        <div className="flex flex-wrap gap-2">
                          {phase.focus_areas?.map((area, j) => (
                            <Badge key={j} className="bg-blue-500/20 text-blue-400 border-none">{area}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Milestones</p>
                        <ul className="space-y-1">
                          {phase.milestones?.map((m, j) => (
                            <li key={j} className="text-sm text-gray-400 flex items-start gap-2">
                              <Star className="w-3 h-3 text-amber-400 mt-1 flex-shrink-0" />
                              {m}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="mt-4">
                      <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Key Actions</p>
                      <div className="space-y-2">
                        {phase.key_actions?.map((action, j) => (
                          <div key={j} className="p-3 bg-white/5 rounded-lg flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5" />
                              <div>
                                <p className="text-sm text-white">{action.action}</p>
                                <p className="text-xs text-gray-500">{action.expected_outcome}</p>
                              </div>
                            </div>
                            <Badge variant="outline" className={`text-xs ${
                              action.priority === 'high' ? 'border-red-500/50 text-red-400' :
                              action.priority === 'medium' ? 'border-amber-500/50 text-amber-400' :
                              'border-gray-500/50 text-gray-400'
                            }`}>{action.priority}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>

          {/* Training Plan */}
          {careerPlan.training_plan?.length > 0 && (
            <Card className="border border-white/10 bg-white/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <GraduationCap className="w-5 h-5 text-purple-400" />
                  Personalized Training Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {careerPlan.training_plan.map((area, i) => (
                    <div key={i} className="p-4 bg-white/5 rounded-xl">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-lg font-medium text-white">{area.skill_area}</h4>
                        <Badge className="bg-purple-500/20 text-purple-400 border-none">
                          ~{area.estimated_time_to_proficiency}
                        </Badge>
                      </div>
                      <p className="text-sm text-amber-400 mb-4">Gap: {area.current_gap}</p>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Recommended Courses</p>
                          <div className="space-y-2">
                            {area.courses?.map((course, j) => (
                              <div key={j} className="p-2 bg-black/30 rounded">
                                <p className="text-sm text-white font-medium">{course.title}</p>
                                <div className="flex gap-2 mt-1">
                                  <span className="text-[10px] px-1.5 py-0.5 bg-purple-500/20 text-purple-400 rounded">{course.platform}</span>
                                  <span className="text-[10px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded">{course.duration}</span>
                                  <span className="text-[10px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded">{course.level}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          {area.certifications?.length > 0 && (
                            <div className="mb-4">
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Certifications</p>
                              <div className="flex flex-wrap gap-1">
                                {area.certifications.map((cert, j) => (
                                  <Badge key={j} variant="outline" className="text-xs border-emerald-500/50 text-emerald-400">{cert}</Badge>
                                ))}
                              </div>
                            </div>
                          )}
                          {area.books?.length > 0 && (
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Books</p>
                              <ul className="space-y-1">
                                {area.books.map((book, j) => (
                                  <li key={j} className="text-xs text-gray-400">📚 {book}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Mentorship Plan with Real Mentor Suggestions */}
          {careerPlan.mentorship_plan && (
            <Card className="border border-white/10 bg-white/5">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Users className="w-5 h-5 text-emerald-400" />
                    Internal Mentorship Opportunities
                  </CardTitle>
                  <Button 
                    onClick={findSuggestedMentors} 
                    size="sm" 
                    variant="outline" 
                    className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                  >
                    <UserPlus className="w-4 h-4 mr-1" /> Find Mentors
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* AI-Matched Mentors from Organization */}
                {suggestedMentors.length > 0 && (
                  <div className="mb-6">
                    <p className="text-xs text-emerald-400 uppercase tracking-widest mb-3">AI-Matched Mentors in Your Organization</p>
                    <div className="grid md:grid-cols-3 gap-3">
                      {suggestedMentors.map((mentor, i) => (
                        <div key={i} className="p-4 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl">
                          <div className="flex items-center gap-3 mb-3">
                            <Avatar className="w-10 h-10">
                              <AvatarFallback className="bg-emerald-500/30 text-emerald-400">
                                {mentor.mentor_name?.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="text-white font-medium text-sm">{mentor.mentor_name}</h4>
                              <p className="text-xs text-gray-500">{mentor.job_title}</p>
                            </div>
                          </div>
                          <Badge className="mb-2 bg-emerald-500/20 text-emerald-400 border-none">
                            {mentor.compatibility_score}% match
                          </Badge>
                          <p className="text-xs text-gray-400 mb-2">{mentor.match_reason}</p>
                          <div>
                            <p className="text-[10px] text-gray-500 uppercase mb-1">Topics to discuss</p>
                            <div className="flex flex-wrap gap-1">
                              {mentor.topics_to_discuss?.slice(0, 3).map((topic, j) => (
                                <span key={j} className="text-[10px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded">{topic}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Mentor Profile Types */}
                <div className="space-y-4">
                  {careerPlan.mentorship_plan.recommended_mentor_profiles?.map((mentor, i) => (
                    <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-xl">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-white font-medium">{mentor.profile_type}</h4>
                          <p className="text-sm text-gray-400">{mentor.ideal_background}</p>
                        </div>
                        <Badge className="bg-white/10 text-gray-300 border-none">{mentor.meeting_frequency}</Badge>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">What to Learn</p>
                          <ul className="space-y-1">
                            {mentor.what_to_learn?.map((item, j) => (
                              <li key={j} className="text-sm text-gray-300 flex items-start gap-2">
                                <Lightbulb className="w-3 h-3 text-amber-400 mt-1 flex-shrink-0" />
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Conversation Starters</p>
                          <ul className="space-y-1">
                            {mentor.conversation_starters?.map((topic, j) => (
                              <li key={j} className="text-sm text-gray-400 flex items-start gap-2">
                                <MessageCircle className="w-3 h-3 text-blue-400 mt-1 flex-shrink-0" />
                                {topic}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Badges & Achievements Encouragement */}
          <Card className="border border-amber-500/20 bg-gradient-to-r from-amber-500/10 to-orange-500/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-400">
                <Trophy className="w-5 h-5" />
                Badges & Milestones to Pursue
              </CardTitle>
              <CardDescription className="text-gray-400">
                Earn recognition as you progress through your career journey
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                    <Medal className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-white font-medium mb-1">Skill Master</h4>
                  <p className="text-xs text-gray-400 mb-2">Complete 3 skill training modules</p>
                  <Progress value={33} className="h-1.5" />
                  <p className="text-[10px] text-gray-500 mt-1">1 of 3 completed</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center">
                    <Flame className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-white font-medium mb-1">Career Pathfinder</h4>
                  <p className="text-xs text-gray-400 mb-2">Complete your career plan</p>
                  <Progress value={100} className="h-1.5" />
                  <p className="text-[10px] text-emerald-400 mt-1">✓ Earned!</p>
                </div>
                <div className="p-4 bg-white/5 rounded-xl text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-white font-medium mb-1">Mentee Rising</h4>
                  <p className="text-xs text-gray-400 mb-2">Connect with a mentor</p>
                  <Progress value={0} className="h-1.5" />
                  <p className="text-[10px] text-gray-500 mt-1">Not started</p>
                </div>
              </div>
              <div className="mt-4 p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
                <p className="text-sm text-amber-300">
                  <Sparkles className="w-4 h-4 inline mr-1" />
                  <strong>Pro tip:</strong> Complete your first Learning Journey to unlock the "Journey Master" badge and earn 500 bonus points!
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Simulate Transition Button */}
          <Card className="border border-purple-500/20 bg-purple-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                    <Play className="w-6 h-6 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">Simulate Your Transition</h3>
                    <p className="text-sm text-gray-400">See what your first 6 months would look like</p>
                  </div>
                </div>
                <Button 
                  onClick={() => simulateTransition(careerGoals.targetRole)}
                  disabled={simulatingTransition}
                  className="bg-purple-500 text-white hover:bg-purple-400"
                >
                  {simulatingTransition ? (
                    <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Simulating...</>
                  ) : (
                    <><Play className="w-4 h-4 mr-2" /> Run Simulation</>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Transition Simulation Results */}
          {transitionSimulation && (
            <Card className="border border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-indigo-500/10">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Briefcase className="w-5 h-5 text-purple-400" />
                  Transition Simulation: {transitionSimulation.role}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="text-3xl font-light text-purple-400">{transitionSimulation.fit_score}%</div>
                    <div>
                      <p className="text-white">Fit Score</p>
                      <p className="text-xs text-gray-500">{transitionSimulation.recommendation}</p>
                    </div>
                  </div>
                  <p className="text-gray-300">{transitionSimulation.transition_summary}</p>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-white/5 rounded-xl">
                    <h4 className="text-white font-medium mb-2">Day 1-30</h4>
                    <p className="text-sm text-gray-400 mb-3">{transitionSimulation.day_1_30?.focus}</p>
                    <p className="text-xs text-gray-500 uppercase mb-2">Quick Wins</p>
                    <ul className="space-y-1">
                      {transitionSimulation.day_1_30?.quick_wins?.map((win, i) => (
                        <li key={i} className="text-xs text-emerald-400">✓ {win}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 bg-white/5 rounded-xl">
                    <h4 className="text-white font-medium mb-2">First 90 Days</h4>
                    <p className="text-xs text-gray-500 uppercase mb-2">Milestones</p>
                    <ul className="space-y-1">
                      {transitionSimulation.first_90_days?.milestones?.map((m, i) => (
                        <li key={i} className="text-xs text-gray-300">• {m}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 bg-white/5 rounded-xl">
                    <h4 className="text-white font-medium mb-2">6-Month Outlook</h4>
                    <p className="text-sm text-gray-400 mb-2">{transitionSimulation.six_month_outlook?.expected_performance}</p>
                    <p className="text-xs text-emerald-400">{transitionSimulation.six_month_outlook?.impact_potential}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Dynamic Learning Paths for Skill Gaps */}
          {careerPlan.training_plan?.length > 0 && (
            <Card className="border border-white/10 bg-white/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <BookOpen className="w-5 h-5 text-purple-400" />
                  Dynamic Learning Paths
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Generate personalized, adaptive learning modules for each skill gap
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue={careerPlan.training_plan[0]?.skill_area}>
                  <TabsList className="bg-white/5 mb-4 flex-wrap h-auto">
                    {careerPlan.training_plan.slice(0, 4).map((area, i) => (
                      <TabsTrigger 
                        key={i} 
                        value={area.skill_area}
                        className="data-[state=active]:bg-purple-500 data-[state=active]:text-white text-gray-400 text-xs"
                      >
                        {area.skill_area}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {careerPlan.training_plan.slice(0, 4).map((area, i) => (
                    <TabsContent key={i} value={area.skill_area}>
                      <DynamicLearningPath 
                        skillGap={{
                          skill_name: area.skill_area,
                          current_level: 'Current',
                          required_level: 'Target',
                          category: area.skill_area
                        }}
                        userEmail={user?.email}
                        onProgressUpdate={(progress) => console.log(`Progress: ${progress}`)}
                      />
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          )}

          {/* AI Coaching Simulator */}
          <Card className="border border-white/10 bg-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Brain className="w-5 h-5 text-purple-400" />
                Practice with AI Coaching Simulator
              </CardTitle>
              <CardDescription className="text-gray-400">
                Practice difficult conversations and leadership scenarios aligned with your career goals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AICoachingSimulator 
                user={user}
                assessment={assessment}
                careerPath={careerGoals.targetRole}
              />
            </CardContent>
          </Card>

          {/* Reset Button */}
          <div className="text-center">
            <Button 
              variant="outline" 
              onClick={() => {
                setCareerPlan(null);
                setTransitionSimulation(null);
              }}
              className="border-white/20 text-gray-400 hover:bg-white/5"
            >
              <RefreshCw className="w-4 h-4 mr-2" /> Start Over with New Goals
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}