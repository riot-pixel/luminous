import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { 
  BookOpen, Play, CheckCircle2, Clock, Star, Sparkles, 
  ChevronRight, Award, Brain, Target, Lightbulb, RefreshCw,
  ThumbsUp, ThumbsDown, FileText, Video, Code, Users
} from "lucide-react";

const contentTypeIcons = {
  video: Video,
  article: FileText,
  exercise: Code,
  quiz: Brain,
  project: Target,
  discussion: Users,
};

export default function DynamicLearningPath({ skillGap, userEmail, onProgressUpdate }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [learningPath, setLearningPath] = useState(null);
  const [completedItems, setCompletedItems] = useState(new Set());
  const [feedback, setFeedback] = useState({});
  const [showFeedbackFor, setShowFeedbackFor] = useState(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [isRegenerating, setIsRegenerating] = useState(false);

  const generateLearningPath = async () => {
    setIsGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a comprehensive, personalized learning path for closing this skill gap:

SKILL GAP:
- Skill: ${skillGap.skill_name || skillGap.skill}
- Current Level: ${skillGap.current_level || skillGap.current || 'Beginner'}
- Target Level: ${skillGap.required_level || skillGap.required || 'Advanced'}
- Category: ${skillGap.category || 'General'}

Create a structured learning path with:
1. 4-6 learning modules, each building on the previous
2. For each module, include:
   - 2-3 micro-learning items (5-15 min each)
   - 1 practical exercise
   - 1 knowledge check question
3. Mix content types: videos, articles, hands-on exercises, quizzes
4. Include real course names from platforms like Coursera, LinkedIn Learning, Udemy, YouTube
5. Add estimated time for each item
6. Include success criteria for each module

Make it practical and actionable with specific resources.`,
        response_json_schema: {
          type: "object",
          properties: {
            path_overview: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                total_duration: { type: "string" },
                difficulty_progression: { type: "string" },
                learning_objectives: { type: "array", items: { type: "string" } }
              }
            },
            modules: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  module_number: { type: "number" },
                  title: { type: "string" },
                  description: { type: "string" },
                  duration: { type: "string" },
                  learning_outcomes: { type: "array", items: { type: "string" } },
                  micro_learning: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        id: { type: "string" },
                        title: { type: "string" },
                        type: { type: "string" },
                        duration: { type: "string" },
                        source: { type: "string" },
                        description: { type: "string" },
                        url_hint: { type: "string" }
                      }
                    }
                  },
                  practical_exercise: {
                    type: "object",
                    properties: {
                      id: { type: "string" },
                      title: { type: "string" },
                      description: { type: "string" },
                      duration: { type: "string" },
                      steps: { type: "array", items: { type: "string" } },
                      deliverable: { type: "string" },
                      success_criteria: { type: "array", items: { type: "string" } }
                    }
                  },
                  knowledge_check: {
                    type: "object",
                    properties: {
                      id: { type: "string" },
                      question: { type: "string" },
                      options: { type: "array", items: { type: "string" } },
                      correct_answer: { type: "number" },
                      explanation: { type: "string" }
                    }
                  },
                  success_criteria: { type: "string" }
                }
              }
            },
            completion_project: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                requirements: { type: "array", items: { type: "string" } },
                evaluation_criteria: { type: "array", items: { type: "string" } }
              }
            },
            tips_for_success: { type: "array", items: { type: "string" } }
          }
        }
      });

      setLearningPath(result);
    } catch (error) {
      console.error("Error generating learning path:", error);
    }
    setIsGenerating(false);
  };

  const toggleComplete = (itemId) => {
    const newCompleted = new Set(completedItems);
    if (newCompleted.has(itemId)) {
      newCompleted.delete(itemId);
    } else {
      newCompleted.add(itemId);
    }
    setCompletedItems(newCompleted);
    onProgressUpdate?.(newCompleted.size);
  };

  const submitFeedback = async (itemId, isPositive) => {
    setFeedback(prev => ({ ...prev, [itemId]: { positive: isPositive, text: feedbackText } }));
    setShowFeedbackFor(null);
    setFeedbackText('');
    
    // Could adapt path based on feedback
    if (!isPositive && feedbackText) {
      setIsRegenerating(true);
      // Regenerate specific module based on feedback
      setIsRegenerating(false);
    }
  };

  const calculateProgress = () => {
    if (!learningPath) return 0;
    let totalItems = 0;
    learningPath.modules?.forEach(m => {
      totalItems += (m.micro_learning?.length || 0) + 2; // +2 for exercise and quiz
    });
    return totalItems > 0 ? Math.round((completedItems.size / totalItems) * 100) : 0;
  };

  if (!learningPath) {
    return (
      <Card className="border border-white/10 bg-white/5">
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500/20 to-indigo-500/20 flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-purple-400" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">
              Generate Learning Path for {skillGap.skill_name || skillGap.skill}
            </h3>
            <p className="text-sm text-gray-400 mb-6 max-w-md mx-auto">
              AI will create a personalized curriculum with micro-learning, exercises, and knowledge checks
            </p>
            <Button
              onClick={generateLearningPath}
              disabled={isGenerating}
              className="bg-purple-500 hover:bg-purple-400 text-white"
            >
              {isGenerating ? (
                <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Generating Path...</>
              ) : (
                <><Brain className="w-4 h-4 mr-2" /> Generate Learning Path</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const progress = calculateProgress();

  return (
    <div className="space-y-6">
      {/* Path Overview */}
      <Card className="border border-purple-500/20 bg-gradient-to-r from-purple-500/10 to-indigo-500/10">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-400" />
                {learningPath.path_overview?.title}
              </CardTitle>
              <CardDescription className="text-gray-400 mt-1">
                {learningPath.path_overview?.description}
              </CardDescription>
            </div>
            <div className="text-right">
              <Badge className="bg-purple-500/20 text-purple-400 border-none">
                {learningPath.path_overview?.total_duration}
              </Badge>
              <p className="text-xs text-gray-500 mt-1">{progress}% complete</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="h-2 mb-4" />
          <div className="flex flex-wrap gap-2">
            {learningPath.path_overview?.learning_objectives?.map((obj, i) => (
              <Badge key={i} variant="outline" className="text-xs border-white/20 text-gray-300">
                {obj}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modules */}
      <div className="space-y-4">
        {learningPath.modules?.map((module, moduleIdx) => {
          const moduleItems = [
            ...(module.micro_learning || []),
            module.practical_exercise,
            module.knowledge_check
          ].filter(Boolean);
          const moduleCompleted = moduleItems.filter(item => completedItems.has(item.id)).length;
          const moduleProgress = moduleItems.length > 0 ? Math.round((moduleCompleted / moduleItems.length) * 100) : 0;

          return (
            <Card key={moduleIdx} className="border border-white/10 bg-white/5">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                      moduleProgress === 100 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/10 text-white'
                    }`}>
                      {moduleProgress === 100 ? <CheckCircle2 className="w-5 h-5" /> : module.module_number}
                    </div>
                    <div>
                      <CardTitle className="text-base text-white">{module.title}</CardTitle>
                      <CardDescription className="text-xs text-gray-500">
                        {module.duration} • {moduleProgress}% complete
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-400">{module.description}</p>

                {/* Micro-learning items */}
                <div className="space-y-2">
                  <p className="text-xs text-gray-500 uppercase tracking-widest">Micro-Learning</p>
                  {module.micro_learning?.map((item, i) => {
                    const Icon = contentTypeIcons[item.type] || BookOpen;
                    const isComplete = completedItems.has(item.id);
                    return (
                      <div key={i} className={`p-3 rounded-lg flex items-start gap-3 ${
                        isComplete ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-white/5'
                      }`}>
                        <Checkbox 
                          checked={isComplete}
                          onCheckedChange={() => toggleComplete(item.id)}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <Icon className="w-4 h-4 text-gray-400" />
                            <span className={`text-sm font-medium ${isComplete ? 'text-emerald-400 line-through' : 'text-white'}`}>
                              {item.title}
                            </span>
                            <Badge variant="outline" className="text-[10px] border-white/10 text-gray-500">
                              {item.duration}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{item.source}</p>
                        </div>
                        {isComplete && !feedback[item.id] && (
                          <div className="flex gap-1">
                            <button onClick={() => submitFeedback(item.id, true)} className="p-1 hover:bg-white/10 rounded">
                              <ThumbsUp className="w-3 h-3 text-gray-500 hover:text-emerald-400" />
                            </button>
                            <button onClick={() => setShowFeedbackFor(item.id)} className="p-1 hover:bg-white/10 rounded">
                              <ThumbsDown className="w-3 h-3 text-gray-500 hover:text-red-400" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Practical Exercise */}
                {module.practical_exercise && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Practical Exercise</p>
                    <div className={`p-4 rounded-lg ${
                      completedItems.has(module.practical_exercise.id) 
                        ? 'bg-emerald-500/10 border border-emerald-500/20' 
                        : 'bg-amber-500/10 border border-amber-500/20'
                    }`}>
                      <div className="flex items-start gap-3">
                        <Checkbox 
                          checked={completedItems.has(module.practical_exercise.id)}
                          onCheckedChange={() => toggleComplete(module.practical_exercise.id)}
                          className="mt-1"
                        />
                        <div>
                          <p className="text-sm font-medium text-white">{module.practical_exercise.title}</p>
                          <p className="text-xs text-gray-400 mt-1">{module.practical_exercise.description}</p>
                          <div className="mt-3">
                            <p className="text-xs text-gray-500 mb-1">Steps:</p>
                            <ul className="space-y-1">
                              {module.practical_exercise.steps?.map((step, j) => (
                                <li key={j} className="text-xs text-gray-400 flex items-start gap-2">
                                  <ChevronRight className="w-3 h-3 mt-0.5 text-amber-400" />
                                  {step}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <Badge className="mt-2 bg-amber-500/20 text-amber-400 border-none text-xs">
                            Deliverable: {module.practical_exercise.deliverable}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Knowledge Check */}
                {module.knowledge_check && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Knowledge Check</p>
                    <div className={`p-4 rounded-lg ${
                      completedItems.has(module.knowledge_check.id) 
                        ? 'bg-emerald-500/10 border border-emerald-500/20' 
                        : 'bg-blue-500/10 border border-blue-500/20'
                    }`}>
                      <div className="flex items-start gap-3">
                        <Checkbox 
                          checked={completedItems.has(module.knowledge_check.id)}
                          onCheckedChange={() => toggleComplete(module.knowledge_check.id)}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-white">{module.knowledge_check.question}</p>
                          <div className="mt-2 space-y-1">
                            {module.knowledge_check.options?.map((opt, j) => (
                              <div key={j} className="text-xs text-gray-400 flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px]">
                                  {String.fromCharCode(65 + j)}
                                </span>
                                {opt}
                              </div>
                            ))}
                          </div>
                          {completedItems.has(module.knowledge_check.id) && (
                            <p className="text-xs text-emerald-400 mt-2">
                              ✓ {module.knowledge_check.explanation}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Completion Project */}
      {learningPath.completion_project && progress >= 80 && (
        <Card className="border-2 border-amber-500/30 bg-gradient-to-r from-amber-500/10 to-orange-500/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-400" />
              Capstone Project: {learningPath.completion_project.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-300 mb-4">{learningPath.completion_project.description}</p>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500 uppercase mb-2">Requirements</p>
                <ul className="space-y-1">
                  {learningPath.completion_project.requirements?.map((req, i) => (
                    <li key={i} className="text-xs text-gray-400 flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 mt-0.5 text-amber-400" />
                      {req}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase mb-2">Evaluation Criteria</p>
                <ul className="space-y-1">
                  {learningPath.completion_project.evaluation_criteria?.map((crit, i) => (
                    <li key={i} className="text-xs text-gray-400 flex items-start gap-2">
                      <Target className="w-3 h-3 mt-0.5 text-amber-400" />
                      {crit}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tips */}
      {learningPath.tips_for_success?.length > 0 && (
        <Card className="border border-white/10 bg-white/5">
          <CardHeader>
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-400" />
              Tips for Success
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {learningPath.tips_for_success.map((tip, i) => (
                <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
                  <Star className="w-3 h-3 mt-1 text-yellow-400" />
                  {tip}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Regenerate */}
      <div className="text-center">
        <Button variant="outline" onClick={generateLearningPath} className="border-white/20 text-gray-400">
          <RefreshCw className="w-4 h-4 mr-2" /> Regenerate Path
        </Button>
      </div>
    </div>
  );
}