import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain, MessageCircle, Send, RefreshCw, Target, Award,
  Sparkles, User, Bot, Mic, MicOff, ThumbsUp, ThumbsDown,
  Lightbulb, AlertTriangle, CheckCircle2, Star, Clock, History,
  GitBranch, FileText
} from "lucide-react";

const COACHING_SCENARIOS = [
  {
    id: "salary_negotiation",
    name: "Salary Negotiation",
    category: "Negotiation",
    difficulty: "intermediate",
    description: "Practice negotiating a raise with your manager",
    context: "You've been in your role for 2 years with excellent performance reviews. You're meeting with your manager to discuss a salary increase.",
    ai_role: "Your manager who is budget-conscious but values your contributions",
    skills_practiced: ["Negotiation", "Communication", "Assertiveness"]
  },
  {
    id: "difficult_feedback",
    name: "Giving Difficult Feedback",
    category: "Leadership",
    difficulty: "advanced",
    description: "Practice delivering constructive criticism to a team member",
    context: "A team member has been consistently missing deadlines and it's affecting the team. You need to address this directly.",
    ai_role: "Your team member who may be defensive but is generally open to feedback",
    skills_practiced: ["Leadership", "Emotional Intelligence", "Communication"]
  },
  {
    id: "job_interview",
    name: "Job Interview Practice",
    category: "Career",
    difficulty: "beginner",
    description: "Practice answering tough interview questions",
    context: "You're interviewing for a senior position at a top company. The interviewer will ask behavioral and situational questions.",
    ai_role: "A thorough interviewer who asks follow-up questions",
    skills_practiced: ["Interview Skills", "Self-Presentation", "Storytelling"]
  },
  {
    id: "conflict_resolution",
    name: "Conflict Resolution",
    category: "Leadership",
    difficulty: "advanced",
    description: "Mediate a conflict between two team members",
    context: "Two of your team members have a disagreement about project approach that's affecting team morale.",
    ai_role: "One of the team members involved in the conflict",
    skills_practiced: ["Conflict Resolution", "Mediation", "Emotional Intelligence"]
  },
  {
    id: "promotion_conversation",
    name: "Promotion Discussion",
    category: "Career",
    difficulty: "intermediate",
    description: "Make your case for a promotion",
    context: "You believe you're ready for a promotion to a leadership role. You're meeting with your skip-level manager.",
    ai_role: "Your skip-level manager who needs to be convinced",
    skills_practiced: ["Self-Advocacy", "Strategic Communication", "Executive Presence"]
  },
  {
    id: "client_pushback",
    name: "Handling Client Pushback",
    category: "Negotiation",
    difficulty: "intermediate",
    description: "Navigate a difficult client conversation",
    context: "A client is unhappy with a deliverable and is pushing back aggressively. You need to de-escalate and find a solution.",
    ai_role: "A frustrated client who feels their expectations weren't met",
    skills_practiced: ["Client Management", "De-escalation", "Problem Solving"]
  },
  {
    id: "stakeholder_alignment",
    name: "Stakeholder Alignment",
    category: "Leadership",
    difficulty: "advanced",
    description: "Align multiple stakeholders on a controversial decision",
    context: "You need to get buy-in from a skeptical stakeholder for a major initiative that will change their department's workflow.",
    ai_role: "A skeptical department head who is resistant to change",
    skills_practiced: ["Influence", "Strategic Communication", "Change Management"]
  },
  {
    id: "mentoring_session",
    name: "Mentoring Session",
    category: "Leadership",
    difficulty: "beginner",
    description: "Practice being an effective mentor",
    context: "You're mentoring a junior colleague who is struggling with career direction and confidence.",
    ai_role: "A junior colleague seeking guidance and support",
    skills_practiced: ["Mentoring", "Active Listening", "Coaching"]
  }
];

export default function AICoachingSimulator({ user, assessment, careerPath }) {
  const queryClient = useQueryClient();
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sessionActive, setSessionActive] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [overallScore, setOverallScore] = useState(null);
  const [coachPersonality, setCoachPersonality] = useState(null);
  const [branchPoints, setBranchPoints] = useState([]);
  const [difficultyLevel, setDifficultyLevel] = useState("medium");
  const scrollRef = useRef(null);

  const { data: pastSessions } = useQuery({
    queryKey: ['coachingSessions', user?.email],
    queryFn: () => base44.entities.CoachingSession.filter({ user_email: user?.email }, '-session_date'),
    enabled: !!user?.email,
    initialData: [],
  });

  const saveSessionMutation = useMutation({
    mutationFn: (data) => base44.entities.CoachingSession.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['coachingSessions'] }),
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation]);

  const startSession = async () => {
    if (!selectedScenario) return;
    setSessionActive(true);
    setConversation([]);
    setFeedback(null);
    setShowFeedback(false);
    setOverallScore(null);
    setBranchPoints([]);

    // Generate AI coach personality
    setIsLoading(true);
    try {
      // First, create adaptive coach personality
      const personalityResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Create an AI coach personality adapted to this user's profile.

USER PROFILE:
- Personality: ${assessment?.myers_briggs?.type || 'Unknown'}
- Career Goal: ${careerPath || 'General development'}
- Communication Style: ${assessment?.strengths?.top_strengths?.[0]?.name || 'Professional'}

SCENARIO: ${selectedScenario.name}
BASE ROLE: ${selectedScenario.ai_role}

Create a coach personality that will be:
- Appropriately challenging for their level
- Adapted to their personality type
- Aligned with their career goals
- ${difficultyLevel === 'easy' ? 'Supportive and encouraging' : difficultyLevel === 'hard' ? 'Demanding and rigorous' : 'Balanced between challenge and support'}`,
        response_json_schema: {
          type: "object",
          properties: {
            base_traits: { type: "array", items: { type: "string" } },
            adapted_to_user: { type: "string" },
            communication_style: { type: "string" }
          }
        }
      });

      setCoachPersonality(personalityResult);

      // Initial AI message with personality
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are playing the role of: ${selectedScenario.ai_role}

SCENARIO: ${selectedScenario.name}
CONTEXT: ${selectedScenario.context}

YOUR PERSONALITY PROFILE:
${personalityResult.adapted_to_user}
Communication Style: ${personalityResult.communication_style}

USER PROFILE:
- Name: ${user?.full_name || 'a professional'}
- Personality: ${assessment?.myers_briggs?.type || 'Unknown'}
- Career Goal: ${careerPath || 'Professional development'}
- Difficulty Setting: ${difficultyLevel}

Start the conversation naturally as your character. Set the scene and give them an opportunity to practice. Stay in character throughout.

Keep your opening message to 2-3 sentences that establish the situation.`,
        response_json_schema: {
          type: "object",
          properties: {
            message: { type: "string" },
            tone: { type: "string" },
            hint_for_user: { type: "string" }
          }
        }
      });

      setConversation([{
        role: "ai",
        content: result.message,
        tone: result.tone,
        hint: result.hint_for_user,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      console.error("Error starting session:", error);
    }
    setIsLoading(false);
  };

  const sendMessage = async () => {
    if (!userInput.trim() || isLoading) return;

    const newMessage = { role: "user", content: userInput, timestamp: new Date().toISOString() };
    setConversation(prev => [...prev, newMessage]);
    setUserInput("");
    setIsLoading(true);

    try {
      const conversationHistory = [...conversation, newMessage].map(m => 
        `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`
      ).join('\n\n');

      const turnNumber = conversation.filter(m => m.role === 'user').length;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are playing the role of: ${selectedScenario.ai_role}
Personality: ${coachPersonality?.communication_style || 'Professional'}

SCENARIO: ${selectedScenario.name}
CONTEXT: ${selectedScenario.context}
USER CAREER GOAL: ${careerPath || 'General development'}
DIFFICULTY: ${difficultyLevel}

CONVERSATION SO FAR:
${conversationHistory}

Continue the roleplay with SCENARIO BRANCHING:
- Identify if the user's response leads to a significant branch point (good/bad decision, defensive/open response, etc.)
- If a branch occurs, note what alternative paths exist
- Adapt the difficulty based on their performance
- Stay in character but adjust your approach based on their communication style

${turnNumber > 3 ? 'You are mid-conversation - start introducing complexity or conflict naturally.' : ''}
${turnNumber > 6 ? 'Begin working toward resolution or conclusion.' : ''}

Provide:
1. Your response (2-4 sentences, in character)
2. Real-time feedback on their approach
3. Whether a branch point occurred
4. Alternative outcomes if they had responded differently`,
        response_json_schema: {
          type: "object",
          properties: {
            message: { type: "string" },
            tone: { type: "string" },
            real_time_feedback: {
              type: "object",
              properties: {
                positive: { type: "string" },
                improvement: { type: "string" },
                score: { type: "number" }
              }
            },
            branch_point: {
              type: "object",
              properties: {
                occurred: { type: "boolean" },
                branch_taken: { type: "string" },
                alternative_outcomes: { type: "array", items: { type: "string" } }
              }
            }
          }
        }
      });

      // Record branch point if significant
      if (result.branch_point?.occurred) {
        setBranchPoints(prev => [...prev, {
          turn: turnNumber,
          user_choice: userInput,
          branch_taken: result.branch_point.branch_taken,
          alternative_outcomes: result.branch_point.alternative_outcomes
        }]);
      }

      setConversation(prev => [...prev, {
        role: "ai",
        content: result.message,
        tone: result.tone,
        feedback: result.real_time_feedback,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      console.error("Error sending message:", error);
    }
    setIsLoading(false);
  };

  const endSession = async () => {
    setIsLoading(true);
    try {
      const conversationHistory = conversation.map(m => 
        `${m.role === 'user' ? 'User' : 'AI'}: ${m.content}`
      ).join('\n\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this coaching simulation conversation and provide comprehensive feedback.

SCENARIO: ${selectedScenario.name}
SKILLS PRACTICED: ${selectedScenario.skills_practiced.join(', ')}
USER PERSONALITY: ${assessment?.myers_briggs?.type || 'Unknown'}
USER CAREER GOAL: ${careerPath || 'Not specified'}
DIFFICULTY LEVEL: ${difficultyLevel}

COACH PERSONALITY USED:
${coachPersonality?.adapted_to_user || 'Standard coach'}

BRANCH POINTS ENCOUNTERED:
${branchPoints.map(bp => `Turn ${bp.turn}: Chose "${bp.branch_taken}"`).join('\n') || 'No major branches'}

CONVERSATION (${conversation.length} turns):
${conversationHistory}

Provide detailed feedback on:
1. Overall performance score (0-100), adjusted for difficulty
2. Communication effectiveness across dimensions
3. Specific strengths demonstrated
4. Areas for improvement aligned with career goals
5. Actionable tips for next time
6. How their personality type affected their approach
7. Recommended next scenarios to practice
8. Career alignment analysis - how this scenario relates to their goals`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_score: { type: "number" },
            performance_summary: { type: "string" },
            communication_analysis: {
              type: "object",
              properties: {
                clarity: { type: "number" },
                confidence: { type: "number" },
                empathy: { type: "number" },
                persuasiveness: { type: "number" },
                professionalism: { type: "number" }
              }
            },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            actionable_tips: { type: "array", items: { type: "string" } },
            personality_insights: { type: "string" },
            career_alignment: { type: "string" },
            recommended_scenarios: { type: "array", items: { type: "string" } },
            badges_earned: { type: "array", items: { type: "string" } },
            skill_improvements_demonstrated: { type: "array", items: { type: "string" } }
          }
        }
      });

      setFeedback(result);
      setOverallScore(result.overall_score);
      setShowFeedback(true);

      // Save session to database
      await saveSessionMutation.mutateAsync({
        user_email: user.email,
        scenario_id: selectedScenario.id,
        scenario_name: selectedScenario.name,
        session_date: new Date().toISOString(),
        conversation_turns: conversation.filter(m => m.role === 'user').length,
        conversation_transcript: conversation,
        branch_points: branchPoints,
        ai_coach_personality: coachPersonality,
        overall_score: result.overall_score,
        detailed_feedback: {
          communication_analysis: result.communication_analysis,
          strengths: result.strengths,
          improvements: result.improvements,
          actionable_tips: result.actionable_tips,
          personality_insights: result.personality_insights,
          career_alignment: result.career_alignment
        },
        badges_earned: result.badges_earned,
        skill_improvements_demonstrated: result.skill_improvements_demonstrated,
        recommended_next_scenarios: result.recommended_scenarios
      });

    } catch (error) {
      console.error("Error ending session:", error);
    }
    setIsLoading(false);
    setSessionActive(false);
  };

  const difficultyColors = {
    beginner: 'bg-green-600',
    intermediate: 'bg-yellow-600',
    advanced: 'bg-red-600'
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="practice" className="space-y-6">
        <TabsList className="bg-gray-900 border border-gray-800">
          <TabsTrigger value="practice">Practice Sessions</TabsTrigger>
          <TabsTrigger value="history">
            <History className="w-4 h-4 mr-1" />Session History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="practice">
      {/* Scenario Selection */}
      {!sessionActive && !showFeedback && (
        <Card className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="w-6 h-6 text-purple-400" />
              AI 1-on-1 Coaching Simulator
            </CardTitle>
            <CardDescription className="text-gray-400">
              Practice difficult conversations and leadership scenarios with AI-powered real-time feedback
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Difficulty Selector */}
            <div className="flex items-center gap-4 p-3 bg-gray-800 rounded-lg mb-4">
              <span className="text-gray-400 text-sm">Difficulty:</span>
              <div className="flex gap-2">
                {['easy', 'medium', 'hard'].map(level => (
                  <Button
                    key={level}
                    size="sm"
                    variant={difficultyLevel === level ? 'default' : 'outline'}
                    onClick={() => setDifficultyLevel(level)}
                    className={difficultyLevel === level ? 'bg-purple-600' : 'border-gray-700 text-gray-400'}
                  >
                    {level.charAt(0).toUpperCase() + level.slice(1)}
                  </Button>
                ))}
              </div>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {COACHING_SCENARIOS.map(scenario => (
                <button
                  key={scenario.id}
                  onClick={() => setSelectedScenario(scenario)}
                  className={`p-4 rounded-lg text-left transition-all ${
                    selectedScenario?.id === scenario.id
                      ? 'bg-purple-600 border-2 border-purple-400'
                      : 'bg-gray-800 border-2 border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-white font-medium text-sm">{scenario.name}</p>
                    <Badge className={`${difficultyColors[scenario.difficulty]} text-[10px]`}>
                      {scenario.difficulty}
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-xs mb-2">{scenario.description}</p>
                  <Badge variant="outline" className="text-[10px] border-gray-600 text-gray-400">
                    {scenario.category}
                  </Badge>
                </button>
              ))}
            </div>

            {selectedScenario && (
              <div className="p-4 bg-gray-800 rounded-lg mb-4">
                <h4 className="text-white font-medium mb-2">{selectedScenario.name}</h4>
                <p className="text-gray-400 text-sm mb-3">{selectedScenario.context}</p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {selectedScenario.skills_practiced.map((skill, i) => (
                    <Badge key={i} className="bg-purple-600 text-xs">{skill}</Badge>
                  ))}
                </div>
                <p className="text-gray-500 text-xs">
                  <strong>AI Role:</strong> {selectedScenario.ai_role}
                </p>
              </div>
            )}

            <Button 
              onClick={startSession} 
              disabled={!selectedScenario}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Start Coaching Session
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Active Session */}
      {sessionActive && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="border-b border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-white text-lg">{selectedScenario?.name}</CardTitle>
                <CardDescription className="text-gray-400">
                  {selectedScenario?.skills_practiced.join(' • ')}
                </CardDescription>
              </div>
              <Button variant="destructive" size="sm" onClick={endSession}>
                End & Get Feedback
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {/* Conversation */}
            <ScrollArea ref={scrollRef} className="h-[400px] p-4">
              <div className="space-y-4">
                {conversation.map((msg, i) => (
                  <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                    {msg.role === 'ai' && (
                      <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div className={`max-w-[70%] ${msg.role === 'user' ? 'order-first' : ''}`}>
                      <div className={`p-3 rounded-lg ${
                        msg.role === 'user' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-800 text-gray-200'
                      }`}>
                        {msg.content}
                      </div>
                      {msg.feedback && (
                        <div className="mt-2 p-2 bg-green-900/30 border border-green-800 rounded text-xs">
                          <p className="text-green-400">✓ {msg.feedback.positive}</p>
                          {msg.feedback.improvement && (
                            <p className="text-yellow-400 mt-1">💡 {msg.feedback.improvement}</p>
                          )}
                        </div>
                      )}
                      {msg.hint && i === 0 && (
                        <div className="mt-2 p-2 bg-blue-900/30 border border-blue-800 rounded text-xs">
                          <p className="text-blue-400">💡 Tip: {msg.hint}</p>
                        </div>
                      )}
                    </div>
                    {msg.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
                      <RefreshCw className="w-4 h-4 text-white animate-spin" />
                    </div>
                    <div className="p-3 bg-gray-800 rounded-lg">
                      <span className="text-gray-400">Thinking...</span>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t border-gray-800">
              <div className="flex gap-2">
                <Textarea
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder="Type your response..."
                  className="bg-gray-800 border-gray-700 text-white min-h-[60px]"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                />
                <Button onClick={sendMessage} disabled={isLoading || !userInput.trim()} className="bg-blue-600">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Feedback */}
      {showFeedback && feedback && (
        <div className="space-y-4">
          {/* Score Card */}
          <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-white mb-1">Session Complete!</h3>
                  <p className="text-gray-400">{selectedScenario?.name}</p>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-purple-400">{overallScore}</div>
                  <p className="text-gray-400 text-sm">Overall Score</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Communication Analysis */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Communication Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-5 gap-4">
                {Object.entries(feedback.communication_analysis || {}).map(([key, value]) => (
                  <div key={key} className="text-center">
                    <div className="relative w-16 h-16 mx-auto mb-2">
                      <svg className="transform -rotate-90 w-16 h-16">
                        <circle cx="32" cy="32" r="28" stroke="#374151" strokeWidth="4" fill="none" />
                        <circle 
                          cx="32" cy="32" r="28" 
                          stroke={value >= 80 ? '#10b981' : value >= 60 ? '#f59e0b' : '#ef4444'}
                          strokeWidth="4" 
                          fill="none"
                          strokeDasharray={`${value * 1.76} 176`}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-white font-bold">{value}</span>
                      </div>
                    </div>
                    <p className="text-gray-400 text-xs capitalize">{key}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Strengths */}
            <Card className="bg-green-900/20 border-green-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-green-400 text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />Strengths Demonstrated
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {feedback.strengths?.map((s, i) => (
                    <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                      <Star className="w-3 h-3 text-green-400 mt-1 flex-shrink-0" />{s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Improvements */}
            <Card className="bg-yellow-900/20 border-yellow-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-yellow-400 text-sm flex items-center gap-2">
                  <Lightbulb className="w-4 h-4" />Areas for Improvement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {feedback.improvements?.map((s, i) => (
                    <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                      <AlertTriangle className="w-3 h-3 text-yellow-400 mt-1 flex-shrink-0" />{s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Actionable Tips */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-400" />
                Actionable Tips for Next Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-3">
                {feedback.actionable_tips?.map((tip, i) => (
                  <div key={i} className="p-3 bg-blue-900/20 border border-blue-800 rounded-lg">
                    <p className="text-gray-300 text-sm">{tip}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Personality & Career Insights */}
          <div className="grid md:grid-cols-2 gap-4">
            {feedback.personality_insights && (
              <Card className="bg-purple-900/20 border-purple-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-purple-400 text-sm flex items-center gap-2">
                    <Brain className="w-4 h-4" />Personality Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 text-sm">{feedback.personality_insights}</p>
                </CardContent>
              </Card>
            )}
            {feedback.career_alignment && (
              <Card className="bg-cyan-900/20 border-cyan-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-cyan-400 text-sm flex items-center gap-2">
                    <Target className="w-4 h-4" />Career Alignment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 text-sm">{feedback.career_alignment}</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Branch Points Review */}
          {branchPoints.length > 0 && (
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <GitBranch className="w-4 h-4" />Decision Points
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {branchPoints.map((bp, i) => (
                    <div key={i} className="p-3 bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-blue-600 text-xs">Turn {bp.turn}</Badge>
                        <p className="text-white text-sm">Path: {bp.branch_taken}</p>
                      </div>
                      <p className="text-gray-400 text-xs mb-2">You chose: "{bp.user_choice.substring(0, 80)}..."</p>
                      {bp.alternative_outcomes?.length > 0 && (
                        <div>
                          <p className="text-gray-500 text-xs mb-1">Alternative outcomes:</p>
                          {bp.alternative_outcomes.map((alt, j) => (
                            <p key={j} className="text-cyan-400 text-xs ml-2">• {alt}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommended Next Scenarios */}
          {feedback.recommended_scenarios?.length > 0 && (
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Target className="w-4 h-4" />Practice Next
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {feedback.recommended_scenarios.map((scenario, i) => {
                    const scenarioData = COACHING_SCENARIOS.find(s => s.name === scenario);
                    return scenarioData ? (
                      <Button
                        key={i}
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedScenario(scenarioData);
                          setShowFeedback(false);
                          startSession();
                        }}
                        className="border-gray-700 text-gray-400 hover:bg-gray-800"
                      >
                        {scenario}
                      </Button>
                    ) : (
                      <Badge key={i} variant="outline" className="border-gray-700 text-gray-400">{scenario}</Badge>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Badges Earned */}
          {feedback.badges_earned?.length > 0 && (
            <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Award className="w-6 h-6 text-yellow-400" />
                  <div>
                    <p className="text-white font-medium">Badges Earned!</p>
                    <div className="flex gap-2 mt-1">
                      {feedback.badges_earned.map((badge, i) => (
                        <span key={i} className="text-xl">🏆</span>
                      ))}
                      <span className="text-gray-400 text-sm">{feedback.badges_earned.join(' • ')}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-3">
            <Button onClick={() => { setShowFeedback(false); setSelectedScenario(null); }} variant="outline" className="flex-1 border-gray-700">
              Choose New Scenario
            </Button>
            <Button onClick={startSession} className="flex-1 bg-purple-600">
              <RefreshCw className="w-4 h-4 mr-2" />Retry This Scenario
            </Button>
          </div>
        </div>
      )}
        </TabsContent>

        <TabsContent value="history">
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white">Your Coaching History</CardTitle>
              <CardDescription className="text-gray-400">Review past simulations and track progress</CardDescription>
            </CardHeader>
            <CardContent>
              {pastSessions?.length === 0 ? (
                <div className="text-center py-12">
                  <History className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No sessions yet</p>
                  <p className="text-gray-500 text-sm">Complete a coaching session to see your history</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pastSessions.map(session => (
                    <Card key={session.id} className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="text-white font-medium">{session.scenario_name}</h4>
                            <p className="text-gray-400 text-sm">{new Date(session.session_date).toLocaleDateString()}</p>
                          </div>
                          <Badge className={
                            session.overall_score >= 80 ? 'bg-green-600' :
                            session.overall_score >= 60 ? 'bg-yellow-600' : 'bg-red-600'
                          }>
                            Score: {session.overall_score}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs mb-3">
                          <div className="p-2 bg-gray-700 rounded text-center">
                            <p className="text-gray-400">Turns</p>
                            <p className="text-white font-bold">{session.conversation_turns}</p>
                          </div>
                          <div className="p-2 bg-gray-700 rounded text-center">
                            <p className="text-gray-400">Branches</p>
                            <p className="text-white font-bold">{session.branch_points?.length || 0}</p>
                          </div>
                          <div className="p-2 bg-gray-700 rounded text-center">
                            <p className="text-gray-400">Badges</p>
                            <p className="text-white font-bold">{session.badges_earned?.length || 0}</p>
                          </div>
                          <div className="p-2 bg-gray-700 rounded text-center">
                            <p className="text-gray-400">Skills</p>
                            <p className="text-white font-bold">{session.skill_improvements_demonstrated?.length || 0}</p>
                          </div>
                        </div>
                        {session.detailed_feedback?.career_alignment && (
                          <div className="p-2 bg-cyan-900/20 border border-cyan-800 rounded mb-3">
                            <p className="text-cyan-400 text-xs">{session.detailed_feedback.career_alignment}</p>
                          </div>
                        )}
                        <details className="text-sm">
                          <summary className="text-purple-400 cursor-pointer hover:text-purple-300">View Full Feedback</summary>
                          <div className="mt-3 space-y-3">
                            <div>
                              <p className="text-gray-400 text-xs mb-1">Strengths:</p>
                              {session.detailed_feedback?.strengths?.map((s, i) => (
                                <p key={i} className="text-green-400 text-xs">✓ {s}</p>
                              ))}
                            </div>
                            <div>
                              <p className="text-gray-400 text-xs mb-1">Areas to Improve:</p>
                              {session.detailed_feedback?.improvements?.map((s, i) => (
                                <p key={i} className="text-yellow-400 text-xs">• {s}</p>
                              ))}
                            </div>
                            {session.branch_points?.length > 0 && (
                              <div>
                                <p className="text-gray-400 text-xs mb-1">Decision Branches:</p>
                                {session.branch_points.map((bp, i) => (
                                  <div key={i} className="text-xs text-gray-400 ml-2">
                                    Turn {bp.turn}: {bp.branch_taken}
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </details>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}