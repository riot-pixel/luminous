import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, TrendingUp, TrendingDown, Sparkles, Target, CheckCircle2,
  Lightbulb, Zap, Award, ArrowRight, RefreshCw, Star, AlertCircle
} from "lucide-react";

export default function PerformanceFeedbackEngine({ user, assessment, userSkills, previousAssessments, learningJourneys }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Auto-generate feedback on mount or when key data changes
  useEffect(() => {
    if (user && assessment && !feedback) {
      generatePerformanceFeedback();
    }
  }, [user?.email]);

  const calculateProgressMetrics = () => {
    // Skill progression
    const skillProgress = userSkills?.reduce((acc, skill) => {
      const profOrder = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
      acc.totalSkills = (acc.totalSkills || 0) + 1;
      acc.avgProficiency = (acc.avgProficiency || 0) + profOrder.indexOf(skill.current_proficiency);
      if (skill.target_proficiency && 
          profOrder.indexOf(skill.current_proficiency) >= profOrder.indexOf(skill.target_proficiency)) {
        acc.goalsReached = (acc.goalsReached || 0) + 1;
      }
      return acc;
    }, {}) || {};

    // Learning journey progress
    const journeyProgress = learningJourneys?.reduce((acc, journey) => {
      acc.total = (acc.total || 0) + 1;
      if (journey.status === 'completed') acc.completed = (acc.completed || 0) + 1;
      if (journey.status === 'in_progress') acc.inProgress = (acc.inProgress || 0) + 1;
      acc.totalPoints = (acc.totalPoints || 0) + (journey.earned_points || 0);
      return acc;
    }, {}) || {};

    // Assessment trends
    const assessmentTrend = previousAssessments?.length > 1 ? {
      satisfactionChange: previousAssessments[0]?.life_wheel?.overall_satisfaction - 
                         (previousAssessments[1]?.life_wheel?.overall_satisfaction || 0),
      hasImproved: previousAssessments[0]?.life_wheel?.overall_satisfaction > 
                   (previousAssessments[1]?.life_wheel?.overall_satisfaction || 0)
    } : null;

    return { skillProgress, journeyProgress, assessmentTrend };
  };

  const generatePerformanceFeedback = async () => {
    setIsAnalyzing(true);
    try {
      const metrics = calculateProgressMetrics();
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert performance coach providing personalized feedback. Analyze this employee's data and provide actionable insights.

EMPLOYEE PROFILE:
- Name: ${user?.full_name}
- Role: ${user?.job_title || 'Not specified'}
- Department: ${user?.department || 'Not specified'}
- Personality Type: ${assessment?.myers_briggs?.type || 'Unknown'}

TOP STRENGTHS:
${assessment?.strengths?.top_strengths?.slice(0, 5).map(s => `- ${s.name}: ${s.score}/10`).join('\n') || 'Not assessed'}

CURRENT SKILLS (${userSkills?.length || 0} total):
${userSkills?.slice(0, 10).map(s => `- ${s.skill_name}: ${s.current_proficiency}${s.target_proficiency ? ` (target: ${s.target_proficiency})` : ''}`).join('\n') || 'No skills recorded'}

LIFE SATISFACTION SCORES:
${assessment?.life_wheel ? Object.entries(assessment.life_wheel).slice(0, 8).map(([k, v]) => `- ${k}: ${v}/10`).join('\n') : 'Not assessed'}

LEARNING PROGRESS:
- Total Journeys: ${metrics.journeyProgress.total || 0}
- Completed: ${metrics.journeyProgress.completed || 0}
- In Progress: ${metrics.journeyProgress.inProgress || 0}
- Points Earned: ${metrics.journeyProgress.totalPoints || 0}

SKILL METRICS:
- Total Skills: ${metrics.skillProgress.totalSkills || 0}
- Goals Reached: ${metrics.skillProgress.goalsReached || 0}

Provide:
1. An encouraging overall assessment (2-3 sentences)
2. Top 3 key strengths with specific examples of how to leverage them
3. Top 3 development areas with actionable advice
4. 5 specific micro-actions they can take THIS WEEK
5. Personalized encouragement based on their personality type
6. Badge/milestone recommendations to pursue`,
        response_json_schema: {
          type: "object",
          properties: {
            overall_assessment: { type: "string" },
            performance_score: { type: "number" },
            key_strengths: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  strength: { type: "string" },
                  evidence: { type: "string" },
                  how_to_leverage: { type: "string" }
                }
              }
            },
            development_areas: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  current_state: { type: "string" },
                  actionable_advice: { type: "string" },
                  resources: { type: "array", items: { type: "string" } }
                }
              }
            },
            micro_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  time_required: { type: "string" },
                  impact_area: { type: "string" },
                  difficulty: { type: "string" }
                }
              }
            },
            personality_insight: { type: "string" },
            recommended_badges: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  badge_name: { type: "string" },
                  why_pursue: { type: "string" },
                  steps_to_earn: { type: "array", items: { type: "string" } }
                }
              }
            },
            motivational_message: { type: "string" }
          }
        }
      });

      setFeedback(result);
      setLastUpdated(new Date());
    } catch (error) {
      console.error("Error generating feedback:", error);
    }
    setIsAnalyzing(false);
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty?.toLowerCase()) {
      case 'easy': return 'bg-emerald-500/20 text-emerald-400';
      case 'medium': return 'bg-amber-500/20 text-amber-400';
      case 'hard': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  if (isAnalyzing && !feedback) {
    return (
      <Card className="border border-white/10 bg-white/5">
        <CardContent className="py-12 text-center">
          <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-4 animate-spin" />
          <p className="text-white font-medium">Analyzing your performance data...</p>
          <p className="text-sm text-gray-400">Creating personalized feedback</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-2 border-blue-500/30 bg-gradient-to-r from-blue-500/10 to-indigo-500/10">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center">
                <Brain className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">AI Performance Coach</h3>
                <p className="text-sm text-gray-400">
                  {lastUpdated ? `Updated ${lastUpdated.toLocaleDateString()}` : 'Personalized feedback based on your data'}
                </p>
              </div>
            </div>
            <Button 
              onClick={generatePerformanceFeedback}
              disabled={isAnalyzing}
              variant="outline"
              className="border-white/20 text-gray-300 hover:bg-white/10"
            >
              {isAnalyzing ? (
                <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Refreshing...</>
              ) : (
                <><RefreshCw className="w-4 h-4 mr-2" /> Refresh Feedback</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {feedback && (
        <>
          {/* Overall Assessment */}
          <Card className="border border-white/10 bg-white/5">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{feedback.performance_score || 75}</span>
                </div>
                <div className="flex-1">
                  <h4 className="text-white font-medium mb-1">Your Performance Summary</h4>
                  <p className="text-gray-300 text-sm">{feedback.overall_assessment}</p>
                  <p className="text-sm text-purple-400 mt-3 italic">"{feedback.personality_insight}"</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Strengths & Development Areas */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Strengths */}
            <Card className="border border-emerald-500/20 bg-emerald-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-emerald-400">
                  <TrendingUp className="w-5 h-5" />
                  Key Strengths
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {feedback.key_strengths?.map((strength, i) => (
                  <div key={i} className="p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Star className="w-4 h-4 text-amber-400" />
                      <h5 className="text-white font-medium text-sm">{strength.strength}</h5>
                    </div>
                    <p className="text-xs text-gray-400 mb-2">{strength.evidence}</p>
                    <div className="p-2 bg-emerald-500/10 rounded">
                      <p className="text-xs text-emerald-400">
                        <Lightbulb className="w-3 h-3 inline mr-1" />
                        {strength.how_to_leverage}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Development Areas */}
            <Card className="border border-amber-500/20 bg-amber-500/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-400">
                  <Target className="w-5 h-5" />
                  Growth Opportunities
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {feedback.development_areas?.map((area, i) => (
                  <div key={i} className="p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <AlertCircle className="w-4 h-4 text-amber-400" />
                      <h5 className="text-white font-medium text-sm">{area.area}</h5>
                    </div>
                    <p className="text-xs text-gray-400 mb-2">{area.current_state}</p>
                    <div className="p-2 bg-amber-500/10 rounded mb-2">
                      <p className="text-xs text-amber-400">
                        <ArrowRight className="w-3 h-3 inline mr-1" />
                        {area.actionable_advice}
                      </p>
                    </div>
                    {area.resources?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {area.resources.slice(0, 2).map((res, j) => (
                          <span key={j} className="text-[10px] px-1.5 py-0.5 bg-white/10 text-gray-400 rounded">{res}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Micro-Actions */}
          <Card className="border border-purple-500/20 bg-purple-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Zap className="w-5 h-5" />
                This Week's Micro-Actions
              </CardTitle>
              <CardDescription className="text-gray-400">
                Small steps that make a big difference
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {feedback.micro_actions?.map((action, i) => (
                  <div key={i} className="p-3 bg-white/5 rounded-lg border border-white/10 hover:border-purple-500/30 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <CheckCircle2 className="w-4 h-4 text-purple-400 mt-0.5" />
                      <Badge className={`text-[10px] ${getDifficultyColor(action.difficulty)}`}>
                        {action.difficulty}
                      </Badge>
                    </div>
                    <p className="text-sm text-white mb-2">{action.action}</p>
                    <div className="flex items-center justify-between text-[10px] text-gray-500">
                      <span>⏱ {action.time_required}</span>
                      <span>📈 {action.impact_area}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommended Badges */}
          {feedback.recommended_badges?.length > 0 && (
            <Card className="border border-amber-500/20 bg-gradient-to-r from-amber-500/10 to-orange-500/10">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-400">
                  <Award className="w-5 h-5" />
                  Badges to Pursue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  {feedback.recommended_badges.map((badge, i) => (
                    <div key={i} className="p-4 bg-white/5 rounded-xl text-center">
                      <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                        <Award className="w-6 h-6 text-white" />
                      </div>
                      <h4 className="text-white font-medium text-sm mb-1">{badge.badge_name}</h4>
                      <p className="text-xs text-gray-400 mb-2">{badge.why_pursue}</p>
                      <div className="text-left">
                        <p className="text-[10px] text-gray-500 uppercase mb-1">Steps to earn:</p>
                        <ul className="space-y-0.5">
                          {badge.steps_to_earn?.slice(0, 3).map((step, j) => (
                            <li key={j} className="text-[10px] text-gray-400 flex items-start gap-1">
                              <span className="text-amber-400">•</span> {step}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Motivational Message */}
          {feedback.motivational_message && (
            <div className="p-4 bg-gradient-to-r from-purple-500/20 to-indigo-500/20 rounded-xl border border-purple-500/30 text-center">
              <p className="text-purple-300 italic">"{feedback.motivational_message}"</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}