import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Sparkles, Route, Trophy, Star, Clock, Target, BookOpen, 
  CheckCircle2, Play, Award, Flame, Zap, ArrowRight
} from "lucide-react";

export default function LearningJourneyGenerator({ user, userSkills, assessment, roleRequirements, existingJourneys }) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [generatedJourney, setGeneratedJourney] = useState(null);
  const [config, setConfig] = useState({
    targetRole: '',
    timeCommitment: '5-10 hours/week',
    focusArea: 'balanced',
    difficulty: 'intermediate'
  });

  const createJourneyMutation = useMutation({
    mutationFn: (data) => base44.entities.LearningJourney.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['learningJourneys'] });
    }
  });

  const availableRoles = [...new Set(roleRequirements?.map(r => r.role_title) || [])];

  // Calculate skill gaps
  const calculateSkillGaps = () => {
    if (!userSkills || !roleRequirements) return [];
    
    const userSkillMap = userSkills.reduce((acc, s) => {
      acc[s.skill_name] = s.current_proficiency;
      return acc;
    }, {});

    const targetReqs = config.targetRole 
      ? roleRequirements.filter(r => r.role_title === config.targetRole)
      : roleRequirements.slice(0, 10);

    const profOrder = ['None', 'Beginner', 'Intermediate', 'Advanced', 'Expert'];
    
    return targetReqs.filter(req => {
      const current = profOrder.indexOf(userSkillMap[req.skill_name] || 'None');
      const required = profOrder.indexOf(req.required_proficiency);
      return current < required;
    }).map(req => ({
      skill: req.skill_name,
      current: userSkillMap[req.skill_name] || 'None',
      required: req.required_proficiency,
      priority: req.priority,
      gap: profOrder.indexOf(req.required_proficiency) - profOrder.indexOf(userSkillMap[req.skill_name] || 'None')
    }));
  };

  const generateJourney = async () => {
    setIsGenerating(true);
    try {
      const skillGaps = calculateSkillGaps();
      
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert learning experience designer. Create a personalized Learning Journey for this employee.

EMPLOYEE PROFILE:
- Name: ${user?.full_name}
- Current Role: ${user?.job_title || 'Not specified'}
- Personality Type: ${assessment?.myers_briggs?.type || 'Unknown'}
- Top Strengths: ${assessment?.strengths?.top_strengths?.slice(0, 5).map(s => s.name).join(', ') || 'Not assessed'}
- Learning Style: Based on personality, prefer ${assessment?.myers_briggs?.type?.includes('N') ? 'conceptual/theoretical' : 'practical/hands-on'} learning

TARGET & PREFERENCES:
- Target Role: ${config.targetRole || 'General career growth'}
- Time Commitment: ${config.timeCommitment}
- Focus: ${config.focusArea}
- Difficulty: ${config.difficulty}

SKILL GAPS TO ADDRESS:
${skillGaps.slice(0, 8).map(g => `- ${g.skill}: ${g.current} → ${g.required} (${g.priority})`).join('\n') || 'General skill development'}

Create a structured Learning Journey with:
1. A compelling title and description
2. 4-6 sequential modules, each with:
   - Learning content (courses, articles, videos)
   - Practical exercise with deliverable
   - Assessment criteria
3. 2-3 milestone achievements with badges
4. A completion badge with bonus points
5. Realistic time estimates

Make it engaging, progressive, and achievement-oriented.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" },
            skill_focus: { type: "array", items: { type: "string" } },
            estimated_duration: { type: "string" },
            modules: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  module_id: { type: "string" },
                  title: { type: "string" },
                  type: { type: "string" },
                  description: { type: "string" },
                  duration: { type: "string" },
                  resources: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        type: { type: "string" },
                        provider: { type: "string" }
                      }
                    }
                  },
                  exercise: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      deliverable: { type: "string" }
                    }
                  },
                  assessment_criteria: { type: "array", items: { type: "string" } },
                  points: { type: "number" }
                }
              }
            },
            milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  module_index: { type: "number" },
                  badge_name: { type: "string" },
                  points: { type: "number" }
                }
              }
            },
            completion_badge: {
              type: "object",
              properties: {
                name: { type: "string" },
                description: { type: "string" },
                points: { type: "number" }
              }
            },
            total_points: { type: "number" }
          }
        }
      });

      setGeneratedJourney({
        ...result,
        user_email: user?.email,
        target_role: config.targetRole,
        difficulty_level: config.difficulty,
        status: 'not_started',
        progress_percentage: 0,
        earned_points: 0,
        ai_generated: true,
        personalization_factors: {
          learning_style: assessment?.myers_briggs?.type,
          time_commitment: config.timeCommitment,
          skill_gaps_addressed: skillGaps.slice(0, 5).map(g => g.skill)
        },
        modules: result.modules.map(m => ({ ...m, completed: false })),
        milestones: result.milestones.map(m => ({ ...m, achieved: false }))
      });
      
      setShowConfig(false);
    } catch (error) {
      console.error("Error generating journey:", error);
    }
    setIsGenerating(false);
  };

  const startJourney = async () => {
    if (!generatedJourney) return;
    
    await createJourneyMutation.mutateAsync({
      ...generatedJourney,
      started_date: new Date().toISOString(),
      status: 'in_progress'
    });
    
    setGeneratedJourney(null);
  };

  return (
    <div className="space-y-6">
      {/* Generate Journey CTA */}
      <Card className="border-2 border-purple-500/30 bg-gradient-to-r from-purple-500/10 to-indigo-500/10">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center">
                <Route className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">AI Learning Journey Creator</h3>
                <p className="text-sm text-gray-400">
                  Get a personalized learning path curated just for you
                </p>
              </div>
            </div>
            <Dialog open={showConfig} onOpenChange={setShowConfig}>
              <DialogTrigger asChild>
                <Button className="bg-purple-500 text-white hover:bg-purple-400">
                  <Sparkles className="w-4 h-4 mr-2" /> Create Journey
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-950 border-white/10 text-white">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Route className="w-5 h-5 text-purple-400" />
                    Configure Your Learning Journey
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label className="text-gray-300">Target Role (Optional)</Label>
                    <Select value={config.targetRole} onValueChange={(v) => setConfig({...config, targetRole: v})}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue placeholder="Select target role" />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        <SelectItem value={null} className="text-white">General Growth</SelectItem>
                        {availableRoles.map(role => (
                          <SelectItem key={role} value={role} className="text-white">{role}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-gray-300">Weekly Time Commitment</Label>
                    <Select value={config.timeCommitment} onValueChange={(v) => setConfig({...config, timeCommitment: v})}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        <SelectItem value="2-5 hours/week" className="text-white">Light (2-5 hrs/week)</SelectItem>
                        <SelectItem value="5-10 hours/week" className="text-white">Moderate (5-10 hrs/week)</SelectItem>
                        <SelectItem value="10-15 hours/week" className="text-white">Intensive (10-15 hrs/week)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-gray-300">Focus Area</Label>
                    <Select value={config.focusArea} onValueChange={(v) => setConfig({...config, focusArea: v})}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        <SelectItem value="balanced" className="text-white">Balanced Learning</SelectItem>
                        <SelectItem value="technical" className="text-white">Technical Skills</SelectItem>
                        <SelectItem value="leadership" className="text-white">Leadership & Soft Skills</SelectItem>
                        <SelectItem value="practical" className="text-white">Hands-on Projects</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-gray-300">Difficulty Level</Label>
                    <Select value={config.difficulty} onValueChange={(v) => setConfig({...config, difficulty: v})}>
                      <SelectTrigger className="bg-black border-white/10 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/10">
                        <SelectItem value="beginner" className="text-white">Beginner</SelectItem>
                        <SelectItem value="intermediate" className="text-white">Intermediate</SelectItem>
                        <SelectItem value="advanced" className="text-white">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={generateJourney}
                    disabled={isGenerating}
                    className="w-full bg-purple-500 hover:bg-purple-400"
                  >
                    {isGenerating ? (
                      <><Sparkles className="w-4 h-4 mr-2 animate-spin" /> Creating Your Journey...</>
                    ) : (
                      <><Sparkles className="w-4 h-4 mr-2" /> Generate Learning Journey</>
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Generated Journey Preview */}
      {generatedJourney && (
        <Card className="border-2 border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 to-teal-500/10">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <Badge className="mb-2 bg-emerald-500/20 text-emerald-400 border-none">
                  <Sparkles className="w-3 h-3 mr-1" /> AI Generated
                </Badge>
                <CardTitle className="text-white text-xl">{generatedJourney.title}</CardTitle>
                <CardDescription className="text-gray-400 mt-1">
                  {generatedJourney.description}
                </CardDescription>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-amber-400">{generatedJourney.total_points}</div>
                <p className="text-xs text-gray-500">Total Points</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Journey Stats */}
            <div className="grid grid-cols-4 gap-3">
              <div className="p-3 bg-white/5 rounded-lg text-center">
                <Clock className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                <p className="text-sm text-white">{generatedJourney.estimated_duration}</p>
                <p className="text-[10px] text-gray-500">Duration</p>
              </div>
              <div className="p-3 bg-white/5 rounded-lg text-center">
                <BookOpen className="w-5 h-5 text-purple-400 mx-auto mb-1" />
                <p className="text-sm text-white">{generatedJourney.modules?.length || 0}</p>
                <p className="text-[10px] text-gray-500">Modules</p>
              </div>
              <div className="p-3 bg-white/5 rounded-lg text-center">
                <Trophy className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                <p className="text-sm text-white">{generatedJourney.milestones?.length || 0}</p>
                <p className="text-[10px] text-gray-500">Milestones</p>
              </div>
              <div className="p-3 bg-white/5 rounded-lg text-center">
                <Target className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                <p className="text-sm text-white">{generatedJourney.skill_focus?.length || 0}</p>
                <p className="text-[10px] text-gray-500">Skills</p>
              </div>
            </div>

            {/* Skills Focus */}
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-widest mb-2">Skills You'll Develop</p>
              <div className="flex flex-wrap gap-2">
                {generatedJourney.skill_focus?.map((skill, i) => (
                  <Badge key={i} className="bg-purple-500/20 text-purple-400 border-none">{skill}</Badge>
                ))}
              </div>
            </div>

            {/* Module Preview */}
            <div>
              <p className="text-xs text-gray-500 uppercase tracking-widest mb-3">Learning Modules</p>
              <div className="space-y-2">
                {generatedJourney.modules?.map((module, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 text-sm font-bold">
                      {i + 1}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-white">{module.title}</p>
                      <p className="text-xs text-gray-500">{module.duration} • {module.resources?.length || 0} resources</p>
                    </div>
                    <Badge variant="outline" className="text-xs border-white/20 text-gray-400">
                      +{module.points || 50} pts
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Completion Badge Preview */}
            {generatedJourney.completion_badge && (
              <div className="p-4 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-amber-400 uppercase tracking-widest">Completion Badge</p>
                    <h4 className="text-lg font-medium text-white">{generatedJourney.completion_badge.name}</h4>
                    <p className="text-sm text-gray-400">{generatedJourney.completion_badge.description}</p>
                    <Badge className="mt-1 bg-amber-500 text-black">
                      +{generatedJourney.completion_badge.points} bonus points
                    </Badge>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                onClick={startJourney}
                className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-white"
              >
                <Play className="w-4 h-4 mr-2" /> Start This Journey
              </Button>
              <Button
                onClick={() => setGeneratedJourney(null)}
                variant="outline"
                className="border-white/20 text-gray-400 hover:bg-white/5"
              >
                Generate Another
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active Journeys */}
      {existingJourneys?.filter(j => j.status === 'in_progress').length > 0 && (
        <div>
          <h3 className="text-white font-medium mb-3">Your Active Journeys</h3>
          <div className="space-y-3">
            {existingJourneys.filter(j => j.status === 'in_progress').map((journey, i) => (
              <Card key={i} className="border border-white/10 bg-white/5">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="text-white font-medium">{journey.title}</h4>
                      <p className="text-xs text-gray-500">{journey.estimated_duration}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-amber-400">{journey.earned_points || 0}</p>
                      <p className="text-[10px] text-gray-500">of {journey.total_points} pts</p>
                    </div>
                  </div>
                  <Progress value={journey.progress_percentage || 0} className="h-2 mb-2" />
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">{journey.progress_percentage || 0}% complete</span>
                    <Button size="sm" variant="outline" className="border-purple-500/30 text-purple-400">
                      Continue <ArrowRight className="w-3 h-3 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}